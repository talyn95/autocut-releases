# AutoCut against the best: feature by feature

Built from each product's **public** feature lists and reviews (October 2026). Nothing here copies their code;
it lists what each one does so AutoCut can match or beat it. ✅ = AutoCut has it. 🆕 = added in 0.16. ⏭ = next.

AutoCut's edge across all five: it runs **on your own computer** (no per-seat or per-credit pricing, footage
never uploaded, the free local AI by default), it is **brand-aware everywhere** (every caption, graphic and
design uses the client's colours, fonts and logo), and it outputs **editable Premiere timelines and HyperFrames
projects**, not just flattened exports.

**Marketing brain (0.17):** every AI feature reads AutoCut's video-marketing knowledge base (`autocut/knowledge/`), and the
**Strategist** panel gives each client an AI head of content (hooks, scripts, plans, ad angles, copy reviews).

## 1. Short form editing (vs Descript, CapCut)

| Their feature | AutoCut |
|---|---|
| Text-based editing (edit the transcript, the video follows) | ✅ Transcript editor: click words to cut/restore, fix caption typos, re-cut |
| Remove filler words, shorten word gaps | ✅ Fillers, stutters, pauses over `max_pause` |
| Remove retakes (Descript) | 🆕 Whole-sentence retakes, even reworded; keeps the last take (`remove_retakes`) |
| Studio Sound (Descript) | 🆕 Studio Sound: noise/hum reduction, de-ess, presence EQ, compression, limiter |
| Animated captions with styles, keyword highlight | ✅ pop, karaoke, punch, clean, highlight; brand fonts/colours |
| Auto B-roll, stickers, effects, transitions | ✅ Client B-roll + stock, story cutaways, pop-up icons, light leaks, punch-ins |
| Green screen / subject cutout | ✅ Hook text behind the speaker, pop-out moments |
| Effect-every-sentence edits (creator "17 effects" style) | 🆕 Effects edit: 17 effects (paper cut-out, magazine cover, screen wall, pixel zoom, sketch boil, graph rise, glass text, orbit spin, pull-out reveal, phone frame, dolly zoom, news wall, frame pop, punch-through, green screen, interface world, tick list), picked per sentence by AI + rules |
| Multi-format (9:16, 1:1, 16:9) | ✅ |
| Eye contact, regenerate speech (AI voice), translate/dub | ⏭ Needs heavy AI models; candidates for a later release |

## 2. Motion graphics (vs HyperFrames/After Effects templates)

| Their feature | AutoCut |
|---|---|
| HTML/GSAP compositions rendered frame-accurately | ✅ Built on HyperFrames itself (Apache 2.0) |
| Studio editor (timeline, properties, live preview) | ✅ Edit in Studio + Re-render |
| Prompt to animation | ✅ 8 brand templates from a prompt; `custom:` has the AI write a whole composition, with a repair round |
| Transparent ProRes for editors | ✅ ProRes 4444 alpha, WebM alpha, MP4, GIF |
| Reference-matching (look and pacing) | ✅ Drop a reference image/video |
| Transcript → kinetic typography video (Katana, Jitter) | 🆕 0.18: script/SRT/recording → synced kinetic type, counters, steps, your graphics, end card |
| Your photos and clips inside animated layouts, read by AI (Canva/CapCut templates with media slots) | 🆕 0.27: drop media → AI reads subject/text/typography/colours → framed, full-screen, split, phone, fanned prints; clips play in the layout; storyboards place them; Graphics → Motion; match its colours and fonts |
| Explainer-style short-form edit (speaker panel + explaining graphics, the creator-ad look) | 🆕 0.26: raw take → rough cut, head pop-out panel, word-group captions, build cards, price stickers, strike + FREE badge, step tracker, name card |
| Your own fonts, logos and graphics | 🆕 0.18: upload TTF/OTF/WOFF, a logo and images; used by every engine |
| ~450-block registry (transitions, charts, maps, 3D) | 🆕 0.19: searchable in the Look book; custom designs start from the closest blocks |
| Stock music and SFX libraries (Epidemic Sound, Artlist, CapCut's sounds) | 🆕 0.20: original music composed per video in each client's sound (10 styles, stems), synthesized effects placed on the edit; A1 dialogue / A2 effects / A3 music in the XML |
| Template marketplaces (Envato, Motion Array): thousands of packs | 🆕 0.19: 18 looks × 41 layouts × 12 storyboards, and per-client style DNA so clients never share a look |
| AI reviews its own frames before delivering | ⏭ Snapshot → AI critique → fix loop |

## 3. Podcast clipping (vs Opus Clip)

| Their feature | AutoCut |
|---|---|
| AI picks the best moments with a virality score | ✅ Measured score (hook, payoff, energy, length) blended with the AI's 0–100 review |
| Prompt-to-clip / topic search (ClipAnything) | 🆕 "Find clips about…": on-topic moments rise in both the rules and the AI review |
| Hook titles and alternatives | ✅ Title + three hook options, one click to use |
| Auto-reframe, active speaker tracking | ✅ Follow (tracked), jump between speakers, split, PiP, fit |
| Animated captions, B-roll inside clips | ✅ Clips run through the full short form pipeline (captions, B-roll, graphics, Studio Sound) |
| Post copy (captions, hashtags) | ✅ Titles, captions, hashtags, YouTube title/description, LinkedIn/Facebook posts |
| Schedule and publish | ⏭ Through your Metricool connection |
| Visual-only moments (no speech) | ⏭ Multimodal moment finding |

## 4. Multicam (vs AutoPod, Premiere auto-multicam)

| Their feature | AutoCut |
|---|---|
| Audio sync of cameras and recorders | ✅ |
| Auto-switch on who's talking, up to many cameras/mics | ✅ |
| Wide shots, with a frequency control | 🆕 Wide shots: less often / normal / more often |
| Minimum shot length; cutaways in long monologues | ✅ Shortest shot, `max_shot` cutaways |
| Map each mic to its camera | 🆕 Editable "Voice from" for every person (file, or a single recorder channel) |
| Screen recordings as picture-in-picture | ✅ |
| Jump-cut editor / silence removal | ✅ Optional cut ums and long pauses |
| Clean dialogue | 🆕 Studio Sound on every mic |
| Premiere timeline out | ✅ FCP7 XML + one-pass MP4 export |

## 5. Marketing graphics (vs Canva)

| Their feature | AutoCut |
|---|---|
| Brand kit applied automatically | 🆕 Every design in the client's colours, fonts and logo |
| Magic Design (prompt → designs) | 🆕 The AI writes the copy in the client's voice and picks the layout ("Write it for me") |
| Magic Resize | 🆕 One design → post, feed 4:5, story, YouTube thumbnail, link ad |
| Several looks to choose from | 🆕 Bold, clean and dark for each |
| Bulk create from a spreadsheet | 🆕 CSV → one design per row (up to 100) |
| Templates: quotes, stats, ads, testimonials, events, tips, carousels, thumbnails | 🆕 All eight, carousels as PNGs + one PDF |
| Background remover / subject cutout | 🆕 YouTube thumbnails cut the person out of a photo or a video frame |
| Editable afterwards | 🆕 Edit in Studio + Re-render; or `custom:` for a fully AI-designed graphic |
| AI image generation | ✅ Optional on Macs (FLUX via mflux) |
| Your images in, marketable graphics out (ChatGPT/Canva style) | 🆕 0.17: photos, products (auto cut-out), logos, look references; Product spotlight and Photo + headline designs; the AI reads the images |
| Huge stock template library | ⏭ More layouts per design type |

## 6. Keeping up (vs SaaS tools that update themselves)

| Their feature | AutoCut |
|---|---|
| Updates without reinstalling | 🆕 0.21: one-click signed updates from the agency's feed, tested on each computer first, with roll back |
| New templates every month | 🆕 Content packs: new looks, storyboards, music styles and sound flavours without a new version |
| "Now with the latest AI model" | 🆕 Model catalog: "auto" settings follow new free and Claude models; any OpenAI-compatible local server |
| What's new screen | 🆕 After every update |
| Beta program | 🆕 Stable and beta channels per computer |
| Bring your own AI (ChatGPT/Claude/Grok) | 🆕 0.23: connect your own accounts with monthly caps; AI images on any computer |
| Works inside your AI assistant | 🆕 0.23: AutoCut as an MCP connector in Claude Desktop, Claude Code, Cursor |
| After Effects keyframe easing (Easy Ease, overshoot, glow/shadow layers) | 🆕 0.24: seven motion feels on every graphic |
