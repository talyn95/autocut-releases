"""Settings and per-client brand profiles."""
from __future__ import annotations

import copy
import os
import re
import socket
import sys
from dataclasses import dataclass
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent          # the code (git repo)
TEMPLATE_DIR = ROOT / "templates" / "client"
EXAMPLES_DIR = ROOT / "examples"
IS_WINDOWS = sys.platform == "win32"
# Where this computer keeps clients, footage and finished work: /Users/Shared/AutoCut on a Mac,
# C:\Users\Public\AutoCut on Windows. Every computer is independent; nothing is shared unless you set it up.
SHARED_ROOT = (Path(os.environ.get("PUBLIC", r"C:\Users\Public")) / "AutoCut") if IS_WINDOWS \
    else Path("/Users/Shared/AutoCut")
# Per-machine settings live outside the repo so updates never overwrite them.
LOCAL_SETTINGS = Path(os.environ.get("AUTOCUT_SETTINGS") or (
    Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming")) / "AutoCut" / "settings.yaml" if IS_WINDOWS
    else Path.home() / "Library" / "Application Support" / "AutoCut" / "settings.yaml"))

FORMATS = {
    "vertical": (1080, 1920),
    "landscape": (1920, 1080),
    "square": (1080, 1080),
    "portrait": (1080, 1350),
}

DEFAULT_SETTINGS = {
    "machine_name": "",          # shown on jobs; defaults to the Mac's name
    "clients_dir": str(SHARED_ROOT / "clients"),
    "share_url": "",             # e.g. smb://mac-studio.local/AutoCut — mounted at launch if set
    "process_jobs": True,        # False = dashboard only, this Mac never renders
    "preview": True,             # render an MP4 preview with every job
    "port": 8765,
    "listen_on_network": False,  # True = other office Macs can open this dashboard
    "extra_path": [] if IS_WINDOWS else ["/opt/homebrew/bin", "/usr/local/bin"],
    "minutes_saved_per_footage_minute": 4,
    "motion_blur_samples": 4,
    "agency_credit": "Made by Triumphant Media",
    "local_llm": {               # (older setting; see ai: below)
        "url": "http://127.0.0.1:11434",
        "model": "llama3.2",
    },
    "web": {                     # web-hosted AutoCut (see deploy/HOSTING.md)
        "require_login": False,  # true = every page needs a signed-in user (always on when hosted)
        "trust_proxy": False,    # true behind Caddy / Cloudflare Tunnel: use X-Forwarded-For/-Proto
        "public_url": "",        # e.g. https://autocut.example.com (enables secure cookies)
        "session_hours": 12,
        "max_upload_gb": 60,
    },
    "hyperframes": {             # Motion graphic generator engine: HTML + GSAP rendered by HyperFrames (mograph/hyper.py)
        "enabled": True,         # used when its runtime is set up (autocut hyperframes-setup); false = classic engine only
        "runtime_dir": "",       # blank = hyperframes-runtime next to the clients folder
    },
    "ai": {                      # the marketing brain: free local AI first, Claude only as backup
        "local_url": "http://127.0.0.1:11434",  # Ollama on this Mac (the installer sets it up)
        "local_model": "auto",   # auto = the biggest free model this Mac's memory runs well (gemma3)
        "claude_backup": True,   # use Claude when the local model can't answer (needs an API key below)
        "claude_api_key": "",    # or set the ANTHROPIC_API_KEY environment variable; blank = never use Claude
        "claude_model": "auto",  # auto = the current default in content/catalog.json (moves with updates)
        "claude_monthly_limit_usd": 25,  # Claude stops being used for the rest of the month past this
        "post_copy": True,       # write titles, captions and hashtags for every finished video
        "openai_url": "",        # optional: an OpenAI-compatible server (LM Studio http://127.0.0.1:1234/v1, vLLM, llama.cpp)
        "openai_model": "",      # blank = the first model that server lists
        "openai_api_key": "",    # only if that server wants one
    },
    "updates": {                 # signed one-click updates (updates.py, docs/RELEASING.md)
        # the agency's signed update feed (tools/release.py publish-git); blank = updates come as a new zip (or git)
        "feed_url": "https://raw.githubusercontent.com/talyn95/autocut-releases/main/feed.json",
        "channel": "stable",     # stable | beta
        "check": True,           # look for an update when AutoCut starts (and daily) and show a banner
        "keep_versions": 3,      # older versions kept for "Roll back"
    },
    "features": {},              # experiment switches (content/catalog.json `features`): name: true / false
    "stock": {                   # free stock B-roll API keys (https://www.pexels.com/api/ · https://pixabay.com/api/docs/)
        "pexels_api_key": "",
        "pixabay_api_key": "",
    },  # the "Agency credit" switch puts this bottom-right in videos    # motion-graphics quality: 4 = smooth AE-style blur, 2 = faster, 1 = off  # for the "time saved" estimate on the dashboard
    "motion_studio_path": "" if IS_WINDOWS else str(SHARED_ROOT / "motion-studio"),  # Kinetik Motion Studio (optional)
    "whisper": {
        "backend": "auto",      # auto | mlx | faster-whisper
        "model": "auto",        # auto = what this computer runs well (hardware.py); or small / medium / large-v3 / large-v3-turbo
        "language": "en",
    },
    "video_extensions": [".mp4", ".mov", ".m4v", ".mkv", ".mxf"],
}

DEFAULT_BRAND = {
    "client": "Unnamed Client",
    "website": "",  # the client's site (brand kit from a website fills it in; end cards and copy can use it)
    "format": "vertical",
    "fps": None,  # None = match footage
    "vocabulary": [],  # names/places/products the speech model should spell correctly
    "colors": {
        "primary": "#F2A900",
        "secondary": "#111111",
        "text": "#FFFFFF",
        "outline": "#000000",
    },
    "fonts": {
        "caption": "Montserrat",
        "headline": "Montserrat",
        "folder": "assets/fonts",
    },
    "captions": {
        "enabled": True,
        "style": "pop",          # pop | highlight | karaoke | punch | clean
        "words_per_line": 3,
        "max_line_seconds": 2.2,
        "position": "lower",     # lower | middle | upper
        "size": 86,
        "bold": True,
        "uppercase": True,
        "outline_width": 6,
        "shadow": 2,
        "highlight_numbers": True,
        "highlight_words": [],
    },
    "edit": {
        "remove_fillers": True,
        "filler_words": ["um", "umm", "uh", "uhh", "uhm", "erm", "er", "ah", "ahh", "hmm", "mm", "mhm"],
        "remove_stutters": True,
        "remove_restarts": True,  # false starts: "we do a — we do a free inspection"
        "remove_retakes": True,   # a whole line said again: keep the last take
        "max_pause": 0.30,       # longest silence kept between words (seconds)
        "pad": 0.08,             # breathing room kept around each cut
        "head_pad": 0.15,
        "tail_pad": 0.35,
    },
    "cta": {
        "enabled": True,
        "text": "",
        "subtext": "",
        "duration": 3.0,
        "end_card": "",          # optional pre-made end card video
    },
    "logo": {
        "file": "",
        "watermark": True,
        "position": "top-right", # top-left | top-right | bottom-left | bottom-right
        "width_pct": 16,
        "opacity": 0.85,
    },
    "broll": {
        "enabled": True,
        "folder": "assets/broll",
        "every_seconds": 7,
        "clip_seconds": 2.5,
        "skip_first_seconds": 3,
        "stock": True,           # fill gaps with free Pexels/Pixabay clips (needs API keys in settings)
        "stock_per_video": 3,
    },
    "audio": {
        "normalize": True,       # level the dialogue to a consistent loudness
        "target_lufs": -14,      # -14 suits Instagram/TikTok/YouTube
    },
    "music": {
        "source": "auto",        # auto = the client's own track if set, else original music AutoCut composes | file | composed | none
        "file": "",
        "level_db": -20,         # the client's own track, under the dialogue
        "ai_level_db": -17,      # composed music (made at -14 LUFS) under the dialogue
        "style": "",             # force a style (corporate, lofi, cinematic, pop, hiphop, acoustic, tech, luxury, sport, playful)
        "energy": "",            # low | medium | high (blank: the music director decides per video)
    },
    "sound": {                   # sound design (switch: effects.sound_design)
        "density": "normal",     # light | normal | rich
        "level_db": 0,           # louder/quieter effects overall
        "flavour": "",           # blank: from the client's motion look (clean, hard, digital, airy, soft, cinematic, paper, bubbly)
        "notes": "",             # plain-English direction for the AI sound designer, e.g. "dark and punchy, a riser before the offer"
    },
    # On/off switches for every creative layer. The dashboard edits this block;
    # each upload or re-run can override it.
    "effects": {
        "captions": True,
        "media": True,
        "broll": True,
        "motion_graphics": True,
        "punch_ins": True,
        "graphic_cards": True,
        "lower_third": False,
        "story": True,
        "popups": False,
        "overlays": False,
        "subject_cutout": False,
        "studio_sound": True,
        "sound_design": True,
        "music": True,
        "cover": True,
        "credit": False,
    },
    "marketing": {               # the client's marketing brief: the AI writes and picks clips with this in mind
        "industry": "",
        "audience": "",          # who they're trying to reach
        "offer": "",             # what they sell / the main offer
        "voice": "",             # e.g. friendly and plain-spoken, expert but not stuffy
        "location": "",          # market or service area, if local
        "goals": "",             # e.g. booked inspections, followers, newsletter sign-ups
        "platforms": ["TikTok", "Instagram Reels", "YouTube Shorts"],
        "hashtags": [],          # always included, e.g. ["#AcmeRoofing"]
        "avoid": [],             # words or claims never to use
    },
    "media": {
        "seconds": 3.0,          # how long each screenshot/photo/graphic stays up
        "max_per_minute": 6,
    },
    "graphics": {
        "style": "pro",          # pro = AutoCut Motion (eased, motion-blurred) | classic = simple flat graphics
    },
    "motion": {                  # the built-in motion pack (switch: effects.motion_graphics)
        "hook_title": True,      # animated title at the start (skipped when the cutout hook is used)
        "slams": 2,              # keyword "slams" on highlight words
        "slam_every_seconds": 8,
        "swipes": 2,             # brand swipe transitions over cuts
        "swipe_every_seconds": 8,
        "cta_outro": True,       # animated CTA end card (unless the client has their own end card)
    },
    "punch_ins": {
        "zoom": 1.15,            # tight shot scale vs. wide
        "pattern": "alternate",  # alternate | keywords (tight only on highlight words' segments)
    },
    "cards": {
        "numbers": True,         # "$3,000", "20 minutes", "5 stars", "50%"
        "phrases": [],           # extra phrases that get a card when spoken
        "seconds": 2.2,
        "max_per_minute": 4,
        "position": "chest",     # chest (below the face) | top (above the head)
    },
    "lower_third": {
        "name": "",
        "title": "",
        "start": 1.0,
        "seconds": 4.0,
    },
    "story": {
        "max_per_minute": 1.5,   # how often a storyboard cutaway can appear
        "min_gap_seconds": 15,   # at least this long between two of them
        "max_beats": 4,          # pictures per storyboard (2–4)
        "max_seconds": 7,        # longest cutaway
        "speaker_pip": True,     # keep the speaker on screen in a framed picture-in-picture
    },
    "popups": {
        "folder": "assets/stickers",  # client stickers, named by keyword: money.png, roof.png
        "builtin": True,              # AutoCut's starter set (check, star, dollar, clock…)
        "icon_library": True,         # + 2,100 Lucide icons as brand-colour badges (house, banknote, mic…)
        "seconds": 1.4,
        "max_per_minute": 6,
        "size_pct": 24,
    },
    "overlays": {
        "vignette": True,
        "grain": True,
        "light_leaks": True,
        "leak_every_seconds": 12,
        "folder": "assets/overlays",  # client's own overlay clips (alpha .mov) used for leaks
    },
    "cutout": {
        "engine": "auto",        # auto | vision (Apple, Mac only) | onnx
        "hook": True,            # hook text BEHIND the speaker for the first seconds
        "hook_seconds": 2.6,
        "pops": 2,               # moments the speaker pops out over a brand-colour background
        "pop_seconds": 1.6,
    },
    "motion_studio": {
        "enabled": False,
        "brand_json": "motion/brand.json",
        "pieces": [],
    },
}


def deep_merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def _read_yaml(path: Path) -> dict:
    return (yaml.safe_load(path.read_text()) or {}) if path.exists() else {}


def load_settings() -> dict:
    """Defaults ← repo settings.yaml (shared) ← this Mac's settings.yaml."""
    s = deep_merge(DEFAULT_SETTINGS, _read_yaml(ROOT / "settings.yaml"))
    s = deep_merge(s, _read_yaml(LOCAL_SETTINGS))
    s["machine_name"] = s["machine_name"] or socket.gethostname().split(".")[0]
    for extra in reversed(s["extra_path"]):  # apps launched from Finder get a bare PATH
        if extra not in os.environ.get("PATH", "").split(os.pathsep):
            os.environ["PATH"] = extra + os.pathsep + os.environ.get("PATH", "")
    return s


def clients_dir(settings: dict) -> Path:
    p = Path(settings["clients_dir"]).expanduser()
    return p if p.is_absolute() else ROOT / p


def list_clients(settings: dict) -> list[Path]:
    root = clients_dir(settings)
    if not root.is_dir():
        return []
    return [d for d in sorted(root.iterdir())
            if (d / "brand.yaml").exists() and not d.name.startswith(("_", "."))]


def slugify(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")


@dataclass
class Client:
    slug: str
    folder: Path
    brand: dict

    def path(self, rel: str) -> Path | None:
        """Resolve a brand-relative path; None when blank."""
        if not rel:
            return None
        p = Path(rel).expanduser()
        return p if p.is_absolute() else self.folder / p

    @property
    def size(self) -> tuple[int, int]:
        return FORMATS[self.brand["format"]]


def load_client(slug_or_path: str, settings: dict) -> Client:
    p = Path(slug_or_path)
    folder = p if (p / "brand.yaml").exists() else clients_dir(settings) / slug_or_path
    brand_file = folder / "brand.yaml"
    if not brand_file.exists():
        raise SystemExit(f"No brand.yaml for client '{slug_or_path}' (looked in {folder})")
    brand = deep_merge(DEFAULT_BRAND, yaml.safe_load(brand_file.read_text()) or {})
    if brand["format"] not in FORMATS:
        raise SystemExit(f"{brand_file}: format must be one of {', '.join(FORMATS)}")
    return Client(slug=folder.name, folder=folder, brand=brand)


def hex_to_rgb(color: str) -> tuple[int, int, int]:
    c = color.strip().lstrip("#")
    if len(c) == 3:
        c = "".join(ch * 2 for ch in c)
    if not re.fullmatch(r"[0-9a-fA-F]{6}", c):
        raise ValueError(f"Not a hex colour: {color!r}")
    return int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)


def brand_backdrop(brand: dict) -> tuple[str, str]:
    """Two ffmpeg colours (0xRRGGBB) for a rich brand-tinted background behind previews and
    proofs, deep enough that white text and the brand colour both read on it. Never gray."""
    try:
        r, g, b = hex_to_rgb(brand["colors"]["primary"])
    except (KeyError, ValueError):
        r, g, b = 230, 57, 70
    if max(r, g, b) - min(r, g, b) < 24:  # a gray/black/white brand colour → use a deep navy instead
        r, g, b = 32, 64, 160
    dark = tuple(int(c * 0.22) for c in (r, g, b))
    mid = tuple(int(c * 0.5) for c in (r, g, b))
    return "0x%02x%02x%02x" % dark, "0x%02x%02x%02x" % mid
