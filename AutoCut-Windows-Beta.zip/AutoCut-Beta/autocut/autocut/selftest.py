"""`autocut selftest`: a quick check that this copy of AutoCut works on this computer (about 10 seconds).

The updater runs the *new* version's self-test before switching to it (updates.py), so a release that can't import,
load its content, write a Premiere XML or make sound never replaces a working one. Add a check here when a release
adds something that could fail on someone's computer but not in the tests.
"""
from __future__ import annotations

import importlib
import json
import pkgutil
import tempfile
import time
from pathlib import Path

import autocut

OPTIONAL = {"rumps", "mlx_whisper", "faster_whisper", "anthropic", "mflux", "onnxruntime", "Vision", "Quartz",
            "AppKit", "Foundation", "objc", "skia"}


def _imports() -> str:
    bad, skipped = [], []
    for m in pkgutil.walk_packages(autocut.__path__, "autocut."):
        if m.name in ("autocut.__main__", "autocut.macapp"):
            continue
        try:
            importlib.import_module(m.name)
        except ModuleNotFoundError as e:
            if (e.name or "").split(".")[0] in OPTIONAL:
                skipped.append(f"{m.name} (needs {e.name})")
            else:
                bad.append(f"{m.name}: {e}")
        except Exception as e:  # noqa: BLE001
            bad.append(f"{m.name}: {type(e).__name__}: {e}")
    if bad:
        raise RuntimeError("; ".join(bad[:5]))
    return f"all modules import" + (f" ({len(skipped)} optional skipped)" if skipped else "")


def _content() -> str:
    from . import content
    content.ensure_loaded()
    s = content.summary()
    builtin = [p for p in s["packs"] if p["source"] == "built-in" and p["problems"]]
    if builtin:
        raise RuntimeError(f"built-in pack {builtin[0]['id']}: {builtin[0]['problems'][0]}")
    cat = content.catalog()
    for k in ("ai", "whisper", "engines"):
        if k not in cat:
            raise RuntimeError(f"catalog.json has no {k}")
    t = s["totals"]
    return f"{t['looks']} looks, {t['storyboards']} storyboards, {t['music_styles']} music styles"


def _settings() -> str:
    import yaml
    from .config import DEFAULT_BRAND, TEMPLATE_DIR, deep_merge, load_settings
    load_settings()
    brand = yaml.safe_load((TEMPLATE_DIR / "brand.yaml").read_text(encoding="utf-8")) or {}
    deep_merge(DEFAULT_BRAND, brand)
    return "settings and the client template load"


def _xml() -> str:
    import xml.etree.ElementTree as ET
    from .media import MediaInfo
    from .premiere_xml import Timeline
    with tempfile.TemporaryDirectory() as tmp:
        clip = MediaInfo(path=Path(tmp) / "clip.mp4", duration=10, width=1080, height=1920, fps=30, audio_channels=2,
                         has_video=True)
        tl = Timeline("selftest", 30, (1080, 1920))
        tl.add_video("edit", clip, 0, 0, 90)
        out = tl.write(Path(tmp) / "t.xml")
        root = ET.parse(out).getroot()
        if root.tag != "xmeml":
            raise RuntimeError("the Premiere XML isn't xmeml")
    return "Premiere XML writes"


def _sound() -> str:
    import numpy as np
    from .sound import composer, sfx
    x, meta = composer.compose({"style": "corporate", "key": "C", "seed": 1, "energy": "medium"}, 4.0)
    y = sfx.make("whoosh", "clean", 1)
    for name, a in (("music", x), ("sound effect", y)):
        if not np.isfinite(a).all() or float(np.abs(a).max()) < 1e-3:
            raise RuntimeError(f"the {name} came out silent or broken")
    return "music and sound effects synthesize"


def _crypto() -> str:
    from . import ed25519
    seed = bytes.fromhex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60")
    pub = ed25519.public_key(seed)
    sig = ed25519.sign(seed, b"autocut")
    if not ed25519.verify(pub, b"autocut", sig) or ed25519.verify(pub, b"autocuT", sig):
        raise RuntimeError("signature checks don't work")
    return "update signatures verify"


def _web() -> str:
    page = Path(autocut.__file__).parent / "web" / "index.html"
    if "function api(" not in page.read_text(encoding="utf-8"):
        raise RuntimeError("the dashboard page is incomplete")
    return "dashboard page present"


CHECKS = [("imports", _imports), ("content", _content), ("settings", _settings), ("xml", _xml), ("sound", _sound),
          ("signatures", _crypto), ("dashboard", _web)]


def run() -> dict:
    results = []
    for name, fn in CHECKS:
        t0 = time.time()
        try:
            results.append({"check": name, "ok": True, "msg": fn(), "s": round(time.time() - t0, 2)})
        except Exception as e:  # noqa: BLE001
            results.append({"check": name, "ok": False, "msg": f"{type(e).__name__}: {e}", "s": round(time.time() - t0, 2)})
    return {"version": autocut.__version__, "ok": all(r["ok"] for r in results), "results": results}


def main() -> int:
    r = run()
    for x in r["results"]:
        print(f"  {'✓' if x['ok'] else '✗'} {x['check']}: {x['msg']} ({x['s']}s)")
    print(json.dumps({"version": r["version"], "ok": r["ok"]}))
    return 0 if r["ok"] else 1
