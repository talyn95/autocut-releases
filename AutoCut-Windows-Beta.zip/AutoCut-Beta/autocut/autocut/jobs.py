"""The job queue, shared by every AutoCut Mac through the clients folder.

Any Mac can drop footage into clients/<client>/incoming/. Each Mac running the
worker polls those folders. To take a file it renames it to a hidden
".claim-<machine>-…" name. A rename is atomic on the file server, so exactly one
Mac wins and the others skip it. The winner moves the file into footage/ and
writes ready/<video>/status.json, which every dashboard reads.
"""
from __future__ import annotations

import contextlib
import json
import os
import queue
import shutil
import sys
import threading
import time
import traceback
from datetime import datetime
from pathlib import Path

from .config import list_clients, load_client

STATUS = "status.json"


def now() -> str:
    return datetime.now().isoformat(timespec="seconds")


_status_lock = threading.Lock()  # the job thread and its heartbeat both write status.json


def write_status(job: Path, **fields) -> dict:
    with _status_lock:
        job.mkdir(parents=True, exist_ok=True)
        path = job / STATUS
        try:
            data = json.loads(path.read_text()) if path.exists() else {}
        except json.JSONDecodeError:
            data = {}
        data.update(fields, updated=now())
        tmp = job / f".{STATUS}.{os.getpid()}.{threading.get_ident()}"  # unique per writer
        tmp.write_text(json.dumps(data, indent=2))
        tmp.replace(path)
        return data


OPTIONS_SUFFIX = ".autocut.json"  # per-video choices (effects, hook) uploaded next to the video


def read_options(job: Path) -> dict:
    p = job / "options.json"
    try:
        return json.loads(p.read_text()) if p.exists() else {}
    except json.JSONDecodeError:
        return {}


def claim(f: Path, machine: str) -> Path | None:
    """Atomically take an incoming file. Returns its new home in footage/, or None
    if another Mac got there first. Its options sidecar moves into the job folder."""
    claimed = f.with_name(f".claim-{machine}-{f.name}")
    try:
        os.rename(f, claimed)
    except (FileNotFoundError, OSError):
        return None
    footage = f.parent.parent / "footage"
    footage.mkdir(exist_ok=True)
    dest = footage / f.name
    if dest.exists():  # same file name uploaded twice: keep both
        if f.name.endswith(".clip.json"):
            dest = footage / f"{f.name[:-len('.clip.json')]}-{datetime.now():%H%M%S}.clip.json"
        else:
            dest = footage / f"{f.stem}-{datetime.now():%H%M%S}{f.suffix}"
    shutil.move(str(claimed), dest)
    sidecar = f.with_name(f.name + OPTIONS_SUFFIX)
    if sidecar.exists():
        job = f.parent.parent / "ready" / dest.stem
        job.mkdir(parents=True, exist_ok=True)
        try:
            shutil.move(str(sidecar), job / "options.json")
        except FileNotFoundError:
            pass
    return dest


def list_jobs(settings: dict, limit: int = 100) -> list[dict]:
    jobs = []
    for client in list_clients(settings):
        for st in (client / "ready").glob(f"*/{STATUS}"):
            try:
                data = json.loads(st.read_text())
            except (json.JSONDecodeError, OSError):
                continue
            job = st.parent
            summary = job / "job.json"
            if data.get("state") == "done" and summary.exists():
                try:
                    data = {**json.loads(summary.read_text()), **data}
                except json.JSONDecodeError:
                    pass
            data.update(client_slug=client.name, job=job.name, dir=str(job),
                        mtime=st.stat().st_mtime)
            xml = next(job.glob("*AutoCut.xml"), None)
            prev = next(job.glob("*preview.mp4"), None)
            data["options"] = read_options(job)
            # a job whose Mac stopped sending heartbeats (crashed, asleep, unplugged)
            data["stalled"] = data.get("state") == "processing" and time.time() - data["mtime"] > 300
            data["xml"] = str(xml) if xml else None
            data["preview"] = str(prev) if prev else None
            final, cover = job / f"{job.name} - final.mp4", job / "cover.png"
            data["final"] = str(final) if final.exists() else None
            data["cover"] = str(cover) if cover.exists() else None
            jobs.append(data)
    jobs.sort(key=lambda j: j["mtime"], reverse=True)
    return jobs[:limit]


def stats(settings: dict) -> dict:
    """Totals for the dashboard: videos cut, footage handled, editing time saved (estimate)."""
    week_ago = time.time() - 7 * 86400
    out = {"week": {"videos": 0, "footage_min": 0.0, "words_cut": 0}, "all": {"videos": 0, "footage_min": 0.0, "words_cut": 0}}
    for j in list_jobs(settings, limit=100000):
        if j.get("state") != "done" or j.get("fmt") or "source_seconds" not in j:
            continue
        for key in ("all", "week") if j["mtime"] >= week_ago else ("all",):
            out[key]["videos"] += 1
            out[key]["footage_min"] += j["source_seconds"] / 60
            out[key]["words_cut"] += j.get("fillers_removed", 0)
    rate = float(settings["minutes_saved_per_footage_minute"])
    for v in out.values():
        v["hours_saved"] = round(v["footage_min"] * rate / 60, 2)
        v["footage_min"] = round(v["footage_min"], 1)
    out["rate"] = rate
    return out


def waiting_files(settings: dict) -> list[Path]:
    exts = set(settings["video_extensions"])
    out = []
    for client in list_clients(settings):
        inc = client / "incoming"
        if inc.is_dir():
            out += [f for f in sorted(inc.iterdir())
                    if (f.suffix.lower() in exts or f.name.endswith(".clip.json")) and not f.name.startswith(".")]
    return out


class _Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, s):
        for st in self.streams:
            st.write(s)
            st.flush()
        return len(s)

    def flush(self):
        for st in self.streams:
            st.flush()


class Worker(threading.Thread):
    """Processes one video at a time: manual requests first, then the watch folders."""

    def __init__(self, settings: dict, poll: float = 5.0):
        super().__init__(daemon=True, name="autocut-worker")
        self.settings = settings
        self.poll = poll
        self.requests: queue.Queue = queue.Queue()
        self.paused = not settings["process_jobs"]
        self.current: dict | None = None
        self._sizes: dict[Path, int] = {}
        self._stop = threading.Event()

    def stop(self):
        self._stop.set()

    def request(self, video: Path, client_dir: Path, **opts):
        self.requests.put((video, client_dir, opts))

    def _ready_to_claim(self, f: Path) -> bool:
        """Only take a file once its size has stopped changing (copy finished)."""
        try:
            size = f.stat().st_size
        except FileNotFoundError:
            return False
        prev = self._sizes.get(f)
        self._sizes[f] = size
        return prev == size and size > 0

    def request_export(self, job: Path):
        self.requests.put(("__export__", job, {}))

    def request_motion(self, item: Path):
        self.requests.put(("__mograph__", item, {}))

    def request_design(self, item: Path):
        self.requests.put(("__design__", item, {}))

    def render_design(self, item: Path) -> None:
        from .design.stills import render_item
        self.current = {"video": "Graphic: " + item.name, "client": "Graphics", "started": time.time()}
        try:
            render_item(item, self.settings)
        except Exception:
            traceback.print_exc()
        finally:
            self.current = None

    def render_motion(self, item: Path) -> None:
        from .mograph.prompt import render_item
        self.current = {"video": "Motion graphic: " + item.name, "client": "Create", "started": time.time()}
        try:
            render_item(item, self.settings)
        except Exception:
            traceback.print_exc()
        finally:
            self.current = None

    def run(self):
        while not self._stop.is_set():
            try:
                video, client_dir, opts = self.requests.get_nowait()
            except queue.Empty:
                video = None
                if not self.paused:
                    for f in waiting_files(self.settings):
                        if self._ready_to_claim(f):
                            video = claim(f, self.settings["machine_name"])
                            if video:
                                client_dir, opts = f.parent.parent, {}
                                self._sizes.pop(f, None)
                                break
            if video is None and not self.paused:
                folder = self._next_longform()
                if folder:
                    if folder.parent.name == "multicam":
                        self.process_multicam(folder)
                    else:
                        self.analyze_longform(folder)
                    continue
            if video is None:
                self._stop.wait(self.poll)
                continue
            if video == "__design__":
                self.render_design(client_dir)  # (client_dir holds the Graphics-tab item folder here)
                continue
            if video == "__mograph__":
                self.render_motion(client_dir)  # (client_dir holds the Create-tab item folder here)
                continue
            if video == "__export__":
                self.export(client_dir)  # (client_dir holds the job folder here)
            else:
                self.process(video, client_dir, **opts)

    def process(self, video: Path, client_dir: Path, job_name: str | None = None, **opts) -> bool:
        """Cut one video. Extra aspect ratios ("formats" option) follow as their own jobs."""
        if video.name.endswith(".clip.json"):
            return self.process_clip(video, client_dir)
        job = client_dir / "ready" / (job_name or video.stem)
        job.mkdir(parents=True, exist_ok=True)
        if opts:  # a re-run with new choices: merge them into what this video already had
            merged = {**read_options(job), **opts}
            (job / "options.json").write_text(json.dumps(merged, indent=2))
        opts = read_options(job)
        ok = self._run(video, client_dir, job, opts)
        if ok and not opts.get("fmt"):
            for fmt in opts.get("formats") or []:
                fjob = client_dir / "ready" / f"{video.stem}-{fmt}"
                fjob.mkdir(parents=True, exist_ok=True)
                fopts = {**{k: v for k, v in opts.items() if k != "formats"}, "fmt": fmt}
                (fjob / "options.json").write_text(json.dumps(fopts, indent=2))
                self._run(video, client_dir, fjob, fopts)
        return ok

    @contextlib.contextmanager
    def _heartbeat(self, job: Path):
        """Touch status.json every 30s so other Macs can tell a busy job from a crashed one."""
        done = threading.Event()

        def beat():
            while not done.wait(30):
                write_status(job)
        t = threading.Thread(target=beat, daemon=True)
        t.start()
        try:
            yield
        finally:
            done.set()

    def _run(self, video: Path, client_dir: Path, job: Path, opts: dict) -> bool:
        from .pipeline import run_job
        machine = self.settings["machine_name"]
        write_status(job, state="processing", machine=machine, started=now(), video=str(video),
                     client=client_dir.name, error=None, step="starting", fmt=opts.get("fmt"))
        self.current = {"video": job.name, "client": client_dir.name, "started": time.time()}
        ok = False
        with (job / "log.txt").open("a") as log, self._heartbeat(job):
            log.write(f"\n=== {now()} on {machine} ===\n")
            try:
                with contextlib.redirect_stdout(_Tee(log, sys.__stdout__)):
                    client = load_client(str(client_dir), self.settings)
                    run_job(video, client, self.settings, preview=self.settings["preview"],
                            hook=opts.get("hook", ""), effects=opts.get("effects"), assets=opts.get("assets"),
                            edits=opts.get("edits"), fmt=opts.get("fmt"), job_name=job.name,
                            on_step=lambda step: write_status(job, step=step))
                write_status(job, state="done", finished=now(), step="done")
                ok = True
            except Exception as e:
                log.write(traceback.format_exc())
                write_status(job, state="error", finished=now(), error=str(e)[:500])
        self.current = None
        return ok

    def process_clip(self, spec_path: Path, client_dir: Path) -> bool:
        """One clip from a long video: reframe it for each requested shape, then cut it like any video."""
        from .clips.reframe import render_clip
        from .config import FORMATS
        spec = json.loads(spec_path.read_text())
        words = json.loads(Path(spec["transcript"]).read_text())["words"]
        a, b = float(spec["start"]), float(spec["end"])
        clip_words = [{**w, "start": round(w["start"] - a, 3), "end": round(w["end"] - a, 3)}
                      for w in words if w["start"] >= a - 0.05 and w["end"] <= b + 0.1]
        ok = True
        for fmt in spec.get("formats") or ["vertical"]:
            job = client_dir / "ready" / f"{spec['name']}-{fmt}"
            job.mkdir(parents=True, exist_ok=True)
            (job / "transcript.json").write_text(json.dumps({"source": spec["source"], "words": clip_words}))
            hook = spec.get("hook", "")
            if len(hook.split()) > 7:  # on-screen titles work best short
                hook = " ".join(hook.split()[:7]).rstrip(",;:") + "…"
            opts = {"effects": spec.get("effects"), "hook": hook, "fmt": fmt,
                    "clip": {"source": spec["source"], "start": a, "end": b, "layout": spec.get("layout", "auto")}}
            (job / "options.json").write_text(json.dumps(opts, indent=2))
            write_status(job, state="processing", machine=self.settings["machine_name"], started=now(),
                         client=client_dir.name, step="reframing", error=None)
            src = client_dir / "footage" / f"{spec['name']}-{fmt}.mp4"
            try:
                with self._heartbeat(job):
                    render_clip(Path(spec["source"]), a, b, spec.get("detect") or {}, spec.get("layout", "auto"),
                                FORMATS[fmt], src, words=words)
            except Exception as e:
                write_status(job, state="error", error=f"Reframing failed: {str(e)[:300]}")
                ok = False
                continue
            write_status(job, video=str(src))
            ok = self._run(src, client_dir, job, opts) and ok
        return ok

    # ---- long videos (Clips tab) -------------------------------------------------
    def _next_longform(self) -> Path | None:
        from .config import list_clients
        for client in list_clients(self.settings):
            for pending in sorted([*(client / "multicam").glob("*/.pending"), *(client / "longform").glob("*/.pending")]):
                claimed = pending.with_name(f".claimed-{self.settings['machine_name']}")
                try:
                    os.rename(pending, claimed)  # atomic: only one Mac analyses it
                except OSError:
                    continue
                return pending.parent
        return None

    def analyze_longform(self, folder: Path) -> bool:
        from .clips.analyze import analyze
        write_status(folder, state="processing", machine=self.settings["machine_name"], started=now(),
                     step="starting", error=None)
        self.current = {"video": folder.name + " (finding clips)", "client": folder.parent.parent.name,
                        "started": time.time()}
        try:
            with self._heartbeat(folder), (folder / "log.txt").open("a") as log, \
                    contextlib.redirect_stdout(_Tee(log, sys.__stdout__)):
                analyze(folder, self.settings, on_step=lambda s: write_status(folder, step=s))
            write_status(folder, state="done", step="done", finished=now())
            return True
        except Exception as e:
            with (folder / "log.txt").open("a") as log:
                log.write(traceback.format_exc())
            write_status(folder, state="error", error=str(e)[:400])
            return False
        finally:
            self.current = None

    def process_multicam(self, folder: Path) -> bool:
        """A multicam podcast/interview: sync, cut between speakers, XML + preview (multicam/project.py)."""
        from .multicam.project import build, options
        client_dir = folder.parent.parent
        write_status(folder, state="processing", machine=self.settings["machine_name"], started=now(),
                     step="starting", error=None)
        self.current = {"video": folder.name + " (multicam)", "client": client_dir.name, "started": time.time()}
        try:
            with self._heartbeat(folder), (folder / "log.txt").open("a") as log, \
                    contextlib.redirect_stdout(_Tee(log, sys.__stdout__)):
                log.write(f"\n=== {now()} on {self.settings['machine_name']} ===\n")
                job = build(folder, client_dir, self.settings, on_step=lambda s: write_status(folder, step=s))
            write_status(folder, state="done", step="done", finished=now(), output=str(job))
            if options(folder).get("clips"):
                self._multicam_to_clips(folder, job)
            return True
        except Exception as e:
            with (folder / "log.txt").open("a") as log:
                log.write(traceback.format_exc())
            write_status(folder, state="error", error=str(e)[:400])
            return False
        finally:
            self.current = None

    def _multicam_to_clips(self, folder: Path, job: Path) -> None:
        """Render the finished podcast and hand it to the Clips tab as a long video."""
        if not self.export(job):
            return
        final = job / f"{job.name} - final.mp4"
        lf = folder.parent.parent / "longform" / f"{folder.name}-podcast"
        lf.mkdir(parents=True, exist_ok=True)
        dest = lf / final.name
        if not dest.exists():
            try:
                os.link(final, dest)  # same disk: instant, no extra space
            except OSError:
                shutil.copy2(final, dest)
        # cameras already frame one person each, so a centre crop is the right vertical reframe
        (lf / "options.json").write_text(json.dumps({"count": 8, "min_len": 20, "max_len": 60, "layout": "center"}))
        write_status(lf, state="queued", step="waiting for a free Mac")
        (lf / ".pending").touch()

    def export(self, job: Path) -> bool:
        """Full-quality MP4 of the rough cut, straight from the saved timeline (no Premiere needed)."""
        from .premiere_xml import Timeline
        from .preview import render_preview
        write_status(job, export="running")
        self.current = {"video": job.name + " (export)", "client": job.parent.parent.name, "started": time.time()}
        try:
            with self._heartbeat(job):
                if (job / "multicam.json").exists():  # one-pass multicam renderer
                    from .multicam.render import render
                    out = render(json.loads((job / "multicam.json").read_text()), job / f"{job.name} - final.mp4",
                                 final=True)
                else:
                    out = render_preview(Timeline.load(job / "timeline.json"), job / f"{job.name} - final.mp4",
                                         height=None, final=True)
            write_status(job, export="done", export_file=str(out))
            return True
        except Exception as e:
            with (job / "log.txt").open("a") as log:
                log.write(f"\n=== export failed {now()} ===\n{traceback.format_exc()}")
            write_status(job, export="error", error=f"Export failed: {str(e)[:300]}")
            return False
        finally:
            self.current = None
