# GRAPHIC DESIGN FOR SOCIAL AND ADS

- One message per graphic. Hierarchy: headline (big) → support line → proof/detail → CTA → logo (small).
- Mobile first: headline readable at thumb size; few words; strong contrast; generous margins; nothing important
  in platform UI zones.
- Brand consistency: client colours, fonts and logo every time; one accent colour for the key word or number.
- Use real photography (the team, the work, the product, the customer) over stock when possible; people's faces and
  eyes draw attention; cut-outs over brand colour feel premium.
- Thumbnails: 3-5 words max (complement the title, don't repeat it), an expressive face, one focal point,
  high contrast, readable at small size, curiosity or a clear outcome.
- Carousels: slide 1 is a hook (promise or question), each slide one point, last slide a CTA (save/share/book);
  consistent layout and numbering; 5-10 slides.
- Static ads: offer or benefit as the headline, social proof (stars, review quote, numbers), a clear button-style
  CTA; test multiple headlines and images.
- Quote/testimonial cards: short, specific quotes with a name and context; stars only if real.
