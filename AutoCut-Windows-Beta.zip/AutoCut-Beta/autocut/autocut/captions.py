"""Brand-styled captions: an editable SRT plus an animated (kinetic) ASS file.

The ASS file is rendered to a transparent ProRes 4444 overlay in overlays.py.
Styles:
  pop      words build on screen one at a time, always centred; the newest word pops in the brand colour
  karaoke  the whole line shows; the spoken word lights up in the brand colour
  highlight  like pop, plus a brand-colour box behind the word being said (the popular short-form look)
  punch    one big word at a time, centre screen (hype / short-form)
  clean    plain lines with a soft fade (corporate / long-form)
"""
from __future__ import annotations

import re

from .config import hex_to_rgb
from .edit import norm

SENTENCE_END = re.compile(r"[.?!]$")


def ass_color(hex_color: str, alpha: int = 0) -> str:
    r, g, b = hex_to_rgb(hex_color)
    return f"&H{alpha:02X}{b:02X}{g:02X}{r:02X}"


def display_text(word: str, upper: bool) -> str:
    w = word.strip().strip(",.;:")
    w = w.replace("\\", "").replace("{", "(").replace("}", ")")
    return w.upper() if upper else w


def group_lines(words: list[dict], per_line: int, max_secs: float) -> list[list[dict]]:
    lines: list[list[dict]] = []
    cur: list[dict] = []
    for w in words:
        if cur and (len(cur) >= per_line
                    or w["start"] - cur[-1]["end"] > 0.6
                    or w["end"] - cur[0]["start"] > max_secs
                    or SENTENCE_END.search(cur[-1]["word"])
                    or cur[-1]["word"].endswith(",") and len(cur) > 1):
            lines.append(cur)
            cur = []
        cur.append(w)
    if cur:
        lines.append(cur)
    return lines


def line_windows(lines: list[list[dict]], total: float) -> list[tuple[float, float]]:
    out = []
    for i, line in enumerate(lines):
        start = line[0]["start"]
        nxt = lines[i + 1][0]["start"] if i + 1 < len(lines) else total
        out.append((start, max(start + 0.2, min(nxt, line[-1]["end"] + 0.5))))
    return out


def ts_srt(t: float) -> str:
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"


def ts_ass(t: float) -> str:
    cs = int(round(t * 100))
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02}:{s:02}.{cs:02}"


def write_srt(words: list[dict], total: float, cfg: dict, path) -> None:
    lines = group_lines(words, max(cfg["words_per_line"], 5), 3.0)
    rows = []
    for i, (line, (s, e)) in enumerate(zip(lines, line_windows(lines, total)), 1):
        text = " ".join(display_text(w["word"], False) for w in line)
        rows.append(f"{i}\n{ts_srt(s)} --> {ts_srt(e)}\n{text}\n")
    path.write_text("\n".join(rows))


def write_ass(words: list[dict], total: float, brand: dict, size: tuple[int, int], path) -> None:
    cfg, colors = brand["captions"], brand["colors"]
    W, H = size
    style = cfg["style"]
    fontsize = cfg["size"] * (1.7 if style == "punch" else 1.0) * (W / 1080 if W < H else H / 1080)
    if style == "punch":
        align, margin_v = 5, 0
    else:
        align, margin_v = {"lower": (2, int(H * 0.22)), "middle": (5, 0),
                           "upper": (8, int(H * 0.12))}[cfg["position"]]

    text_c, hi_c = ass_color(colors["text"]), ass_color(colors["primary"])
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Main,{brand['fonts']['caption']},{fontsize:.0f},{text_c},{text_c},{ass_color(colors['outline'])},{ass_color(colors['outline'], 0x60)},{-1 if cfg['bold'] else 0},0,0,0,100,100,0,0,1,{cfg['outline_width']},{cfg['shadow']},{align},{int(W * 0.08)},{int(W * 0.08)},{margin_v},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    keywords = {norm(k) for k in cfg["highlight_words"]}

    def is_key(w: dict) -> bool:
        n = norm(w["word"])
        return n in keywords or (cfg["highlight_numbers"] and bool(re.search(r"\d", w["word"])))

    def scale_tags(w: dict, pop: bool) -> str:
        base = 112 if is_key(w) else 100
        if pop:
            return (rf"\fscx{base * 0.7:.0f}\fscy{base * 0.7:.0f}\t(0,90,\fscx{base * 1.15:.0f}\fscy{base * 1.15:.0f})"
                    rf"\t(90,170,\fscx{base}\fscy{base})")
        return rf"\fscx{base}\fscy{base}"

    box = max(10, int(fontsize * 0.42))

    def box_run(w: dict, active: bool, pop: bool) -> str:
        """The highlight layer: identical text and scaling (so it lines up exactly), but only the active
        word shows, as a thick brand-colour outline with an invisible fill: a rounded box behind it."""
        txt = display_text(w["word"], cfg["uppercase"])
        vis = rf"\1a&HFF&\3c{hi_c}\3a&H00&\bord{box}\shad0" if active else r"\alpha&HFF&\bord0\shad0"
        return "{" + vis + scale_tags(w, pop) + "}" + txt

    def word_run(w: dict, active: bool, pop: bool = False) -> str:
        txt = display_text(w["word"], cfg["uppercase"])
        tags = [r"\c" + (hi_c if (active or is_key(w)) else text_c)]
        base = 112 if is_key(w) else 100
        if pop:
            tags.append(rf"\fscx{base * 0.7:.0f}\fscy{base * 0.7:.0f}"
                        rf"\t(0,90,\fscx{base * 1.15:.0f}\fscy{base * 1.15:.0f})"
                        rf"\t(90,170,\fscx{base}\fscy{base})")
        else:
            tags.append(rf"\fscx{base}\fscy{base}")
        return "{" + "".join(tags) + "}" + txt

    events = []
    lines = group_lines(words, 1 if style == "punch" else cfg["words_per_line"], cfg["max_line_seconds"])
    for line, (ls, le) in zip(lines, line_windows(lines, total)):
        if style == "clean":
            text = " ".join(display_text(w["word"], cfg["uppercase"]) for w in line)
            events.append((ls, le, r"{\fad(120,120)}" + text))
            continue
        for i, w in enumerate(line):
            s = ls if i == 0 else w["start"]
            e = line[i + 1]["start"] if i + 1 < len(line) else le
            if e - s < 0.02:
                continue
            if style == "punch":
                runs = [word_run(w, active=False, pop=True)]
            elif style == "karaoke":
                runs = [word_run(x, active=(j == i)) for j, x in enumerate(line)]
            elif style == "highlight":  # pop, with a box behind the word being said (on its own layer below)
                said = line[:i + 1]
                events.append((s, e, " ".join(box_run(x, active=(j == i), pop=(j == i)) for j, x in enumerate(said)), 0))
                runs = [word_run(x, active=False, pop=(j == i)) for j, x in enumerate(said)]
                events.append((s, e, " ".join(runs), 1))
                continue
            else:  # pop: only the words said so far, so the line stays centred as it grows (no stagger)
                runs = [word_run(x, active=(j == i), pop=(j == i)) for j, x in enumerate(line[:i + 1])]
            events.append((s, e, " ".join(runs)))

    body = "".join(f"Dialogue: {ev[3] if len(ev) > 3 else 1},{ts_ass(ev[0])},{ts_ass(ev[1])},Main,,0,0,0,,{ev[2]}\n"
                   for ev in events)
    path.write_text(header + body)
