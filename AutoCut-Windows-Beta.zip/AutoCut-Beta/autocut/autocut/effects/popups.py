"""Pop-up stickers: an icon bounces in next to the speaker when a matching word is said.

Built-in stickers live in effects/stickers/. A client's own stickers go in
assets/stickers/, named by the word that triggers them (money.png, roof.png,
or "roof shingles.png" for several words). Client stickers win over built-ins.
"""
from __future__ import annotations

import math
from pathlib import Path

from PIL import Image

from ..broll import stem
from ..config import Client
from .render import write_rgba

BUILTIN = Path(__file__).parent / "stickers"
BUILTIN_TAGS = {
    "check": "yes right done guaranteed approved correct perfect easy simple ready",
    "x": "no wrong mistake mistakes never avoid problem problems bad fail",
    "star": "best review reviews rating rated stars top quality amazing five",
    "dollar": "money price prices cost costs save saving savings dollars cash pay budget cheap afford financing",
    "arrow-up": "grow growth increase more boost higher up value results",
    "heart": "love family families care loved happy",
    "clock": "minutes minute time hours hour today fast quick schedule wait day",
    "house": "home homes house houses roof property neighborhood",
    "lightbulb": "idea tip tips secret know learn smart trick",
    "question": "why what how question questions wondering",
    "exclamation": "important warning damage attention urgent careful danger storm",
    "fire": "hot fire popular trending crazy insane",
}


def library(client: Client) -> dict[str, Path | str]:
    """trigger stem → sticker file (or "icon:<name>" for the icon library, drawn on first use).
    Priority: the client's own stickers, then the 12 built-ins, then the 2,100-icon library."""
    lib: dict[str, Path | str] = {}
    if client.brand["popups"].get("icon_library", True):
        from .iconlib import index
        lib.update({k: f"icon:{v}" for k, v in index().items()})
    if client.brand["popups"]["builtin"]:
        for name, words in BUILTIN_TAGS.items():
            for w in words.split():
                lib[stem(w)] = BUILTIN / f"{name}.png"
    folder = client.path(client.brand["popups"]["folder"])
    if folder and folder.is_dir():
        for p in sorted(folder.glob("*.png")):
            for w in p.stem.replace("-", " ").replace("_", " ").split():
                lib[stem(w)] = p
    return lib


def find_popups(words: list[dict], client: Client, occupied, total: float) -> list[dict]:
    cfg = client.brand["popups"]
    lib = library(client)
    if not lib:
        return []
    dur, gap = float(cfg["seconds"]), 60.0 / max(1, cfg["max_per_minute"])
    out, last, side = [], -1e9, 0
    for w in words:
        s = stem(w["word"])
        if s not in lib or w["start"] - last < gap or w["start"] + dur > total - 0.3:
            continue
        if not occupied.free(w["start"], w["start"] + dur, gap=0.1):
            continue
        sticker = lib[s]
        if isinstance(sticker, str):  # an icon-library badge in the client's brand colour
            from .iconlib import sticker as icon_sticker
            sticker = icon_sticker(sticker[5:], client.brand["colors"]["primary"])
        out.append({"start": w["start"], "sticker": sticker, "word": w["word"].strip(",.!?"), "side": side})
        occupied.take(w["start"], w["start"] + dur, "popup")
        last, side = w["start"], 1 - side
    return out


def _scale_curve(t: float, dur: float) -> float:
    """0 → overshoot → settle, gentle float, then shrink out."""
    if t < 0.12:
        return 1.18 * (t / 0.12)
    if t < 0.22:
        return 1.18 - 0.18 * ((t - 0.12) / 0.10)
    if t > dur - 0.15:
        return max(0.0, (dur - t) / 0.15)
    return 1.0 + 0.03 * math.sin((t - 0.22) * 6)


def render_popup(pop: dict, client: Client, size: tuple[int, int], fps: float, out: Path) -> Path:
    W, H = size
    dur = float(client.brand["popups"]["seconds"])
    base = int(min(W, H) * client.brand["popups"]["size_pct"] / 100)
    sticker = Image.open(pop["sticker"]).convert("RGBA")
    sticker.thumbnail((base, base), Image.LANCZOS)
    # shoulder height, out to the side, clear of the face
    cx = W * (0.17 if pop["side"] == 0 else 0.83)
    cy = H * (0.50 if H > W else 0.42)
    n = max(1, round(dur * fps))

    def frames():
        for i in range(n):
            t = i / fps
            k = _scale_curve(t, dur)
            canvas = Image.new("RGBA", (W, H), (0, 0, 0, 0))
            if k > 0.01:
                sw, sh = max(1, int(sticker.width * k)), max(1, int(sticker.height * k))
                img = sticker.resize((sw, sh), Image.BILINEAR)
                angle = 8 * math.sin(t * 5) * (1 if pop["side"] else -1)
                img = img.rotate(angle, resample=Image.BICUBIC, expand=True)
                canvas.alpha_composite(img, (int(cx - img.width / 2), int(cy - img.height / 2)))
            yield canvas.tobytes()

    return write_rgba(frames(), size, fps, out)
