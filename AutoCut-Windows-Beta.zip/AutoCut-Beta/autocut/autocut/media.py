"""ffprobe / ffmpeg helpers."""
from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path


@dataclass
class MediaInfo:
    path: Path
    duration: float
    width: int = 0
    height: int = 0
    fps: float = 0.0
    audio_channels: int = 0
    has_video: bool = False
    is_still: bool = False


def run(cmd: list[str], quiet: bool = True) -> subprocess.CompletedProcess:
    res = subprocess.run(cmd, capture_output=True, text=True)
    if res.returncode != 0:
        raise RuntimeError(f"Command failed: {' '.join(map(str, cmd))}\n{res.stderr[-2000:]}")
    return res


def probe(path: Path) -> MediaInfo:
    out = run(["ffprobe", "-v", "error", "-print_format", "json",
               "-show_format", "-show_streams", str(path)]).stdout
    data = json.loads(out)
    fmt = data.get("format", {})
    info = MediaInfo(path=Path(path), duration=float(fmt.get("duration") or 0))
    for s in data.get("streams", []):
        if s.get("codec_type") == "video" and not info.has_video:
            info.has_video = True
            w, h = int(s.get("width", 0)), int(s.get("height", 0))
            rotation = 0
            for sd in s.get("side_data_list", []) or []:
                if "rotation" in sd:
                    rotation = int(float(sd["rotation"]))
            rotation = rotation or int(s.get("tags", {}).get("rotate", 0) or 0)
            if abs(rotation) % 180 == 90:  # phone footage stored sideways
                w, h = h, w
            info.width, info.height = w, h
            rate = s.get("avg_frame_rate") or s.get("r_frame_rate") or "0/1"
            try:
                info.fps = float(Fraction(rate)) if rate != "0/0" else 0.0
            except ZeroDivisionError:
                info.fps = 0.0
            if s.get("codec_name") in ("png", "mjpeg", "jpeg", "webp", "bmp", "tiff") and info.duration < 0.1:
                info.is_still = True
        elif s.get("codec_type") == "audio" and not info.audio_channels:
            info.audio_channels = int(s.get("channels", 2))
    if not info.duration and info.has_video:
        info.is_still = True
    return info


def timebase(fps: float) -> tuple[int, bool]:
    """Premiere XML expresses rates as an integer timebase plus an NTSC flag."""
    for tb in (24, 25, 30, 50, 60, 120):
        if abs(fps - tb) < 0.01:
            return tb, False
        if abs(fps - tb * 1000 / 1001) < 0.01:
            return tb, True
    return max(1, round(fps)), False


def extract_audio(video: Path, wav: Path) -> Path:
    run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(video),
         "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(wav)])
    return wav


_ENCODERS: set[str] | None = None


def has_encoder(name: str) -> bool:
    global _ENCODERS
    if _ENCODERS is None:
        try:
            out = subprocess.run(["ffmpeg", "-hide_banner", "-encoders"], capture_output=True, text=True).stdout
            _ENCODERS = {line.split()[1] for line in out.splitlines() if line.startswith(" V") and len(line.split()) > 1}
        except OSError:
            _ENCODERS = set()
    return name in _ENCODERS


_HW: list[str] | None = None


def _hardware_h264() -> str:
    """The first H.264 hardware encoder that really works here ("" = none). Windows ffmpeg builds list
    NVIDIA/Intel/AMD encoders whether or not that GPU is in the machine, so each one is test-run once."""
    global _HW
    if _HW is None:
        _HW = []
        if has_encoder("h264_videotoolbox"):
            _HW.append("h264_videotoolbox")
        else:
            for enc in ("h264_nvenc", "h264_qsv", "h264_amf"):
                if has_encoder(enc) and subprocess.run(
                        ["ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i",
                         "color=black:s=256x256:d=0.2", "-c:v", enc, "-pix_fmt", "yuv420p", "-f", "null", "-"],
                        capture_output=True).returncode == 0:
                    _HW.append(enc)
                    break
    return _HW[0] if _HW else ""


def video_encoder(quality: str = "high") -> list[str]:
    """H.264 encoder args. The graphics chip encodes several times faster than the CPU and leaves the
    cores free for the next job: Apple's media engine on a Mac; NVIDIA, Intel or AMD on a Windows PC.
    AUTOCUT_SOFTWARE_ENCODE=1 forces the CPU encoder."""
    import os
    hw = "" if os.environ.get("AUTOCUT_SOFTWARE_ENCODE") else _hardware_h264()
    if hw == "h264_videotoolbox":
        q = {"final": "80", "high": "72", "preview": "55"}.get(quality, "65")
        return ["-c:v", "h264_videotoolbox", "-q:v", q, "-allow_sw", "1"]
    if hw:
        q = {"final": "18", "high": "19", "preview": "26"}.get(quality, "22")
        return {"h264_nvenc": ["-c:v", "h264_nvenc", "-preset", "p5", "-rc", "vbr", "-cq", q, "-b:v", "0"],
                "h264_qsv": ["-c:v", "h264_qsv", "-preset", "medium", "-global_quality", q],
                "h264_amf": ["-c:v", "h264_amf", "-quality", "quality", "-rc", "cqp",
                             "-qp_i", q, "-qp_p", q]}[hw]
    crf, preset = {"final": ("17", "slow"), "high": ("17", "fast"),
                   "preview": ("23", "veryfast")}.get(quality, ("19", "fast"))
    return ["-c:v", "libx264", "-crf", crf, "-preset", preset]
