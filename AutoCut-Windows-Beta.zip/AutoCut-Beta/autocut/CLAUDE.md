# AutoCut: guide for Claude Code

AutoCut is a local rough-cut editor for Triumphant Media, a video agency. It runs on each
computer by itself, a Mac (menu-bar app) or a Windows PC (Start-menu shortcut), with a web dashboard.
Every computer is independent: no server, nothing shared (the older shared-queue Mac setup is optional).
Raw talking-head footage goes in; out comes a Premiere Pro FCP7 XML rough cut with:

- fillers and dead air removed
- brand-styled kinetic captions
- B-roll, logo watermark and CTA end card
- Kinetik Motion Studio graphics

Users are video editors, not developers. Keep the UI and the messages plain.

Dashboard tabs (data-tab id → label): `queue` Short form edits, `create` Motion graphic generator,
`design` Graphics, `multicam` Long form editor, `clips` Clip generator, `clients` Clients, `machine` This Mac.
`docs/COMPETITIVE.md` lists each tab against the best product in its class (Descript/CapCut, HyperFrames, Opus Clip,
AutoPod, Canva): what AutoCut matches and what's next. Keep it current when you add features.
The code and API still use the short ids (longform = Clip generator projects, multicam = Long form editor).

## Run and test

```bash
.venv/bin/python -m unittest -v                         # all tests; needs ffmpeg, ~30s
.venv/bin/python -m autocut app --headless              # dashboard at http://127.0.0.1:8765
.venv/bin/python -m autocut run examples/demo-roofing-co/sample/test-take-01.mp4 \
    --client demo-roofing-co --transcript examples/demo-roofing-co/sample/test-take-01.transcript.json --preview
```

To use a scratch data folder instead of the real shared one, set
`AUTOCUT_SETTINGS=/path/to/settings.yaml` with `clients_dir: /tmp/whatever`.

**Always run the tests before committing.** Changes reach computers as signed releases (docs/RELEASING.md;
This Mac → Updates installs them); shared-queue Macs without a feed still pull with "Update AutoCut".

## Code map (autocut/)

| File | Role |
|---|---|
| `pipeline.py` | `run_job()`: one video → job folder. Read this first; it calls everything else in order |
| `transcribe.py` | Local Whisper (MLX on Apple Silicon, faster-whisper elsewhere) with word timestamps. The prompt keeps fillers. Caches `transcript.json` |
| `edit.py` | `find_restarts()` (false starts), `find_retakes()` (whole-sentence retakes, keeps the last) and `plan_edit()` (takes transcript-editor `force_remove`/`force_keep`/`fixes`): removes fillers/stutters, closes pauses > `max_pause`, snaps to frames. Returns segments (source in/out → timeline in/out) and kept words retimed to the timeline |
| `captions.py` | Line grouping, SRT, and kinetic ASS styles (`pop`, `karaoke`, `punch`, `clean`). New caption styles go here |
| `overlays.py` | Renders ASS to ProRes 4444 alpha (`ass` filter with `alpha=1`), the watermark PNG, the generated CTA end card, and the style proof |
| `broll.py` | Keyword matching of transcript windows against clip filenames / `tags.csv` |
| `effects/__init__.py` | Effect registry (`EFFECTS`), `resolve()` (client defaults ← per-video overrides), `Occupancy` (keeps big visuals from overlapping) |
| `effects/cards.py` | Number/phrase graphic cards + lower third (ASS vector drawing → alpha ProRes) |
| `effects/popups.py` | Keyword-triggered stickers (built-ins in `effects/stickers/`, client `assets/stickers/`), PIL frames → alpha ProRes |
| `effects/overlays.py` | Grain+vignette loop and light leaks (generated, or the client's own clips) |
| `effects/cutout.py` | Person segmentation (Apple Vision on macOS, ONNX U²-Net fallback). Renders hook-text-behind-speaker and pop-out moments |
| `effects/media.py` | The team's own media: library (`CATEGORIES`, `tags.json`), per-video assets, placement (`plan_media`), full-screen Ken Burns + floating-card renders |
| `effects/story.py` | Story cutaways: `find_moments` (transcript → 2–4 picturable beats: client media > b-roll video > icon), Skia storyboard with 3D tiles, PiP videos and a framed speaker (`render_moment`) |
| `effects/cover.py` | Cover/thumbnail PNG (segmentation + brand colour + hook text + logo) |
| `effects/render.py` | Shared helpers: RGBA frame piping to ffmpeg, ASS building blocks |
| `mograph/engine.py` | AutoCut Motion: Skia frame loop with motion blur (sub-frame accumulation, skipped on still frames), brand `Look` (colours/fonts) |
| `mograph/templates.py` | Templates `name(look, **params) -> (dur, draw)`: hook_title, slam, stat_counter, phrase_card, lower_third, swipe, cta_outro, kinetic_type. New templates go here + `TEMPLATES`; `make(speed=)` plays any template faster/slower |
| `mograph/placement.py` | Where the pack goes in a video (hook, slams, swipes, CTA outro, pro cards/lower third) |
| `mograph/gallery.py` | "Preview motion pack" reel |
| `mograph/hyper.py` | HyperFrames engine: runtime setup (pinned CLI + GSAP + Chrome Headless Shell in `hyperframes-runtime/`, telemetry off), `build()` fills `mograph/hf/<template>.html` into `hf/base.html` (brand colours/fonts, `--u` units, `T()` speed), `make()` renders ProRes 4444 alpha, `make_custom()` has the AI write a whole composition (one repair round). Templates must follow the HyperFrames contract in the module docstring/`CUSTOM_GUIDE` |
| `design/stills.py` | Graphics tab: brand designs (quote, stat, offer, testimonial, thumbnail with cutout, tips, event, carousel) as HTML + `design/design.css`, one design per frame so a batch renders in one HyperFrames pass to PNGs; sizes (post/portrait/story/thumbnail/ad) × looks (bold/clean/dark); Magic Design (`magic_design`, AI + rules fallback), bulk CSV (`rows_from_csv`), carousel PDF, `custom` AI-written stills |
| `audio.py` | Studio Sound: ffmpeg voice-cleanup chain (`CHAIN`), `studio_sound()` writes the cleaned WAV the timeline uses |
| `report.py` | Report a problem: zip of description, versions, doctor, scrubbed settings, app log, recent job logs |
| `sound/` | Music + sound design (docs/SOUND.md): `synth.py` numpy instruments/DSP, `composer.py` 10 styles → arrangement fitted to length + stems, `sfx.py` 13 effects × 8 flavours, `design.py` events → cues (density, peak alignment, no overlaps), `director.py` per-client sound identity (`sound-style.json`) + per-video brief (AI with knowledge/music.md, rules fallback), `aimusic.py` optional ACE-Step via its local REST API, `score()` / `mix_video()`. Pipeline: A1 dialogue (dual-mono), A2 effects, A3 music (`Timeline.audio_layout = "roles"`; older timelines "stereo") |
| `mograph/library/` | Motion library (docs/LIBRARY.md): `looks.py` 18 style families (tokens), `elements.py` 41 layouts `fn(c, params, sid, t0, dur) -> Part` over a JS kit (`compose.KIT`: textIn/boxIn/lineIn/strokeIn/popIn/countUp/out in the look's motion vocabulary), `compose.py` colour roles (contrast-checked) + page, `build.py` one element / look sheets / `samples`, `storyboards.py` 12 recipes (slots → scenes, AI or rules), `dna.py` per-client style DNA (`motion-style.json`, least-overlap assignment, `similarity`), `registry.py` + `registry.json` (448 HyperFrames registry items; `reference_for` feeds `make_custom`). `prompt._library_render` routes Create-tab templates (`library.MAP`) through it when a look applies |
| `mograph/feel.py` | After Effects-style motion feels: bezier speed curves (`EIN`/`EOUT`/`EIO`) + `feel()`/`feelOut()` layers (scale, rotation, glow, shadow lift on CSS vars). Used by the library kit and transcript videos; `pick(look, override)` |
| `mograph/script.py` | Transcript → kinetic typography video: `read_transcript` (json/SRT/VTT/plain text, paced by `pace`), `beats` (sentences, split evenly), `plan` (stat/list/slam/image/kinetic per beat; `_ai_plan` refines key words), `build` (one HyperFrames composition, absolute word timing), `make_video`/`finish` (render MP4, mux the voice; `voice.txt` in the project for re-renders) |
| `mograph/explainer.py` | Explainer split edit style (Create tab → Transcript to video → Style; MCP `make_explainer_video`): `cut_take` (edit.plan_edit → cut.mp4), `plan` (per sentence: card / media + price sticker / interlude with strike + badge / step tracker / intro name card; AI refines highlights and labels, rules fallback), `framing` + `geometry` (speaker panel, head just over its edge), `render_popout` (person cut-out band as VP9 alpha WebM), `build` (one HyperFrames composition with the take as a muted `<video>`) |
| `mograph/customize.py` | The Create tab's own logo/fonts/graphics: `describe` (kind + role), `apply(client, assets, work)` → a client copy with that logo and fonts, `graphics()`, `media()` (photos/graphics/clips as readings), `match()` ("Match my media": colours + fonts) |
| `mograph/media_read.py` | Understanding dropped-in media: `measure` (size, transparency, palette, video length/pacing), `rules_read` (role from name/shape), `ai_read` (vision via brain.ask: subject, words in it, typography → `font_for` a bundled font, mood, role, best use, caption), `read` (cached in hidden `.<file>.read.json`), `brief` (lines for AI prompts), `style`, `prepare_video` (H.264, silent, ≤1920, held on its last frame), `poster`. Feeds the media layouts (`elements.py` kind `media`), storyboards (`media_scenes`), the prompt (`parse(media=)`) and `hyper.make_custom(media=)` |
| `mograph/prompt.py` | Create tab: prompt → spec (rules + the AI brain, + a reference), `render_item` (sizes × formats, speed), motion library listing |
| `clips/analyze.py` | Clips tab: sentence-aligned candidates, viral-potential score + reasons, AI review via the brain (score, title, hooks, why) |
| `clips/reframe.py` | Person detection (segmentation blobs) → speakers / follow (tracked: `track_person` + sendcmd) / split / pip / fit layouts as ffmpeg filter graphs; `render_clip` |
| `speakers.py` | Who is talking when: streamed per-channel loudness, head-movement activity, `shots()` (jump cuts with a minimum length, optional wide shot) |
| `multicam/sync.py` | Audio sync of cameras and recorders (FFT cross-correlation of onset envelopes) |
| `multicam/project.py` | Multicam tab: file roles, `analyze` (sync + who's who), `plan` (shots, PiP, filler toggle), `build` (XML + recipe + preview) |
| `multicam/render.py` | One-pass ffmpeg render of a multicam recipe (cameras switched with `overlay=enable`) |
| `effects/iconlib.py` | Lucide icons (effects/icons, ISC) → brand badge stickers; `CURATED` word→icon map |
| `brain.py` | The AI brain: `ask()` tries the free local Ollama model first, Claude (anthropic SDK, structured output, `fallbacks="default"`) as backup under a monthly cap; `status()` for the dashboard |
| `knowledge/*.md` | The agency's video-marketing knowledge base (core, hooks, retention, platforms, ads, copy, scripts, strategy, agency, design, motion, prompting). Plain Markdown: edit it to teach every AI feature |
| `design/assets.py` | Your images in the Graphics tab: roles (photo, product, logo, style), `guess_role`, product cut-out (U²-Net-P ONNX, 5 MB, downloaded once), `apply()` into a design's photo fields, `style_colors()` from a reference |
| `marketing.py` | `system_prompt(brand, task)`: the knowledge files for that task (`TASKS`) + the client brief; `strategist()` (the Strategist panel); the marketing `PLAYBOOK` (everything), the client's `brief()` (brand.yaml `marketing:`), and the post copy pack (`post_copy`, `write_copy`, YouTube `chapters`) |
| `mograph/reference.py` | Reference material for the Create tab: palette (k-means), light/dark, video pacing → speed, the AI's style read |
| `stock.py` | Pexels/Pixabay stock B-roll for uncovered topics |
| `aiimage.py` | Optional FLUX.1-schnell image generation via mflux |
| `motion.py` | Motion Studio bridge: fills `{{PLACEHOLDER}}` spec templates, swaps in the client's brand.json under a cross-Mac mkdir lock, runs `node render.mjs --format mov` |
| `premiere_xml.py` | `Timeline`: FCP7 xmeml writer. `TRACKS` names the 13 video tracks; `add_video(track_name, …, zoom=, center=)`; tracks grow on demand |
| `media.py` | ffprobe helpers and `video_encoder()` (VideoToolbox on Macs, x264 elsewhere; `AUTOCUT_SOFTWARE_ENCODE=1` forces x264) |
| `preview.py` | Flattens a Timeline to an H.264 preview with ffmpeg |
| `jobs.py` | Shared queue: atomic-rename `claim()`, `status.json` per job, `Worker` thread |
| `app.py` | stdlib HTTP server + JSON API used by `web/index.html`. Path-guarded file serving (`safe_path`), the sign-in gate, security headers, chunked uploads (`_store_chunk`) |
| `auth.py` | Web-hosted sign-in: users.json (PBKDF2), roles admin/editor, sessions, lockout, setup code, audit log |
| `package.py` | "Download for Premiere": job zip with the XML re-pointed at /Users/Shared/AutoCut-Downloads/<job>/media |
| `web/index.html` | The whole dashboard (vanilla JS, no build step). Every request goes through `api()` / `putFile()` (they add the `X-AutoCut` header) |
| `web/login.html` | Sign-in page (and first-admin setup) for the hosted version |
| `macapp.py` | `rumps` menu-bar wrapper (✂). Falls back to the plain server off-Mac |
| `checks.py` | Brand-kit checks and machine "doctor" (structured results) |
| `config.py` | Settings layering: defaults ← repo `settings.yaml` ← `~/Library/Application Support/AutoCut/settings.yaml`. `DEFAULT_BRAND` holds every brand.yaml key and its default |
| `cli.py` | Command-line entry points |
| `content.py` + `content/` | Built to evolve (docs/EXTENDING.md): `catalog.json` (AI model tiers/prices, whisper, engine pins, experiment `features`) and **content packs** (`pack.json`: looks, storyboards, music_styles, style_fits, sfx_flavours, look_flavour, knowledge, catalog). `register(kind, dict)` merges packs into the engines' own dicts in place (looks.py, storyboards.py, composer.py, sfx.py, director.py call it); every entry is checked against what the built-ins use; `reload()`, `install_pack`, `set_enabled`, `feature()` |
| `updates.py` | Signed one-click updates (docs/RELEASING.md): feed.json + Ed25519 `.sig` verified with `release_key.pub`, SHA-256-pinned zip, new version's `selftest` before an all-or-nothing swap into the AutoCut folder (`.autocut-updates/versions` keeps roll-back copies), `restart()`, `rollback()`; git checkouts still use mac/update.sh |
| `accounts.py` | People's own ChatGPT (OpenAI) and Grok (xAI) accounts next to Claude: API key per person, "auto" model from the account's /models and catalog `ai.accounts` preferences, monthly caps (`brain.record`), `ask`, `image`, `test`. brain.ask order: local → compatible → `ai.cloud_order`; `prefer="cloud"` puts accounts first |
| `mcp.py` | AutoCut as an MCP connector (`autocut mcp`, stdio JSON-RPC): tools that drive the running dashboard over 127.0.0.1 (queue videos, jobs, motion graphics, graphics, music, Strategist); `install_claude_desktop()`. Docs: docs/AI-ACCOUNTS.md |
| `brandscan.py` | New client from a website: `scan(url)` (logo from JSON-LD/header/icons, colours from theme-color + CSS + logo, fonts from CSS/Google Fonts with TTF download, details, AI brief with rules fallback) → draft; `create(proposal)` writes brand.yaml with ruamel (comments kept). API `/api/clients/scan`, `/api/clients/from-scan` (drafts in `clients/_scans/`) |
| `stats.py` | Opt-in shared monthly totals: `consent()` (state.json), `row()` (numbers only from results.month), `maybe_send()` (daily from updates.background_check; once per month) to catalog `stats.url` (owner-set, not pack-changeable) or settings `stats_url`. API `/api/share-stats`. docs/STATS.md |
| `results.py`, `onboarding.py` | "Your month in AutoCut" (counts from ready jobs + Create/Graphics items, `ESTIMATES` for time saved, measured turnaround; pop-up once a month) and the welcome tour + Getting started checklist (state.json) |
| `hardware.py` | This computer: `profile()` (chip, cores, memory, Apple Silicon / NVIDIA, encoder, free disk), `tier()` light/standard/pro, `recommend()` (speech model, local AI, AI music), `whisper_model()` resolves `whisper.model: auto`, `benchmark()` (cached in hardware.json); This Mac → This computer |
| `ed25519.py`, `selftest.py`, `migrations.py` | Pure-Python signatures; `autocut selftest` (imports, content, XML, sound, signatures); one-time steps per version + What's new (`state.json`) |

Other parts of the repo:

| Path | Contents |
|---|---|
| `mac/` | `install.sh` (`--main` / `--join` / `--solo`), `join.sh`, `update.sh`, `build_app.sh` (makes `/Applications/AutoCut.app`, a bash launcher that runs `python -m autocut app`), `icon.png` |
| `templates/client/` | What a new client folder starts as |
| `deploy/` | Web hosting: `HOSTING.md` (Mac Studio + Cloudflare Tunnel, or Docker server), `docker-compose.yml`, `Caddyfile`, `entrypoint.sh`; `Dockerfile` is at the repo root |
| `examples/` | The demo client; copied into the data folder on first run |

Queue items beyond plain videos:

- `incoming/<name>.clip.json`: a clip from the Clips tab, handled by `Worker.process_clip`.
- `longform/<name>/.pending`: a long video (or several, from a dropped folder) waiting for analysis.
  A worker claims it by renaming it to `.claimed-<mac>`.
- `multicam/<name>/.pending`: a multicam project, claimed the same way. Output goes to `ready/<name>-multicam/`
  (with `multicam.json`, the render recipe that "Export MP4" uses).
- Dashboard uploads of projects: `POST /api/project/new` → `PUT /api/project/upload` per file → `POST /api/project/start`.
- Worker requests `__export__` (MP4 export) and `__mograph__` (Create-tab render).

## Data layout (not in git)

```
config.SHARED_ROOT/clients/<slug>/        (/Users/Shared/AutoCut on a Mac, C:\Users\Public\AutoCut on Windows)
  brand.yaml  assets/{fonts,logo,broll,music,endcard}/  motion/
  incoming/  footage/  ready/<video>/{status.json, job.json, log.txt, *.xml, captions.*, *.mov, preview.mp4}
```

## Adding a new effect

1. Add it to `EFFECTS` in `effects/__init__.py` and to `DEFAULT_BRAND["effects"]`.
   Add its settings block to `DEFAULT_BRAND` and document it in `templates/client/brand.yaml`.
2. Write `effects/<name>.py`. It finds moments (respecting `Occupancy`) and renders clips into the job's `fx/` folder.
3. Wire it into `pipeline.run_job`. Gate it on `fx["<name>"]`, give it its own track in `TRACKS`,
   and count it in `applied`.
4. Add a test in `tests/`. The dashboard picks the switch up automatically from `/api/effects`.

## Keeping AutoCut current

- New looks / storyboards / music styles / sound flavours / know-how: a **content pack** (`packs/<id>`, docs/EXTENDING.md),
  not code. New AI models: `content/catalog.json`. Never hard-code a model name or engine version elsewhere.
- Code changes ship as a **signed release**: bump the version, write the CHANGELOG section, commit, push a `v<version>`
  tag (`-beta` in the tag = beta channel). `.github/workflows/release.yml` tests, builds, signs (secret
  `AUTOCUT_RELEASE_KEY`) and publishes to the public releases repo's `feed` release. Never commit the private key.
  By hand: `tools/release.py build` + `publish-github` (docs/RELEASING.md, docs/OWNER-GUIDE.md).
- **Nothing central:** every feature runs on the user's own computer (no AutoCut server, no shared queue by default).
  Heavy defaults go through `hardware.py` ("auto"), never assume a big machine.
- Saved data changing shape → a migration in `migrations.py`. Something that could fail on a user's computer → a check
  in `selftest.py` (updates run it before switching). ROADMAP.md is the tech radar; keep it current.

## Rules and gotchas

- **New brand settings:** add every new brand key to `DEFAULT_BRAND` (config.py) and
  document it in `templates/client/brand.yaml`. Existing clients' files must keep working
  without the new key.
- **Python and dependencies:** Python 3.12 on the Macs. Prefer the standard library and avoid new
  dependencies. If you must add one, put it in `requirements.txt`; `update.sh` installs it.
- **XML file paths:** the XML references media by absolute path; build links with `premiere_xml.pathurl`
  (`file://localhost/C%3A/...` on Windows). Shared-queue Macs see the shared folder at the same path
  `/Users/Shared/AutoCut` (a symlink on the Minis). Don't break that.
- **Mac and Windows:** both are supported. Use `config.SHARED_ROOT` / `LOCAL_SETTINGS` for paths, never
  hard-code `/Users/...`; use `Path.replace` (not `rename`) to overwrite; guard OS-specific calls with
  `sys.platform`; encoders come from `media.video_encoder()` (VideoToolbox on a Mac, a test-run NVIDIA/Intel/AMD
  encoder on Windows, else libx264). Windows runs Python in UTF-8 mode (`__main__.py`, `windows/AutoCut.cmd`).
  Installers: `mac/install.sh`, `windows/install.ps1` (PowerShell 5.1 compatible, ASCII only).
- **Frame accuracy:** all timeline math is in frames at the sequence fps (`Timeline.frames`).
  NTSC rates use timebase + `<ntsc>TRUE`.
- **Premiere XML quirks:** Premiere ignores most FCP7 text/title generators. That's why
  captions and graphics are rendered video overlays, not XML text.
- **Fonts:** libass loads fonts from `assets/fonts` (via `fontsdir`). Premiere and Motion Studio
  need them installed on the computer (`app.install_fonts`: ~/Library/Fonts, or the per-user Windows Fonts folder).
- **Multiple Macs:** they process jobs at the same time. Any new shared state needs an atomic
  operation (rename / mkdir), not file locks.
- **Client data:** never commit it, and never put client names in code.
- **Dashboard API:** a change needs a matching update in `web/index.html` and a test in `tests/`.
- **Clip generator = 9:16 first:** its clips are watched on phones, vertically. Design, test and judge every
  Clip generator change at 1080x1920 first (framing, captions, graphics, safe zones under the TikTok/Reels/Shorts
  buttons and caption text); other shapes are optional extras and must never be the default.
- **Hosted security:** with `web.require_login` on, every route except /login, /api/login, /api/setup,
  /api/ping and /icon.png needs a session; changes need the `X-AutoCut: 1` header; anything that reads or
  writes machine settings, users or code is in `ADMIN_ONLY`. New endpoints: decide which group they're in, and
  never send a raw `fetch` from the dashboard (use `api()`/`putFile()`).
- **AI:** call `brain.ask()`, never Ollama or Claude directly, and always keep a rules-based fallback so
  AutoCut works with no AI. Marketing prompts start from `marketing.system_prompt(brand, task)` (task picks the
  knowledge files; keep each task's prompt small for the local model). New marketing know-how goes in `knowledge/`.
- **Test with variety, not only the roofing demo:** the owner wants tests that show range. For motion graphics run
  `tests/showcase/run.py` (five fictional brands: dentistry, gym, restaurant, real estate, SaaS; light and dark
  palettes, serif/condensed/mono fonts; every aspect ratio; tiers 1–4 from templates to a multi-scene promo) and add new
  cases there. Use the demo roofing client only for the footage-based pipelines that need its sample video.
- **Look:** no gray backgrounds in anything rendered (use `config.brand_backdrop`); on-screen text stays centred.
- **Commits:** bump `autocut/__init__.py` `__version__` for user-visible releases and add a line
  to CHANGELOG.md.
