Please install and start AutoCut on this Windows PC so I can beta test it today. Follow these steps in order. Run the commands yourself in the terminal (PowerShell). Explain briefly what each step is doing, because I'm not a developer.

## Context
- AutoCut is a local video-editing app: Python, ffmpeg, and a web dashboard. Everything runs on this PC; there's no server.
- It came to me as a zip from Triumphant Media. The extracted folder is called `AutoCut-Beta`, probably in `%USERPROFILE%\Downloads\AutoCut-Beta`. Inside it are `START HERE.md` (my guide), this file, and `autocut\` (the app).
- The app has its own installer, `autocut\windows\install.ps1`. Use that rather than installing things by hand. It uses winget to install Python 3.12, ffmpeg and Ollama (the free AI), then sets up a Python virtual environment, Start menu and Desktop shortcuts, and a speech model.

## Rules
- **Don't run anything as administrator and don't ask for my password.** If Windows shows an approval prompt (UAC) during a winget install, tell me to click **Yes**.
- **Don't edit AutoCut's code** unless I ask. If a step fails, show me the error, look at the logs, and suggest a fix before changing anything.
- **Long steps:** the installer can take 15–30 minutes, mostly downloads. Give commands enough time (use a long timeout, or run them in the background and check back) rather than giving up early.

## Steps

1. **Check this PC.** Run in PowerShell:
   ```
   Get-ComputerInfo -Property OsName, OsVersion, CsTotalPhysicalMemory
   Get-CimInstance Win32_VideoController | Select-Object Name
   Get-PSDrive C
   ```
   Tell me:
   - the Windows version (AutoCut needs Windows 10 or 11, 64-bit)
   - the memory and graphics card
   - the free disk space on C: (about 30 GB is needed)

   If there isn't enough space, stop and tell me.

2. **Find the package.** Look for `autocut\windows\install.ps1` under `%USERPROFILE%\Downloads\AutoCut-Beta`, the current folder, or the Desktop. If you only find the zip, extract it first:
   `Expand-Archive "$env:USERPROFILE\Downloads\AutoCut-Beta.zip" "$env:USERPROFILE\Downloads" -Force`.
   If you can't find it, ask me where I put it.

3. **Check winget.** Run `winget --version`. If it isn't found, stop and tell me to install **App Installer** from the Microsoft Store.

4. **Run the installer hands-free.**
   ```
   powershell -NoProfile -ExecutionPolicy Bypass -File "<package>\autocut\windows\install.ps1" -Yes
   ```
   - It copies AutoCut to `%USERPROFILE%\AutoCut` (an older copy there is renamed, not deleted) and unblocks the downloaded files.
   - `-Yes` answers every question with a safe default: the free AI is installed; starting at sign-in is skipped.
   - It installs Python 3.12, ffmpeg, Ollama and Node.js with winget, plus the HyperFrames motion graphics engine (about 250 MB), then AutoCut's Python packages, the free AI model (gemma3, 3–17 GB depending on memory), the shortcuts, and the speech model (~1.5 GB), then opens AutoCut.
   - Tell me roughly where it's up to as it goes.
   - If it fails, show me the last part of the output and diagnose it. Network hiccups: just re-run the same command; it's safe to repeat. If a winget install failed, a new PowerShell window sometimes helps (it picks up the new PATH).

5. **Check it's healthy.**
   ```
   cd $env:USERPROFILE\AutoCut
   .venv\Scripts\python -X utf8 -m autocut doctor
   ```
   Show me the results. Anything marked as a failure needs fixing before testing; warnings are fine (Motion Studio and AI image generation are Mac-only extras). Tell me whether hardware video encoding was found (NVIDIA, Intel or AMD). **HyperFrames motion graphics engine ready** must be a pass: if it isn't, run `.venv\Scripts\python -X utf8 -m autocut hyperframes-setup` (it needs `node --version` 22 or newer; `winget install OpenJS.NodeJS.LTS` if not, then open a new PowerShell window) and show me the output.
   Then check the AI once the app is running (step 6): `Invoke-RestMethod http://127.0.0.1:8765/api/ai`. `local.ready` should be true. If it isn't, start Ollama from the Start menu and run the `ollama pull` command the installer printed.

6. **Make sure the app is running.**
   - If `Invoke-RestMethod http://127.0.0.1:8765/api/ping` doesn't return `ok: True`, start it with `Start-Process "$env:USERPROFILE\AutoCut\windows\AutoCut.cmd" -WindowStyle Minimized`, wait about 10 seconds and try again.
   - If it still isn't up, run `.venv\Scripts\python -X utf8 -m autocut app --headless` in the AutoCut folder and show me its error output.

7. **Quick test run.** Run AutoCut once on the sample video that ships with it:
   ```
   cd $env:USERPROFILE\AutoCut
   .venv\Scripts\python -X utf8 -m autocut run examples\demo-roofing-co\sample\test-take-01.mp4 --client demo-roofing-co --transcript examples\demo-roofing-co\sample\test-take-01.transcript.json --preview
   ```
   - It should finish in a few minutes and print where the Premiere XML went.
   - Tell me how long it took. Then open the preview MP4 it made (in the same folder as the XML) with `Invoke-Item`.

8. **Open the dashboard:** `Start-Process http://127.0.0.1:8765`. Tell me:
   - **Short form edits** is where I drop talking-head videos.
   - **Motion graphic generator** makes graphics from a description.
   - **Long form editor** is for podcasts and interviews (one or more cameras).
   - **Clip generator** finds social clips in long videos.
   - The **Demo Roofing Co** client is ready to use.

9. **Finish** by telling me, in a few lines:
    - what got installed and where:
      - the app: `%USERPROFILE%\AutoCut`
      - my projects: `C:\Users\Public\AutoCut\clients`
      - the shortcut: **AutoCut** in the Start menu and on the Desktop
    - how to start and stop it: the AutoCut shortcut starts it (a small AutoCut window sits in the taskbar); closing that window quits it
    - anything that failed or was skipped

    Then point me to section 3 of `START HERE.md` (the test plan).

## While I'm testing
If I ask for help with a problem:
- read the relevant log first:
  - for short form edits, the job's `log.txt` in `C:\Users\Public\AutoCut\clients\<client>\ready\<video>\`
  - for long form and clip projects, `log.txt` in `...\multicam\<project>\` or `...\longform\<project>\`
- check the output of `autocut doctor`

If I ask for a bug report: first suggest the **Report a problem** button in AutoCut (top right), which zips the logs for me. Otherwise write one with:
- my steps
- what I expected
- what happened
- the relevant log lines
- the AutoCut version (`%USERPROFILE%\AutoCut\autocut\__init__.py`)
- the PC's Windows version, processor, memory and graphics card

`%USERPROFILE%\AutoCut\README.md` explains every feature, and `CLAUDE.md` maps the code. Read them if you need to understand how something works.
