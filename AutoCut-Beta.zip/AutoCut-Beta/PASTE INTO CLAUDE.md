Please install and start AutoCut on this Mac so I can beta test it today. Follow these steps in order. Run the commands yourself in the terminal. Explain briefly what each step is doing, because I'm not a developer.

## Context
- AutoCut is a local video-editing app: Python, ffmpeg, and a web dashboard with a menu-bar app.
- It came to me as a zip from Triumphant Media. The unzipped folder is called `AutoCut-Beta`, probably in `~/Downloads/AutoCut-Beta`. Inside it are `START HERE.md` (my guide), this file, and `autocut/` (the app).
- The app has its own installer, `autocut/mac/install.sh`. Use that rather than installing things by hand. It sets up Homebrew packages, a Python virtual environment, the `/Applications/AutoCut.app` launcher and a speech model.

## Rules
- **Don't use `sudo` and don't type or ask for my password.** If something needs my password (only installing Homebrew should), stop and tell me the exact command to run myself in Terminal.
- **Don't edit AutoCut's code** unless I ask. If a step fails, show me the error, look at the logs, and suggest a fix before changing anything.
- **Long steps:** the installer can take 15–30 minutes, mostly downloads. Give commands enough time (use a long timeout, or run them in the background and check back) rather than giving up early.

## Steps

1. **Check this Mac.** Run `sw_vers`, `uname -m` and `df -h ~`. Tell me:
   - the macOS version
   - whether it's Apple Silicon (`arm64`) or Intel
   - the free disk space

   AutoCut needs macOS 13 or newer and about 30 GB free (it downloads a free AI model sized to this Mac's memory). Intel works but is slower. If there isn't enough space or macOS is too old, stop and tell me.

2. **Find the package.** Look for `autocut/mac/install.sh` under `~/Downloads/AutoCut-Beta`, the current folder, or `~/Desktop`. If you can't find it, ask me where I unzipped it.

3. **Check Homebrew.** Run `brew --version`. If brew isn't found, try `eval "$(/opt/homebrew/bin/brew shellenv)"` (Apple Silicon) or `eval "$(/usr/local/bin/brew shellenv)"` (Intel), then check again.
   If it's still not installed, **stop** and tell me to run this myself in Terminal, typing my password when asked:
   ```
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   ```
   After I say it's done, continue.

4. **Copy AutoCut into place.**
   - If `~/AutoCut` already exists, rename it to `~/AutoCut-old-<date-time>`; don't delete it.
   - Copy and unblock:
     ```
     ditto "<package>/autocut" ~/AutoCut
     xattr -dr com.apple.quarantine ~/AutoCut
     ```

5. **Run the installer hands-free.**
   ```
   bash ~/AutoCut/mac/install.sh --solo --yes
   ```
   - `--solo` sets up a single Mac with no network sharing.
   - `--yes` answers every question with a safe default and shows no pop-up dialogs. AI image generation and starting at login are both skipped; I can turn them on later.
   - It installs ffmpeg, Python 3.12, git and node with Homebrew, then the HyperFrames motion graphics engine (about 250 MB), then AutoCut's Python packages, the free AI brain (Ollama plus a gemma3 model, 3–17 GB), builds `/Applications/AutoCut.app`, downloads the speech model (~1.5 GB) and opens the app.
   - Tell me roughly where it's up to as it goes.
   - If it fails, show me the last part of the output and diagnose it. Common causes: network hiccups (just re-run the same command; it's safe to repeat) and a Homebrew package that needs `brew update` first.

6. **Check it's healthy.**
   ```
   cd ~/AutoCut && .venv/bin/python -m autocut doctor
   ```
   Show me the results. Anything marked as a failure needs fixing before testing; warnings are fine. A warning about Motion Studio is expected, because it's an optional separate tool. **HyperFrames motion graphics engine ready** must be a pass: if it isn't, run `cd ~/AutoCut && .venv/bin/python -m autocut hyperframes-setup` (it needs `node --version` 22 or newer; `brew install node` if not) and show me the output.
   Then check the AI: `curl -s http://127.0.0.1:8765/api/ai` once the app is running (step 7). `local.ready` should be true. If it isn't, run `brew services start ollama` and the `ollama pull` command the installer printed.

7. **Make sure the app is running.**
   - If `curl -s http://127.0.0.1:8765/api/ping` doesn't return `{"ok": true}`, run `open /Applications/AutoCut.app`, wait about 10 seconds and try again.
   - If it still isn't up, start it in the background with `~/AutoCut/.venv/bin/python -m autocut app --headless` and check again. If that fails, show me its error output.

8. **Quick test run.** Run AutoCut once on the sample video that ships with it:
   ```
   cd ~/AutoCut && .venv/bin/python -m autocut run examples/demo-roofing-co/sample/test-take-01.mp4 \
     --client demo-roofing-co --transcript examples/demo-roofing-co/sample/test-take-01.transcript.json --preview
   ```
   - It should finish in a few minutes and print where the Premiere XML went.
   - Tell me how long it took. Then open the preview MP4 it made (in the same folder as the XML) with `open`.

9. **Open the dashboard:** `open http://127.0.0.1:8765`. Tell me:
   - **Short form edits** is where I drop talking-head videos.
   - **Motion graphic generator** makes graphics from a description.
   - **Long form editor** is for podcasts and interviews (one or more cameras).
   - **Clip generator** finds social clips in long videos.
   - The **Demo Roofing Co** client is ready to use.

10. **Finish** by telling me, in a few lines:
    - what got installed and where:
      - the app: `~/AutoCut`
      - my projects: `/Users/Shared/AutoCut/clients`
      - the launcher: `/Applications/AutoCut.app`
    - how to start and stop it: open AutoCut from Applications, use the ✂ menu-bar icon → **Open Dashboard** / **Quit AutoCut**
    - anything that failed or was skipped

    Then point me to section 3 of `START HERE.md` (the test plan).

## While I'm testing
If I ask for help with a problem:
- read the relevant log first:
  - for short form edits, the job's `log.txt` in `/Users/Shared/AutoCut/clients/<client>/ready/<video>/`
  - for long form and clip projects, `log.txt` in `.../multicam/<project>/` or `.../longform/<project>/`
- check the output of `autocut doctor`

If I ask for a bug report: first suggest the **Report a problem** button in AutoCut (top right), which zips the logs for me. Otherwise write one with:
- my steps
- what I expected
- what happened
- the relevant log lines
- the AutoCut version (`~/AutoCut/autocut/__init__.py`)
- my Mac model and macOS version

`~/AutoCut/README.md` explains every feature, and `~/AutoCut/CLAUDE.md` maps the code. Read them if you need to understand how something works.
