# AutoCut beta: start here

Thanks for beta testing AutoCut for Triumphant Media.

AutoCut is a video editor that runs entirely on your own computer, a Mac or a Windows PC. There's no server, no cloud uploads and no per-video costs. Each computer runs on its own, with its own clients and footage.

- **Raw footage in:** talking-head videos, podcasts, interviews, streams.
- **Edits out:** a Premiere Pro rough cut (an XML file you import), a preview MP4, and optionally a finished MP4.
- **What it does:**
  - cuts ums and pauses
  - adds brand-styled captions, B-roll, motion graphics and storyboard cutaways
  - edits multi-camera podcasts
  - finds short social clips in long videos
  - generates motion graphics from a text description
  - designs on-brand social graphics: posts, stories, thumbnails, ads and carousels
  - cleans up voices (Studio Sound) and drops retakes

This package contains:

| File / folder | What it is |
|---|---|
| `START HERE.md` | This guide: what you need, how to install, what to test, how to report problems |
| `PASTE INTO CLAUDE.md` | For a Mac: instructions for Claude Code. Paste it in and Claude installs and starts AutoCut for you |
| `PASTE INTO CLAUDE (Windows).md` | The same, for a Windows PC |
| `autocut/` | The app itself (code, demo client, sample video) |

---

## 1. What you need

- **A Mac** with **macOS 13 (Ventura) or newer**, ideally Apple Silicon (M1–M4). Intel Macs work, but transcription and rendering are slower.
- **Or a Windows 10 or 11 PC** (64-bit), ideally with 16 GB+ of memory and an NVIDIA, Intel or AMD graphics chip for fast rendering.
  An NVIDIA card also speeds up transcription. Without one, it all still works on the CPU, just slower.
- **About 30 GB of free disk space:** tools, a 1.5 GB speech model, the free AI model (3–17 GB depending on
  your Mac's memory), and room for renders.
- **Mac only: your Mac password**, once, to install Homebrew (the standard Mac tool installer) if you don't have it.
  On Windows, the installer uses winget, which is built in; Windows may ask you to approve each install.
- **About 30 minutes** for the first install. Most of that is downloads that run on their own.
- **Optional:**
  - **Adobe Premiere Pro**, to open the rough cuts. Without it you can still watch the previews and export MP4s.
  - **Some of your own footage:** a 1–2 minute talking-head clip, a 10–20 minute podcast or stream, and, if you have one, a two-camera interview with separate mic recordings.

## 2. Install

> Every computer is independent: install AutoCut on each one the same way. Nothing is shared between them
> and no server is needed. On a **Windows PC**, skip to **Windows** below.

### Option A: let Claude do it (recommended)

You need **Claude Code**: either the terminal version, or the **Code** section of the Claude desktop app.
An ordinary Claude chat in the browser can't run commands on your Mac, so it can't install this.
Setup instructions for Claude Code: https://code.claude.com/docs

1. Unzip the package (double-click the .zip). Leave the unzipped **AutoCut-Beta** folder in **Downloads**.
2. **Install Homebrew yourself first**, if you don't have it. Claude can't type your password.
   - Open **Terminal** (⌘-Space, type "Terminal").
   - Run: `brew --version`. If it prints a version number, skip to step 3.
   - If not, paste this, press Return, and type your Mac password when asked (the cursor doesn't move while you type; that's normal):
     ```
     /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
     ```
   - When it finishes, it prints two or three "Next steps" commands. Run them; they put `brew` on your path.
3. Start Claude Code in Terminal from the package folder:
   ```
   cd ~/Downloads/AutoCut-Beta
   claude
   ```
   (In the desktop app, open the **AutoCut-Beta** folder as the project instead.)
4. Open **PASTE INTO CLAUDE.md**, copy everything in it, paste it into Claude, and press Return.
5. Approve the commands Claude asks to run. The install takes 15–30 minutes, mostly downloads.
   Claude tells you when it's done and opens the AutoCut dashboard in your browser.

### Option B: do it yourself

1. **Got the .dmg?** Double-click it; **Install AutoCut** is right there (it copies AutoCut to your home folder, so
   you can eject the disk image afterwards). **Got the .zip?** Unzip it and open the **autocut** folder inside.
2. **Right-click → Open** on **Install AutoCut**. Use right-click the first time, because macOS asks about files from the internet. Click **Open** again if asked.
3. Choose **On its own**. Answer the questions; the defaults are fine. Type your Mac password when asked.
4. When it finishes, a **✂** appears in the menu bar. Click it, then **Open Dashboard**.

### Windows

**With Claude:** start Claude Code (terminal or desktop app) in the unzipped **AutoCut-Beta** folder, then paste in
everything from **PASTE INTO CLAUDE (Windows).md**. Claude installs and starts AutoCut.

**Yourself:**
1. Right-click the zip → **Extract All…**. (Don't run it from inside the zip.)
2. Open **AutoCut-Beta → autocut** and double-click **Install AutoCut (Windows).cmd**.
   If Windows shows "Windows protected your PC", click **More info → Run anyway**.
3. Answer the questions in the window; the defaults are fine. Approve the installs Windows asks about.
   It takes 15–30 minutes, mostly downloads (Python, ffmpeg, the free AI and the speech model).
4. When it's done, AutoCut opens in your browser. From then on, start it from the **AutoCut** shortcut in the
   Start menu or on the Desktop. A small AutoCut window sits in the taskbar while it runs; **close that window to quit AutoCut**.

### Afterwards

- **Mac:** AutoCut lives in `~/AutoCut`. Your projects and renders live in `/Users/Shared/AutoCut/clients`.
- **Windows:** AutoCut lives in `%USERPROFILE%\AutoCut`. Your projects and renders live in `C:\Users\Public\AutoCut\clients`.
- **New versions** come as a new package: install it the same way. Your clients, footage and settings are kept.
- **To start it:** open **AutoCut** from Applications. A ✂ appears in the menu bar; choose **Open Dashboard**.
  You can also open http://127.0.0.1:8765 in your browser while AutoCut is running.
- **To stop it:** ✂ → **Quit AutoCut**. (Windows: the Start menu shortcut starts it; close the AutoCut window in the taskbar to stop it.)

---

## 3. What to test

Work through these in order. Each tab is named across the top of the dashboard.
A **Demo Roofing Co** client is already set up, so you can start straight away.
For each item, note anything that's broken, confusing, slow, or ugly.

### Short form edits (talking-head videos)
1. Pick **Demo Roofing Co**. Drop in a 1–2 minute talking-head video of yourself; phone footage is fine.
2. Watch the status column. Note **how long it takes** from drop to "done".
3. Click **Preview**. Check:
   - **Cuts:** ums and pauses removed, nothing important cut.
   - **Captions:** correct words, centred, readable.
   - **Story cutaways:** when you describe something (for example "the storm hits, water gets in, then mould"), a storyboard of icons should animate in, with you framed in a corner.
4. Record a take where you **say a sentence, mess it up, and say it again** (reworded is fine). Is only your last take kept?
   **Studio Sound** is on by default: does your voice sound cleaner than the raw file? (Turn it off under Re-run with changes to compare.)
5. **More ▾ → Edit transcript.** Click a word to cut or restore it, then **Save & re-cut**. Did the change apply?
6. **More ▾ → Re-run with changes…** Switch some effects off and on (Story cutaways, Pop-up stickers, Subject cutout…). Do the switches do what they say?
7. Tick **Also make → Square 1:1** on an upload. Do you get a square version too?
8. **More ▾ → Export finished MP4.** Does the exported file look and sound right?
9. If you have Premiere: **Show XML**, then in Premiere **File → Import** that XML. Does the sequence open with the clips, captions and graphics on their tracks?

### The AI (check this first)
1. Open **This Mac** (**This PC** on Windows) and look at **AI brain**. It should say the free local AI is running, with a model name.
   If not, tell whoever set this up; AutoCut still works without it, but clip picks and post copy are basic.
2. After any edit finishes: **More ▾ → Post copy**. Are the hooks, titles and captions something you'd actually post?

### Motion graphic generator
It uses the **HyperFrames** engine (Details → Engine says so). If it only offers "Classic", HyperFrames didn't install;
see section 5.
1. Make a client for a business you know (Clients → New client, with its colours), then pick it as the **Brand**.
2. Try: `lower third for 'Your Name' 'Beta Tester' in square and vertical` (use your own name), then **Generate**.
3. Try: `stat counter '$1,250,000' 'sold in 9 days' vertical` and `slam 'NO EXCUSES' vertical`. Does everything stay inside the frame?
4. Try: `kinetic typography 'Six weeks. / *Zero* shortcuts. / Real strength.' vertical`.
5. **Custom designs:** `custom: animated bar chart, monthly sales Jan 40 Feb 55 Mar 80, landscape`, then something of your
   own (a 3-step process, a price card, a list). This works best with a Claude key (This Mac → AI brain). Without one,
   the free local AI tries. Tell us what you asked for and how close it came.
6. **Edit in Studio:** on a finished graphic, click **Edit in Studio**. HyperFrames Studio opens in your browser. Change a word
   or a timing, then come back and press **Re-render**. Did your change make it into the new file?
7. Drop a **reference**: a screenshot or short clip of a graphic style you like, then Generate. Does it pick up the colours and the feel?
8. Drop the **.mov** onto a Premiere/Final Cut/Resolve/CapCut timeline over footage. Is the background transparent?
9. **Look book:** pick each of your clients. Does each get a different look that suits the business? Press **Preview
   this look**. Try **Shuffle** and changing the look. Then make a lower third and a chart for two different clients:
   do they look clearly different?
10. **Charts and storyboards:** `bar chart 'Leads by source' Google 42, Referrals 31, Instagram 18 landscape`. Then in
   **Storyboard** pick a structure, write one line about a real offer or event, **Plan scenes**, fix anything, render.
   Would you post it?
11. **Music & sound:** in **Music & sound** pick a client and Compose. Does it fit the business? Try two clients: do
   they sound different? Then run a short-form edit and import its XML into Premiere: is the dialogue on A1, the
   sound effects on A2 and the music on A3? Are the effects on the right moments, and is the music under the voice?
12. **Your logo, fonts & graphics:** drop your logo, a font file (TTF/OTF from your brand kit) and an image or two into
   that drop zone, then make a graphic. Does it use your font and logo?
13. **Transcript to video:** paste a 30–60 second script into **Transcript to video** (or drop an SRT, or a voice memo
    or video of you talking), pick sizes, add a call to action, **Make video**. Do the words appear as they're said?
    With a recording: is the voice in sync? Name one of your images after a word in the script (e.g. `menu.png` and say
    "menu"): does it appear at that moment?

### Graphics (still designs for social)
1. Pick a **Brand**, then try: `Instagram post and story: 'Free consultation' this week only, book online` → **Design**.
2. Try a **YouTube thumbnail** with a photo of a person (or a video: AutoCut takes a frame). Is the person cut out cleanly?
3. Try a **carousel**: `carousel: 5 mistakes first-time clients make`. Do the slides read well in order? Is there a PDF?
4. Tick several **Sizes** and all three **Looks**. Does every version look designed, not squashed?
5. **Bulk create:** make a spreadsheet with columns `headline,offer,cta` (one row per ad), save it as CSV, and use it.
6. **Your own images:** drop a product photo, a photo of real work, your logo and an image whose colours you like.
   Check each one's role, then press **Design**. Is the product cut out cleanly? Do the colours follow your reference?
7. **Strategist** (top right): pick a client and try **20 hooks**, **Video script** and **30-day plan**. Is the advice
   specific and usable? Would you post it?

### Long form editor (podcasts and interviews)
1. Drop **all the files from one shoot together**: each camera, plus any separate mic or recorder audio, plus a screen recording if there is one.
2. When it says **edited**, click **Open** and check:
   - **Sync:** do the cameras line up with the sound?
   - **Who's who:** does each person's voice go with the camera that shows them? Fix any mistakes and **Re-edit**.
   - **Cutting:** does it cut to whoever is talking, without flicking back and forth too fast?
   - **Ums and pauses:** they should be **kept** by default. Turn on **Cut ums & ahs** and **Re-edit**. Does that work?
   - **Voice from:** change which mic or recorder channel belongs to a person, then **Re-edit**. Does the camera follow the right voice?
   - **Wide shots:** try **More often** and **Less often**. Can you feel the difference?
   - **Studio Sound** (on by default): does the dialogue sound cleaner? Turn it off and compare.
   - **Screen recording:** if you included one, does it appear as picture-in-picture with the speaker in the corner?
3. Try a **single-camera** long video too.

### Clip generator (social clips from long videos)
1. Drop a 10–20 minute podcast or stream. Wait for **clips found**, then **Choose clips**.
   Then drop it again with **Find clips about…** filled in (a topic from the video). Are the clips on that topic now?
2. Are the top-scored clips actually the best moments? Do the AI's reasons make sense? Click one of the hook
   options under a clip to use it as the title, and try the ±1 s trim buttons.
3. **Make selected clips** in **Vertical 9:16**. With two people on camera, does it jump between speakers?
4. Drop a **folder** containing two videos. Does it become one project?
   Then drop **two folders** at once. Do you get two projects?

### Clients
1. **New client:** add your own (or a made-up) brand: logo, colours, fonts.
2. **Make caption sample.** Does it look on-brand?
3. Run a short video for that client. Are the brand colours and fonts used throughout?

### General
- Is anything on screen **gray, off-centre, or misaligned**?
- Is any wording confusing?
- Note how long each kind of job takes, along with your computer: Mac model (Apple menu → About This Mac), or on Windows the processor, memory and graphics card (Settings → System → About).

---

## 4. Reporting problems

**Easiest:** click **Report a problem** (top right of AutoCut), describe what happened, and press **Make the report**.
It saves one zip to your Desktop with AutoCut's version, your computer's details, the health check and the logs of your
latest jobs (no footage). Attach it to a reply to the email this package came with.

Otherwise, reply to that email and include:

1. **Which tab** and **what you did**: the steps, and the file you used (length, camera, format).
2. **What you expected** and **what happened.**
3. **A screenshot or screen recording** if it's visual.
4. **The log:** in Short form edits, **More ▾ → Log** on that job. In Long form editor and Clip generator, the project's `log.txt` is in `<clients folder>/<client>/multicam/<project>/` or `.../longform/<project>/` (the clients folder is under **Afterwards** above).
5. **Your AutoCut version and computer:** shown in **This Mac** / **This PC**. If you're using Claude, ask it to run AutoCut's `doctor` check (`~/AutoCut/.venv/bin/python -m autocut doctor` on a Mac, `%USERPROFILE%\AutoCut\.venv\Scripts\python -m autocut doctor` on Windows) and include the output.

If you're working with Claude, you can also just say "write up a bug report for what just happened". It can read the logs for you.

## Your computer does the work

AutoCut runs entirely on your own computer: nothing is uploaded to a server, and how fast it works depends on your
machine. **This Mac / This PC → This computer** shows what your computer handles well, and **Run a speed test** gives
a rough time for a 10-minute video. AutoCut picks its heavier settings (speech model, local AI size) to fit.

| | Works | Recommended |
|---|---|---|
| Mac | Apple Silicon (M1 or newer), 8 GB memory | M-series Pro/Max or newer, 16 GB+ |
| Windows | Windows 10/11 64-bit, 8 GB memory | 16 GB+, an NVIDIA graphics card |
| Free space | 30 GB | 100 GB+ (footage and renders) |

## 5. If something goes wrong

| Problem | Fix |
|---|---|
| The dashboard says **"AutoCut is not running"** | Open AutoCut from Applications (✂ in the menu bar), or in Terminal: `~/AutoCut/.venv/bin/python -m autocut app` |
| macOS says the installer "can't be opened" | Right-click → **Open** instead of double-clicking |
| Motion graphics only offer the **Classic** engine | HyperFrames isn't set up. Mac: `~/AutoCut/.venv/bin/python -m autocut hyperframes-setup`; Windows: `%USERPROFILE%\AutoCut\.venv\Scripts\python -m autocut hyperframes-setup` (needs Node.js 22+, which the installer adds) |
| **Edit in Studio** opens but animations don't play | Studio loads a few animation add-ons from the internet; check your connection. Rendering doesn't need it |
| A job is stuck on "processing" for a long time | **This Mac** shows if the Mac is busy. Long podcasts take a while the first time; check the job's Log |
| No ✂ in the menu bar | Open http://127.0.0.1:8765 directly. If that fails, start it from Terminal as above and send the error |
| Need to start over | Quit AutoCut, delete `~/AutoCut`, and install again. Your projects in `/Users/Shared/AutoCut` stay |
| **Windows:** "Windows protected your PC" | **More info → Run anyway** |
| **Windows:** the AutoCut shortcut does nothing | Open http://127.0.0.1:8765. If that fails, double-click `windows\AutoCut.cmd` in `%USERPROFILE%\AutoCut` and send what the window says |
| **Windows:** rendering is slow | **This PC** shows whether the graphics chip is used for encoding. Without NVIDIA, Intel or AMD encoding, the CPU does it |
| You want more AI power | **This Mac / This PC → AI accounts**: connect your own Claude, ChatGPT or Grok API key (each with a monthly cap). Or add AutoCut to Claude Desktop under **Use AutoCut from your AI app** and ask Claude to make graphics or queue footage |
| You want the newest AutoCut | **This Mac / This PC → Updates**. From 0.21, once the agency's update address is set there, new versions install with one click (and **Roll back** undoes one) |
| **Windows:** need to start over | Close AutoCut, delete `%USERPROFILE%\AutoCut`, install again. Projects in `C:\Users\Public\AutoCut` stay |

Thanks again. Your feedback decides what gets fixed before the team uses this on client work.
