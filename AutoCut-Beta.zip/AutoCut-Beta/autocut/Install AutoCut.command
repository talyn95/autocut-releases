#!/bin/bash
# Double-click to install AutoCut on this Mac. (First time: right-click → Open.)
cd "$(dirname "$0")" || exit 1
HERE="$(pwd)"
clear
echo "AutoCut installer"
echo "================="

# Every Mac runs on its own by default: its clients, footage and finished work stay on this Mac.
ROLE=$(osascript -e 'button returned of (display dialog "How should this Mac run AutoCut?" & return & return & "• On its own (recommended): everything stays on this Mac. Nothing is shared and no server is needed." & return & return & "• Office server: this Mac holds a queue that other Macs on the office network share (see the guide)." buttons {"Cancel", "Office server", "On its own"} default button "On its own" with title "Install AutoCut" with icon note)' 2>/dev/null)
case "$ROLE" in
  "On its own") MODE=--solo ;;
  "Office server") MODE=--main ;;
  *) echo "Cancelled."; exit 0 ;;
esac

DEST="$HOME/AutoCut"
if [ "$HERE" != "$DEST" ]; then
  if [ -e "$DEST" ]; then
    OLD="$HOME/AutoCut-old-$(date +%Y%m%d-%H%M%S)"
    echo "Moving the previous copy to $OLD"
    mv "$DEST" "$OLD"
  fi
  echo "Copying AutoCut to $DEST"
  ditto "$HERE" "$DEST"
fi
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null
bash "$DEST/mac/install.sh" $MODE
echo
read -r -p "All done — press Enter to close this window."
