# Client onboarding: building a brand kit

Every new client gets a brand kit before their first video goes through AutoCut.
It takes 20–30 minutes once you have their files, and every video after that uses it.

## 1. What to collect from the client

| Item | What exactly | Why |
|---|---|---|
| **Logo** | Transparent **PNG** (1000 px+ wide) and **SVG** if they have it. Light and dark versions if they exist. | Watermark, end card, Motion Studio logo builds (SVG) |
| **Colours** | Hex codes: primary, secondary, accent, plus text colour. Get them from the brand guide; don't colour-pick a JPEG. | Caption highlight, end card, motion graphics |
| **Fonts** | The actual **.ttf/.otf files** for the headline and body fonts, or the Google Font name. Adobe Fonts / licensed fonts must be activated on each editing Mac. | Captions, CTA, titles |
| **CTA** | Main call to action and the secondary line ("Book your free estimate" / "Link in bio"). Seasonal CTAs too. | End card + CTA outro |
| **Spokesperson** | Name and title for the lower third (e.g. "Jordan Reyes, Owner"). | Lower third |
| **Icons / stickers** | Optional: their own icons or emoji-style art as transparent PNGs. | Pop-up stickers |
| **Keywords** | 5–15 words or offers they want emphasised (e.g. *free*, *same-day*, *financing*). | Caption highlight words, Motion Studio word triggers |
| **B-roll** | Every clip of their business, team, jobs, products. Phone footage is fine. | Cutaways |
| **Music** | Licensed tracks they own, or pick from your licensed library. | Music bed |
| **Platforms** | Where videos run (Reels/TikTok = vertical, YouTube = landscape, Feed = 4:5). | `format` |
| **Don'ts** | Words, colours, competitors or claims to avoid. | Notes in brand.yaml |

### Request email you can send

> Hi {{name}}, to set up your video brand kit we need:
> 1. Your logo as a transparent PNG (and SVG if you have one)
> 2. Your brand colours (hex codes, e.g. #E63946) or your brand guide PDF
> 3. Your font files, or the font names if they're Google Fonts
> 4. Your main call to action (what should viewers do at the end of every video?)
> 5. Any photos/video of your team, jobs, location or products for B-roll
>
> You can drop everything into this folder: {{upload link}}

## 2. Build the kit (in the AutoCut dashboard)

1. **Clients** tab → type the client name → **Add**.
2. Add their files in the **Media library** (drag and drop, pick a category first), or
   **Open folder** to put them in place in Finder:

   | Put this | Here |
   |---|---|
   | Font files | **Fonts** category, then **Install fonts on this Mac** on every editing Mac |
   | Logo | `assets/logo/logo.png` |
   | B-roll | `assets/broll/`, renamed descriptively: `crew-installing-shingles.mp4`, not `IMG_4412.MOV` |
   | Music (optional) | `assets/music/` |

3. In the dashboard's brand kit editor, set:
   - `colors`
   - `fonts`: the family name exactly as Font Book shows it
   - `cta.text` / `cta.subtext`
   - `captions.highlight_words` (their keywords)
   - `vocabulary`: business name, owner names, towns, products
   - `format`

   Then **Save**. The check list above the editor updates. Fix every ✗.
4. **Make caption sample** renders a 5-second sample of their caption style. Send it to
   the client for sign-off. It's saved in their folder under `ready/_style-proof/`.
   If they want changes, edit `captions`, save, and make a new sample.

## 3. Motion Studio pieces (optional, recommended)

1. In Motion Studio (`/Users/Shared/AutoCut/motion-studio`), put the client's colours, fonts and SVG logo in `brand.json`.
   Copy that file to `clients/<client>/motion/brand.json`.
2. Build the recurring pieces once: a hook title, a keyword burst, a CTA outro.
   Copy each finished spec into `clients/<client>/motion/` and swap the changing text for
   `{{HOOK}}`, `{{CTA_TEXT}}`, `{{WORD}}`, etc.
3. In `brand.yaml`, set `motion_studio.enabled: true` and list the pieces with their placements.
4. Save. The dashboard checks that the pieces and the studio are found.

## 4. First video

1. In **Short form edits**, pick the client and drop their first real video.
2. Watch the **Preview**, then adjust `edit.max_pause`, caption size/position and B-roll frequency.
3. Click **Re-run**. It reuses the transcript, so it's quick.

From then on, anyone can drop footage for that client on any Mac.

## Brand-kit sign-off checklist

- [ ] Logo PNG (transparent) + SVG
- [ ] Colours confirmed as hex
- [ ] Fonts installed on every editing Mac + in `assets/fonts`
- [ ] CTA text approved by client
- [ ] Highlight keywords listed
- [ ] 20+ B-roll clips, descriptively named
- [ ] Dashboard shows **brand kit ready**
- [ ] Caption style proof approved by client
- [ ] Motion Studio brand.json + templates (if used)
