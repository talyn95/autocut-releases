# AutoCut

A Mac and Windows app for Triumphant Media that turns raw talking-head footage into a
Premiere Pro rough cut in each client's brand:

- **Cuts:** ums, uhs, stutters and dead air removed
- **Kinetic captions:** in the client's fonts and colours
- **B-roll:** cutaways matched to what's being said
- **Logo watermark** and **CTA end card**
- **Motion graphics:** Kinetik Motion Studio pieces
- **Music bed** (optional)

Editors import one XML file and finish the last 20–25 %.

Everything runs on each computer by itself (Mac or Windows PC). There's no server, no cloud and no
Claude tokens per video, and no footage leaves the computer it was dropped on.

---

## How it runs

Each computer is **independent**: install AutoCut on it and it does everything itself (transcription,
cutting, rendering, the free AI). Its clients, footage and finished work stay on that computer:

| | App | Clients, footage, renders | This computer's settings |
|---|---|---|---|
| **Mac** | `~/AutoCut` | `/Users/Shared/AutoCut/clients` | `~/Library/Application Support/AutoCut/settings.yaml` |
| **Windows** | `%USERPROFILE%\AutoCut` | `C:\Users\Public\AutoCut\clients` | `%APPDATA%\AutoCut\settings.yaml` |

To use the same client on two computers, copy its folder from one clients folder to the other.

## Install

See **INSTALL.md**:

| Computer | What to do |
|---|---|
| **Mac** | Double-click **Install AutoCut** (right-click → Open the first time) → **On its own** |
| **Windows PC** | Double-click **Install AutoCut (Windows).cmd** |
| **Phones, iPads** | Optional: open a computer's dashboard address (**This Mac → Add another device**) |

The installers set up everything (Homebrew on a Mac, winget on Windows). Under the hood they run
`mac/install.sh --solo` and `windows/install.ps1`. New versions: install the new package the same way.

### Sharing one queue between Macs (optional, older setup)

A Mac can be an **office server** instead (`mac/install.sh --main`): it shares `/Users/Shared/AutoCut` over SMB,
other Macs join with `mac/join.sh`, every Mac watches the same queue and the next free Mac claims each video.
Updates then come from `/Users/Shared/AutoCut/code.git` (**This Mac → Update AutoCut**). Windows PCs don't join this.

## Using it

Open **AutoCut** (in Applications, or it starts at login). A **✂** appears in the menu bar.
**Open Dashboard** gives you these tabs:

| Tab | What it's for |
|---|---|
| **Short form edits** | Pick a client, drag videos in, watch progress. Then **Show XML** (opens Finder on it), **Preview**, **Log**, **Re-run**. Finished long-form edits and clips are listed here too. |
| **Motion graphic generator** | Describe a motion graphic and render it in any size (below). |
| **Long form editor** | Whole podcasts and interviews, one camera or several (below). |
| **Clip generator** | Long videos into short social clips (below). |
| **Clients** | Add a client, check their brand kit, edit colours/captions/CTA/pacing, make a caption sample for sign-off, open their folder to add fonts, logo and B-roll. |
| **This Mac** | Health check, AI brain, music & sound, **Updates** (one-click signed updates, What's new, roll back), **Content packs**, settings for this Mac only. |

Instead of the dashboard, you can drop footage straight into
`/Users/Shared/AutoCut/clients/<client>/incoming/` in Finder.

### After a video is cut

Each row in **Rough cuts** has:

- **Show XML / Preview:** import into Premiere, or watch a quick draft.
- **Edit transcript:** the whole transcript with every cut struck out.
  - **Click** a word to cut it, or to bring back something AutoCut removed.
  - **⌥ Option-click** (long-press on a phone) fixes a caption typo.
  - **Save & re-cut** rebuilds the edit in about a minute; it never re-transcribes.
- **More ▾:**
  - **Export finished MP4:** a full-quality, ready-to-post video, no Premiere needed.
  - **Cover image:** a thumbnail of the speaker cut out over brand colour, with the hook text.
  - **Log**, **Re-run with changes…**, **Remove from list** (moved to `ready/.trash`).
- **Retry:** appears if a job failed, or if the Mac cutting it stopped responding ("stalled").

**Also make** (above the video drop zone) adds square, 4:5 and/or landscape versions of the same edit.
Each comes back as its own row, such as `video-square`.

AutoCut also does a few things on every video, with no switch needed:

- **False starts:** "we do a — we do a free inspection" keeps only the retake.
  Turn this off with `edit.remove_restarts: false` in the client's brand kit.
- **Dialogue levelling:** speech is set to -14 LUFS, the loudness Instagram, TikTok and YouTube expect.
  Change it with `audio.target_lufs`.
- **Notifications:** a Mac notification pops up when a video it cut is ready.

The numbers across the top of Short form edits show videos cut and an estimate of editing time saved.
The estimate assumes 4 minutes of editing per minute of footage; change it with
`minutes_saved_per_footage_minute` in settings.

### On the web (protected)

AutoCut can also run as a protected website (your own address, sign-in required, HTTPS) so the team can use
it from anywhere. Two routes: the Mac Studio behind a free Cloudflare Tunnel, or a server with Docker.
Everything, including the security it adds and step-by-step setup, is in [deploy/HOSTING.md](deploy/HOSTING.md).
Admins add people under **This Mac → Team**; in the browser, finished cuts have **Download for Premiere**.

### The AI brain (free, on your Macs)

AutoCut thinks with a free AI model that runs on each Mac (Ollama with Google's gemma3; the installer picks the
size for the Mac's memory and downloads it). Nothing leaves the office and it costs nothing. It:

- reviews clip candidates like a social media strategist: score, title, three hook options, why, best platform
- writes post copy for every finished video: titles, captions, hashtags, YouTube description and chapters,
  LinkedIn and Facebook posts (**More ▾ → Post copy**)
- reads motion-graphic prompts and studies reference images and videos

It works from a built-in marketing playbook plus each client's **marketing brief** (the `marketing:` section of
brand.yaml: audience, offer, voice, location, goals, platforms, hashtags, words to avoid). Fill that in for each
client; it's what makes the hooks and captions sound like them.

**Claude is the backup, not the default.** It's only used when the local model can't answer, or when someone
chooses "Use Claude" / "Rewrite with Claude", and only if a Claude API key is set. To set one up, add this under
**This Mac → Settings for this Mac only**:

```yaml
ai:
  claude_api_key: sk-ant-...
  claude_monthly_limit_usd: 25   # Claude stops being used for the rest of the month past this
```

**This Mac** shows whether the free AI is running and what Claude has cost this month. With no AI at all,
AutoCut still works: clips are scored by its built-in rules, and post copy is a plain draft.

### Clip generator: long podcasts and streams into short clips

The **Clip generator** works like Opus Clips, but everything runs on your Macs.

1. Pick a client, how many clips and roughly how long, then drop the long videos in. Each video
   is its own project. Drop **folders** to group: each folder is one project (folder 1 = project 1,
   folder 2 = project 2); a folder of folders gives one project per sub-folder. When a project holds
   several videos (part 1 and part 2 of a stream), the best moments from all of them are ranked together.
2. The next free Mac:
   - transcribes it
   - scores every sentence-aligned moment for viral potential (hook, energy, emotion, pace,
     payoff, completeness, length)
   - detects the layout
3. **Choose clips** lists the best moments with their scores and the reasons behind them. You can:
   - rename a clip (the name becomes its on-screen hook title)
   - change its layout
   - preview the exact segment
   - read its transcript
   - add your own clip by start and end time
4. Pick the shapes (9:16, 1:1, 4:5, 16:9) and effects, then **Make selected clips**. Every clip goes
   through the full AutoCut edit (filler removal, captions, motion graphics…) and lands in **Short form edits**,
   spread across all the Macs.

Layouts:

| Layout | For |
|---|---|
| **Jump between speakers** | Two or more people in a wide shot: simple jump cuts to whoever is talking (default when several people are found) |
| **Follow the speaker** | Single camera: crops to the speaker and follows them as they move |
| **Two speakers (stacked)** | Two people side by side, stacked top and bottom |
| **Facecam + gameplay** | Picture-in-picture: a facecam in a corner is detected, moved to the top, gameplay underneath |
| **Whole frame** | No one detected: the whole frame over a blurred background |
| **Centre crop** | A plain centre crop |

If a local AI model ([Ollama](https://ollama.com)) is running on a Mac, it also ranks the clips
and writes their titles.

### Long form editor: whole podcasts and interviews (multicam)

Drop every file from one shoot together: the cameras, any audio recorders (lav mics, Zoom/Tascam,
a mixer's multitrack) and any screen recording. Loose files dropped together are one project; drop
folders to queue several shoots at once (one project per folder).

The next free Mac:

1. **Syncs** everything by sound (no clapper needed; 10 ms accuracy). Files with no sound, such as
   most screen recordings, start at 0 unless you type a start time.
2. **Finds the voices**: separate audio files, or separate channels of one file (a two-lav recorder),
   each become a speaker. With one shared mic, each one-person camera stands for its person.
3. **Pairs voices with cameras** by matching when each mic is loud with when each camera's subject moves.
   A spare camera, or one with “wide” in its name, is the wide shot.
4. **Cuts** to whoever is talking: simple jump cuts with a shortest-shot length, the wide shot when both
   talk at once or nobody does, and a short cutaway in very long monologues. Cuts land between words.
5. **Picture-in-picture**: while a screen recording shows something, it fills the frame and the speaker
   sits in the corner. Lines like “let me pull this up” or “look at this article” get a marker in the
   XML, so the editor can drop the clip or article in.
6. Keeps every um, ah and pause unless **Cut ums & ahs** / **Cut long pauses** is on (those need a transcript,
   made from a mix of all the mics).

Out comes a Premiere XML (V1 camera cuts, V2 screen, V3 the speaker picture-in-picture, one audio
track per mic, levelled), a preview, and **Export finished MP4** in Short form edits. **Also find social clips**
renders the finished episode and sends it to the Clip generator.

**Open** a finished project to fix anything: rename the speakers, change which camera shows whom,
change a file's role or start time, flip the switches, then **Re-edit**.

File-name hints: “wide”, “master”, “2-shot” → wide camera; “screen”, “capture”, “display”, “obs” →
screen recording. Everything else is guessed from the file.

### Graphics: on-brand still designs (Canva-style)

Describe it ("Instagram post and story: 'Free roof inspection' this week only") and press **Design**. The AI writes
the copy in the client's voice and picks the layout; you can change anything before **Make graphics**.
- **Designs:** quote card, stat card, offer/ad, testimonial, YouTube thumbnail (the person cut out of a photo or a
  video frame), tips/list, event, and multi-slide **carousels** (PNGs plus one PDF for LinkedIn).
- **Every size at once:** post 1:1, feed 4:5, story 9:16, YouTube thumbnail, link ad 1.91:1.
- **Three looks:** bold (brand colour), clean (light), dark. Always the client's colours, fonts and logo.
- **Bulk create:** a spreadsheet (CSV) with a column per field → one design per row.
- **Your own images:** drop photos, product shots, a logo or a look you like. Each gets a role: *Feature this photo*,
  *Product* (cut out of its background automatically), *Logo* (instead of the client's) or *Match this look* (its colours
  lead the design). Two new designs use them: **Product spotlight** and **Photo + headline**. The AI looks at the
  images when it writes the copy.
- **Edit in Studio** opens any design in HyperFrames Studio; **Re-render** picks up your edits.
- Needs the HyperFrames engine (the installers set it up).

### Strategist (top right)

An AI head of content that knows video marketing: hooks, retention, every platform, paid ads and creative testing,
copy frameworks, scripts and interview questions, content plans and repurposing, and running an agency (onboarding,
packages, reporting). Pick a client and ask, or use a quick action: 20 hooks, a video script, a 30-day plan, ad angles,
interview questions, repurposing, or a review of your copy. The same knowledge base (`autocut/knowledge/`) is behind
every AI feature: clip picks, post copy, graphics and motion graphics.

### Motion graphic generator: motion graphics on demand

**HyperFrames engine (recommended):** with HyperFrames set up (the installers offer it; or
`autocut hyperframes-setup`, which needs Node.js 22+), graphics are built as HTML and GSAP animation and
rendered frame by frame in headless Chrome by [HyperFrames](https://github.com/heygen-com/hyperframes)
(open source, Apache 2.0). It runs on this computer with telemetry off and no account. The result is cleaner type, real
motion blur, and transparent ProRes 4444 that drops straight onto a Premiere track. Every render keeps an editable
project (`hf-<graphic>-<size>/`) that a designer can open with `npx hyperframes preview` or the HyperFrames desktop app.
**Details → Engine** switches back to the classic engine for one graphic.

**Edit in Studio:** HyperFrames graphics have **Edit in Studio** in the gallery. It opens the graphic in
[HyperFrames Studio](https://www.hyperframes.dev/studio), the browser editor with a timeline, property panel and live
preview, served from this computer. Change text, timing or motion there, then press **Re-render** in AutoCut to get new
files. Studio fetches a few animation plugins from the internet, so it needs a connection; rendering doesn't.

**Showcase:** `PYTHONPATH=. python tests/showcase/run.py OUT` renders a varied battery across five fictional brands, from
simple templates to a 4-scene promo, and writes contact sheets, a reel per aspect ratio and a report.

**Custom designs:** start the prompt with `custom:` (or pick **Custom design**) and describe anything:
`custom: a 3-step process 'Free inspection' 'Photo report' 'Fixed for good' with numbered cards, vertical`.
The AI writes a whole HyperFrames composition in the client's colours and fonts. If it doesn't render, the error
goes back to the AI once for a fix. Claude does this much better than the small local model, so custom designs use Claude
(within the monthly cap) when a key is set.

**References:** drop an image or a short video of a look you like next to the prompt. AutoCut pulls its colours,
whether it's light or dark, and (for videos) its pacing, and the AI describes its mood, typography and motion.
With **Match it** on, the graphic uses those colours (unless the prompt names some), plays at the matching pace,
and uses the template the AI suggests if the prompt didn't name one.

**Music and sound design (free, made on this computer):** every edit gets original, royalty-free music in the client's
own sound (10 styles; each client has a signature style, key and motif, chosen to differ from your other clients) and
sound effects on what happens on screen (whooshes on transitions, pops on stickers, impacts on slams, a riser into the
reveal). The Premiere XML puts the **dialogue on A1, sound effects on A2 and music on A3**. Optional AI music with
ACE-Step (`autocut music-setup`). Details: [docs/SOUND.md](docs/SOUND.md).

**Motion library (every client looks different):** 18 looks (Corporate Clean, Editorial Serif, Neon Night, Glass Tech,
Sport Bold, Hand-made Paper, Luxury Serif… each a full design system modelled on a best-selling marketplace category or a
2026 trend, written from scratch) × 41 layouts (10 lower thirds, 6 titles, 10 charts: bars, columns, line, donut,
meter, before/after, counters, waffle, timeline, funnel; callouts, lists, testimonials, end cards, transitions) and 12
storyboard structures (problem-agitate-solve ad, listicle, testimonial, before/after, launch, event, data story,
how-to, explainer, hiring, listing, limited offer). Each client gets its own **style DNA** (a look + layout order +
transition) that suits the business and stays clear of your other clients; pick a client and graphics follow it.
**Look book** shows and changes it; **Storyboard** writes and draws a whole short video from one line. Custom
designs can start from any of the 448 open-source HyperFrames registry blocks. Details: [docs/LIBRARY.md](docs/LIBRARY.md).

**Transcript to video (Katana-style):** the **Transcript to video** panel turns a script or a transcript into a full
kinetic typography video. Paste a script, or drop a transcript (TXT, SRT, VTT, AutoCut's transcript.json) or the
recording itself (MP3, WAV, MP4, MOV: transcribed on this computer, and the voice is laid under the video in sync).
The words land as they're said, the key word in each phrase lights up in the brand colour, numbers count up, "first /
step two…" get numbered badges, short punchlines slam in, your graphics appear when they're mentioned (name the file
after what it shows, e.g. `dashboard.png`), and it ends on the logo and call to action. Plain text is paced like speech.
The AI (when one is running) picks the highlights; rules do otherwise. Output is an MP4 with sound plus an editable
HyperFrames project, so **Edit in Studio** and **Re-render** work here too.

**Your logo, fonts and graphics:** the **Your logo, fonts & graphics** drop zone in the Create tab customizes every
graphic and transcript video made there: a logo replaces the brand's (end cards, watermark), font files (TTF, OTF, WOFF,
WOFF2) become the headline font (the first) and body font (the second), and other images are featured: picture cards in
transcript videos, and assets the AI must use in `custom:` designs. Pick each image's role (logo / graphic).

**Kinetic typography:** `kinetic typography 'Your roof took a beating / Hail damage hides / We find it *free*'`.
Each `/` is a beat with its own entrance (punch-in, masked rise, brand-colour wipe, tracking-in), centred, with
`*keywords*` in the brand colour.


Describe a graphic, for example `lower third for 'Jordan Reyes' 'Owner, Acme Roofing' square and vertical, green screen`.
Then **Generate**, or **Read prompt** to check the details first.

- **Graphics:** hook title, keyword slam, stat counter, phrase card, lower third, swipe transition, CTA end card.
- **Sizes:** 9:16, 1:1, 4:5, 16:9, 4K 16:9, 4K 9:16. "all sizes" gives the four main ones.
- **Layout:** position (top / upper / center / lower / bottom), transparent, green-screen or solid
  background, length, frame rate.
- **Colours:** a client's brand, or custom colours.
- **Exports:** ProRes .mov and WebM keep transparency, for any editor (Premiere, Final Cut, Resolve,
  CapCut). MP4 and GIF are also available.
- **Library:** renders are kept in `/Users/Shared/AutoCut/motion-library`, shared by every Mac.

### AutoCut Motion (After Effects-style graphics)

The **Motion graphics** switch turns on AutoCut's own motion-graphics engine.
It uses the techniques that make After Effects work look premium:

- eased keyframes with overshoot
- real motion blur
- masked text reveals
- staggered timing
- lines and bars that draw on
- gradients, glows and light sweeps

| Graphic | When it appears |
|---|---|
| **Hook title** | Words rise out of masks at the start, an accent bar draws on, then a light sweep. Uses the upload's Hook text |
| **Keyword slam** | On highlight words, up to 2 per video. Punches in with a shockwave and camera shake |
| **Stat counter** | Numbers that are said ("$3,000"). A gradient panel springs in and the number counts up |
| **Phrase card** | The client's key phrases, shown in a brand pill with a sweep underline |
| **Lower third** | Wipe-in panels, the name rises in, the title tracks in |
| **Swipe transition** | Brand-colour bands sweep across a cut, up to 2 per video |
| **CTA outro** | Animated end card: drifting brand shapes, logo spring, a pulsing button |

- **Brand:** every graphic uses the client's colours and fonts automatically.
- **Preview:** **Clients → Preview motion pack** renders all of them in that client's brand,
  over a frame of their latest footage. Use it for client sign-off.
- **Tuning:** the `motion:` section of the brand kit sets how many slams and swipes, and turns the
  hook title and CTA outro on or off. `graphics.style: classic` brings back the old flat graphics.
- **Speed:** quality vs. speed is `motion_blur_samples` in settings (4 = smooth, 2 = faster).
- **Motion Studio:** Kinetik Motion Studio pieces, if configured, still render alongside.

### Visuals AutoCut finds or makes for you

- **Icons:** 2,100+ open-source Lucide icons become pop-up stickers in the client's brand colour.
  For example, "money" gives a banknote and "storm" a lightning cloud. The client's own stickers come first.
- **Stock B-roll:** when a client's library has nothing for what's being said, AutoCut downloads free
  clips from Pexels or Pixabay. Credits are recorded in `assets/broll/stock/CREDITS.csv`, and the clips stay in
  the library. Add free API keys under **This Mac → Settings** (`stock: pexels_api_key / pixabay_api_key`).
- **AI images (optional):** **Clients → Media library → Generate with AI** makes illustrations, clip art,
  photos or backgrounds in the client's colours, locally with FLUX.1-schnell (Apache-2.0). The installer offers it;
  it downloads several GB on first use.

### Agency credit

"Made by Triumphant Media" sits in the bottom-right corner of the app. The **Agency credit** effect
switch, off by default, puts the same small credit in the bottom-right of a video. Change the
wording with `agency_credit` in settings.

### Adding your own media (drag and drop)

**For one video** — Short form edits → **Media for these videos**:

1. Drop screenshots, photos, logos, graphics or short clips in.
2. Optionally type a keyword for each ("inspection report"). It appears when that's said.
   Without a keyword, AutoCut spaces it out through the video.
3. Pick a look, or leave **Auto**:
   - **Floating card** (the PNG/screenshot default): a framed card that pops in over the speaker
   - **Full screen** (the camera photo/clip default): fills the frame with a slow push-in
4. Drop the video(s) below. The media goes with them, and stays with them on a Re-run.

Images dropped by mistake into the video box are moved to the media list for you.

**For every video of a client** — Clients tab → **Media library**:

1. Pick a category and drop files in.

   | Category | Notes |
   |---|---|
   | Screenshots, Photos, Graphics, Logos | Shown in videos when tagged (see step 2) |
   | B-roll clips | Matched to what's said |
   | Stickers | Pop-up stickers |
   | Overlays | Light leaks / textures |
   | Music, Fonts, End card | Used by the brand kit |

2. Type **keywords** under an item ("shingles, roof replacement"). It shows up in any video
   where those words are said. Untagged library items are never placed automatically.
3. **Remove** moves a file to `assets/.trash`, so nothing is lost by accident.
4. **Install fonts on this Mac** copies the client's fonts into the Mac's font library
   for Premiere and Motion Studio. Do it once on each Mac.

Accepted files: PNG, JPG, HEIC (iPhone), WebP, GIF, TIFF, MP4, MOV. Wrong file types are refused
with a message saying what that category accepts.

### Creative effects (on/off switches)

Every creative layer has a switch. Each client's **defaults** are set in **Clients**.
You can change them **per upload** (the switches above the drop zone) and **per re-run**
(the Re-run button asks).

| Switch | What it adds |
|---|---|
| **Kinetic captions** | brand-styled animated captions, always centred. Styles (`captions.style` in brand.yaml): `pop` (words build up), `highlight` (a brand-colour box behind the spoken word), `karaoke`, `punch` (one big word at a time), `clean` |
| **Your media** | the screenshots, photos, logos and graphics you added (above) |
| **B-roll cutaways** | clips from the client's library, matched to what's said |
| **Motion graphics** | Kinetik Motion Studio pieces (hook title, keyword bursts, CTA outro) |
| **Punch-in zooms** | alternating wide/tight framing, so jump cuts feel intentional |
| **Graphic cards** | branded cards for numbers ("20 MINUTES", "$3,000") and key phrases |
| **Lower third** | the speaker's name and title near the start |
| **Story cutaways** | when the speaker describes something ("the hail hits, water gets in, six months later…"), a short storyboard cutaway tells it in pictures: 3D brand-colour icon tiles, the client's own tagged images, and picture-in-picture videos from their B-roll, joined by animated arrows, each appearing as its word is said. The speaker stays on screen in a framed picture-in-picture. Tag media (or make "3D render" AI images) to have your own pictures used. Settings: `story:` in brand.yaml |
| **Pop-up stickers** | icons that bounce in on matching words: a house on "roof", $ on "price". Clients can add their own |
| **Texture overlays** | vignette, film grain, light leaks on cuts |
| **Subject cutout** | hook text **behind** the speaker for the opening seconds, and the speaker **popping out** over a brand-colour panel on key words |
| **Music bed** | the client's track under the dialogue |
| **Cover image** | a thumbnail: the speaker cut out over brand colour with the hook text |

- **Hook text:** the box next to the client picker sets the hook. It's used behind the speaker
  and by Motion Studio's `{{HOOK}}`. Leave it blank and AutoCut picks one from the first
  few seconds of speech.
- **Fine-tuning:** each effect's settings (zoom amount, card position, sticker size, number of
  pop-outs…) live in that client's brand kit, with comments explaining each line.

### Opening a rough cut in Premiere

**File → Import →** the `… - AutoCut.xml`. Each effect lands on its own track, so editors
can keep, move or delete any of it:

| Track | Contents |
|---|---|
| V1 | edit (punch-ins applied) + CTA end card |
| V2 | B-roll + full-screen media |
| V3 | grain + vignette |
| V4 | light leaks |
| V5 | behind-the-speaker layer (hook text / brand panel) |
| V6 | speaker cutout |
| V7 | graphic cards + lower third |
| V8 | your media (floating cards) |
| V9 | pop-up stickers |
| V10 | story cutaways |
| V11 | kinetic captions |
| V12 | logo |
| V13 | Motion Studio |
| A1/A2 | dialogue |
| A3 | music |

- Timeline markers explain each B-roll pick.
- For editable captions instead, mute V3 and import `captions.srt`.

### Client onboarding

See **ONBOARDING.md**: what to collect from the client, how to build their brand kit, and sign-off.

---

## Changing the software

AutoCut is plain Python plus one HTML file, kept in git. Every change is versioned
and can be undone.

### Easiest: ask Claude Code (in the browser, no office computer needed)

The code lives in a private GitHub repo; nothing depends on one computer (docs/OWNER-GUIDE.md).

1. Open claude.ai/code and pick the `autocut` repo.
2. Describe the change, e.g. "add a 'bold yellow box' caption style", or "cut pauses a bit less aggressively".
3. Claude reads **CLAUDE.md** (the map of the code), makes the change, and runs the tests.
4. Say "release it to everyone" (or "as a beta"). Claude bumps the version and pushes a version tag; the release
   robot (`.github/workflows/release.yml`) tests, builds, signs and publishes it. Every AutoCut shows a banner and
   installs it with one click (self-tested, with roll back). Details: docs/RELEASING.md.

New looks, storyboards and music styles don't need a release: they're content packs (docs/EXTENDING.md).
Where AutoCut is heading, and the tech we watch: ROADMAP.md.

### Where things live

| Path | What |
|---|---|
| `autocut/` | the program (see CLAUDE.md for each file) |
| `autocut/web/index.html` | the dashboard UI |
| `templates/client/` | starting brand kit for new clients |
| `examples/demo-roofing-co/` | demo client + sample video |
| `mac/` | Mac installer, updater, app builder, icon |
| `windows/` | Windows installer, updater, launcher, icon |
| `tests/` | automated tests |
| `settings.yaml` | shared defaults (in git) |
| `~/Library/Application Support/AutoCut/settings.yaml` | this Mac's overrides (not in git) |
| `%APPDATA%\AutoCut\settings.yaml` | this Windows PC's overrides (not in git) |
| `~/Library/Logs/AutoCut.log` | app log |

### Command line (power users)

Everything the app does is also available from Terminal: `~/AutoCut/.venv/bin/python -m autocut --help`.

| Command | What it does |
|---|---|
| `run VIDEO --client SLUG [--hook "…"] [--preview]` | rough-cut one video now |
| `watch` | process the shared queue without the app |
| `new-client NAME` | create a client from the template |
| `check-client SLUG` | check a brand kit |
| `style-proof SLUG` | render a caption sample |
| `doctor [--download]` | check this Mac (and fetch the speech model) |

## Troubleshooting

- **✂ not in the menu bar:** open AutoCut from Applications. If it still doesn't appear,
  check `~/Library/Logs/AutoCut.log`.
- **A job shows "error":** click **Log** next to it.
- **A Mac Mini shows no clients:** the share isn't connected. In Finder, Go → Connect to Server,
  then quit and reopen AutoCut.
- **Media offline in Premiere:** the XML was opened on a Mac that can't see
  `/Users/Shared/AutoCut`. Connect the share, or relink the first clip.
- **Captions in the wrong font:** the font family name in `brand.yaml` must match the
  font file's name. The Clients tab check tells you.
