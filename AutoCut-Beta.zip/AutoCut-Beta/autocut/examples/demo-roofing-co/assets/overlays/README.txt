Optional overlay clips (alpha .mov, e.g. licensed light leaks). Used instead of the generated leaks.
