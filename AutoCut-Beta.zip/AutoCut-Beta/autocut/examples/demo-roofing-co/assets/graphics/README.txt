Graphics (shown as a floating card). Add them in the dashboard: Clients → Media library.
