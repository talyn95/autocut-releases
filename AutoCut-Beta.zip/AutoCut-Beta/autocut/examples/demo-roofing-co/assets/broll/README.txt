B-roll library. Name clips by what is in them: roof-shingles-closeup.mp4, team-handshake-office.mov
Optional tags.csv: filename,extra tags
