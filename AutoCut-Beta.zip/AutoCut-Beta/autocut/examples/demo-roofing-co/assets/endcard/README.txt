Optional pre-made end card video (set cta.end_card in brand.yaml).
