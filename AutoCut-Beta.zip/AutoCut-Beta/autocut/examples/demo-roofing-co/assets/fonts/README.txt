Drop the client font files here (.ttf/.otf). Install them on every editing Mac too.
Inter (demo font) is licensed under the SIL Open Font License 1.1 — see Inter-LICENSE.txt.
