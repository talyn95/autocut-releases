Client stickers (transparent PNG), named by the word that triggers them:
money.png, roof.png, "free estimate.png". These win over AutoCut built-ins.
