logo.png = transparent PNG, at least 1000px wide. Add logo.svg for Motion Studio.
