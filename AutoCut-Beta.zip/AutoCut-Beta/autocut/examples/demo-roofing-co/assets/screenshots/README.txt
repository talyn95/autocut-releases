Screenshots (shown as a floating card). Add them in the dashboard: Clients → Media library.
Give them keywords there and they appear when those words are said.
