Photos (shown full screen with a slow push-in). Add them in the dashboard: Clients → Media library.
