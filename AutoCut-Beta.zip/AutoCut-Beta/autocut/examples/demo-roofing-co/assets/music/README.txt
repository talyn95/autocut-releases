Optional licensed music bed (set music.file in brand.yaml).
