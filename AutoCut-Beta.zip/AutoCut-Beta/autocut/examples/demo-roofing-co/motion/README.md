# Motion Studio templates for this client

1. In Motion Studio, set this client's colours, fonts and logo in `brand.json`,
   then copy that file here as `brand.json`.
2. Design the pieces you want on every video (hook title, keyword burst, CTA
   outro…) in Motion Studio. Copy each finished spec here (e.g. `hook-title.json`).
3. Replace the words that change per video with placeholders:
   `{{HOOK}}`, `{{CTA_TEXT}}`, `{{CTA_SUBTEXT}}`, `{{CLIENT}}`, `{{WORD}}`
   (`{{WORD}}` = the spoken word that triggered a `place: word:...` piece).
4. List them under `motion_studio.pieces` in `../brand.yaml` and set `enabled: true`.
