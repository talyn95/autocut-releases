"""AutoCut.app: menu-bar app that runs the dashboard server and the worker.

Launched by /Applications/AutoCut.app (built by mac/build_app.sh). Lives in the
menu bar as ✂, with Open Dashboard / Pause / Quit. Without `rumps` installed
(e.g. not a Mac), falls back to the plain server.
"""
from __future__ import annotations

import subprocess

from .app import open_dashboard, serve
from .config import clients_dir


def main() -> None:
    try:
        import rumps
    except ImportError:
        serve(open_browser=True)
        return

    server, app = serve(open_browser=True, block=False)
    url = f"http://127.0.0.1:{app.settings['port']}/"

    class AutoCutMenu(rumps.App):
        def __init__(self):
            super().__init__("AutoCut", title="✂", quit_button=None)
            self.status = rumps.MenuItem("Starting…")
            self.pause_item = rumps.MenuItem("Pause processing", callback=self.toggle_pause)
            self.menu = [
                rumps.MenuItem("Open Dashboard", callback=lambda _: open_dashboard(url), key="d"),
                self.status,
                None,
                self.pause_item,
                rumps.MenuItem("Open Clients Folder", callback=lambda _: subprocess.run(
                    ["open", str(clients_dir(app.settings))])),
                None,
                rumps.MenuItem("Quit AutoCut", callback=self.quit, key="q"),
            ]

        seen: dict[str, str] = {}

        @rumps.timer(5)
        def notify(self, _):
            """A Mac notification when a video this Mac cut is ready (or failed)."""
            from .jobs import list_jobs
            for j in list_jobs(app.settings, limit=30):
                key, state = j["dir"], j.get("state", "") + "/" + str(j.get("export"))
                before = self.seen.get(key)
                self.seen[key] = state
                if before is None or before == state or j.get("machine") != app.settings["machine_name"]:
                    continue
                if j.get("state") == "done" and not before.startswith("done"):
                    rumps.notification("Rough cut ready ✂", j["job"], "Open AutoCut to import the XML into Premiere.")
                elif j.get("state") == "error" and not before.startswith("error"):
                    rumps.notification("AutoCut couldn't cut a video", j["job"], (j.get("error") or "")[:120])
                elif j.get("export") == "done" and "/done" not in before:
                    rumps.notification("Finished MP4 exported", j["job"], "Download it from the dashboard (More ▾).")

        @rumps.timer(2)
        def tick(self, _):
            w = app.worker
            if w.current:
                self.title = "✂ ●"
                self.status.title = f"Cutting {w.current['video']}"
            else:
                self.title = "✂"
                self.status.title = "Paused" if w.paused else f"Ready on {app.settings['machine_name']}"
            self.pause_item.title = "Resume processing" if w.paused else "Pause processing"

        def toggle_pause(self, _):
            app.worker.paused = not app.worker.paused

        def quit(self, _):
            if app.worker.current and rumps.alert(
                    "AutoCut is cutting a video", "Quit anyway? It will restart from the beginning next time.",
                    ok="Quit", cancel="Keep running") != 1:
                return
            server.shutdown()
            rumps.quit_application()

    AutoCutMenu().run()
