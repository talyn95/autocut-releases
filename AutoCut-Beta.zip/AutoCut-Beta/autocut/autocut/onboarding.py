"""First run: the welcome walkthrough and the "Getting started" checklist on the dashboard.

Each step is worked out from what's on this computer (a real client exists, a rough cut finished…), so the checklist
ticks itself off as the owner uses AutoCut. Whether the welcome was seen and whether the checklist was hidden live in
state.json next to this computer's settings.
"""
from __future__ import annotations

from pathlib import Path

from . import jobs, migrations
from .config import list_clients

DEMO = {"demo-roofing-co"}


def steps(settings: dict) -> list[dict]:
    from .design import stills
    from .mograph import prompt
    real = [d for d in list_clients(settings) if d.name not in DEMO]
    done_jobs = [j for j in jobs.list_jobs(settings, limit=500) if j.get("state") == "done"]
    motion = any(i.get("state") == "done" for i in prompt.list_items(settings, limit=200))
    graphic = any(i.get("state") == "done" for i in stills.list_items(settings, limit=200))
    from . import accounts, brain, hardware
    ai = bool(brain.local_status(settings).get("ready")) or any(accounts.key(settings, p) for p in accounts.IDS) \
        or brain.claude_available(settings)[0]
    bench = bool((hardware.cached() or {}).get("benchmark"))
    return [
        {"key": "client", "title": "Add your first client", "how": "Clients → New client from a website (or type a name)",
         "tab": "clients", "done": bool(real)},
        {"key": "video", "title": "Edit your first video", "how": "Short form edits → pick the client → drop raw footage",
         "tab": "queue", "done": bool(done_jobs)},
        {"key": "motion", "title": "Make a motion graphic", "how": "Motion graphic generator → describe it in a sentence",
         "tab": "create", "done": motion},
        {"key": "graphic", "title": "Make a social graphic", "how": "Graphics → describe a post, an offer or a thumbnail",
         "tab": "design", "done": graphic},
        {"key": "speed", "title": "Check this computer", "how": "This Mac → This computer → Run a speed test",
         "tab": "machine", "done": bench},
        {"key": "ai", "title": "Turn on AI", "how": "Free local AI, or your own Claude / ChatGPT / Grok account",
         "tab": "machine", "done": ai, "optional": True},
    ]


def info(settings: dict) -> dict:
    st = migrations.state()
    s = steps(settings)
    required = [x for x in s if not x.get("optional")]
    return {"welcomed": bool(st.get("welcomed")), "hidden": bool(st.get("getting_started_hidden")),
            "steps": s, "done": sum(x["done"] for x in required), "total": len(required),
            "complete": all(x["done"] for x in required)}


def update(welcomed: bool | None = None, hidden: bool | None = None) -> None:
    st = migrations.state()
    if welcomed is not None:
        st["welcomed"] = bool(welcomed)
    if hidden is not None:
        st["getting_started_hidden"] = bool(hidden)
    migrations._save(st)
