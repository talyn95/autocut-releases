"""Local speech-to-text with word timestamps. Nothing leaves the machine.

Whisper normally "cleans up" speech and drops ums and uhs. The prompt below
nudges it to write them out; anything it still drops shows up as a gap between
words, which the editor tightens anyway (see edit.py).
"""
from __future__ import annotations

import json
import platform
from pathlib import Path

from . import content, hardware
from .media import extract_audio

VERBATIM_PROMPT = (
    "Umm, so, uh, I was like, you know, thinking... Hmm. Uh, okay so, um, "
    "here's the thing, uh, we we basically, um, did it."
)

MLX_REPOS = content.catalog()["whisper"]["mlx_repos"]  # content/catalog.json (updates add models)


def _pick_backend(choice: str) -> str:
    if choice != "auto":
        return choice
    if platform.system() == "Darwin" and platform.machine() == "arm64":
        try:
            import mlx_whisper  # noqa: F401
            return "mlx"
        except ImportError:
            pass
    return "faster-whisper"


def transcribe(video: Path, workdir: Path, settings: dict, vocabulary: list[str] | None = None) -> dict:
    cfg = settings["whisper"]
    wav = extract_audio(video, workdir / "audio16k.wav")
    backend = _pick_backend(cfg.get("backend", "auto"))
    model = hardware.whisper_model(cfg)  # "auto" = what this computer runs well (hardware.py)
    lang = cfg.get("language") or None
    prompt = VERBATIM_PROMPT + (" " + ", ".join(vocabulary) + "." if vocabulary else "")
    words: list[dict] = []
    print(f"  transcribing with {backend} ({model}) …")

    if backend == "mlx":
        import mlx_whisper
        res = mlx_whisper.transcribe(
            str(wav), path_or_hf_repo=MLX_REPOS.get(model, model), language=lang,
            word_timestamps=True, initial_prompt=prompt,
            condition_on_previous_text=False)
        for seg in res["segments"]:
            for w in seg.get("words", []):
                words.append({"word": w["word"].strip(), "start": float(w["start"]),
                              "end": float(w["end"]), "prob": float(w.get("probability", 1))})
    else:
        from faster_whisper import WhisperModel
        try:
            import ctranslate2  # comes with faster-whisper; sees an NVIDIA GPU (Windows/Linux) if there is one
            device = "cuda" if ctranslate2.get_cuda_device_count() > 0 else "cpu"
        except Exception:
            device = "cpu"
        def run(device: str) -> list[dict]:
            m = WhisperModel(model, device=device, compute_type="float16" if device == "cuda" else "int8")
            segments, _ = m.transcribe(str(wav), language=lang, word_timestamps=True,
                                       initial_prompt=prompt, vad_filter=False,
                                       condition_on_previous_text=False)
            return [{"word": w.word.strip(), "start": float(w.start), "end": float(w.end), "prob": float(w.probability)}
                    for seg in segments for w in seg.words or []]
        try:
            words = run(device)
        except Exception as e:  # a GPU without NVIDIA's CUDA libraries: the CPU still works, just slower
            if device == "cpu":
                raise
            print(f"  GPU transcription unavailable ({e}); using the CPU")
            words = run("cpu")

    wav.unlink(missing_ok=True)
    return {"source": str(video), "backend": backend, "model": model,
            "words": [w for w in words if w["word"]]}


def load_or_transcribe(video: Path, workdir: Path, settings: dict, transcript: Path | None,
                       vocabulary: list[str] | None = None) -> dict:
    cache = workdir / "transcript.json"
    if transcript:
        data = json.loads(Path(transcript).read_text())
    elif cache.exists():
        data = json.loads(cache.read_text())
    else:
        data = transcribe(video, workdir, settings, vocabulary)
    cache.write_text(json.dumps(data, indent=1))
    return data
