"""Who is talking, when. Shared by the Clips tab (speaker jump cuts) and the Multicam tab.

Two signals, best first:
  audio    one mic per person (separate files, or separate channels of one file): the loudest
           mic, relative to its own noise floor, is the talker
  picture  no separate mics: the person whose head/mouth area moves most is the talker
`shots()` turns per-person activity into simple jump cuts with a minimum shot length,
so the edit doesn't flicker on every "mm-hm".
"""
from __future__ import annotations

import subprocess
from pathlib import Path

import numpy as np

HOP = 0.1  # seconds per activity sample


def audio_energy(source: Path, channels: list[int] | None = None, start: float = 0.0,
                 dur: float | None = None, offset: float = 0.0, hop: float = HOP) -> np.ndarray:
    """Loudness in dB every `hop` seconds → array [n_channels, T]. Streams the audio, so a
    three-hour recording needs only a few MB of memory.

    `channels` picks channels of the file (0-based; None = all, kept separate).
    `offset` is where the file starts on a shared timeline (file time = timeline time - offset);
    the gap is padded with silence, so recorders that started late line up with the cameras.
    """
    rate = 4000
    probe = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries",
                            "stream=channels", "-of", "csv=p=0", str(source)], capture_output=True, text=True)
    nch = int((probe.stdout.strip() or "0").split(",")[0] or 0)
    picks = [c for c in (channels if channels is not None else range(max(1, nch))) if c < max(1, nch)] or [0]
    if nch == 0:
        return np.full((len(picks), 0), -90.0)
    seek = start - offset
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error"]
    if seek > 0:
        cmd += ["-ss", f"{seek:.3f}"]
    cmd += ["-i", str(source)]
    if dur is not None:
        cmd += ["-t", f"{max(0.0, dur + min(0.0, seek)):.3f}"]
    cmd += ["-vn", "-ar", str(rate), "-f", "f32le", "-acodec", "pcm_f32le", "-"]
    hop_n = max(1, int(round(rate * hop)))
    block = hop_n * nch * 4 * 2000  # 2000 hops per read
    out, carry = [], b""
    with subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL) as proc:
        while True:
            chunk = proc.stdout.read(block)
            if not chunk:
                break
            data = carry + chunk
            usable = len(data) // (hop_n * nch * 4) * (hop_n * nch * 4)
            carry = data[usable:]
            if not usable:
                continue
            pcm = np.frombuffer(data[:usable], dtype=np.float32).reshape(-1, hop_n, nch)[:, :, picks]
            out.append(10 * np.log10((pcm.astype(np.float64) ** 2).mean(axis=1) + 1e-12).T)
    db = np.concatenate(out, axis=1) if out else np.full((len(picks), 0), -90.0)
    db = np.maximum(db, -90.0)
    if seek < 0:  # the file starts after timeline time `start`: silence before it
        db = np.concatenate([np.full((db.shape[0], int(round(-seek / hop))), -90.0), db], axis=1)
    if dur is not None:
        n = int(round(dur / hop))
        db = db[:, :n] if db.shape[1] >= n else np.pad(db, ((0, 0), (0, n - db.shape[1])), constant_values=-90.0)
    return db


def channels_are_separate(energy: np.ndarray) -> bool:
    """True when a multi-channel file holds different mics (not a stereo copy of one mix)."""
    if energy.shape[0] < 2 or energy.shape[1] < 20:
        return False
    a, b = energy[0], energy[1]
    if np.abs(a - b).mean() < 1.0:  # identical channels
        return False
    return bool(np.corrcoef(a, b)[0, 1] < 0.9)


def normalize(energy: np.ndarray) -> np.ndarray:
    """dB → 0..1 'talking' strength per person, each relative to their own mic's noise floor
    and speech level, so a hot mic doesn't win every time."""
    out = np.zeros_like(energy, dtype=float)
    for i, e in enumerate(energy):
        if e.size == 0:
            continue
        floor, peak = np.percentile(e, 20), np.percentile(e, 95)
        out[i] = np.clip((e - floor) / max(6.0, peak - floor), 0, 1)
    return out


def motion_activity(source: Path, people: list[dict], start: float, dur: float, fps: float = 10.0) -> np.ndarray:
    """Head-area movement per person every HOP seconds → [n_people, T] (0..1).

    A talking person's mouth, jaw and head move far more than a listener's."""
    w, h = 320, 180
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-ss", f"{start:.3f}", "-i", str(source),
                        "-t", f"{dur:.3f}", "-vf", f"fps={fps},scale={w}:{h},format=gray", "-f", "rawvideo", "-"],
                       capture_output=True)
    frames = np.frombuffer(r.stdout, dtype=np.uint8)
    n = len(frames) // (w * h)
    if n < 2:
        return np.zeros((len(people), 0))
    frames = frames[: n * w * h].reshape(n, h, w).astype(np.int16)
    diff = np.abs(np.diff(frames, axis=0))  # n-1 frames of movement
    acts = []
    for p in people:
        x0 = int(max(0, (p["cx"] - p["w"] * 0.32) * w))
        x1 = int(min(w, (p["cx"] + p["w"] * 0.32) * w))
        top = p["cy"] - p["h"] / 2
        y0 = int(max(0, (top + p["h"] * 0.04) * h))
        y1 = int(min(h, (top + p["h"] * 0.38) * h))  # the head
        if x1 - x0 < 2 or y1 - y0 < 2:
            acts.append(np.zeros(n - 1))
            continue
        acts.append(diff[:, y0:y1, x0:x1].mean(axis=(1, 2)))
    acts = np.array(acts, dtype=float)
    # resample from video fps to HOP
    t_src = np.arange(acts.shape[1]) / fps
    t_dst = np.arange(0, dur, HOP)
    acts = np.array([np.interp(t_dst, t_src, a) for a in acts])
    # whole-frame movement (camera shake, lighting) isn't anyone talking
    acts = acts - acts.min(axis=0, keepdims=True) * 0.6
    out = np.zeros_like(acts)
    for i, a in enumerate(acts):
        lo, hi = np.percentile(a, 15), np.percentile(a, 92)
        out[i] = np.clip((a - lo) / max(1e-3, hi - lo), 0, 1)
    return out


def smooth(x: np.ndarray, secs: float) -> np.ndarray:
    k = max(1, int(round(secs / HOP)))
    if k <= 1 or x.shape[-1] == 0:
        return x
    kernel = np.ones(k) / k
    return np.array([np.convolve(row, kernel, mode="same") for row in x])


def shots(activity: np.ndarray, min_shot: float = 1.8, wide: int | None = None,
          wide_after: float = 0.0, both_threshold: float = 0.55) -> list[tuple[float, float, int]]:
    """Per-person activity [n, T] → jump cuts [(start, end, who)] covering the whole range.

    who = the person index, or `wide` (if given) when nobody is clearly talking for
    `wide_after` seconds, or when two people talk over each other."""
    n, T = activity.shape
    if T == 0:
        return []
    act = smooth(activity, 0.6)
    who = act.argmax(axis=0)
    if wide is not None and n > 1:
        srt = np.sort(act, axis=0)
        overlap = (srt[-2] > both_threshold) & (srt[-1] - srt[-2] < 0.12)
        quiet = srt[-1] < 0.18
        if wide_after > 0:
            k = int(wide_after / HOP)
            run = 0
            long_quiet = np.zeros(T, bool)
            for t in range(T):
                run = run + 1 if quiet[t] else 0
                if run >= k:
                    long_quiet[t - run + 1: t + 1] = True
        else:
            long_quiet = np.zeros(T, bool)
        who = np.where(overlap | long_quiet, wide, who)
    # runs
    runs: list[list] = []
    for t, w in enumerate(who):
        if runs and runs[-1][2] == w:
            runs[-1][1] = t + 1
        else:
            runs.append([t, t + 1, int(w)])
    # merge shots shorter than min_shot into the neighbour, shortest first
    min_len = int(min_shot / HOP)
    changed = True
    while changed and len(runs) > 1:
        changed = False
        i = min(range(len(runs)), key=lambda j: runs[j][1] - runs[j][0])
        if runs[i][1] - runs[i][0] < min_len:
            if i == 0:
                j = 1
            elif i == len(runs) - 1:
                j = i - 1
            else:  # join the side that's the same person, else the longer side
                j = i - 1 if (runs[i - 1][1] - runs[i - 1][0]) >= (runs[i + 1][1] - runs[i + 1][0]) else i + 1
            lo, hi = min(runs[i][0], runs[j][0]), max(runs[i][1], runs[j][1])
            runs[j][0], runs[j][1] = lo, hi
            del runs[i]
            # neighbours that are now the same person become one shot
            k = 0
            while k < len(runs) - 1:
                if runs[k][2] == runs[k + 1][2]:
                    runs[k][1] = runs[k + 1][1]
                    del runs[k + 1]
                else:
                    k += 1
            changed = True
    return [(round(a * HOP, 2), round(b * HOP, 2), w) for a, b, w in runs]


def snap_to_words(cuts: list[tuple[float, float, int]], words: list[dict], window: float = 0.6):
    """Move each cut point into the nearest gap between words (cutting mid-word looks jumpy)."""
    if not words or len(cuts) < 2:
        return cuts
    gaps = [(words[i]["end"] + words[i + 1]["start"]) / 2 for i in range(len(words) - 1)]
    out = [list(c) for c in cuts]
    for i in range(1, len(out)):
        t = out[i][0]
        near = min(gaps, key=lambda g: abs(g - t), default=t)
        if abs(near - t) <= window and out[i - 1][0] + 0.5 < near < out[i][1] - 0.5:
            out[i - 1][1] = out[i][0] = round(near, 3)
    return [tuple(c) for c in out]
