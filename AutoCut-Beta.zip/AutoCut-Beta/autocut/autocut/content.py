"""Content that grows without code changes: the catalog (AI models, engine pins, experiments) and content packs.

A content pack is a folder with a `pack.json` (and optionally `knowledge/*.md`). It is data only, never code, so a
pack can't break AutoCut: every entry is checked against what the built-in engines can draw or play, and a bad entry
is skipped with a message on the This Mac tab. What a pack can add:

  looks          motion style families (mograph/library/looks.py tokens); `"base": "<look>"` starts from a built-in
  storyboards    multi-scene recipes (storyboards.py): slots + scenes over the existing layouts
  music_styles   composer styles (sound/composer.py); `"base": "<style>"` starts from a built-in
  style_fits     industry words → music style (adds to the built-in lists)
  sfx_flavours   sound-effect flavours (sound/sfx.py); look_flavour  look → flavour
  knowledge      extra marketing know-how appended to knowledge/<topic>.md (or files in the pack's knowledge/ folder)
  catalog        the `ai`, `whisper` and `features` parts of catalog.json (a new local model tier, a new Claude model)

Packs never replace built-in entries (existing clients keep their look and sound); new layouts, templates and
instruments are code and arrive with app updates (updates.py). Where packs live:

  autocut/content/packs/<id>/      shipped with the app (replaced by updates)
  <data folder>/packs/<id>/        this computer's own and ones installed from the update feed (kept across updates)

A folder with a `.disabled` file is skipped. docs/EXTENDING.md has the format with examples.
"""
from __future__ import annotations

import copy
import json
import os
import re
import shutil
import zipfile
from pathlib import Path

from . import __version__

HERE = Path(__file__).parent / "content"
CATALOG_FILE = HERE / "catalog.json"
KINDS = ("looks", "storyboards", "music_styles", "style_fits", "sfx_flavours", "look_flavour")
CATALOG_PARTS = ("ai", "whisper", "features")
ID_RX = re.compile(r"[a-z0-9][a-z0-9_-]{1,40}")

_targets: dict[str, tuple[dict, dict]] = {}   # kind → (the live dict the engine uses, its built-in snapshot)
_state: dict = {"packs": None, "catalog": None, "errors": {}, "added": {}}
_hooks: list = []


# ---- where packs live ----------------------------------------------------------------------------
def packs_dir() -> Path:
    if os.environ.get("AUTOCUT_PACKS_DIR"):
        return Path(os.environ["AUTOCUT_PACKS_DIR"])
    from .config import clients_dir, load_settings
    return clients_dir(load_settings()).parent / "packs"


def version_tuple(v: str) -> tuple:
    return tuple(int(x) for x in re.findall(r"\d+", str(v))[:3]) or (0,)


def _read_pack(folder: Path, source: str) -> dict | None:
    f = folder / "pack.json"
    if not f.exists():
        return None
    info = {"id": folder.name, "path": str(folder), "source": source, "enabled": not (folder / ".disabled").exists()}
    try:
        data = json.loads(f.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("pack.json must be an object")
    except (ValueError, OSError) as e:
        return {**info, "name": folder.name, "data": {}, "problems": [f"pack.json can't be read: {e}"]}
    kn = folder / "knowledge"
    if kn.is_dir():
        k = dict(data.get("knowledge") or {})
        for md in sorted(kn.glob("*.md")):
            k.setdefault(md.stem, md.read_text(encoding="utf-8"))
        data["knowledge"] = k
    info.update(name=str(data.get("name") or folder.name), version=str(data.get("version") or "1.0"),
                author=str(data.get("author") or ""), description=str(data.get("description") or ""), data=data,
                problems=[])
    if data.get("min_app") and version_tuple(data["min_app"]) > version_tuple(__version__):
        info["problems"].append(f"needs AutoCut {data['min_app']} or newer")
        info["too_new"] = True
    return info


def packs(refresh: bool = False) -> list[dict]:
    """Every pack found, built-in first, then this computer's (sorted by id, so conflicts resolve the same way)."""
    if _state["packs"] is None or refresh:
        out = []
        for src, root in (("built-in", HERE / "packs"), ("local", packs_dir())):
            if root.is_dir():
                for d in sorted(root.iterdir()):
                    if d.is_dir() and not d.name.startswith((".", "_")):
                        p = _read_pack(d, src)
                        if p:
                            out.append(p)
        _state["packs"] = out
    return _state["packs"]


def _active() -> list[dict]:
    return [p for p in packs() if p["enabled"] and not p.get("too_new")]


# ---- checking entries against what the engines support ----------------------------------------------
def _values(kind: str, key: str) -> set:
    """Every value the built-in entries use for a token: those are the ones the engine is known to draw/play."""
    snap = _targets.get(kind, ({}, {}))[1]
    out = set()
    for v in snap.values():
        x = v.get(key) if isinstance(v, dict) else None
        out.add(json.dumps(x, sort_keys=True) if isinstance(x, (list, tuple, dict)) else x)
    return out


def _num(v, lo, hi) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and lo <= v <= hi


def _check_look(key: str, v: dict) -> tuple[dict | None, list[str]]:
    snap = _targets["looks"][1]
    base = v.get("base") or "corporate"
    if base not in snap:
        return None, [f"look '{key}': unknown base '{base}'"]
    look = {**copy.deepcopy(snap[base]), **{k: x for k, x in v.items() if k != "base"}}
    look.setdefault("inspired_by", f"a content pack (based on {snap[base]['name']})")
    look["base"] = base
    errs = []
    if not isinstance(look.get("name"), str) or look["name"] == snap[base]["name"]:
        errs.append(f"look '{key}': give it its own name")
    for k in ("head", "body", "num"):
        f = look.get(k)
        if not (isinstance(f, (list, tuple)) and len(f) == 2 and isinstance(f[0], str) and _num(f[1], 100, 900)):
            errs.append(f"look '{key}': {k} must be [\"Font family\", weight]")
        else:
            look[k] = (f[0], int(f[1]))
    for k in ("case", "panel", "shadow", "motif", "texture", "enter", "exit", "palette"):
        if look.get(k) not in _values("looks", k):
            errs.append(f"look '{key}': {k} '{look.get(k)}' isn't one AutoCut can draw "
                        f"({', '.join(sorted(str(x) for x in _values('looks', k)))})")
    for k, lo, hi in (("radius", 0, 200), ("stroke", 0, 20), ("speed", 0.4, 2.0), ("stagger", 0, 0.4)):
        if not _num(look.get(k), lo, hi):
            errs.append(f"look '{key}': {k} must be a number from {lo} to {hi}")
    if not re.fullmatch(r"-?\d*\.?\d+em", str(look.get("track", ""))):
        errs.append(f"look '{key}': track must look like 0.02em")
    if not re.fullmatch(r"(none|linear|(power[1-4]|expo|back|elastic|circ|sine|quad|cubic|quart|quint|bounce)"
                        r"\.(in|out|inOut))", str(look.get("ease", ""))):
        errs.append(f"look '{key}': ease must be a GSAP ease like power3.out")
    for k in ("mood", "fits"):
        if not (isinstance(look.get(k), list) and all(isinstance(x, str) for x in look[k])):
            errs.append(f"look '{key}': {k} must be a list of words")
    from .mograph.feel import FEELS
    if look.get("feel") is not None and look["feel"] not in FEELS:
        errs.append(f"look '{key}': feel must be one of {', '.join(FEELS)}")
    look["italic"], look["dark"] = bool(look.get("italic")), bool(look.get("dark"))
    return (None if errs else look), errs


def _check_style(key: str, v: dict) -> tuple[dict | None, list[str]]:
    from .sound.composer import SCALES
    snap = _targets["music_styles"][1]
    base = v.get("base") or "corporate"
    if base not in snap:
        return None, [f"music style '{key}': unknown base '{base}'"]
    st = {**copy.deepcopy(snap[base]), **{k: x for k, x in v.items() if k != "base"}, "base": base}
    errs = []
    if not isinstance(st.get("name"), str) or st["name"] == snap[base]["name"]:
        errs.append(f"music style '{key}': give it its own name")
    if st.get("mode") not in SCALES:
        errs.append(f"music style '{key}': mode must be one of {', '.join(SCALES)}")
    for k in ("chords", "rhythm", "bass", "bass_rhythm", "motif"):
        if st.get(k) not in _values("music_styles", k):
            errs.append(f"music style '{key}': {k} '{st.get(k)}' isn't an instrument/pattern AutoCut has "
                        f"({', '.join(sorted(str(x) for x in _values('music_styles', k) if x))})")
    arps = {tuple(json.loads(a)) for a in _values("music_styles", "arp") if a and a != "null"}
    if st.get("arp") is not None:
        if not (isinstance(st["arp"], (list, tuple)) and tuple(st["arp"]) in arps):
            errs.append(f"music style '{key}': arp must be null or one of {sorted(arps)}")
        else:
            st["arp"] = tuple(st["arp"])
    if not _num(st.get("bpm"), 50, 180):
        errs.append(f"music style '{key}': bpm must be 50–180")
    if not _num(st.get("register"), 40, 80):
        errs.append(f"music style '{key}': register must be 40–80 (a MIDI note)")
    progs = st.get("progs")
    if not (isinstance(progs, list) and progs and all(isinstance(p, list) and p and all(isinstance(d, int) and 1 <= d <= 7
                                                                                        for d in p) for p in progs)):
        errs.append(f"music style '{key}': progs must be chord progressions of scale degrees 1–7, e.g. [[1, 5, 6, 4]]")
    rv = st.get("reverb")
    if not (isinstance(rv, (list, tuple)) and len(rv) == 2 and _num(rv[0], 0.2, 8) and _num(rv[1], 0, 0.8)):
        errs.append(f"music style '{key}': reverb must be [seconds, mix]")
    else:
        st["reverb"] = tuple(rv)
    drums_ok = {d for s in snap.values() for lvl in s["drums"].values() for d in lvl}
    drums = {}
    for lvl, parts in (st.get("drums") or {}).items():
        n = int(lvl) if str(lvl).isdigit() else 0
        if n not in (1, 2, 3) or not isinstance(parts, dict):
            errs.append(f"music style '{key}': drums are levels 1, 2 and 3")
            continue
        for d, pat in parts.items():
            if d not in drums_ok or not re.fullmatch(r"[x.o]{16}", str(pat)):
                errs.append(f"music style '{key}': drum '{d}' needs a 16-step pattern of x . o "
                            f"(drums: {', '.join(sorted(drums_ok))})")
        drums[n] = parts
    st["drums"] = drums
    for k in ("swing", "pump"):
        if k in st and not _num(st[k], 0, 1):
            errs.append(f"music style '{key}': {k} must be 0–1")
    if "lowpass" in st and not _num(st["lowpass"], 800, 20000):
        errs.append(f"music style '{key}': lowpass must be 800–20000 Hz")
    if not isinstance(st.get("mood"), str) or not isinstance(st.get("ace"), str):
        errs.append(f"music style '{key}': mood and ace (the AI music prompt) must be text")
    return (None if errs else st), errs


def _check_recipe(key: str, v: dict) -> tuple[dict | None, list[str]]:
    from .mograph.library.elements import LAYOUTS
    errs = []
    slots = v.get("slots")
    if not (isinstance(slots, list) and all(isinstance(s, (list, tuple)) and len(s) == 3 and all(isinstance(x, str) for x in s)
                                            for s in slots)):
        return None, [f"storyboard '{key}': slots must be [name, hint, default] lists"]
    names = {s[0] for s in slots}
    scenes = []
    for i, sc in enumerate(v.get("scenes") or []):
        kind = sc.get("kind") if isinstance(sc, dict) else None
        if kind not in LAYOUTS:
            errs.append(f"storyboard '{key}' scene {i + 1}: kind must be one of {', '.join(LAYOUTS)}")
            continue
        bad = [x for x in sc.get("layouts") or [] if x not in LAYOUTS[kind]]
        if bad:
            errs.append(f"storyboard '{key}' scene {i + 1}: no {kind} layout {', '.join(bad)}")
        if sc.get("each") and sc["each"] not in names:
            errs.append(f"storyboard '{key}' scene {i + 1}: each '{sc['each']}' isn't a slot")
        if "dur" in sc and not _num(sc["dur"], 0.8, 30):
            errs.append(f"storyboard '{key}' scene {i + 1}: dur must be 0.8–30 seconds")
        if not isinstance(sc.get("params", {}), dict):
            errs.append(f"storyboard '{key}' scene {i + 1}: params must be an object")
        scenes.append(dict(sc, params=dict(sc.get("params") or {})))
    if not scenes:
        errs.append(f"storyboard '{key}': needs scenes")
    if not isinstance(v.get("name"), str):
        errs.append(f"storyboard '{key}': needs a name")
    rec = {"name": v.get("name"), "use": str(v.get("use") or ""), "slots": [tuple(s) for s in slots], "scenes": scenes}
    return (None if errs else rec), errs


def _check_flavour(key: str, v: dict) -> tuple[dict | None, list[str]]:
    snap = _targets["sfx_flavours"][1]
    base = v.get("base") or "clean"
    if base not in snap:
        return None, [f"sound flavour '{key}': unknown base '{base}'"]
    f = {**snap[base], **{k: x for k, x in v.items() if k != "base"}}
    errs = [f"sound flavour '{key}': {k} must be 0–1" for k in ("bright", "hard", "room") if not _num(f.get(k), 0, 1)]
    if not _num(f.get("length"), 0.3, 3):
        errs.append(f"sound flavour '{key}': length must be 0.3–3")
    for k in list(f):
        if k not in ("bright", "hard", "room", "length", "glitchy", "grain"):
            errs.append(f"sound flavour '{key}': unknown setting {k}")
    return (None if errs else f), errs


CHECK = {"looks": _check_look, "music_styles": _check_style, "storyboards": _check_recipe, "sfx_flavours": _check_flavour}


# ---- merging into the engines ----------------------------------------------------------------------
def register(kind: str, target: dict) -> dict:
    """Called once by each engine module with its built-in dict; pack entries are merged into it in place, so every
    `from .looks import LOOKS` sees them, and reload() can put the built-ins back first."""
    if kind not in _targets:
        _targets[kind] = (target, copy.deepcopy(target))
        _merge(kind)
    return target


def _merge(kind: str) -> None:
    target, snap = _targets[kind]
    added = _state["added"].setdefault(kind, {})
    for p in _active():
        entries = p["data"].get(kind) or {}
        if not isinstance(entries, dict):
            _problem(p, f"{kind} must be an object of key: entry")
            continue
        for key, v in entries.items():
            if kind in ("style_fits", "look_flavour"):
                _merge_map(kind, p, key, v)
                continue
            if not ID_RX.fullmatch(str(key)):
                _problem(p, f"{kind} key '{key}': use lowercase letters, digits, dashes and underscores")
            elif key in snap:
                _problem(p, f"{kind} '{key}' is built in; packs add new entries, pick another key")
            elif key in added:
                _problem(p, f"{kind} '{key}' is also in the pack '{added[key]}'; that one is used")
            elif not isinstance(v, dict):
                _problem(p, f"{kind} '{key}' must be an object")
            else:
                entry, errs = CHECK[kind](key, v)
                for e in errs:
                    _problem(p, e)
                if entry:
                    entry["pack"] = p["id"]
                    target[key] = entry
                    added[key] = p["id"]


def _merge_map(kind: str, p: dict, key: str, v) -> None:
    target, snap = _targets[kind]
    if kind == "style_fits":
        styles = _targets.get("music_styles", ({}, {}))[0]
        if key not in styles or not (isinstance(v, list) and all(isinstance(x, str) for x in v)):
            _problem(p, f"style_fits '{key}': must be an existing music style and a list of industry words")
            return
        target.setdefault(key, [])
        target[key] = target[key] + [w.lower() for w in v if w.lower() not in target[key]]
    else:
        if v not in _targets.get("sfx_flavours", ({}, {}))[0]:
            _problem(p, f"look_flavour '{key}': '{v}' isn't a sound flavour")
        elif key in snap:
            _problem(p, f"look_flavour '{key}' is built in")
        else:
            target[key] = v


def _problem(p: dict, msg: str) -> None:
    lst = _state["errors"].setdefault(p["id"], [])
    if msg not in lst:
        lst.append(msg)


def ensure_loaded() -> None:
    """Import every engine that registers content (so checks and listings see all of it)."""
    from .mograph.library import looks, storyboards  # noqa: F401
    from .sound import composer, director, sfx  # noqa: F401


def reload() -> dict:
    """Re-read every pack and rebuild the engines' tables from their built-ins + packs (no restart needed)."""
    ensure_loaded()
    _state.update(packs=None, catalog=None, errors={}, added={})
    packs(refresh=True)
    for kind in ("looks", "music_styles", "sfx_flavours", "storyboards", "style_fits", "look_flavour"):
        if kind in _targets:
            target, snap = _targets[kind]
            target.clear()
            target.update(copy.deepcopy(snap))
            _merge(kind)
    for fn in _hooks:
        fn()
    return summary()


def on_reload(fn) -> None:
    _hooks.append(fn)


def summary() -> dict:
    ensure_loaded()
    out = []
    for p in packs():
        counts = {k: len(p["data"].get(k) or {}) for k in (*KINDS, "knowledge") if p["data"].get(k)}
        out.append({k: p.get(k) for k in ("id", "name", "version", "author", "description", "source", "enabled", "path")}
                   | {"counts": counts, "problems": p["problems"] + _state["errors"].get(p["id"], [])})
    return {"packs": out, "dir": str(packs_dir()),
            "totals": {k: len(_targets[k][0]) for k in ("looks", "storyboards", "music_styles", "sfx_flavours")
                       if k in _targets}}


# ---- installing / removing ------------------------------------------------------------------------
def install_pack(src: Path, sha256: str | None = None) -> dict:
    """A pack folder or .zip → <data folder>/packs/<id>. Checked first; nothing is copied if it has problems."""
    import hashlib
    import tempfile
    src = Path(src)
    if sha256 and hashlib.sha256(src.read_bytes()).hexdigest() != sha256.lower():
        raise ValueError("the pack download doesn't match the signed update feed; not installed")
    with tempfile.TemporaryDirectory() as tmp:
        folder = src
        if src.suffix.lower() == ".zip":
            with zipfile.ZipFile(src) as z:
                for n in z.namelist():
                    if n.startswith("/") or ".." in Path(n).parts or not re.search(r"(pack\.json|\.md|/)$", n):
                        raise ValueError(f"packs hold only pack.json and knowledge .md files ({n})")
                z.extractall(tmp)
            found = sorted(Path(tmp).rglob("pack.json"), key=lambda f: len(f.parts))
            if not found:
                raise ValueError("no pack.json in the zip")
            folder = found[0].parent
        data = json.loads((folder / "pack.json").read_text(encoding="utf-8"))
        pid = str(data.get("id") or "")
        if not ID_RX.fullmatch(pid):
            raise ValueError("pack.json needs an id: lowercase letters, digits and dashes")
        problems = check_pack(folder)
        if problems:
            raise ValueError("; ".join(problems[:6]))
        dest = packs_dir() / pid
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(folder, dest, ignore=shutil.ignore_patterns(".*"))
    reload()
    return {"id": pid, "path": str(dest)}


def check_pack(folder: Path) -> list[str]:
    """Problems with a pack folder, without installing it (release.py and the install use this)."""
    ensure_loaded()
    p = _read_pack(Path(folder), "check")
    if p is None:
        return ["no pack.json"]
    errs = list(p["problems"])
    data = p["data"]
    unknown = [k for k in data if k not in (*KINDS, "knowledge", "catalog", "id", "name", "version", "author",
                                            "description", "min_app", "homepage")]
    errs += [f"unknown section '{k}'" for k in unknown]
    for kind in CHECK:
        for key, v in (data.get(kind) or {}).items():
            if key in _targets[kind][1]:
                errs.append(f"{kind} '{key}' is built in")
            elif isinstance(v, dict):
                errs += CHECK[kind](key, v)[1]
    for t in data.get("knowledge") or {}:
        if not (HERE.parent / "knowledge" / f"{t}.md").exists():
            errs.append(f"knowledge '{t}': no such topic (use {', '.join(f.stem for f in (HERE.parent / 'knowledge').glob('*.md'))})")
    bad = [k for k in data.get("catalog") or {} if k not in CATALOG_PARTS]
    errs += [f"catalog '{k}' can only come with an app update" for k in bad]
    return errs


def remove_pack(pid: str) -> None:
    d = packs_dir() / pid
    if not ID_RX.fullmatch(pid or "") or not (d / "pack.json").exists():
        raise ValueError("no such pack on this computer (built-in packs can be switched off, not removed)")
    shutil.rmtree(d)
    reload()


def set_enabled(pid: str, on: bool) -> None:
    p = next((x for x in packs() if x["id"] == pid), None)
    if not p:
        raise ValueError("no such pack")
    flag = Path(p["path"]) / ".disabled"
    if on:
        flag.unlink(missing_ok=True)
    else:
        flag.write_text("switched off on the This Mac tab\n")
    reload()


# ---- knowledge + catalog --------------------------------------------------------------------------
def knowledge_extra(topic: str) -> str:
    out = []
    for p in _active():
        t = (p["data"].get("knowledge") or {}).get(topic)
        if isinstance(t, str) and t.strip():
            out.append(t.strip())
    return "\n\n".join(out)


def _deep(a: dict, b: dict) -> dict:
    out = dict(a)
    for k, v in b.items():
        out[k] = _deep(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out


def catalog() -> dict:
    """catalog.json, plus what packs add to its ai / whisper / features parts."""
    if _state["catalog"] is None:
        c = json.loads(CATALOG_FILE.read_text(encoding="utf-8"))
        for p in _active():
            extra = {k: v for k, v in (p["data"].get("catalog") or {}).items() if k in CATALOG_PARTS and isinstance(v, dict)}
            c = _deep(c, extra)
        _state["catalog"] = c
    return _state["catalog"]


def feature(settings: dict, name: str) -> bool:
    """An experiment switch: settings `features: {name: true}` wins, else the catalog's default."""
    mine = (settings.get("features") or {}) if settings else {}
    if name in mine:
        return bool(mine[name])
    return bool(((catalog().get("features") or {}).get(name) or {}).get("default", False))
