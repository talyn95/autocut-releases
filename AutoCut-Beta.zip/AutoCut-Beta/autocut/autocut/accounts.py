"""People's own AI accounts: ChatGPT (OpenAI) and Grok (xAI) next to Claude, for extra brainpower and images.

Each person pastes an API key from that maker's developer console (This Mac → AI accounts). A chat subscription
(ChatGPT Plus, SuperGrok, Claude Pro) can't be plugged into other apps; the developer account is the way in, billed
per use to that person, with a monthly cap here so it never runs away. (To use a chat subscription *with*
AutoCut, it works the other way round: mcp.py makes AutoCut a connector inside Claude Desktop and other AI apps.)

Both speak the OpenAI-style API (chat/completions, images/generations, models). Which model to use is "auto" by
default: the first id from catalog.json `ai.accounts.<id>.prefer` that the account actually has, so new models are
picked up as the makers release them. brain.py asks these after the free local AI, in `ai.cloud_order`.

Settings (`ai:`): chatgpt_api_key / grok_api_key (or OPENAI_API_KEY / XAI_API_KEY), chatgpt_model / grok_model
("auto" or an id), chatgpt_monthly_limit_usd / grok_monthly_limit_usd, cloud_order.
"""
from __future__ import annotations

import base64
import json
import os
import time
import urllib.error
import urllib.request

from . import content

IDS = ("chatgpt", "grok")
_models: dict[str, tuple[float, list[str]]] = {}  # (key tail, provider) → (when, model ids)


def spec(pid: str) -> dict:
    return content.catalog()["ai"]["accounts"][pid]


def key(settings: dict, pid: str) -> str:
    a = settings.get("ai") or {}
    return str(a.get(f"{pid}_api_key") or os.environ.get(spec(pid)["env"]) or "").strip()


def masked(k: str) -> str:
    return f"{k[:5]}…{k[-4:]}" if len(k) > 12 else ("set" if k else "")


def limit(settings: dict, pid: str) -> float:
    return float((settings.get("ai") or {}).get(f"{pid}_monthly_limit_usd", 25))


def _req(settings: dict, pid: str, path: str, body: dict | None = None, timeout: float = 60) -> dict:
    k = key(settings, pid)
    req = urllib.request.Request(spec(pid)["base"].rstrip("/") + path,
                                 data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Authorization": f"Bearer {k}", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())


def _error(e: Exception) -> str:
    if isinstance(e, urllib.error.HTTPError):
        try:
            msg = json.loads(e.read()).get("error", {})
            msg = msg.get("message") if isinstance(msg, dict) else str(msg)
        except Exception:  # noqa: BLE001
            msg = ""
        return {401: "the key was refused (check it, or make a new one)", 403: "this key isn't allowed to do that",
                429: "the account is out of credit or over its rate limit"}.get(e.code, f"error {e.code}") + \
            (f": {msg[:160]}" if msg else "")
    return f"couldn't reach it ({e})"


def models(settings: dict, pid: str, refresh: bool = False) -> list[str]:
    """The model ids this account can use (cached for 6 hours)."""
    ck = f"{pid}:{key(settings, pid)[-6:]}"
    hit = _models.get(ck)
    if hit and not refresh and time.time() - hit[0] < 6 * 3600:
        return hit[1]
    ids = sorted(m.get("id", "") for m in _req(settings, pid, "/models", timeout=15).get("data", []))
    _models[ck] = (time.time(), ids)
    return ids


def _pick(ids: list[str], prefer: list[str], avoid: list[str]) -> str:
    ok = [m for m in ids if not any(a in m.lower() for a in avoid)]
    for want in prefer:
        exact = [m for m in ok if m == want]
        if exact:
            return exact[0]
        starts = sorted((m for m in ok if m.startswith(want)), key=lambda m: (len(m), m))
        if starts:
            return starts[0]
    return ok[-1] if ok else ""


def model(settings: dict, pid: str) -> str:
    want = str((settings.get("ai") or {}).get(f"{pid}_model") or "auto")
    if want != "auto":
        return want
    s = spec(pid)
    return _pick(models(settings, pid), s["prefer"], s.get("avoid", []))


def image_model(settings: dict, pid: str) -> str:
    s = spec(pid)
    ids = models(settings, pid)
    return next((m for want in s.get("image_prefer", []) for m in ids if m == want or m.startswith(want)), "")


def available(settings: dict, pid: str) -> tuple[bool, str]:
    from .brain import usage
    if not key(settings, pid):
        return False, "not connected"
    used = usage().get("by", {}).get(pid, {}).get("usd", 0.0)
    if used >= limit(settings, pid):
        return False, f"this month's limit (${limit(settings, pid):.0f}) is used up"
    return True, ""


def ask(settings: dict, pid: str, system: str, prompt: str, schema: dict | None, images: list | None,
        timeout: float) -> dict | str | None:
    """One question to this account (None if it can't answer; brain.py then tries the next engine)."""
    from pathlib import Path

    from .brain import _parse, record, strict_schema
    ok, _ = available(settings, pid)
    if not ok:
        return None
    try:
        m = model(settings, pid)
    except Exception as e:  # noqa: BLE001
        print(f"  ! {spec(pid)['label']}: {_error(e)}")
        return None
    content_parts: list | str = prompt
    if images:
        content_parts = [{"type": "text", "text": prompt}] + [
            {"type": "image_url", "image_url": {"url": "data:image/png;base64," + base64.b64encode(Path(p).read_bytes()).decode()}}
            for p in images]
    body = {"model": m, "messages": [{"role": "system", "content": system}, {"role": "user", "content": content_parts}]}
    tries = [dict(body, response_format={"type": "json_schema", "json_schema": {"name": "answer", "strict": True,
                                                                                 "schema": strict_schema(schema)}}), body] \
        if schema else [body]
    for b in tries:
        try:
            r = _req(settings, pid, "/chat/completions", b, timeout=timeout)
        except Exception as e:  # noqa: BLE001
            if isinstance(e, urllib.error.HTTPError) and e.code == 400 and b is not tries[-1]:
                continue  # this model doesn't take a JSON schema: ask plainly, _parse reads the JSON
            print(f"  ! {spec(pid)['label']}: {_error(e)}")
            return None
        u = r.get("usage") or {}
        s = spec(pid)
        record(pid, m, (u.get("prompt_tokens", 0) * s["usd_in"] + u.get("completion_tokens", 0) * s["usd_out"]) / 1e6)
        text = ((r.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
        out = _parse(text, schema)
        if out is not None:
            return out
    return None


SHAPES = {"chatgpt": {"square": "1024x1024", "vertical": "1024x1536", "landscape": "1536x1024"},
          "grok": {"square": "1:1", "vertical": "9:16", "landscape": "16:9"}}


def image(settings: dict, pid: str, prompt: str, shape: str = "square") -> bytes:
    """One generated image (PNG/JPEG bytes) from this account. Raises RuntimeError with a plain reason."""
    from .brain import record
    ok, why = available(settings, pid)
    if not ok:
        raise RuntimeError(f"{spec(pid)['label']}: {why}")
    try:
        m = image_model(settings, pid)
    except Exception as e:  # noqa: BLE001
        raise RuntimeError(f"{spec(pid)['label']}: {_error(e)}")
    if not m:
        raise RuntimeError(f"{spec(pid)['label']}: this account has no image model")
    body = {"model": m, "prompt": prompt[:3800], "n": 1}
    if pid == "chatgpt":
        body["size"] = SHAPES["chatgpt"].get(shape, "1024x1024")
    else:
        body.update(response_format="b64_json", aspect_ratio=SHAPES["grok"].get(shape, "1:1"))
    try:
        r = _req(settings, pid, "/images/generations", body, timeout=300)
    except urllib.error.HTTPError as e:
        if pid == "grok" and e.code == 400 and "aspect_ratio" in body:  # older image models: no aspect ratio
            body.pop("aspect_ratio")
            r = _req(settings, pid, "/images/generations", body, timeout=300)
        else:
            raise RuntimeError(f"{spec(pid)['label']}: {_error(e)}")
    except Exception as e:  # noqa: BLE001
        raise RuntimeError(f"{spec(pid)['label']}: {_error(e)}")
    d = (r.get("data") or [{}])[0]
    record(pid, m, spec(pid).get("usd_image", 0.1))
    if d.get("b64_json"):
        return base64.b64decode(d["b64_json"])
    if d.get("url"):
        with urllib.request.urlopen(d["url"], timeout=120) as resp:
            return resp.read()
    raise RuntimeError(f"{spec(pid)['label']}: no image came back")


def test(settings: dict, pid: str) -> dict:
    """Check a key works: list its models and ask a one-word question."""
    if not key(settings, pid):
        return {"ok": False, "error": "paste an API key first"}
    try:
        ids = models(settings, pid, refresh=True)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": _error(e)}
    m = model(settings, pid)
    t0 = time.time()
    out = ask(settings, pid, "Reply with the single word: ready", "Are you ready?", None, None, 60)
    if not out:
        return {"ok": False, "error": f"the account answered the model list but not a question with {m}", "model": m}
    return {"ok": True, "model": m, "image_model": image_model(settings, pid), "models": len(ids),
            "seconds": round(time.time() - t0, 1)}


def status(settings: dict) -> dict:
    from .brain import usage
    by = usage().get("by", {})
    out = {}
    for pid in IDS:
        s = spec(pid)
        k = key(settings, pid)
        ok, why = available(settings, pid)
        out[pid] = {"label": s["label"], "maker": s["maker"], "console": s["console"], "connected": bool(k),
                    "available": ok, "reason": why, "key": masked(k),
                    "model": str((settings.get("ai") or {}).get(f"{pid}_model") or "auto"),
                    "limit_usd": limit(settings, pid), "usd": round(by.get(pid, {}).get("usd", 0.0), 2),
                    "calls": by.get(pid, {}).get("calls", 0)}
    return out
