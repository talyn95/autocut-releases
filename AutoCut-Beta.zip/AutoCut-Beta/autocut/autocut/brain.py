"""The AI brain: one place every feature asks a question.

Order, by default:
  1. the free local model on this Mac (Ollama, e.g. gemma3), no cost, nothing leaves the office
     (or any OpenAI-compatible server you point `openai_url` at: LM Studio, vLLM, llama.cpp; tried next)
  2. Claude, only as backup: if the local model isn't running, times out, or gives an unusable answer,
     and only when a Claude API key is set and this month's spend is under `claude_monthly_limit_usd`
  3. None: every caller has a rules-based fallback, so AutoCut still works with no AI at all

A caller can pass prefer="cloud" (or the older "claude") for a job where quality matters more than cost ("Use my AI
account" in the dashboard): the person's connected accounts go first, in `cloud_order`. Monthly caps still apply.
Connected accounts: Claude (here), ChatGPT and Grok (accounts.py).

Settings (settings.yaml, `ai:`): local_url, local_model ("auto" picks by this Mac's memory),
openai_url / openai_model / openai_api_key (an OpenAI-compatible server; blank url = off),
claude_backup, claude_api_key (or the ANTHROPIC_API_KEY environment variable), claude_model ("auto" = the
catalog's current default), claude_monthly_limit_usd.

Which models exist, their memory tiers and prices live in content/catalog.json, not here: when a better free
model or a new Claude model comes out, a signed update (or a content pack) changes the catalog and every "auto"
setting moves to it. A new kind of provider is one more `_ask_<name>` function added to ENGINES.
"""
from __future__ import annotations

import base64
import json
import os
import subprocess
import sys
import threading
import time
import urllib.request
from datetime import datetime
from pathlib import Path

from . import content
from .config import LOCAL_SETTINGS

USAGE_FILE = LOCAL_SETTINGS.parent / "ai-usage.json"
_lock = threading.Lock()
_last: dict = {}  # which engine answered the most recent question (for logs / the dashboard)


def cfg(settings: dict) -> dict:
    a = dict(settings.get("ai") or {})
    old = settings.get("local_llm") or {}  # settings from before 0.10
    a.setdefault("local_url", old.get("url", "http://127.0.0.1:11434"))
    if old.get("model") and old.get("model") != "llama3.2":
        a.setdefault("local_model", old["model"])
    a.setdefault("local_model", "auto")
    a.setdefault("claude_backup", True)
    a.setdefault("claude_model", "auto")
    if a["claude_model"] in ("", "auto", None):
        a["claude_model"] = content.catalog()["ai"]["claude"]["default"]
    a.setdefault("cloud_order", ["claude", "chatgpt", "grok"])
    a.setdefault("openai_url", "")
    a.setdefault("openai_model", "")
    a.setdefault("openai_api_key", "")
    a.setdefault("claude_monthly_limit_usd", 25)
    return a


def memory_gb() -> float:
    try:
        if sys.platform == "win32":
            import ctypes

            class MemStatus(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MemStatus()
            m.dwLength = ctypes.sizeof(MemStatus)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return m.ullTotalPhys / 2**30
        if sys.platform == "darwin":
            return int(subprocess.run(["sysctl", "-n", "hw.memsize"], capture_output=True, text=True).stdout) / 2**30
        return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 2**30
    except (OSError, ValueError):
        return 16.0


def recommended_model(gb: float | None = None) -> str:
    """The biggest free model this Mac runs comfortably (catalog.json `ai.local.tiers`, biggest first)."""
    gb = memory_gb() if gb is None else gb
    tiers = sorted(content.catalog()["ai"]["local"]["tiers"], key=lambda t: -t["min_gb"])
    return next((t["model"] for t in tiers if gb >= t["min_gb"]), tiers[-1]["model"])


def prices(model: str) -> tuple[float, float]:
    """$ per million tokens (input, output), for the monthly cap. Unknown models count at the priciest rate."""
    models = content.catalog()["ai"]["claude"]["models"]
    m = models.get(model) or max(models.values(), key=lambda x: x["usd_out"])
    return m["usd_in"], m["usd_out"]


# ---- local (Ollama) ------------------------------------------------------------------------
def local_status(settings: dict) -> dict:
    c = cfg(settings)
    url = c["local_url"].rstrip("/")
    want = recommended_model() if c["local_model"] == "auto" else c["local_model"]
    try:
        with urllib.request.urlopen(url + "/api/tags", timeout=1.0) as r:
            models = [m["name"] for m in json.loads(r.read()).get("models", [])]
    except Exception:
        return {"running": False, "model": want, "installed": [], "ready": False}
    have = want if want in models else next((m for m in models if m.split(":")[0] == want.split(":")[0]), None)
    have = have or (models[0] if models else None)
    return {"running": True, "model": have or want, "installed": models, "ready": bool(have)}


def _ask_local(settings: dict, system: str, prompt: str, schema: dict | None, images: list[Path] | None,
               timeout: float) -> dict | str | None:
    st = local_status(settings)
    if not st["ready"]:
        return None
    msg = {"role": "user", "content": prompt}
    if images:
        msg["images"] = [base64.b64encode(Path(p).read_bytes()).decode() for p in images]
    body = {"model": st["model"], "stream": False, "messages": [{"role": "system", "content": system}, msg],
            "options": {"temperature": 0.4, "num_ctx": 16384}}
    if schema:
        body["format"] = schema  # Ollama constrains the answer to this JSON schema
    req = urllib.request.Request(cfg(settings)["local_url"].rstrip("/") + "/api/chat", data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            text = json.loads(r.read())["message"]["content"]
    except Exception:
        return None
    return _parse(text, schema)


# ---- an OpenAI-compatible server (LM Studio, vLLM, llama.cpp, Jan, …) ------------------------------------
def compatible_status(settings: dict) -> dict:
    c = cfg(settings)
    url = (c.get("openai_url") or "").rstrip("/")
    if not url:
        return {"configured": False, "running": False, "model": "", "models": []}
    try:
        req = urllib.request.Request(url + "/models", headers=_compat_headers(c))
        with urllib.request.urlopen(req, timeout=1.5) as r:
            models = [m.get("id") for m in json.loads(r.read()).get("data", [])]
    except Exception:
        return {"configured": True, "running": False, "model": c.get("openai_model") or "", "models": [], "url": url}
    model = c.get("openai_model") or (models[0] if models else "")
    return {"configured": True, "running": True, "model": model, "models": models, "url": url}


def _compat_headers(c: dict) -> dict:
    h = {"Content-Type": "application/json"}
    if c.get("openai_api_key"):
        h["Authorization"] = "Bearer " + c["openai_api_key"]
    return h


def _ask_compatible(settings: dict, system: str, prompt: str, schema: dict | None, images: list[Path] | None,
                    timeout: float) -> dict | str | None:
    st = compatible_status(settings)
    if not (st["running"] and st["model"]):
        return None
    c = cfg(settings)
    content_parts: list | str = prompt
    if images:
        content_parts = [{"type": "text", "text": prompt}] + [
            {"type": "image_url", "image_url": {"url": "data:image/png;base64," + base64.b64encode(Path(p).read_bytes()).decode()}}
            for p in images]
    body = {"model": st["model"], "temperature": 0.4,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": content_parts}]}
    tries = [dict(body, response_format={"type": "json_schema", "json_schema": {"name": "answer", "schema": schema}}), body] \
        if schema else [body]
    for b in tries:  # not every server takes a JSON schema; the plain request + _parse is the fallback
        req = urllib.request.Request(st["url"] + "/chat/completions", data=json.dumps(b).encode(), headers=_compat_headers(c))
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                text = json.loads(r.read())["choices"][0]["message"]["content"] or ""
        except Exception:
            continue
        out = _parse(text, schema)
        if out is not None:
            return out
    return None


# ---- Claude (backup) -------------------------------------------------------------------------
def _month() -> str:
    return datetime.now().strftime("%Y-%m")


def usage() -> dict:
    """This month's spend on connected AI accounts: total and per account ("by")."""
    try:
        data = json.loads(USAGE_FILE.read_text())
    except (OSError, json.JSONDecodeError):
        data = {}
    m = data.get(_month(), {})
    by = dict(m.get("by") or {})
    if "claude" not in by and m.get("usd"):  # usage files from before 0.23 counted Claude only
        by["claude"] = {"usd": m["usd"], "calls": m.get("calls", 0)}
    return {"month": _month(), "usd": round(m.get("usd", 0.0), 4), "calls": m.get("calls", 0), "by": by}


def record(pid: str, model: str, usd: float) -> None:
    with _lock:
        try:
            data = json.loads(USAGE_FILE.read_text())
        except (OSError, json.JSONDecodeError):
            data = {}
        m = data.setdefault(_month(), {"usd": 0.0, "calls": 0})
        if "by" not in m:
            m["by"] = {"claude": {"usd": m["usd"], "calls": m["calls"]}} if m["usd"] else {}
        b = m["by"].setdefault(pid, {"usd": 0.0, "calls": 0})
        for d in (m, b):
            d["usd"] += usd
            d["calls"] += 1
        USAGE_FILE.parent.mkdir(parents=True, exist_ok=True)
        USAGE_FILE.write_text(json.dumps(data, indent=1))


def _record(model: str, usage_obj) -> None:
    pin, pout = prices(model)
    record("claude", model, (getattr(usage_obj, "input_tokens", 0) * pin + getattr(usage_obj, "output_tokens", 0) * pout) / 1e6)


def claude_available(settings: dict) -> tuple[bool, str]:
    c = cfg(settings)
    if not (c.get("claude_api_key") or os.environ.get("ANTHROPIC_API_KEY")):
        return False, "no Claude API key set"
    try:
        import anthropic  # noqa: F401
    except ImportError:
        return False, "the anthropic package isn't installed"
    if usage()["by"].get("claude", {}).get("usd", 0.0) >= float(c["claude_monthly_limit_usd"]):
        return False, f"this month's Claude limit (${c['claude_monthly_limit_usd']}) is used up"
    return True, ""


def _ask_claude(settings: dict, system: str, prompt: str, schema: dict | None, images: list[Path] | None) -> dict | str | None:
    ok, _why = claude_available(settings)
    if not ok:
        return None
    import anthropic
    c = cfg(settings)
    client = anthropic.Anthropic(api_key=c.get("claude_api_key") or None)
    content: list = []
    for p in images or []:
        ext = Path(p).suffix.lower().lstrip(".")
        media = {"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png", "webp": "image/webp",
                 "gif": "image/gif"}.get(ext, "image/png")
        content.append({"type": "image", "source": {"type": "base64", "media_type": media,
                                                    "data": base64.standard_b64encode(Path(p).read_bytes()).decode()}})
    content.append({"type": "text", "text": prompt})
    kwargs = {}
    if schema:
        kwargs["output_config"] = {"format": {"type": "json_schema", "schema": strict_schema(schema)}}
    try:
        resp = client.beta.messages.create(
            model=c["claude_model"], max_tokens=16000, system=system,
            messages=[{"role": "user", "content": content}],
            betas=["server-side-fallback-2026-07-01"], fallbacks="default", **kwargs)
    except anthropic.APIStatusError as e:
        print(f"  ! Claude backup failed ({e.status_code}): {str(e.message)[:200]}")
        return None
    except anthropic.APIConnectionError:
        print("  ! Claude backup unreachable (network)")
        return None
    _record(c["claude_model"], resp.usage)
    if resp.stop_reason == "refusal":
        return None
    text = next((b.text for b in resp.content if b.type == "text"), "")
    return _parse(text, schema)


def strict_schema(schema: dict) -> dict:
    """Claude's structured output wants every object closed and every field listed as required."""
    s = dict(schema)
    if s.get("type") == "object":
        props = {k: strict_schema(v) for k, v in s.get("properties", {}).items()}
        s.update(properties=props, required=list(props), additionalProperties=False)
    elif s.get("type") == "array" and isinstance(s.get("items"), dict):
        s["items"] = strict_schema(s["items"])
    return s


def _parse(text: str, schema: dict | None):
    if not schema:
        return text.strip() or None
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`").split("\n", 1)[-1]
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        a, b = text.find("{"), text.rfind("}")
        try:
            data = json.loads(text[a:b + 1]) if a >= 0 else None
        except json.JSONDecodeError:
            data = None
    if not isinstance(data, dict):
        return None
    missing = [k for k in schema.get("required", []) if k not in data]
    return None if missing else data


# ---- the one entry point --------------------------------------------------------------------------
def ask(settings: dict, system: str, prompt: str, schema: dict | None = None, images: list[Path] | None = None,
        prefer: str = "local", timeout: float = 240) -> dict | str | None:
    """Ask the brain. Returns the parsed JSON (when a schema is given), text, or None if no AI answered."""
    c = cfg(settings)
    cloud = [x for x in c["cloud_order"] if x in ENGINES and x not in ("local", "compatible")]
    cloud += [x for x in ("claude", "chatgpt", "grok") if x not in cloud]
    if prefer in ("claude", "cloud", "chatgpt", "grok"):
        if prefer in ("chatgpt", "grok", "claude") and prefer in cloud:  # a specific account first
            cloud.remove(prefer)
            cloud.insert(0, prefer)
        order = cloud + ["local", "compatible"]
    else:
        order = ["local", "compatible"] + (cloud if c["claude_backup"] else [])
    for engine in order:
        t0 = time.time()
        out = ENGINES[engine](settings, system, prompt, schema, images, timeout)
        if out is not None:
            _last.update(engine=engine, seconds=round(time.time() - t0, 1), at=time.time())
            return out
    return None


def _account(pid):
    def ask_it(settings, system, prompt, schema, images, timeout):
        from . import accounts
        return accounts.ask(settings, pid, system, prompt, schema, images, timeout)
    return ask_it


ENGINES = {"local": _ask_local, "compatible": _ask_compatible,
           "claude": lambda st, sy, pr, sc, im, _t: _ask_claude(st, sy, pr, sc, im),
           "chatgpt": _account("chatgpt"), "grok": _account("grok")}


def last_engine() -> str | None:
    return _last.get("engine")


def status(settings: dict) -> dict:
    loc = local_status(settings)
    ok, why = claude_available(settings)
    c = cfg(settings)
    from . import accounts
    return {"local": loc, "compatible": compatible_status(settings), "accounts": accounts.status(settings),
            "cloud_order": c["cloud_order"], "claude": {"available": ok, "reason": why, "backup": c["claude_backup"],
                                     "key": accounts.masked(str(c.get("claude_api_key") or os.environ.get("ANTHROPIC_API_KEY") or "")),
                                     "usd_claude": round(usage()["by"].get("claude", {}).get("usd", 0.0), 2),
                                     "model_setting": str((settings.get("ai") or {}).get("claude_model") or "auto"),
                                     "model": c["claude_model"], "limit_usd": c["claude_monthly_limit_usd"],
                                     **usage()},
            "recommended_model": recommended_model(), "memory_gb": round(memory_gb())}
