"""AutoCut's marketing knowledge: the playbook every AI prompt starts from, the client's own
marketing brief, and the post copy pack (titles, captions, hashtags, chapters) for finished videos.

The playbook is what turns a general AI model into a short-form video marketer. Edit it here
when the team learns something; every feature picks it up.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from . import brain, content

KNOWLEDGE_DIR = Path(__file__).parent / "knowledge"
# which parts of the knowledge base each AI task reads (core is always first). Keeping it per task keeps the
# prompt small enough for the free local model while every feature thinks like a video marketer.
TASKS = {
    "copy": ["hooks", "copy", "platforms"],                      # post copy: titles, captions, hashtags
    "clips": ["hooks", "retention", "platforms"],               # judging and titling clips
    "design": ["design", "copy", "ads"],                        # still graphics
    "motion": ["motion", "hooks"],                              # motion graphics
    "reference": ["design"],                                    # reading a reference's style
    "music": ["music", "platforms"],                            # scoring: the music director and sound designer
    "strategist": ["hooks", "retention", "platforms", "ads", "copy", "scripts", "strategy", "agency", "design",
                   "motion", "music", "prompting"],
}
_cache: dict[str, str] = {}


def knowledge(*topics: str) -> str:
    """The named knowledge files (core first), joined."""
    out = []
    for t in ("core", *topics):
        if t not in _cache:
            f = KNOWLEDGE_DIR / f"{t}.md"
            base = f.read_text(encoding="utf-8").strip() if f.exists() else ""
            _cache[t] = "\n\n".join(x for x in (base, content.knowledge_extra(t)) if x)  # + content packs
        if _cache[t] and _cache[t] not in out:
            out.append(_cache[t])
    return "\n\n".join(out)


def topics_for(question: str) -> list[str]:
    """The knowledge files a free-form question needs (used by the Strategist with the small local model)."""
    q = question.lower()
    keys = {"hooks": r"hook|open|first second|scroll", "retention": r"retention|watch time|drop|keep watching|pacing",
            "platforms": r"tiktok|instagram|reel|youtube|short|linkedin|facebook|platform|google business|hashtag",
            "ads": r"\bads?\b|paid|meta|campaign|roas|cpl|cpm|ctr|offer|angle|creative test|budget",
            "copy": r"caption|copy|headline|title|description|cta|call to action|write",
            "scripts": r"script|shoot|interview|question|story|testimonial|b-roll|film",
            "strategy": r"plan|calendar|pillar|funnel|repurpos|strategy|month|week|cadence|local",
            "agency": r"client|agency|pric|package|retainer|onboard|report|contract|revision|proposal",
            "design": r"graphic|design|thumbnail|carousel|static|image|post\b|flyer",
            "motion": r"motion|animation|lower third|kinetic|graphic",
            "prompting": r"prompt|glossary|term|what does|mean"}
    import re as _re
    hit = [t for t, rx in keys.items() if _re.search(rx, q)]
    return hit or ["hooks", "strategy", "copy"]


# The whole playbook (kept for anything that wants it all, e.g. Claude with a big context window)
PLAYBOOK = knowledge(*TASKS["strategist"])


def _reload() -> None:  # a content pack was added or switched off
    global PLAYBOOK
    _cache.clear()
    PLAYBOOK = knowledge(*TASKS["strategist"])


content.on_reload(_reload)


def brief(brand: dict) -> str:
    """The client's marketing brief from brand.yaml (marketing: section)."""
    m = brand.get("marketing") or {}
    lines = [f"Client: {brand.get('client', '')}"]
    for key, label in (("industry", "Industry"), ("audience", "Audience"), ("offer", "What they sell / offer"),
                       ("voice", "Brand voice"), ("location", "Location / market"), ("goals", "Goals")):
        if m.get(key):
            lines.append(f"{label}: {m[key]}")
    cta = brand.get("cta") or {}
    if cta.get("text"):
        lines.append(f"Main call to action: {cta['text']}" + (f" ({cta['subtext']})" if cta.get("subtext") else ""))
    if m.get("platforms"):
        lines.append("Platforms: " + ", ".join(m["platforms"]))
    if m.get("hashtags"):
        lines.append("Always include these hashtags: " + " ".join(m["hashtags"]))
    if m.get("avoid"):
        lines.append("Never say: " + ", ".join(m["avoid"]))
    return "\n".join(lines)


def system_prompt(brand: dict | None = None, task: str = "copy", extra: list[str] | None = None) -> str:
    """Every AI prompt starts here: the agency's knowledge for this task, then the client's own brief."""
    topics = list(TASKS.get(task, TASKS["copy"])) + [t for t in (extra or []) if t not in TASKS.get(task, [])]
    return knowledge(*topics) + ("\n\n# THE CLIENT\n" + brief(brand) if brand else "")


STRATEGIST_ACTIONS = {
    "hooks": "Write 20 scroll-stopping hooks (under 8 words each) for this, grouped by hook type, true to the offer.",
    "plan": "Make a 30-day content plan: pillars, a weekly rhythm, and each post's format, hook and CTA in a table.",
    "script": "Write a 45-60 second short-form video script: on-screen hook text, what to say, B-roll ideas per line, CTA.",
    "ads": "Give 8 ad angles to test, each with a hook, the core message, the format (UGC, demo, testimonial...) and the CTA.",
    "interview": "Write 15 interview questions for a shoot that will produce great standalone clips, and why each works.",
    "review": "Review this caption/script/idea like a strict head of content: what works, what to cut, a rewritten version.",
    "repurpose": "Show how to repurpose one long video/podcast on this topic into a week of content across platforms.",
}


def strategist(question: str, settings: dict, brand: dict | None = None, action: str | None = None,
               prefer: str = "local") -> dict:
    """The Strategist: an agency head of content answering in plain words, using the knowledge base."""
    ask = (STRATEGIST_ACTIONS.get(action, "") + "\n\n" if action else "") + (question or "")
    topics = TASKS["strategist"] if prefer in ("claude", "cloud") else topics_for(ask)
    system = (knowledge(*topics) + ("\n\n# THE CLIENT\n" + brief(brand) if brand else "") +
              "\n\nAnswer as this agency's head of content: practical, specific to this client, formatted with short "
              "headings and bullet points (Markdown). Never invent facts about the client.")
    out = brain.ask(settings, system, ask.strip(), None, prefer=prefer, timeout=300)
    if isinstance(out, str) and out.strip():
        return {"answer": out.strip(), "engine": brain.last_engine()}
    # no AI running: the playbook itself is still useful
    return {"answer": "The AI isn't running on this computer, so here is the agency playbook on this topic:\n\n"
                      + knowledge(*topics_for(ask)), "engine": None}


# ---- post copy pack ---------------------------------------------------------------------------------
COPY_SCHEMA = {
    "type": "object",
    "properties": {
        "hooks": {"type": "array", "items": {"type": "string"}},
        "short_form": {"type": "object", "properties": {
            "title": {"type": "string"}, "caption": {"type": "string"},
            "hashtags": {"type": "array", "items": {"type": "string"}}}},
        "youtube": {"type": "object", "properties": {
            "title": {"type": "string"}, "description": {"type": "string"}}},
        "linkedin": {"type": "object", "properties": {"post": {"type": "string"}}},
        "facebook": {"type": "object", "properties": {"post": {"type": "string"}}},
    },
    "required": ["hooks", "short_form", "youtube", "linkedin", "facebook"],
}


def _fmt_time(s: float) -> str:
    s = int(s)
    return f"{s // 3600}:{s % 3600 // 60:02d}:{s % 60:02d}" if s >= 3600 else f"{s // 60}:{s % 60:02d}"


def chapters(words: list[dict], every: float = 90.0) -> list[tuple[float, str]]:
    """YouTube chapters for long videos: a new chapter at a sentence start roughly every `every` seconds."""
    if not words or words[-1]["end"] < 180:
        return []
    out, last = [(0.0, "")], 0.0
    for i, w in enumerate(words):
        prev = words[i - 1]["word"] if i else "."
        if w["start"] - last >= every and re.search(r"[.?!]$", prev):
            out.append((w["start"], ""))
            last = w["start"]
    # name each chapter from its first sentence
    named = []
    for n, (t, _) in enumerate(out):
        end = out[n + 1][0] if n + 1 < len(out) else 1e9
        seg = [w["word"] for w in words if t <= w["start"] < end][:10]
        title = " ".join(seg).strip(" ,.;")
        named.append((t, (title[:1].upper() + title[1:])[:60] or f"Part {n + 1}"))
    return named


def rule_copy(text: str, brand: dict, title: str = "") -> dict:
    """No AI available: a plain but usable pack straight from the transcript."""
    from .broll import STOP, stem
    from .effects.iconlib import GENERIC
    text = re.sub(r"\b(?:um+|uh+|uhm|erm|er|ah+|hmm+|mhm)\b,?\s*", "", text, flags=re.I)  # no ums in copy
    sentences = [re.sub(r"^(?:so|and|but|okay|ok|well),?\s+", "", s.strip(), flags=re.I)
                 for s in re.split(r"(?<=[.?!])\s+", text) if len(s.split()) >= 4]
    first = sentences[0] if sentences else text[:120]
    first = first[:1].upper() + first[1:]
    title = title or " ".join(first.split()[:9]).rstrip(",.;")
    m = brand.get("marketing") or {}
    tags = list(m.get("hashtags") or [])
    tags += ["#" + w for w in re.findall(r"[a-z]{4,}", (m.get("industry") or "").lower())]
    weak = STOP | GENERIC | {"yours", "minutes", "about", "there", "these", "those", "really", "would", "could",
                             "should", "every", "thing", "things", "today", "maybe", "actually"}
    words = [w.lower() for w in re.findall(r"[A-Za-z]{5,}", text) if w.lower() not in weak]
    counts: dict[str, int] = {}
    for w in words:
        counts[stem(w)] = counts.get(stem(w), 0) + 1
    from .effects.iconlib import index
    things = set(index())  # words with a picture are concrete nouns: better hashtags than verbs
    picks = sorted({w for w in words}, key=lambda w: (stem(w) not in things, -counts[stem(w)]))[:3]
    tags += ["#" + w for w in picks if "#" + w not in tags]
    cta = (brand.get("cta") or {}).get("text", "")
    body = " ".join(sentences[:2]) if sentences else first
    body = body[:1].upper() + body[1:]
    caption = body + (f"\n\n{cta}" if cta else "")
    return {"hooks": [title, " ".join(first.split()[:8]).rstrip(",.;")], "short_form": {"title": title,
            "caption": caption, "hashtags": list(dict.fromkeys(tags))[:5]},
            "youtube": {"title": title[:60], "description": caption},
            "linkedin": {"post": caption}, "facebook": {"post": caption}, "engine": "rules"}


def post_copy(words: list[dict], brand: dict, settings: dict, kind: str = "short", title: str = "",
              prefer: str = "local") -> dict:
    """Titles, captions, hashtags (and chapters for long videos) for one finished video."""
    text = " ".join(w["word"] for w in words)
    dur = words[-1]["end"] if words else 0
    chaps = chapters(words) if kind == "long" else []
    prompt = (f"Write the post copy for this {'long-form' if kind == 'long' else 'short-form'} video "
              f"({dur:.0f} seconds){' titled ' + repr(title) if title else ''}.\n"
              "Give: 3 alternative opening hooks (on-screen text, max 8 words each, true to the content); "
              "short-form title and caption with 3-5 hashtags; a YouTube title and description"
              + (" (the chapters are added for you, don't write them)" if chaps else "")
              + "; a LinkedIn post; a Facebook post. Use the client's call to action.\n\nTRANSCRIPT:\n" + text[:12000])
    out = brain.ask(settings, system_prompt(brand), prompt, COPY_SCHEMA, prefer=prefer)
    pack = out if isinstance(out, dict) else rule_copy(text, brand, title)
    pack.setdefault("engine", brain.last_engine() if isinstance(out, dict) else "rules")
    hashtags = pack["short_form"].get("hashtags") or []
    pack["short_form"]["hashtags"] = [h if h.startswith("#") else "#" + h.replace(" ", "") for h in hashtags][:6]
    if chaps:
        pack["chapters"] = [{"t": t, "label": _fmt_time(t), "title": name} for t, name in chaps]
        pack["youtube"]["description"] = (pack["youtube"]["description"].rstrip() + "\n\n" +
                                          "\n".join(f"{c['label']} {c['title']}" for c in pack["chapters"]))
    return pack


def write_copy(job: Path, pack: dict, words: list[dict] | None = None, kind: str = "short", title: str = "") -> Path:
    (job / "copy.json").write_text(json.dumps(pack, indent=1))
    if words is not None:  # kept so "Rewrite" in the dashboard can redo it later
        (job / "copy-source.json").write_text(json.dumps({"kind": kind, "title": title, "words": words}))
    sf, yt = pack["short_form"], pack["youtube"]
    md = [f"# Post copy ({pack.get('engine', 'rules')})", "", "## Hook options", *[f"- {h}" for h in pack["hooks"]], "",
          "## TikTok / Reels / Shorts", f"**{sf['title']}**", "", sf["caption"], "", " ".join(sf["hashtags"]), "",
          "## YouTube", f"**{yt['title']}**", "", yt["description"], "",
          "## LinkedIn", pack["linkedin"]["post"], "", "## Facebook", pack["facebook"]["post"], ""]
    out = job / "post-copy.md"
    out.write_text("\n".join(md))
    return out
