"""Flatten a Timeline into a quick H.264 preview (for review links / client approval).
Premiere remains the real finishing tool; this is a draft-quality look at the rough cut."""
from __future__ import annotations

import subprocess
from pathlib import Path

from .media import video_encoder
from .premiere_xml import Timeline


def render_preview(tl: Timeline, out: Path, height: int | None = 960, final: bool = False) -> Path:
    """height=None keeps full resolution. final=True: high-quality encode for delivery."""
    W, H = tl.size
    fps = tl.fps
    total = max([i["end"] for t in tl.video for i in t] or [0]) / fps
    inputs: list[str] = []
    idx: dict[Path, int] = {}

    def input_for(info) -> int:
        key = info.path.resolve()
        if key not in idx:
            if info.is_still:
                inputs.extend(["-loop", "1", "-framerate", f"{fps:.3f}", "-i", str(key)])
            else:
                inputs.extend(["-i", str(key)])
            idx[key] = len(idx)
        return idx[key]

    chains = [f"color=c=black:s={W}x{H}:r={fps:.3f}:d={total:.3f}[base0]"]
    layer = 0
    for t_i, track in enumerate(tl.video):
        for it in track:
            n = input_for(it["info"])
            # V1 clips run one frame long (hidden under the next clip) so float
            # rounding in trim can't flash the black canvas at a cut.
            s, e = it["in"] / fps, (it["out"] + (1 if t_i == 0 else 0)) / fps
            at = it["start"] / fps
            zoom = it.get("zoom", 1.0)
            cx, cy = it.get("center") or (0, 0)
            pos = "0:0"
            if zoom < 1.0 and it["info"].width:  # picture-in-picture: a smaller frame, moved by `center`
                zw, zh = int(W * zoom) // 2 * 2, int(H * zoom) // 2 * 2
                fit = f"scale={zw}:{zh}:force_original_aspect_ratio=increase,crop={zw}:{zh}"
                pos = f"{(W - zw) / 2 + cx * W:.0f}:{(H - zh) / 2 + cy * H:.0f}"
            elif it["info"].width and ((it["info"].width, it["info"].height) != (W, H) or zoom != 1.0):
                zw, zh = int(W * zoom) // 2 * 2, int(H * zoom) // 2 * 2
                fit = f"scale={zw}:{zh}:force_original_aspect_ratio=increase,crop={W}:{H}"
            else:
                fit = "null"
            chains.append(f"[{n}:v]trim=start={s:.4f}:end={e:.4f},setpts=PTS-STARTPTS+{at:.4f}/TB,"
                          f"{fit},format=yuva420p[c{layer}]")
            chains.append(f"[base{layer}][c{layer}]overlay={pos}:eof_action=pass:format=auto[base{layer + 1}]")
            layer += 1
    chains.append((f"[base{layer}]scale=-2:{height}," if height else f"[base{layer}]") + "format=yuv420p[vout]")

    # audio: one bus per track. With the A1 dialogue / A2 effects / A3 music layout the music ducks under the voice.
    roles = getattr(tl, "audio_layout", "stereo") == "roles"
    buses: dict[int, list[str]] = {}
    k = 0
    for t_i, track in enumerate(tl.audio):
        for it in track:
            if t_i == 1 and not roles:  # older timelines: A2 is the right channel of the same stereo source
                continue
            n = input_for(it["info"])
            s, e = it["in"] / fps, it["out"] / fps
            delay = int(it["start"] / fps * 1000)
            vol = f",volume={it['level']:.4f}" if it.get("level") is not None else ""
            chains.append(f"[{n}:a]atrim=start={s:.4f}:end={e:.4f},asetpts=PTS-STARTPTS,aformat=channel_layouts=stereo,"
                          f"adelay={delay}:all=1{vol}[a{k}]")
            buses.setdefault(t_i, []).append(f"[a{k}]")
            k += 1
    outs = []
    for t_i, labels in sorted(buses.items()):
        chains.append(f"{''.join(labels)}amix=inputs={len(labels)}:normalize=0[bus{t_i}]" if len(labels) > 1
                      else f"{labels[0]}anull[bus{t_i}]")
        outs.append(f"[bus{t_i}]")
    if roles and 0 in buses and 2 in buses:  # duck the music (A3) under the dialogue (A1)
        chains.append("[bus0]asplit=2[dlg][key]")
        chains.append("[bus2][key]sidechaincompress=threshold=0.02:ratio=6:attack=20:release=450:makeup=1[musd]")
        outs = ["[dlg]" if o == "[bus0]" else "[musd]" if o == "[bus2]" else o for o in outs]
    maps = ["-map", "[vout]"]
    if outs:
        mix = f"amix=inputs={len(outs)}:normalize=0," if len(outs) > 1 else ""
        chains.append(f"{''.join(outs)}{mix}alimiter=limit=0.97[aout]")
        maps += ["-map", "[aout]"]
    script = out.with_suffix(".filter.txt")
    script.write_text(";\n".join(chains))
    cmd = ["ffmpeg", "-y", "-loglevel", "error", *inputs, "-filter_complex_script", str(script),
           *maps, "-t", f"{total:.3f}", *video_encoder("final" if final else "preview"),
           "-profile:v", "high", "-movflags", "+faststart",
           "-c:a", "aac", "-b:a", "192k" if final else "160k", str(out)]
    res = subprocess.run(cmd, capture_output=True, text=True)
    script.unlink(missing_ok=True)
    if res.returncode != 0:
        raise RuntimeError(f"preview render failed: {res.stderr[-1500:]}")
    return out
