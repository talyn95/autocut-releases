"""This computer: what it is, what it can do, and how fast.

AutoCut runs entirely on each person's own computer, so speed depends on that computer. This module reads the hardware
(chip, cores, memory, graphics, free disk), runs a short speed test (video encoding + audio synthesis), and picks the
heavy settings that suit it when they're left on "auto": the speech model, the free local AI model, whether the
optional AI music model is worth installing. The This Mac / This PC tab shows all of it in plain words.
"""
from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path

from .config import LOCAL_SETTINGS, clients_dir

CACHE = LOCAL_SETTINGS.parent / "hardware.json"
TIERS = {
    "light": "Light: fine for short videos and graphics; long videos and AI music are slow here",
    "standard": "Standard: handles everyday short-form work comfortably",
    "pro": "Pro: handles long videos, multicam and the optional AI music model well",
}


def _run(cmd: list[str], timeout: float = 5) -> str:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return ""


def _chip() -> str:
    if sys.platform == "darwin":
        return _run(["sysctl", "-n", "machdep.cpu.brand_string"]) or platform.processor() or "Mac"
    if sys.platform == "win32":
        out = _run(["powershell", "-NoProfile", "-Command", "(Get-CimInstance Win32_Processor).Name"])
        return out.splitlines()[0].strip() if out else platform.processor()
    try:
        for line in Path("/proc/cpuinfo").read_text().splitlines():
            if line.startswith("model name"):
                return line.split(":", 1)[1].strip()
    except OSError:
        pass
    return platform.processor() or platform.machine()


def _nvidia() -> dict | None:
    if not shutil.which("nvidia-smi"):
        return None
    out = _run(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"])
    if not out:
        return None
    name, mem = (out.splitlines()[0].split(",") + ["0"])[:2]
    try:
        return {"name": name.strip(), "vram_gb": round(float(mem) / 1024, 1)}
    except ValueError:
        return {"name": name.strip(), "vram_gb": 0}


def profile(settings: dict | None = None) -> dict:
    """The hardware, read fresh (a second or two: it test-runs the graphics chip's video encoder once)."""
    from .brain import memory_gb
    from .media import _hardware_h264
    apple = sys.platform == "darwin" and platform.machine() == "arm64"
    nv = _nvidia()
    disk_root = clients_dir(settings) if settings else Path.home()
    while not disk_root.exists() and disk_root != disk_root.parent:
        disk_root = disk_root.parent
    try:
        free = shutil.disk_usage(disk_root).free / 2**30
    except OSError:
        free = 0.0
    enc = "" if os.environ.get("AUTOCUT_SOFTWARE_ENCODE") else _hardware_h264()
    return {"os": {"darwin": "mac", "win32": "windows"}.get(sys.platform, "linux"), "chip": _chip(),
            "apple_silicon": apple, "cores": os.cpu_count() or 1, "memory_gb": round(memory_gb(), 1),
            "nvidia": nv, "encoder": enc or "libx264 (the processor)", "hardware_encoder": bool(enc),
            "disk_free_gb": round(free, 1), "disk_path": str(disk_root)}


def tier(p: dict) -> str:
    gb, cores = p["memory_gb"], p["cores"]
    fast_ai = p["apple_silicon"] or bool(p.get("nvidia") and p["nvidia"].get("vram_gb", 0) >= 6)
    if gb >= 30 and cores >= 10 and fast_ai:  # (a 16 GB PC reports ~15.8 GB)
        return "pro"
    if gb >= 15 and (fast_ai or cores >= 8):
        return "standard"
    return "light"


def recommend(p: dict) -> dict:
    """The heavy settings that suit this computer (used where settings say "auto")."""
    from .brain import recommended_model
    gpu_whisper = p["apple_silicon"] or bool(p.get("nvidia"))
    if gpu_whisper and p["memory_gb"] >= 8:
        whisper = "large-v3-turbo"  # fast on Apple Silicon / NVIDIA, the most accurate captions
    elif p["cores"] >= 8 and p["memory_gb"] >= 15:
        whisper = "medium"          # processor only: near-turbo accuracy, a third of the work
    else:
        whisper = "small"
    music_ai = (p["apple_silicon"] and p["memory_gb"] >= 15) or bool(p.get("nvidia") and p["nvidia"].get("vram_gb", 0) >= 8)
    return {"whisper_model": whisper, "local_ai_model": recommended_model(p["memory_gb"]), "ai_music": music_ai,
            "motion_blur_samples": 4 if tier(p) != "light" else 2}


def whisper_model(cfg: dict) -> str:
    """The speech model to use: the setting, or this computer's pick when it's "auto" (cached hardware read)."""
    m = (cfg or {}).get("model") or "auto"
    if m != "auto":
        return m
    p = cached().get("profile")
    if not p:
        from .config import load_settings
        p = profile(load_settings())
    return recommend(p)["whisper_model"]


def benchmark(settings: dict | None = None) -> dict:
    """A ~10 second speed test: encode 6 s of vertical video the way AutoCut does, and compose 8 s of music."""
    import tempfile

    from .media import video_encoder
    out = {}
    with tempfile.TemporaryDirectory() as tmp:
        t0 = time.time()
        r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i", "testsrc2=s=1080x1920:r=30:d=6",
                            *video_encoder("high"), "-pix_fmt", "yuv420p", str(Path(tmp) / "b.mp4")],
                           capture_output=True, timeout=300)
        enc_s = time.time() - t0
        out["encode_fps"] = round(180 / enc_s, 1) if r.returncode == 0 else 0
    t0 = time.time()
    from .sound import composer
    composer.compose({"style": "corporate", "seed": 1}, 8.0)
    out["music_x_realtime"] = round(8.0 / max(0.05, time.time() - t0), 1)
    # A rough 10-minute talking-head estimate: transcription + one render of the cut + the preview
    p = profile(settings)
    rec = recommend(p)
    rtf = {"large-v3-turbo": 0.06 if p["apple_silicon"] or p.get("nvidia") else 0.5, "medium": 0.25, "small": 0.12}
    trans = 600 * rtf.get(rec["whisper_model"], 0.3)
    render = 2 * 600 * 30 / max(1.0, out["encode_fps"])
    mins = (trans + render + 60) / 60
    out["ten_minute_video_min"] = [max(1, round(mins * 0.7)), max(2, round(mins * 1.4))]
    out["at"] = time.strftime("%Y-%m-%d %H:%M")
    data = {"profile": p, "benchmark": out}
    CACHE.parent.mkdir(parents=True, exist_ok=True)
    CACHE.write_text(json.dumps(data, indent=1))
    return out


def cached() -> dict:
    try:
        return json.loads(CACHE.read_text())
    except (OSError, ValueError):
        return {}


def summary(settings: dict) -> dict:
    """Everything the This Mac tab shows about this computer."""
    p = profile(settings)
    c = cached()
    if c.get("profile") != p:
        c = {"profile": p, "benchmark": c.get("benchmark")}
        CACHE.parent.mkdir(parents=True, exist_ok=True)
        CACHE.write_text(json.dumps(c, indent=1))
    t = tier(p)
    rec = recommend(p)
    notes = []
    if p["disk_free_gb"] < 50:
        notes.append(f"Only {p['disk_free_gb']:.0f} GB free where the clients folder is. Footage and renders need room: "
                     "keep 100 GB+ free, or move the clients folder to a bigger drive.")
    if not p["hardware_encoder"]:
        notes.append("No graphics-chip video encoder here, so the processor encodes video (slower, and the computer works harder).")
    if p["memory_gb"] < 15:
        notes.append("16 GB of memory or more makes long videos and the local AI noticeably smoother.")
    if not rec["ai_music"]:
        notes.append("The optional AI music model needs Apple Silicon with 16 GB+ or an NVIDIA card with 8 GB+; "
                     "the built-in Composer makes the music here (it's fast on any computer).")
    return {"profile": p, "tier": t, "tier_label": TIERS[t], "recommended": rec, "benchmark": c.get("benchmark"),
            "notes": notes,
            "settings": {"whisper_model": whisper_model(settings.get("whisper") or {}),
                         "whisper_auto": (settings.get("whisper") or {}).get("model", "auto") in ("auto", "", None)}}
