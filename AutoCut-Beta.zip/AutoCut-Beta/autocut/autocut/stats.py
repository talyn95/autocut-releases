"""Share your monthly totals (opt-in): videos made, editing hours saved, average turnaround, so Triumphant Media can
show what AutoCut does for agencies.

Nothing is sent unless the person says yes (the monthly results pop-up and This Mac ask; `consent()` records it in
this computer's state.json). What goes: one row per computer per month with the totals from results.month (counts by
kind, hours saved, footage minutes, average and fastest turnaround), the AutoCut version, the hardware tier and the
OS, and a random id for this install so a month isn't counted twice. Never client names, video names, transcripts,
footage, or anything about the agency's clients. The agency name goes only if they also tick "include my agency name"
(for case studies).

Where it goes: the HTTPS address in content/catalog.json `stats.url` (set by the owner and shipped in a signed
release; packs can't change it), or a `stats_url` in this computer's settings. docs/STATS.md has a ready-made Google
Sheet receiver. `maybe_send()` runs at start-up and once a day: last month's row goes once, retried on later days if
the address was unreachable.
"""
from __future__ import annotations

import json
import platform
import sys
import time
import urllib.request
import uuid

from . import __version__, migrations

FIELDS = ("rough_cuts", "clips", "multicam", "extra_shapes", "graphics", "motion_graphics", "music")


def url(settings: dict) -> str:
    from . import content
    u = str(settings.get("stats_url") or (content.catalog().get("stats") or {}).get("url") or "").strip()
    return u if u.startswith("https://") or u.startswith("http://127.0.0.1") or u.startswith("http://localhost") else ""


def info(settings: dict) -> dict:
    st = migrations.state()
    return {"share": st.get("stats_share"), "include_name": bool(st.get("stats_name")), "agency": st.get("stats_agency", ""),
            "ready": bool(url(settings)), "last_sent": st.get("stats_sent")}


def consent(share: bool, include_name: bool = False, agency: str = "") -> None:
    st = migrations.state()
    st["stats_share"] = bool(share)
    st["stats_name"] = bool(share and include_name and agency.strip())
    st["stats_agency"] = agency.strip()[:80] if st["stats_name"] else ""
    st.setdefault("install_id", uuid.uuid4().hex)
    migrations._save(st)


def row(settings: dict, ym: str) -> dict:
    """What would be sent for a month: totals only."""
    from . import hardware, results
    m = results.month(settings, ym)
    st = migrations.state()
    out = {"month": ym, "install": st.get("install_id") or "", "version": __version__,
           "os": "mac" if sys.platform == "darwin" else "windows" if sys.platform.startswith("win") else "other",
           "tier": hardware.tier(hardware.cached()["profile"]) if (hardware.cached() or {}).get("profile") else "",
           "chip": platform.machine(),
           "videos": m["videos"], "pieces": m["pieces"], "hours_saved": m["hours_saved"],
           "footage_minutes": m["footage_minutes"], "avg_turnaround_minutes": m["turnaround_minutes"],
           "fastest_minutes": m["fastest_minutes"]}
    out.update({k: int(m["counts"].get(k, 0)) for k in FIELDS})
    if st.get("stats_name") and st.get("stats_agency"):
        out["agency"] = st["stats_agency"]
    return out


def maybe_send(settings: dict, now: float | None = None, force: bool = False) -> dict | None:
    """Send last month's row if this computer agreed and it hasn't gone yet. Returns the row sent (None: nothing)."""
    from .results import _prev
    st = migrations.state()
    target = url(settings)
    if st.get("stats_share") is not True or not target:
        return None
    last = _prev(time.strftime("%Y-%m", time.localtime(now)))
    if st.get("stats_sent") == last and not force:
        return None
    r = row(settings, last)
    if not r["pieces"] and not force:
        st["stats_sent"] = last  # an empty month: nothing worth sending
        migrations._save(st)
        return None
    req = urllib.request.Request(target, data=json.dumps(r).encode(), method="POST",
                                 headers={"Content-Type": "application/json", "User-Agent": f"AutoCut/{__version__}"})
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            resp.read(2000)
    except Exception:  # noqa: BLE001 - offline or the sheet is down: try again tomorrow
        return None
    st = migrations.state()
    st["stats_sent"] = last
    migrations._save(st)
    return r
