"""Free stock B-roll (Pexels, then Pixabay) when a client's own library has nothing for a topic.

Both services are free for commercial use and need a free API key (This Mac → Settings):
    stock:
      pexels_api_key: "…"     https://www.pexels.com/api/
      pixabay_api_key: "…"    https://pixabay.com/api/docs/

Downloads land in the client's assets/broll/stock/, tagged with the search words (so they're
reused next time) and credited in assets/broll/stock/CREDITS.csv.
"""
from __future__ import annotations

import csv
import json
import re
import urllib.parse
import urllib.request
from collections import Counter
from pathlib import Path

from .broll import STOP, content_words, stem

TIMEOUT = 20
ORIENTATION = {"vertical": "portrait", "portrait": "portrait", "square": "square", "landscape": "landscape"}


def _get_json(url: str, headers: dict | None = None) -> dict:
    req = urllib.request.Request(url, headers={"User-Agent": "AutoCut/1.0", **(headers or {})})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        return json.loads(r.read().decode())


def _download(url: str, dest: Path) -> Path:
    req = urllib.request.Request(url, headers={"User-Agent": "AutoCut/1.0"})
    part = dest.with_suffix(".part")
    with urllib.request.urlopen(req, timeout=60) as r, part.open("wb") as f:
        while chunk := r.read(1 << 20):
            f.write(chunk)
    part.replace(dest)
    return dest


def search_pexels(query: str, key: str, orientation: str) -> list[dict]:
    q = urllib.parse.urlencode({"query": query, "per_page": 6, "orientation": orientation, "size": "medium"})
    data = _get_json(f"https://api.pexels.com/videos/search?{q}", {"Authorization": key})
    out = []
    for v in data.get("videos", []):
        files = [f for f in v.get("video_files", []) if f.get("file_type") == "video/mp4" and f.get("width")]
        if not files:
            continue
        # the smallest file that's still at least 1080 on its short side, else the biggest
        good = [f for f in files if min(f["width"], f["height"]) >= 1080]
        f = min(good, key=lambda f: f["width"] * f["height"]) if good else max(files, key=lambda f: f["width"] * f["height"])
        out.append({"provider": "pexels", "id": v["id"], "url": f["link"], "duration": v.get("duration", 0),
                    "credit": (v.get("user") or {}).get("name", ""), "page": v.get("url", "")})
    return out


def search_pixabay(query: str, key: str, orientation: str) -> list[dict]:
    q = urllib.parse.urlencode({"key": key, "q": query, "per_page": 6, "safesearch": "true"})
    data = _get_json(f"https://pixabay.com/api/videos/?{q}")
    out = []
    for v in data.get("hits", []):
        sizes = v.get("videos", {})
        f = sizes.get("large") if sizes.get("large", {}).get("url") else sizes.get("medium")
        if not f or not f.get("url"):
            continue
        portrait = f.get("height", 0) > f.get("width", 0)
        if (orientation == "portrait") != portrait and orientation != "square":
            continue  # Pixabay has no orientation filter; keep matching shapes when possible
        out.append({"provider": "pixabay", "id": v["id"], "url": f["url"], "duration": v.get("duration", 0),
                    "credit": v.get("user", ""), "page": v.get("pageURL", "")})
    return out


def topics(words: list[dict], library_tags: set[str], client_name: str, n: int) -> list[str]:
    """The most-mentioned concrete words the client's library has no clip for."""
    skip = {stem(w) for w in re.findall(r"[A-Za-z']+", client_name)}
    counts = Counter()
    first_form: dict[str, str] = {}
    for w in words:
        word = re.sub(r"[^a-z]", "", w["word"].lower())
        if len(word) < 4 or word in STOP:
            continue
        s = stem(word)
        if s in skip or s in library_tags:
            continue
        counts[s] += 1
        first_form.setdefault(s, word)
    return [first_form[s] for s, _ in counts.most_common(n)]


def fetch(client, words: list[dict], settings: dict, library_tags: set[str], fmt: str) -> list[Path]:
    """Download up to broll.stock_per_video clips for uncovered topics. Never raises."""
    cfg = settings.get("stock") or {}
    keys = [(search_pexels, cfg.get("pexels_api_key")), (search_pixabay, cfg.get("pixabay_api_key"))]
    keys = [(fn, k) for fn, k in keys if k]
    if not keys:
        return []
    folder = client.folder / "assets" / "broll" / "stock"
    folder.mkdir(parents=True, exist_ok=True)
    orientation = ORIENTATION.get(fmt, "landscape")
    tags_path = client.folder / "assets" / "tags.json"
    try:
        tags = json.loads(tags_path.read_text()) if tags_path.exists() else {}
    except json.JSONDecodeError:
        tags = {}
    got: list[Path] = []
    for topic in topics(words, library_tags, client.brand["client"], int(client.brand["broll"]["stock_per_video"])):
        for search, key in keys:
            try:
                results = [r for r in search(topic, key, orientation) if 2 <= (r["duration"] or 5) <= 40]
            except Exception as e:
                print(f"  ! stock search '{topic}' ({search.__name__}): {e}")
                continue
            done = False
            for r in results:
                dest = folder / f"{r['provider']}-{r['id']}-{topic}.mp4"
                rel = dest.relative_to(client.folder).as_posix()
                try:
                    if not dest.exists():
                        _download(r["url"], dest)
                        with (folder / "CREDITS.csv").open("a", newline="") as f:
                            csv.writer(f).writerow([dest.name, r["provider"], r["credit"], r["page"]])
                    tags[rel] = (tags.get(rel, "") + f", {topic}").strip(", ")
                    got.append(dest)
                    print(f"  ✓ stock b-roll for '{topic}': {dest.name} ({r['provider']}, by {r['credit'] or 'unknown'})")
                    done = True
                    break
                except Exception as e:
                    print(f"  ! stock download failed ({r['provider']} {r['id']}): {e}")
            if done:
                break
    if got:
        tmp = tags_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(tags, indent=2, sort_keys=True))
        tmp.replace(tags_path)
    return got


def library_tags(clips) -> set[str]:
    out: set[str] = set()
    for c in clips:
        out |= c.tags
    return out


__all__ = ["fetch", "topics", "library_tags", "content_words"]
