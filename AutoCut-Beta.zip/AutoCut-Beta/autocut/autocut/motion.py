"""Bridge to the Kinetik Motion Studio engine (Node + Puppeteer on the editing Mac).

Each client keeps motion-studio spec *templates* in their `motion/` folder.
A template is a normal motion-studio spec with placeholders that are filled
per video:

    {{CLIENT}} {{CTA_TEXT}} {{CTA_SUBTEXT}} {{HOOK}} {{WORD}}

AutoCut swaps the client's brand.json into the studio, renders each piece as
a ProRes 4444 overlay (`render.mjs --format mov`), restores the studio's own
brand.json, and places the result on the graphics track of the timeline.
"""
from __future__ import annotations

import json
import shutil
import socket
import subprocess
import time
from contextlib import contextmanager
from pathlib import Path

from .config import Client
from .edit import norm
from .media import probe


@contextmanager
def _studio_lock(studio: Path, stale_after: float = 900):
    """One Motion Studio render at a time across ALL Macs. mkdir is atomic on a
    network share (file locks are not), so the lock is a directory."""
    lock = studio / ".autocut-lock"
    while True:
        try:
            lock.mkdir()
            break
        except FileExistsError:
            try:
                if time.time() - lock.stat().st_mtime > stale_after:  # a crashed Mac left it
                    shutil.rmtree(lock, ignore_errors=True)
                    continue
            except FileNotFoundError:
                continue
            time.sleep(2)
    try:
        (lock / "owner").write_text(socket.gethostname())
        yield
    finally:
        shutil.rmtree(lock, ignore_errors=True)


@contextmanager
def _studio_brand(studio: Path, brand_json: Path | None):
    live = studio / "brand.json"
    backup = studio / "brand.json.autocut-backup"
    try:
        if brand_json and brand_json.exists():
            shutil.copy2(live, backup)
            shutil.copy2(brand_json, live)
        yield
    finally:
        if backup.exists():
            shutil.move(backup, live)


def _fill(template: str, values: dict[str, str]) -> str:
    for k, v in values.items():
        template = template.replace("{{" + k + "}}", json.dumps(v)[1:-1])
    return template


def _resolve_place(place, words: list[dict], content_end: float) -> tuple[float, str] | None:
    if place in (None, "start"):
        return 0.0, ""
    if place == "end":
        return content_end, ""
    if isinstance(place, (int, float)):
        return float(place), ""
    if isinstance(place, str) and place.startswith("word:"):
        target = norm(place[5:])
        hit = next((w for w in words if norm(w["word"]) == target), None)
        return (hit["start"], hit["word"]) if hit else None
    raise ValueError(f"Unknown motion placement: {place!r}")


def render_pieces(client: Client, settings: dict, words: list[dict], content_end: float,
                  values: dict[str, str], workdir: Path) -> list[dict]:
    cfg = client.brand["motion_studio"]
    pieces = [p for p in cfg["pieces"] if client.path(p["spec"]).exists()]
    for p in cfg["pieces"]:
        if p not in pieces:
            print(f"  - motion piece {p['spec']} not found in the client folder, skipped")
    if not pieces:
        return []
    if not settings["motion_studio_path"]:
        print("  - motion graphics: Motion Studio isn't set up on this Mac (motion_studio_path), skipped")
        return []
    studio = Path(settings["motion_studio_path"]).expanduser()
    if not (studio / "render.mjs").exists():
        print(f"  ! motion studio not found at '{studio}' — skipping motion graphics "
              "(set motion_studio_path in settings.yaml)")
        return []
    placed = []
    with _studio_lock(studio), _studio_brand(studio, client.path(cfg["brand_json"])):
        for n, piece in enumerate(pieces):
            where = _resolve_place(piece.get("place"), words, content_end)
            if where is None:
                print(f"  - motion piece {piece['spec']}: trigger word not spoken, skipped")
                continue
            start, word = where
            template = client.path(piece["spec"])
            name = f"autocut-{client.slug}-{n}-{template.stem}"
            spec = studio / "specs" / f"{name}.json"
            spec.write_text(_fill(template.read_text(), {**values, "WORD": word}))
            t0 = time.time()
            for cmd in (["node", "lib/validate.mjs", str(spec)],
                        ["node", "render.mjs", str(spec), "--format", "mov"]):
                res = subprocess.run(cmd, cwd=studio, capture_output=True, text=True)
                if res.returncode != 0:
                    raise RuntimeError(f"motion studio failed on {template.name}:\n{res.stdout}{res.stderr}")
            out = studio / "out" / f"{name}.mov"
            if not out.exists():
                fresh = [p for p in (studio / "out").glob("*.mov") if p.stat().st_mtime >= t0]
                if not fresh:
                    raise RuntimeError(f"motion studio rendered nothing for {template.name}")
                out = max(fresh, key=lambda p: p.stat().st_mtime)
            dest = workdir / f"motion_{n}_{template.stem}.mov"
            shutil.copy2(out, dest)
            placed.append({"path": dest, "start": start, "duration": probe(dest).duration,
                           "name": template.stem})
            print(f"  ✓ motion graphic '{template.stem}' at {start:.2f}s")
    return placed
