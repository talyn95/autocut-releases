"""Ed25519 signatures (RFC 8032) in pure Python, so every AutoCut can check that an update really came from
Triumphant Media without any extra package. Verifying takes a few milliseconds; signing (release tool only) too.
Adapted from the RFC 8032 reference implementation (section 6).
"""
from __future__ import annotations

import hashlib
import os

p = 2 ** 255 - 19
L = 2 ** 252 + 27742317777372353535851937790883648493
d = -121665 * pow(121666, p - 2, p) % p
I = pow(2, (p - 1) // 4, p)


def _h(m: bytes) -> bytes:
    return hashlib.sha512(m).digest()


def _xrecover(y: int) -> int:
    xx = (y * y - 1) * pow(d * y * y + 1, p - 2, p)
    x = pow(xx, (p + 3) // 8, p)
    if (x * x - xx) % p != 0:
        x = (x * I) % p
    if x % 2 != 0:
        x = p - x
    return x


By = 4 * pow(5, p - 2, p) % p
B = (_xrecover(By), By, 1, _xrecover(By) * By % p)  # extended coordinates (X, Y, Z, T)


def _add(P, Q):
    x1, y1, z1, t1 = P
    x2, y2, z2, t2 = Q
    a = (y1 - x1) * (y2 - x2) % p
    b = (y1 + x1) * (y2 + x2) % p
    c = t1 * 2 * d * t2 % p
    dd = z1 * 2 * z2 % p
    e, f, g, h = b - a, dd - c, dd + c, b + a
    return (e * f % p, g * h % p, f * g % p, e * h % p)


def _mul(s: int, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _add(Q, P)
        P = _add(P, P)
        s >>= 1
    return Q


def _equal(P, Q) -> bool:
    x1, y1, z1, _ = P
    x2, y2, z2, _ = Q
    return (x1 * z2 - x2 * z1) % p == 0 and (y1 * z2 - y2 * z1) % p == 0


def _encode(P) -> bytes:
    x, y, z, _ = P
    zi = pow(z, p - 2, p)
    x, y = x * zi % p, y * zi % p
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _decode(s: bytes):
    if len(s) != 32:
        raise ValueError("bad point")
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    if y >= p:
        raise ValueError("bad point")
    x = _xrecover(y)
    if (x * x * d * y * y - y * y + x * x + 1) % p != 0 and ((-x * x + y * y - 1 - d * x * x * y * y) % p) != 0:
        raise ValueError("not on curve")
    if x & 1 != sign:
        x = p - x
    return (x, y, 1, x * y % p)


def _secret_scalar(seed: bytes) -> tuple[int, bytes]:
    h = _h(seed)
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def public_key(seed: bytes) -> bytes:
    a, _ = _secret_scalar(seed)
    return _encode(_mul(a, B))


def keygen() -> tuple[bytes, bytes]:
    """(private 32-byte seed, public key)."""
    seed = os.urandom(32)
    return seed, public_key(seed)


def sign(seed: bytes, msg: bytes) -> bytes:
    a, prefix = _secret_scalar(seed)
    A = _encode(_mul(a, B))
    r = int.from_bytes(_h(prefix + msg), "little") % L
    R = _encode(_mul(r, B))
    k = int.from_bytes(_h(R + A + msg), "little") % L
    return R + int.to_bytes((r + k * a) % L, 32, "little")


def verify(public: bytes, msg: bytes, sig: bytes) -> bool:
    try:
        if len(sig) != 64:
            return False
        A = _decode(public)
        R = _decode(sig[:32])
        s = int.from_bytes(sig[32:], "little")
        if s >= L:
            return False
        k = int.from_bytes(_h(sig[:32] + public + msg), "little") % L
        return _equal(_mul(s, B), _add(R, _mul(k, A)))
    except (ValueError, TypeError):
        return False
