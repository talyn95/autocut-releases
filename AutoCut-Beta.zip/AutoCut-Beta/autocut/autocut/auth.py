"""Logins for the web-hosted AutoCut.

Off on an office Mac (`web.require_login: false`, the default). On for a hosted install: every page
and API call then needs a signed-in user. Roles: `admin` (everything, including the team list,
machine settings and updates) and `editor` (all the editing work).

Users live in `users.json` next to the clients folder (shared by every Mac). Passwords are stored
only as PBKDF2-SHA256 hashes. Sessions are random tokens in an HttpOnly cookie, kept in memory
(a restart signs everyone out). After 5 wrong passwords from one address, that address waits 15 minutes.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
import threading
import time
from datetime import datetime
from pathlib import Path

ITERATIONS = 600_000
ROLES = ("admin", "editor")
MIN_PASSWORD = 10
COOKIE = "autocut_session"


class LoginError(Exception):
    pass


def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, ITERATIONS)
    return f"pbkdf2_sha256${ITERATIONS}${salt.hex()}${digest.hex()}"


def check_password(password: str, stored: str) -> bool:
    try:
        _, iters, salt, digest = stored.split("$")
    except ValueError:
        return False
    got = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), int(iters))
    return hmac.compare_digest(got.hex(), digest)


class Auth:
    def __init__(self, settings: dict, data_dir: Path):
        self.settings = settings
        self.file = data_dir / "users.json"
        self.audit_file = data_dir / "audit.log"
        self.sessions: dict[str, dict] = {}
        self.failures: dict[str, list[float]] = {}
        self.lock = threading.Lock()
        # first run of a hosted install: a one-time code to create the first admin (printed in the log)
        self.setup_code = secrets.token_hex(4).upper() if self.enabled and not self._load() else None

    # ---- settings -------------------------------------------------------------------------
    @property
    def cfg(self) -> dict:
        return self.settings.get("web") or {}

    @property
    def enabled(self) -> bool:
        return bool(self.cfg.get("require_login")) or os.environ.get("AUTOCUT_HOSTED") == "1"

    # ---- users ------------------------------------------------------------------------------
    def _load(self) -> dict:
        try:
            return json.loads(self.file.read_text())
        except (OSError, json.JSONDecodeError):
            return {}

    def _save(self, users: dict) -> None:
        self.file.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.file.with_name(f".users.{os.getpid()}.{threading.get_ident()}")
        tmp.write_text(json.dumps(users, indent=1))
        os.chmod(tmp, 0o600)
        tmp.replace(self.file)

    def list_users(self) -> list[dict]:
        return [{"name": n, "role": u["role"], "created": u.get("created"), "last_login": u.get("last_login")}
                for n, u in sorted(self._load().items())]

    @staticmethod
    def _check_name(name: str) -> str:
        name = (name or "").strip().lower()
        if not re.fullmatch(r"[a-z0-9][a-z0-9._@-]{1,63}", name):
            raise ValueError("User names are 2-64 letters, numbers, dots, dashes or @ (an email works)")
        return name

    @staticmethod
    def _check_password(password: str) -> None:
        if len(password or "") < MIN_PASSWORD:
            raise ValueError(f"Passwords need at least {MIN_PASSWORD} characters")

    def add_user(self, name: str, password: str, role: str = "editor") -> dict:
        name = self._check_name(name)
        self._check_password(password)
        if role not in ROLES:
            raise ValueError("role must be admin or editor")
        with self.lock:
            users = self._load()
            if name in users:
                raise ValueError(f"{name} already exists")
            users[name] = {"role": role, "hash": hash_password(password), "created": _now()}
            self._save(users)
        self.setup_code = None
        return {"name": name, "role": role}

    def set_password(self, name: str, password: str) -> None:
        self._check_password(password)
        with self.lock:
            users = self._load()
            if name not in users:
                raise ValueError(f"no user {name}")
            users[name]["hash"] = hash_password(password)
            self._save(users)
        self.end_sessions(name)

    def set_role(self, name: str, role: str) -> None:
        if role not in ROLES:
            raise ValueError("role must be admin or editor")
        with self.lock:
            users = self._load()
            if name not in users:
                raise ValueError(f"no user {name}")
            if users[name]["role"] == "admin" and role != "admin" and self._admins(users) <= 1:
                raise ValueError("Keep at least one admin")
            users[name]["role"] = role
            self._save(users)

    def remove_user(self, name: str) -> None:
        with self.lock:
            users = self._load()
            if name not in users:
                raise ValueError(f"no user {name}")
            if users[name]["role"] == "admin" and self._admins(users) <= 1:
                raise ValueError("Keep at least one admin")
            del users[name]
            self._save(users)
        self.end_sessions(name)

    @staticmethod
    def _admins(users: dict) -> int:
        return sum(1 for u in users.values() if u["role"] == "admin")

    def setup_first_admin(self, code: str, name: str, password: str) -> dict:
        if not self.setup_code or self._load():
            raise PermissionError("This AutoCut already has users. Ask an admin to add you.")
        if not hmac.compare_digest((code or "").strip().upper(), self.setup_code):
            raise PermissionError("That setup code isn't right. It's printed in the server log when AutoCut starts.")
        return self.add_user(name, password, "admin")

    # ---- sign in / out --------------------------------------------------------------------------
    def login(self, name: str, password: str, ip: str) -> str:
        now = time.time()
        with self.lock:
            recent = [t for t in self.failures.get(ip, []) if now - t < 900]
            self.failures[ip] = recent
            if len(recent) >= 5:
                raise LoginError("Too many wrong passwords. Try again in 15 minutes.")
        users = self._load()
        user = users.get((name or "").strip().lower())
        ok = check_password(password or "", user["hash"]) if user else check_password(password or "", _dummy())
        if not ok:
            with self.lock:
                self.failures.setdefault(ip, []).append(now)
            self.audit(name, ip, "login failed")
            raise LoginError("Wrong user name or password")
        name = name.strip().lower()
        token = secrets.token_urlsafe(32)
        hours = float(self.cfg.get("session_hours", 12))
        with self.lock:
            self.failures.pop(ip, None)
            self.sessions[token] = {"name": name, "role": user["role"], "expires": now + hours * 3600}
            users[name]["last_login"] = _now()
            self._save(users)
        self.audit(name, ip, "signed in")
        return token

    def session(self, token: str | None) -> dict | None:
        if not token:
            return None
        s = self.sessions.get(token)
        if not s or s["expires"] < time.time():
            self.sessions.pop(token, None)
            return None
        return s

    def logout(self, token: str | None) -> None:
        self.sessions.pop(token or "", None)

    def end_sessions(self, name: str) -> None:
        with self.lock:
            for t in [t for t, s in self.sessions.items() if s["name"] == name]:
                del self.sessions[t]

    def audit(self, user: str | None, ip: str, what: str) -> None:
        try:
            with self.audit_file.open("a") as f:
                f.write(f"{_now()}\t{user or '-'}\t{ip}\t{what}\n")
        except OSError:
            pass


_dummy_hash: list[str] = []


def _dummy() -> str:
    """So a wrong user name takes as long as a wrong password (no guessing which names exist)."""
    if not _dummy_hash:
        _dummy_hash.append(hash_password("timing-equaliser"))
    return _dummy_hash[0]


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")
