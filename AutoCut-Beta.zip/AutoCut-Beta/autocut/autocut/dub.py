"""AI dubbing: a finished short in another language, voiced by AutoCut's own local voice.

`dub(job, lang)` turns a ready job into `<job>/dub-<lang>/`:
  1. the cut's sentences (words.json, or captions.srt for older jobs) with their timeline slots
  2. translated by the AI brain, each line kept about as long as the original (or your own translation:
     `lines=` / a pasted text, one line per sentence, so no AI is needed)
  3. voiced with sound/voice.py (Kokoro, the language's built-in voice; never a clone of the speaker) and fitted
     to its slot: re-spoken faster when long (never past `MAX_SPEED`); a line that still runs long pushes the next
     one back a little instead of being cut or talked over
  4. dub.wav (48 kHz mono), translated captions (SRT + the client's caption style), an XML with the dub on A1 and
     the translated captions on V11 (music and effects kept), and a preview MP4.
Everything is labelled as AI-dubbed (sequence name, a marker, dub.json) so it can be disclosed when posted.
"""
from __future__ import annotations

import json
import re
import subprocess
import tempfile
from pathlib import Path

RATE = 48000
MAX_SPEED = 1.3  # fastest the voice is asked to speak to fit a slot

# language → (name, Kokoro language code, {gender: built-in voice})
LANGS = {
    "es": ("Spanish", "es", {"male": "em_alex", "female": "ef_dora"}),
    "fr": ("French", "fr-fr", {"male": "ff_siwis", "female": "ff_siwis"}),
    "it": ("Italian", "it", {"male": "im_nicola", "female": "if_sara"}),
    "pt": ("Portuguese (Brazil)", "pt-br", {"male": "pm_alex", "female": "pf_dora"}),
    "hi": ("Hindi", "hi", {"male": "hm_omega", "female": "hf_alpha"}),
    "en": ("English", "en-us", {"male": "am_michael:60,am_onyx:40", "female": "af_heart"}),
}


def languages() -> list[dict]:
    return [{"code": k, "name": v[0]} for k, v in LANGS.items()]


# ---- the lines to dub ---------------------------------------------------------------------------------------
def _srt_lines(path: Path) -> list[dict]:
    def secs(ts):
        h, m, rest = ts.strip().split(":")
        s, ms = rest.split(",")
        return int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 1000
    out = []
    for block in re.split(r"\n\s*\n", path.read_text().strip()):
        rows = block.strip().splitlines()
        if len(rows) >= 3 and "-->" in rows[1]:
            a, b = rows[1].split("-->")
            out.append({"start": secs(a), "end": secs(b), "text": " ".join(rows[2:]).strip()})
    return out


def sentences(words: list[dict], max_secs: float = 7.0) -> list[dict]:
    """Timeline words → spoken lines: one per sentence. Long or unpunctuated runs split at a comma or a breath
    once past max_secs, and always by 1.5 × max_secs."""
    out, cur = [], []

    def flush():
        if cur:
            out.append({"start": cur[0]["start"], "end": cur[-1]["end"],
                        "text": " ".join(w["word"].strip() for w in cur)})
            cur.clear()
    for w in words:
        if cur:
            span, gap = w["start"] - cur[0]["start"], w["start"] - cur[-1]["end"]
            if (gap > 1.2 or span > max_secs * 1.5
                    or span > max_secs and (cur[-1]["word"].rstrip().endswith(",") or gap > 0.12)):
                flush()
        cur.append(w)
        if re.search(r"[.?!]$", w["word"].strip()):
            flush()
    flush()
    return out


def job_lines(job: Path) -> list[dict]:
    if (job / "words.json").exists():
        return sentences(json.loads((job / "words.json").read_text()))
    if (job / "captions.srt").exists():  # cut by an older AutoCut: caption lines, merged into sentences
        merged, cur = [], None
        for ln in _srt_lines(job / "captions.srt"):
            if (cur and not re.search(r"[.?!]$", cur["text"]) and ln["start"] - cur["end"] < 0.8
                    and ln["end"] - cur["start"] <= 7.0):
                cur = {**cur, "end": ln["end"], "text": cur["text"] + " " + ln["text"]}
            else:
                if cur:
                    merged.append(cur)
                cur = dict(ln)
        return merged + ([cur] if cur else [])
    raise ValueError("This video has no transcript to dub yet. Re-run it once first.")


# ---- translation ----------------------------------------------------------------------------------------------
SCHEMA = {"type": "object", "properties": {"lines": {"type": "array", "items": {"type": "string"}}},
          "required": ["lines"]}


def translate(lines: list[dict], lang: str, settings: dict, brand: dict | None = None) -> list[str] | None:
    """The AI brain's translation, one line per line, or None (no AI answered / it lost lines)."""
    from . import brain
    name = LANGS[lang][0]
    keep = ", ".join((brand or {}).get("vocabulary") or [])
    system = (f"You translate short marketing videos into natural, spoken {name}. Each line must be speakable in "
              "about the same time as the original: use short everyday words, keep numbers, prices, names and "
              "the brand as they are, and keep the tone. One output line per input line, same order.")
    prompt = "\n".join(f"{i + 1}. ({ln['end'] - ln['start']:.1f}s) {ln['text']}" for i, ln in enumerate(lines))
    prompt = (f"Translate these {len(lines)} lines into {name}." + (f" Never translate: {keep}." if keep else "")
              + f'\n\n{prompt}\n\nReturn JSON {{"lines": [...{len(lines)} strings]}}.')
    try:
        out = brain.ask(settings, system, prompt, schema=SCHEMA, timeout=240, prefer="local")
    except Exception:  # noqa: BLE001 — no AI means the caller asks for a translation instead
        return None
    got = out.get("lines") if isinstance(out, dict) else None
    if not isinstance(got, list) or len(got) != len(lines) or not all(isinstance(x, str) and x.strip() for x in got):
        return None
    return [re.sub(r"^\s*\d+[.)]\s*", "", x).strip() for x in got]


def parse_translation(text: str, count: int) -> list[str]:
    """A translation pasted by a person: one line per sentence (numbering is fine)."""
    rows = [re.sub(r"^\s*\d+[.)]\s*", "", r).strip() for r in text.splitlines()]
    rows = [r for r in rows if r]
    if len(rows) != count:
        raise ValueError(f"The translation has {len(rows)} lines, but the video has {count} sentences. "
                         "Use one line per sentence.")
    return rows


# ---- voicing and fitting ----------------------------------------------------------------------------------------
def slots(lines: list[dict], total: float) -> list[tuple[float, float]]:
    """Each line may run from its start until just before the next line starts (or the end)."""
    out = []
    for i, ln in enumerate(lines):
        nxt = lines[i + 1]["start"] if i + 1 < len(lines) else total
        out.append((ln["start"], max(ln["start"] + 0.3, nxt - 0.08)))
    return out


def fit_speed(spoken: float, room: float, speed: float = 1.0) -> float | None:
    """The speed to re-speak at so `spoken` seconds fit in `room`, or None when it already fits."""
    if spoken <= room:
        return None
    return round(min(MAX_SPEED, speed * spoken / room * 1.03), 3)


def _read(path: Path):
    import numpy as np
    import soundfile as sf
    a, sr = sf.read(str(path), dtype="float32", always_2d=False)
    if a.ndim > 1:
        a = a.mean(axis=1)
    if sr != RATE:
        raise ValueError(f"unexpected sample rate {sr}")
    return np.asarray(a, dtype="float32")


def voice_lines(texts: list[str], lines: list[dict], total: float, lang: str, settings: dict, gender: str,
                work: Path, speak=None) -> tuple:
    """Speak every line into its slot. Returns (track samples, [{start, end, text, speed, fits}])."""
    import numpy as np
    from .sound import voice
    speak = speak or voice.speak
    name, code, voices = LANGS[lang]
    vname = voices.get(gender) or voices["male"]
    track = np.zeros(int((total + 0.5) * RATE), dtype="float32")
    placed, prev_end = [], 0.0
    for i, (text, (a, b)) in enumerate(zip(texts, slots(lines, total))):
        a = max(a, prev_end + 0.08)  # a line that ran long pushes the next one back a little
        clip, speed = work / f"line_{i:03}.wav", 1.0
        speak(text, clip, settings, voice=vname, speed=speed, lang=code)
        samples = _read(clip)
        for _ in range(2):  # the voice's speed isn't exactly linear: re-check once more
            faster = fit_speed(len(samples) / RATE, max(0.3, b - a), speed)
            if not faster or faster <= speed:
                break
            speed = faster
            speak(text, clip, settings, voice=vname, speed=speed, lang=code)
            samples = _read(clip)
        s0 = int(a * RATE)
        if s0 + len(samples) > len(track):  # only the very end of the video ever cuts a line short
            samples = samples[:max(0, len(track) - s0)].copy()
            fade = min(len(samples), int(0.06 * RATE))
            if fade:
                samples[-fade:] *= np.linspace(1, 0, fade, dtype="float32")
        track[s0:s0 + len(samples)] += samples
        end = a + len(samples) / RATE
        placed.append({"start": round(a, 3), "end": round(end, 3), "text": text, "speed": speed,
                       "fits": end <= b + 0.05})
        prev_end = end
    return track, placed


def caption_words(placed: list[dict]) -> list[dict]:
    """Word timings for the translated captions: each line's words spread over its spoken audio by length."""
    out = []
    for ln in placed:
        ws = ln["text"].split()
        if not ws:
            continue
        weights = [len(w) + 2 for w in ws]
        t, span = ln["start"], ln["end"] - ln["start"]
        for w, k in zip(ws, weights):
            d = span * k / sum(weights)
            out.append({"word": w, "start": round(t, 3), "end": round(t + d * 0.92, 3)})
            t += d
    return out


# ---- the whole job ----------------------------------------------------------------------------------------------
def dub(job: Path, lang: str, settings: dict, client=None, gender: str = "male", translation: str | None = None,
        preview: bool = True, speak=None) -> Path:
    import soundfile as sf
    from . import captions
    from .media import probe
    from .overlays import render_ass
    from .premiere_xml import TRACKS, Timeline
    if lang not in LANGS:
        raise ValueError(f"AutoCut can't dub into '{lang}' yet. It speaks: {', '.join(LANGS)}")
    job = Path(job)
    if not (job / "timeline.json").exists():
        raise ValueError("Re-run this video once first (it was cut by an older AutoCut)")
    if client is None:
        from .config import load_client
        client = load_client(str(job.parent.parent), settings)
    lines = job_lines(job)
    if not lines:
        raise ValueError("There's nothing said in this video to dub.")
    if translation:
        texts, engine = parse_translation(translation, len(lines)), "yours"
    else:
        texts, engine = translate(lines, lang, settings, client.brand), "ai"
        if texts is None:
            raise ValueError("No AI answered to translate this video. Paste your own translation (one line per "
                             "sentence) or turn the AI on under This Mac → AI.")
    tl = Timeline.load(job / "timeline.json")
    fps = tl.fps
    total = max([i["end"] for t in tl.video for i in t] or [0]) / fps
    out = job / f"dub-{lang}"
    out.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        track, placed = voice_lines(texts, lines, total, lang, settings, gender, Path(td), speak=speak)
    wav = out / "dub.wav"
    sf.write(str(wav), track, RATE)

    # translated captions in the client's style (and an SRT to upload to the platform)
    words = caption_words(placed)
    captions.write_srt(words, total, client.brand["captions"], out / f"captions-{lang}.srt")
    size = tuple(tl.size)
    captions.write_ass(words, total, client.brand, size, out / f"captions-{lang}.ass")
    overlay = None
    if (client.brand.get("effects") or {}).get("captions", True):
        overlay = render_ass(out / f"captions-{lang}.ass", client, size, fps, total, out / f"captions-{lang}.mov")

    # the timeline: the dub replaces the dialogue on A1, the translated captions replace V11; music + effects stay
    name = LANGS[lang][0]
    tl.name = f"{tl.name} — {name} (AI dub)"
    dub_info = probe(wav)
    tl.audio[0] = []
    tl.add_audio(1, dub_info, 0, 0, min(tl.frames(dub_info.duration), tl.frames(total)), source_channel=1)
    cap = TRACKS["captions"]
    if len(tl.video) >= cap:
        tl.video[cap - 1] = []
    if overlay:
        tl.add_video("captions", probe(overlay), 0, 0, tl.frames(total), name=f"Captions ({name})")
    tl.marker(0, "AI-dubbed audio", f"Voiced by AutoCut's AI voice in {name}. Label it as AI-dubbed when you post.")
    xml = tl.write(out / f"{job.name} - {lang}.xml")
    tl.save(out / "timeline.json")
    pv = None
    if preview:
        from .preview import render_preview
        pv = render_preview(tl, out / f"{job.name} - {lang} preview.mp4")
    report = {"language": lang, "name": name, "voice": LANGS[lang][2].get(gender) or LANGS[lang][2]["male"],
              "translation": engine, "ai_voice": True, "lines": [{**p, "original": ln["text"]}
                                                                    for p, ln in zip(placed, lines)],
              "too_long": sum(1 for p in placed if not p["fits"]), "xml": str(xml),
              "preview": str(pv) if pv else None, "dub": str(wav)}
    (out / "dub.json").write_text(json.dumps(report, indent=2, ensure_ascii=False))
    return out
