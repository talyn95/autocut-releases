"""Decide what to keep: drop fillers, stutters and dead air, then snap to frames."""
from __future__ import annotations

import re
from dataclasses import dataclass, field


def norm(word: str) -> str:
    return re.sub(r"[^a-z0-9']", "", word.lower())


@dataclass
class Segment:
    src_in: int   # frames in the source clip
    src_out: int
    rec_in: int = 0  # frames on the output timeline
    rec_out: int = 0


@dataclass
class EditPlan:
    fps: float
    segments: list[Segment]
    words: list[dict]                      # kept words, retimed to the output timeline
    removed: list[dict] = field(default_factory=list)
    source_seconds: float = 0.0

    @property
    def frames(self) -> int:
        return self.segments[-1].rec_out if self.segments else 0

    @property
    def seconds(self) -> float:
        return self.frames / self.fps


def find_restarts(words: list[dict], fillers: set[str], max_gap: float = 6.0) -> set[int]:
    """False starts: the speaker says 3+ words, stops, and says them again ("we do a — we do a free
    inspection"). Returns indices of the abandoned attempt (everything before the retake)."""
    content = [i for i, w in enumerate(words) if norm(w["word"]) and norm(w["word"]) not in fillers]
    out: set[int] = set()
    for a in range(len(content)):
        for length in (5, 4, 3):
            first = content[a:a + length]
            if len(first) < length or first[0] in out:
                continue
            phrase = [norm(words[i]["word"]) for i in first]
            for b in range(a + length, min(a + length + 10, len(content) - length + 1)):
                again = content[b:b + length]
                if [norm(words[i]["word"]) for i in again] != phrase:
                    continue
                if words[again[0]]["start"] - words[first[0]]["start"] > max_gap:
                    break
                out.update(range(first[0], again[0]))  # drop the first attempt + anything said in between
                break
            if first[0] in out:
                break
    return out


def sentences(words: list[dict], gap: float = 0.7) -> list[list[int]]:
    """Word indices grouped into sentences: a break at . ? ! or a pause longer than `gap`."""
    out, cur = [], []
    for i, w in enumerate(words):
        cur.append(i)
        nxt = words[i + 1] if i + 1 < len(words) else None
        if re.search(r"[.?!]$", w["word"].strip()) or not nxt or nxt["start"] - w["end"] > gap:
            out.append(cur)
            cur = []
    return out


def find_retakes(words: list[dict], fillers: set[str], max_gap: float = 20.0) -> set[int]:
    """Whole-sentence retakes (Descript's "remove retakes"): the speaker says a line, isn't happy, and says
    it again, often with slightly different words ("We inspect every roof in thirty minutes. — We inspect
    every roof in under thirty minutes, free."). Keeps the last take; returns the indices of the earlier ones.
    Only sentences of 4+ real words count, so a deliberate short repeat ("Not once. Not once.") stays."""
    from difflib import SequenceMatcher
    sents = sentences(words)
    toks = [[norm(words[i]["word"]) for i in s if norm(words[i]["word"]) and norm(words[i]["word"]) not in fillers]
            for s in sents]
    out: set[int] = set()
    for a in range(len(sents)):
        if len(toks[a]) < 4 or sents[a][0] in out:
            continue
        for b in range(a + 1, min(a + 4, len(sents))):
            if words[sents[b][0]]["start"] - words[sents[a][-1]]["end"] > max_gap:
                break
            ta, tb = toks[a], toks[b]
            if len(tb) < 3:
                continue
            ratio = SequenceMatcher(None, ta, tb[:len(ta) + 3]).ratio()
            if (ta[:3] == tb[:3] and ratio >= 0.6) or ratio >= 0.78:
                for k in range(a, b):  # the earlier take, plus any short aside before the new take
                    if k == a or len(toks[k]) < 4:
                        out.update(sents[k])
                break
    return out


def plan_edit(words: list[dict], duration: float, fps: float, cfg: dict,
              force_remove: set[int] | None = None, force_keep: set[int] | None = None,
              fixes: dict | None = None) -> EditPlan:
    """force_remove/force_keep: transcript word indices the editor cut or restored by hand.
    fixes: {index: corrected text} for caption typos."""
    fillers = {norm(f) for f in cfg["filler_words"]}
    force_remove, force_keep, fixes = force_remove or set(), force_keep or set(), fixes or {}
    words = [{**w, "i": i, "word": fixes.get(i, fixes.get(str(i), w["word"]))} for i, w in enumerate(words)]
    restarts = find_restarts(words, fillers) if cfg.get("remove_restarts", True) else set()
    retakes = find_retakes(words, fillers) if cfg.get("remove_retakes", True) else set()
    keep, removed = [], []
    for i, w in enumerate(words):
        n = norm(w["word"])
        nxt = words[i + 1] if i + 1 < len(words) else None
        if i in force_keep:
            keep.append({**w, "removed_before": False})
            continue
        if i in force_remove:
            removed.append({**w, "reason": "manual"})
        elif i in retakes:
            removed.append({**w, "reason": "retake"})
        elif i in restarts:
            removed.append({**w, "reason": "restart"})
        elif cfg["remove_fillers"] and n in fillers:
            removed.append({**w, "reason": "filler"})
        elif (cfg["remove_stutters"] and n and nxt and norm(nxt["word"]) == n
              and nxt["start"] - w["end"] < 0.6):
            removed.append({**w, "reason": "repeat"})
        else:
            keep.append({**w, "removed_before": False})
            continue
        if keep:
            keep[-1]["removed_before"] = True  # a cut must happen after this kept word
    if not keep:
        raise SystemExit("No speech found to keep — check the footage or transcript.")

    pad, max_pause = cfg["pad"], cfg["max_pause"]
    spans: list[list[float]] = []
    # Where each removed word sits, so cuts never leave part of it in.
    rem_iter = sorted(removed, key=lambda r: r["start"])
    for idx, w in enumerate(keep):
        start = max(0.0, w["start"] - (cfg["head_pad"] if idx == 0 else pad))
        end = min(duration, w["end"] + (cfg["tail_pad"] if idx == len(keep) - 1 else pad))
        if spans:
            prev = keep[idx - 1]
            gap = w["start"] - prev["end"]
            if gap <= max_pause and not prev["removed_before"]:
                spans[-1][1] = end
                continue
            between = [r for r in rem_iter if r["start"] >= prev["end"] - 0.01 and r["end"] <= w["start"] + 0.01]
            if between:
                spans[-1][1] = min(spans[-1][1], between[0]["start"])
                start = max(start, between[-1]["end"])
            if start <= spans[-1][1]:
                spans[-1][1] = end
                continue
        spans.append([start, end])

    segments: list[Segment] = []
    rec = 0
    for s, e in spans:
        a, b = round(s * fps), round(e * fps)
        if segments and a <= segments[-1].src_out:
            rec += b - segments[-1].src_out
            segments[-1].src_out = b
            segments[-1].rec_out = rec
            continue
        if b - a < 2:
            continue
        segments.append(Segment(a, b, rec, rec + (b - a)))
        rec += b - a

    out_words = []
    for w in keep:
        f = w["start"] * fps
        seg = next((sg for sg in segments if sg.src_in <= f < sg.src_out), None)
        if seg is None:
            continue
        offset = seg.rec_in - seg.src_in
        s = (f + offset) / fps
        e = min(w["end"] * fps, seg.src_out) + offset
        out_words.append({"word": w["word"], "start": round(s, 3), "end": round(e / fps, 3), "i": w["i"]})

    return EditPlan(fps=fps, segments=segments, words=out_words, removed=removed,
                    source_seconds=duration)


def report(plan: EditPlan) -> str:
    fillers = [r for r in plan.removed if r["reason"] == "filler"]
    repeats = [r for r in plan.removed if r["reason"] == "repeat"]
    restarts = [r for r in plan.removed if r["reason"] == "restart"]
    retakes = [r for r in plan.removed if r["reason"] == "retake"]
    manual = [r for r in plan.removed if r["reason"] == "manual"]
    lines = [
        f"Source length:   {plan.source_seconds:7.1f}s",
        f"Rough cut:       {plan.seconds:7.1f}s  ({plan.source_seconds - plan.seconds:.1f}s removed)",
        f"Cuts:            {max(0, len(plan.segments) - 1)}",
        f"Fillers removed: {len(fillers)}",
        f"Stutters removed:{len(repeats):4d}",
        f"False starts:    {len(restarts)} words",
        f"Earlier takes:   {len(retakes)} words",
        f"Cut by hand:     {len(manual)} words",
        "",
        "Removed words (source time):",
    ]
    lines += [f"  {r['start']:8.2f}s  {r['reason']:6}  {r['word']}" for r in plan.removed]
    return "\n".join(lines) + "\n"
