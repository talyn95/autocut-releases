"""One-time steps after an update, and the "What's new" note.

AutoCut keeps the version it last ran in `state.json` next to this computer's settings. On start, every migration
newer than that version runs once, in order (a failing one is logged and retried next start, the app still opens).
Add a migration when a release changes how saved data is laid out: never edit or delete an old one.

    MIGRATIONS = [("0.21.0", "what it does", function), …]   # function(settings, log) -> None
"""
from __future__ import annotations

import json
import re
import time

from . import __version__
from .config import LOCAL_SETTINGS, ROOT, clients_dir
from .content import version_tuple

STATE_FILE = LOCAL_SETTINGS.parent / "state.json"


def _m_0_21(settings: dict, log) -> None:
    """Content packs: make the packs folder next to the clients folder so it's there to drop packs into."""
    (clients_dir(settings).parent / "packs").mkdir(parents=True, exist_ok=True)


MIGRATIONS = [
    ("0.21.0", "Make the content packs folder", _m_0_21),
]


def state() -> dict:
    try:
        return json.loads(STATE_FILE.read_text())
    except (OSError, ValueError):
        return {}


def _save(st: dict) -> None:
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(st, indent=1))
    tmp.replace(STATE_FILE)


def run(settings: dict, log=print) -> dict:
    """Run the migrations this computer hasn't run yet; note the version change for What's new."""
    st = state()
    last = st.get("version")
    done = set(st.get("migrations", []))
    ran, failed = [], []
    for ver, what, fn in MIGRATIONS:
        key = f"{ver}:{fn.__name__}"
        if key in done or version_tuple(ver) > version_tuple(__version__):
            continue
        try:
            fn(settings, log)
            done.add(key)
            ran.append(what)
        except Exception as e:  # noqa: BLE001 - the app must still open; it retries next start
            failed.append(f"{what}: {e}")
            log(f"  ! update step failed ({what}): {e}")
    if last != __version__:
        if last and version_tuple(last) < version_tuple(__version__):
            st["whats_new_from"] = last
        st.setdefault("history", []).append({"version": __version__, "at": time.strftime("%Y-%m-%d %H:%M")})
        st["history"] = st["history"][-20:]
    st.update(version=__version__, migrations=sorted(done))
    _save(st)
    return {"ran": ran, "failed": failed, "from": last}


def changelog(since: str | None = None, until: str | None = None) -> list[dict]:
    """CHANGELOG.md sections newer than `since` (up to `until`, default this version): [{version, items}]."""
    try:
        text = (ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
    except OSError:
        return []
    out = []
    for m in re.finditer(r"^## (\d+\.\d+\.\d+)\s*\n(.*?)(?=^## |\Z)", text, re.S | re.M):
        v = m.group(1)
        if since and version_tuple(v) <= version_tuple(since):
            continue
        if version_tuple(v) > version_tuple(until or __version__):
            continue
        items = [re.sub(r"\s+", " ", x).strip() for x in re.split(r"^- ", m.group(2), flags=re.M) if x.strip()]
        out.append({"version": v, "items": items})
    return out


def whats_new() -> dict:
    """What changed since the version this computer ran before the last update (empty once dismissed)."""
    st = state()
    since = st.get("whats_new_from")
    return {"since": since, "version": __version__, "sections": changelog(since) if since else []}


def dismiss_whats_new() -> None:
    st = state()
    st.pop("whats_new_from", None)
    _save(st)
