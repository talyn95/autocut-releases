"""Understanding the media people drop into the Motion graphic generator: photos, graphics, screenshots, logos and
video clips, so the motion graphic is designed around them.

For every file:
  measured on this computer (always)   size and shape, transparency, the palette (k-means), light or dark; for video
                                        the length, frame rate, sound, and pacing (how much moves, how often it cuts)
  read by the AI brain (when one runs)  what it shows, any words in it, the typography it uses (matched to the closest
                                        font AutoCut can render), mood, the role it should play, a short caption
  rules otherwise                       the role from the file name, shape and transparency; keywords from the name

`read()` caches each file's reading next to it (.<file>.read.json), so dropping the same file twice costs nothing.
`brief()` turns a set of readings into a few lines the AI designer gets with the request; `style()` gives one colour
palette and font pair to match the media ("Match my media"). `prepare_video()` makes a clip the renderer can play
(H.264 MP4, silent, at most 1920 px, held on its last frame so a scene never runs past its end).
"""
from __future__ import annotations

import hashlib
import json
import re
import subprocess
import tempfile
from pathlib import Path

from .. import brain
from . import reference

ROLES = {
    "photo": "a photo to feature (people, places, work)",
    "product": "a product or object, often cut out",
    "screenshot": "a screen: app, website, social post, document",
    "illustration": "a drawing, icon or graphic made in a design tool",
    "logo": "a logo or wordmark",
    "background": "a texture or backdrop to put words on",
    "broll": "a video clip to show",
}
# a typography description → the closest font AutoCut can always render (hyper.BUNDLED_FONTS)
FONT_STYLES = [
    (r"mono|typewriter|code|terminal", "JetBrains Mono"),
    (r"condensed|compressed|narrow|impact|tall", "Oswald"),
    (r"poster|ultra|black|heavy|fat", "Archivo Black"),
    (r"slab|editorial serif|didone|didot|high[- ]contrast|elegant|luxur|fashion|magazine", "Playfair Display"),
    (r"serif|book|classic|traditional|garamond|times", "EB Garamond"),
    (r"rounded|friendly|soft|playful|bubbly", "Nunito"),
    (r"geometric|futura|modern|clean|minimal", "Montserrat"),
    (r"grotesk|neo|swiss|helvetica|neutral|sans", "Inter"),
]
FONTS = sorted({f for _, f in FONT_STYLES} | {"Poppins", "Outfit", "Lato", "Open Sans", "Roboto", "League Gothic",
                                              "Space Mono", "IBM Plex Mono", "Source Code Pro"})
READ_SCHEMA = {"type": "object", "properties": {
    "subject": {"type": "string"}, "text_in_media": {"type": "string"}, "typography": {"type": "string"},
    "font": {"type": "string"}, "mood": {"type": "string"}, "role": {"type": "string"},
    "best_use": {"type": "string"}, "caption": {"type": "string"},
    "keywords": {"type": "array", "items": {"type": "string"}}},
    "required": ["subject", "role", "caption"]}
VIDEO_EXT = {".mp4", ".mov", ".m4v", ".mkv", ".webm", ".avi"}
STOP = set("img image photo pic picture final copy edit new export screenshot screen shot untitled dsc ai the and for "
           "with of a an".split())


def kind(path: Path) -> str:
    ext = path.suffix.lower()
    if ext == ".gif":
        return "video" if _frames(path) > 1 else "image"
    return "video" if ext in VIDEO_EXT else "image"


def _frames(path: Path) -> int:
    try:
        from PIL import Image
        return getattr(Image.open(path), "n_frames", 1)
    except Exception:  # noqa: BLE001
        return 1


def _probe(path: Path) -> dict:
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,width,height,r_frame_rate:format=duration",
                        "-of", "json", str(path)], capture_output=True, text=True)
    try:
        d = json.loads(r.stdout or "{}")
    except ValueError:
        d = {}
    v = next((s for s in d.get("streams", []) if s.get("codec_type") == "video"), {})
    num, _, den = str(v.get("r_frame_rate", "0/1")).partition("/")
    return {"w": int(v.get("width") or 0), "h": int(v.get("height") or 0),
            "duration": round(float((d.get("format") or {}).get("duration") or 0), 2),
            "fps": round(float(num or 0) / float(den or 1), 2) if float(den or 1) else 0,
            "audio": any(s.get("codec_type") == "audio" for s in d.get("streams", []))}


def measure(path: Path) -> dict:
    """What can be measured without any AI."""
    path = Path(path)
    k = kind(path)
    out = {"name": path.name, "kind": k}
    if k == "video":
        out.update(_probe(path))
        if path.suffix.lower() == ".gif" and not out["w"]:
            from PIL import Image
            out["w"], out["h"] = Image.open(path).size
    else:
        from PIL import Image
        try:
            im = Image.open(path)
            out["w"], out["h"] = im.size
            if im.mode in ("RGBA", "LA", "P"):
                import numpy as np
                a = np.asarray(im.convert("RGBA").resize((96, 96)))[..., 3]
                out["transparent"] = round(float((a < 16).mean()), 2)
        except Exception:  # noqa: BLE001 - SVG and friends: no pixels to measure
            out["w"], out["h"] = 1000, 1000
    w, h = out.get("w") or 1, out.get("h") or 1
    out["aspect"] = round(w / h, 3)
    out["shape"] = "tall" if w / h < 0.8 else "wide" if w / h > 1.25 else "square"
    frames = []
    try:
        frames = reference.frames_of(path, 3 if k == "video" else 1)
    except Exception:  # noqa: BLE001
        pass
    if frames:
        pal = reference.palette(frames, 5)
        out["palette"] = [c for c, _ in pal]
        out["dark"] = sum(reference._lum(c) * s for c, s in pal) < 0.45
    if k == "video" and path.suffix.lower() != ".gif":
        try:
            out.update(reference.pacing(path))
        except Exception:  # noqa: BLE001
            pass
    return out


def _keywords(name: str) -> list[str]:
    words = [w for w in re.split(r"[^a-z0-9]+", Path(name).stem.lower()) if len(w) > 2 and not w.isdigit()]
    return [w for w in words if w not in STOP][:6]


def rules_read(m: dict) -> dict:
    """The role and words from the file itself (no AI)."""
    name = m["name"].lower()
    kw = _keywords(m["name"])
    if m["kind"] == "video":
        role = "broll"
    elif re.search(r"logo|wordmark|brandmark", name):
        role = "logo"
    elif re.search(r"screen|screenshot|app|dashboard|website|post|ui\b|mockup", name):
        role = "screenshot"
    elif re.search(r"bg|background|texture|pattern|backdrop", name):
        role = "background"
    elif re.search(r"icon|illustration|vector|cartoon|drawing|clipart", name) or m["name"].lower().endswith(".svg"):
        role = "illustration"
    elif (m.get("transparent") or 0) > 0.15:
        role = "product"
    else:
        role = "photo"
    subject = " ".join(kw) or {"broll": "a video clip", "logo": "a logo"}.get(role, "an image")
    return {"subject": subject, "role": role, "caption": "", "keywords": kw, "via": "rules"}


def font_for(typography: str, suggested: str = "") -> str:
    """The closest font AutoCut can render for a typography description."""
    if suggested and suggested.lower() in {f.lower() for f in FONTS}:
        return next(f for f in FONTS if f.lower() == suggested.lower())
    t = (typography or "").lower()
    return next((f for rx, f in FONT_STYLES if re.search(rx, t)), "")


def ai_read(path: Path, m: dict, settings: dict, prefer: str = "local") -> dict | None:
    """The AI brain looks at the media (a few frames of a video) and says what it is and how to use it."""
    from .. import marketing
    try:
        frames = reference.frames_of(path, 3 if m["kind"] == "video" else 1, 768)
    except Exception:  # noqa: BLE001
        return None
    if not frames:
        return None
    with tempfile.TemporaryDirectory() as tmp:
        shots = []
        for i, im in enumerate(frames[:3]):
            fp = Path(tmp) / f"m{i}.jpg"
            im.convert("RGB").save(fp, quality=85)
            shots.append(fp)
        what = "frames from a video clip" if m["kind"] == "video" else "an image"
        prompt = (f"This is {what} ({m['name']}, {m['shape']}, {m.get('w')}x{m.get('h')}) an agency dropped into its motion "
                  "graphic generator to use in a branded animation. Tell the motion designer: subject = what it shows "
                  "(max 12 words); text_in_media = any words visible in it, exactly, else empty; typography = the type "
                  "style of those words or the style that would suit it (e.g. heavy condensed sans, elegant high-contrast "
                  f"serif, rounded friendly sans); font = the closest of {', '.join(FONTS)}; mood = 3-6 words; role = one "
                  f"of {', '.join(ROLES)}; best_use = how to feature it in one sentence (e.g. hero shot behind the "
                  "headline, phone-screen mockup, product reveal); caption = a short on-screen caption for it (max 8 "
                  "words, no hashtags); keywords = up to 6 words someone might say when they mean this.")
        out = brain.ask(settings, marketing.knowledge("design", "motion") + "\n\nYou are the agency's senior designer.",
                        prompt, READ_SCHEMA, images=shots, prefer=prefer, timeout=180)
    if not isinstance(out, dict) or not str(out.get("subject", "")).strip():
        return None
    r = {k: (str(out.get(k, "")).strip()[:200] if k != "keywords" else [str(x)[:30] for x in (out.get("keywords") or [])][:6])
         for k in READ_SCHEMA["properties"]}
    if r["role"] not in ROLES:
        r["role"] = ""
    r["via"] = brain.last_engine() or "ai"
    return r


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:16]


def read(path: Path, settings: dict | None = None, use_ai: bool = True, prefer: str = "local") -> dict:
    """Everything known about one piece of media: measured + AI (or rules). Cached next to the file."""
    path = Path(path)
    cache = path.with_name("." + path.name + ".read.json")  # hidden, next to the file
    sha = _sha(path)
    try:
        old = json.loads(cache.read_text())
        if old.get("sha") == sha and (old.get("via") != "rules" or not use_ai or settings is None):
            return old
    except (OSError, ValueError):
        pass
    m = measure(path)
    r = rules_read(m)
    if use_ai and settings is not None:
        ai = ai_read(path, m, settings, prefer)
        if ai:
            role = ai["role"] or r["role"]
            if m["kind"] == "video":
                role = "broll"  # a clip plays as a clip, whatever it shows
            r = {**r, **{k: v for k, v in ai.items() if v}, "role": role,
                 "keywords": list(dict.fromkeys((ai.get("keywords") or []) + r["keywords"]))[:8]}
    r["font"] = font_for(r.get("typography", ""), r.get("font", "")) if (r.get("typography") or r.get("font")) else ""
    out = {**m, **r, "sha": sha, "path": str(path)}
    try:
        cache.write_text(json.dumps(out, indent=1))
    except OSError:
        pass
    return out


def brief(reads: list[dict]) -> str:
    """A few lines for the AI designer: what each piece is (media1, media2 … in order) and how it could be used."""
    lines = []
    for k, r in enumerate(reads, 1):
        bits = [f"media{k}: {r.get('role') or r.get('kind')}, {r.get('shape', '')}"]
        if r.get("kind") == "video" and r.get("duration"):
            bits.append(f"{r['duration']:.0f} s clip" + (f", {r['energy']} pace" if r.get("energy") else ""))
        bits.append(f"shows {r.get('subject') or 'something'}")
        if r.get("text_in_media"):
            bits.append(f'words in it: "{r["text_in_media"][:80]}"')
        if r.get("typography"):
            bits.append(f"type: {r['typography']}")
        if r.get("mood"):
            bits.append(f"mood: {r['mood']}")
        if r.get("palette"):
            bits.append("colours " + " ".join(r["palette"][:3]))
        if r.get("best_use"):
            bits.append(f"use: {r['best_use']}")
        lines.append("; ".join(bits))
    return "\n".join(lines)


def style(reads: list[dict]) -> dict:
    """One look from all the media: a colour pair (vivid accent + a dark), light or dark, and a font pair."""
    from .reference import _lum, _sat
    pal = [c for r in reads for c in (r.get("palette") or [])]
    out: dict = {}
    if pal:
        vivid = sorted(pal, key=lambda c: -_sat(c) * (0.3 + _lum(c)) if _lum(c) > 0.18 else 0)
        dark = min(pal, key=_lum)
        primary = vivid[0] if _sat(vivid[0]) > 0.25 else max(pal, key=_lum)
        out["colors"] = [primary, dark if dark != primary else max(pal, key=_lum)]
        out["palette"] = list(dict.fromkeys(pal))[:6]
        out["dark"] = sum(1 for r in reads if r.get("dark")) > len(reads) / 2
    fonts = [r["font"] for r in reads if r.get("font")]
    if fonts:
        head = max(set(fonts), key=fonts.count)
        out["fonts"] = {"headline": head, "caption": "Inter" if head not in ("Inter", "Montserrat", "Nunito", "Poppins") else head}
    return out


def poster(path: Path) -> Path | None:
    """A still from a clip (hidden, next to it) for thumbnails: browsers can't preview every video format."""
    path = Path(path)
    out = path.with_name("." + path.name + ".poster.jpg")
    if not out.exists():
        d = _probe(path)["duration"]
        subprocess.run(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-ss", f"{min(1.0, d / 3):.2f}", "-i", str(path),
                        "-frames:v", "1", "-vf", "scale=480:-2", str(out)])
    return out if out.exists() else None


def prepare_video(src: Path, dest: Path, min_seconds: float = 10.0, max_seconds: float = 30.0) -> Path:
    """A clip the renderer can play: H.264 MP4, silent, at most 1920 px on the long side, no longer than max_seconds,
    and held on its last frame up to min_seconds (a scene never outlasts its video)."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    info = _probe(src)
    d = info["duration"] or max_seconds
    hold = max(0.0, min_seconds - d)
    vf = ("scale='if(gt(iw,ih),2*trunc(min(1920,iw)/2),-2)':'if(gt(iw,ih),-2,2*trunc(min(1920,ih)/2))',"
          "fps=30,format=yuv420p")
    if hold:
        vf += f",tpad=stop_mode=clone:stop_duration={hold:.2f}"
    subprocess.run(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-i", str(src), "-t", f"{min(d, max_seconds) + hold:.2f}",
                    "-vf", vf, "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-movflags", "+faststart",
                    str(dest)], check=True)
    return dest
