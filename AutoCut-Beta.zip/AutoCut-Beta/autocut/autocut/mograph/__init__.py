"""AutoCut Motion: a small After-Effects-style motion graphics engine.

What makes high-end motion graphics read as "expensive" is mostly technique, not effects:
eased keyframes with overshoot, motion blur, masked reveals, staggered timing, shape layers
that draw on, gradients, glows and light sweeps. This package does exactly those, drawn
with Skia (the graphics library inside Chrome) and rendered to ProRes 4444 with alpha.

  engine.py     frame loop, motion blur (sub-frame accumulation), brand fonts/colours
  ease.py       easing curves + tween()
  templates.py  the pack: hook title, slam, stat counter, lower third, phrase card,
                swipe transition, CTA outro
"""
