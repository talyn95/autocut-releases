"""A reel of every AutoCut Motion template in a client's brand, for sign-off and testing."""
from __future__ import annotations

import subprocess
from pathlib import Path

from ..config import Client, brand_backdrop
from .engine import Look
from .templates import make


def _background(client: Client, size: tuple[int, int], out: Path) -> Path:
    """A still from the client's most recent footage (so graphics are judged over real video),
    else a brand-tinted gradient (never gray)."""
    W, H = size
    footage = sorted((client.folder / "footage").glob("*.*"), key=lambda p: p.stat().st_mtime, reverse=True)
    for f in footage:
        if f.suffix.lower() in (".mp4", ".mov", ".m4v"):
            r = subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", "2", "-i", str(f), "-frames:v", "1",
                                "-vf", f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}", str(out)],
                               capture_output=True)
            if r.returncode == 0 and out.exists():
                return out
    c0, c1 = brand_backdrop(client.brand)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i",
                    f"gradients=s={W}x{H}:c0={c0}:c1={c1}:n=2:d=1", "-frames:v", "1", str(out)], check=True)
    return out


def motion_reel(client: Client, out: Path, fps: float = 30, samples: int = 4) -> Path:
    W, H = client.size
    work = out.parent / "motion-pack"
    work.mkdir(parents=True, exist_ok=True)
    look = Look(client, (W, H), fps)
    b = client.brand
    hook = (b["captions"]["highlight_words"] or ["Watch this"])[0]
    clips = [
        ("hook_title", dict(text=f"The truth about {hook}" if len(hook) < 14 else hook)),
        ("slam", dict(word=hook)),
        ("stat_counter", dict(value="$3,000", label="average saved")),
        ("phrase_card", dict(text=(b["cards"]["phrases"] or [b["cta"]["text"] or "Free estimate"])[0])),
        ("lower_third", dict(name=b["lower_third"]["name"] or "Your Name", title=b["lower_third"]["title"] or b["client"])),
        ("swipe", {}),
        ("cta_outro", dict(text=b["cta"]["text"] or "Book today", sub=b["cta"]["subtext"] or "Link in bio",
                           logo=client.path(b["logo"]["file"]))),
    ]
    bg = _background(client, (W, H), work / "background.png")
    parts = []
    for i, (name, params) in enumerate(clips):
        mov = make(name, look, fps, work / f"{i}_{name}.mov", samples=samples, **params)
        part = work / f"{i}_{name}.mp4"
        pad = 0.4  # a beat of plain background between pieces
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-loop", "1", "-framerate", f"{fps}", "-i", str(bg),
                        "-i", str(mov), "-filter_complex",
                        f"[1]tpad=stop_mode=add:stop_duration={pad}:color=black@0[g];[0][g]overlay=shortest=1,format=yuv420p",
                        "-c:v", "libx264", "-crf", "18", "-preset", "veryfast", "-r", f"{fps}", str(part)], check=True)
        parts.append(part)
    lst = work / "list.txt"
    lst.write_text("".join(f"file '{p.name}'\n" for p in parts))
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(lst),
                    "-c", "copy", str(out)], check=True, cwd=work)
    return out
