"""HyperFrames engine for the Motion graphic generator: graphics as HTML + GSAP, rendered frame by frame in
headless Chrome (https://github.com/heygen-com/hyperframes, Apache 2.0). Runs on this computer like the rest of
AutoCut: no account, no cloud, telemetry off.

Two ways in:
- the eight brand templates in mograph/hf/ (same names and params as the classic Skia templates, so prompts,
  the AI spec and the dashboard don't change), filled with the client's colours, fonts and logo;
- "custom": the AI brain writes a whole composition from the request (Claude does this far better than a
  small local model), checked by rendering, with one repair round if the render fails.

Every render leaves an editable HyperFrames project next to the files (hf-<size>/), so a designer can open it in
the HyperFrames desktop app or `npx hyperframes preview` and keep going.

The runtime (the pinned CLI + GSAP + Chrome Headless Shell) lives in <AutoCut folder>/hyperframes-runtime and is
set up once with `autocut hyperframes-setup` (the installers do it). It needs Node.js 22+ and ffmpeg.
"""
from __future__ import annotations

import html
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

from .. import content
from ..config import Client, clients_dir, hex_to_rgb

HF_VERSION = content.catalog()["engines"]["hyperframes"]  # pinned in content/catalog.json; an app update
GSAP_VERSION = content.catalog()["engines"]["gsap"]       # that moves the pin reinstalls the runtime
TEMPLATE_DIR = Path(__file__).parent / "hf"
TEMPLATES = ("hook_title", "slam", "stat_counter", "phrase_card", "lower_third", "swipe", "cta_outro", "kinetic_type")
OPAQUE = {"cta_outro"}
# fonts HyperFrames bundles: they resolve by name with no font file
BUNDLED_FONTS = {"inter", "montserrat", "outfit", "nunito", "oswald", "league gothic", "archivo black", "space mono",
                 "ibm plex mono", "jetbrains mono", "eb garamond", "playfair display", "source code pro",
                 "noto sans jp", "roboto", "open sans", "lato", "poppins"}
ENV = {"HYPERFRAMES_NO_TELEMETRY": "1", "DO_NOT_TRACK": "1", "HF_CLI_TELEMETRY_DISABLED": "1"}


# ---- the runtime -----------------------------------------------------------------------------------------

def runtime_dir(settings: dict) -> Path:
    custom = os.environ.get("AUTOCUT_HF_RUNTIME") or (settings.get("hyperframes") or {}).get("runtime_dir")
    return Path(custom).expanduser() if custom else clients_dir(settings).parent / "hyperframes-runtime"


def _node() -> str | None:
    node = shutil.which("node")
    if not node:
        return None
    try:
        major = int(subprocess.run([node, "--version"], capture_output=True, text=True).stdout.strip().lstrip("v").split(".")[0])
    except (OSError, ValueError):
        return None
    return node if major >= 22 else None


def _cli(settings: dict) -> Path:
    pkg = runtime_dir(settings) / "node_modules" / "hyperframes"
    try:
        bin_ = json.loads((pkg / "package.json").read_text())["bin"]
        rel = bin_ if isinstance(bin_, str) else bin_.get("hyperframes") or next(iter(bin_.values()))
    except (OSError, ValueError, KeyError, StopIteration):
        rel = "dist/cli.js"
    return pkg / rel


def available(settings: dict) -> bool:
    cfg = settings.get("hyperframes") or {}
    if cfg.get("enabled") is False:
        return False
    rt = runtime_dir(settings)
    return bool(_node()) and _cli(settings).exists() and (rt / "node_modules" / "gsap" / "dist" / "gsap.min.js").exists() \
        and (rt / ".browser-ready").exists()


def setup(settings: dict, log=print) -> bool:
    """Install the pinned HyperFrames CLI, GSAP and Chrome Headless Shell into the runtime folder (one time)."""
    node = _node()
    if not node:
        log("HyperFrames needs Node.js 22 or newer: Mac `brew install node`, Windows `winget install OpenJS.NodeJS.LTS`.")
        return False
    rt = runtime_dir(settings)
    rt.mkdir(parents=True, exist_ok=True)
    (rt / "package.json").write_text(json.dumps({
        "name": "autocut-hyperframes-runtime", "private": True,
        "dependencies": {"hyperframes": HF_VERSION, "gsap": GSAP_VERSION}}, indent=2))
    npm = shutil.which("npm") or shutil.which("npm.cmd")
    if not npm:
        log("npm wasn't found next to Node.js.")
        return False
    env = {**os.environ, **ENV}
    log(f"Installing HyperFrames {HF_VERSION} and GSAP {GSAP_VERSION} …")
    if subprocess.run([npm, "install", "--no-fund", "--no-audit", "--loglevel=error"], cwd=rt, env=env).returncode:
        log("Couldn't install HyperFrames (see above).")
        return False
    log("Downloading the headless Chrome HyperFrames renders with (one time) …")
    if subprocess.run([node, str(_cli(settings)), "browser", "ensure"], cwd=rt, env=env).returncode:
        log("Couldn't download Chrome Headless Shell (see above).")
        return False
    (rt / ".browser-ready").write_text(HF_VERSION)
    log("HyperFrames ready.")
    return True


def render_project(project: Path, out: Path, settings: dict, fmt: str = "mov", quality: str = "high",
                   fps: float = 30) -> Path:
    """Render a HyperFrames project folder. MOV = ProRes 4444 with alpha (drops straight onto a Premiere track)."""
    cmd = [_node() or "node", str(_cli(settings)), "render", str(project), "--format", fmt, "-o", str(out),
           "--quality", quality, "--fps", str(int(round(fps))), "--quiet", "--no-best-effort",
           "--player-ready-timeout", "20000"]
    r = subprocess.run(cmd, cwd=runtime_dir(settings), env={**os.environ, **ENV}, capture_output=True, text=True,
                       timeout=1800)
    if r.returncode or not out.exists():
        msg = "\n".join(line for line in (r.stdout + r.stderr).splitlines() if line.strip() and "[initSession" not in line)
        raise RuntimeError("HyperFrames render failed: " + msg[-1500:])
    return out


def studio(project: Path, settings: dict) -> str:
    """Open a project in HyperFrames Studio (the browser editor, served from this computer). Returns its address."""
    import socket
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    r = subprocess.run([_node() or "node", str(_cli(settings)), "preview", str(project), "--background", "--no-open",
                        "--json", "--port", str(port)], cwd=runtime_dir(settings), env={**os.environ, **ENV},
                       capture_output=True, text=True, timeout=120)
    for line in reversed(r.stdout.splitlines()):
        try:
            res = json.loads(line).get("result") or {}
        except ValueError:
            continue
        if res.get("studioUrl") or res.get("serverUrl"):
            return res.get("studioUrl") or res["serverUrl"]
    raise RuntimeError("HyperFrames Studio didn't start: " + (r.stdout + r.stderr)[-600:])


# ---- brand ---------------------------------------------------------------------------------------------------

def _luma(hex_color: str) -> float:
    r, g, b = hex_to_rgb(hex_color)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def on(hex_color: str) -> str:
    """Readable text colour on top of hex_color."""
    return "#111111" if _luma(hex_color) > 150 else "#ffffff"


def _mix(a: str, b: str, k: float) -> str:
    (r1, g1, b1), (r2, g2, b2) = hex_to_rgb(a), hex_to_rgb(b)
    return "#%02x%02x%02x" % tuple(int(x + (y - x) * k) for x, y in ((r1, r2), (g1, g2), (b1, b2)))


def _fonts(client: Client, project: Path) -> tuple[str, str, str]:
    """(@font-face CSS, headline family, body family). The client's font files go into assets/fonts/."""
    from .engine import _font_files
    files = _font_files(client)
    faces, families = [], set()
    if files:
        (project / "assets" / "fonts").mkdir(parents=True, exist_ok=True)
    for f, family, weight in files:
        shutil.copy2(f, project / "assets" / "fonts" / f.name)
        faces.append(f'@font-face {{ font-family: "{family}"; src: url("assets/fonts/{f.name}"); '
                     f"font-weight: {weight}; font-display: block; }}")
        families.add(family.lower())

    def pick(role: str) -> str:
        fam = client.brand["fonts"].get(role) or "Montserrat"
        return fam if fam.lower() in families | BUNDLED_FONTS else "Montserrat"
    return "\n      ".join(faces), pick("headline"), pick("caption")


# ---- building a project from a template ----------------------------------------------------------------------

def words_html(text: str) -> str:
    """Each word in a span (for per-word motion); *keyword* gets the accent colour."""
    out = []
    for w in str(text).split():
        acc = w.startswith("*") and w.rstrip(".,!?;:").endswith("*") and len(w.strip("*")) > 0
        clean = html.escape(w.replace("*", ""))
        out.append(f'<span class="w accent">{clean}</span>' if acc else f'<span class="w">{clean}</span>')
    return " ".join(out)


def _sections(name: str) -> dict:
    text = (TEMPLATE_DIR / f"{name}.html").read_text(encoding="utf-8")
    parts = re.split(r"<!-- (STYLE|BODY|SCRIPT) -->\n", text)
    return {parts[i]: parts[i + 1] for i in range(1, len(parts) - 1, 2)}


def _fill(body: str, fields: dict) -> str:
    def rep(m):
        kind, key = m.group(1), m.group(2)
        v = str(fields.get(key, "") or "")
        return words_html(v) if kind == "words" else html.escape(v)
    return re.sub(r"\{\{(text|words):(\w+)\}\}", rep, body)


def duration(template: str, params: dict) -> float:
    if params.get("dur"):
        return max(0.5, min(20.0, float(params["dur"])))
    if template == "kinetic_type":
        return round(_beats(params.get("text", ""))[-1]["end"] + 0.15, 2)
    return {"hook_title": 2.8, "slam": 1.4, "stat_counter": 2.6, "phrase_card": 2.4, "lower_third": 4.5,
            "swipe": 0.7, "cta_outro": 3.4}[template]


def _beats(text: str) -> list[dict]:
    """Kinetic type beats: split on ' / ' (or sentence ends); each holds 0.5 s + 0.3 s a word (motion craft)."""
    raw = [b.strip() for b in re.split(r"\s+/\s+|(?<=[.!?])\s+", str(text)) if b.strip()] or ["…"]
    t, out = 0.1, []
    for b in raw:
        n = len(b.split())
        hold = 0.5 + 0.3 * n + 0.075 * n
        out.append({"text": b, "start": round(t, 3), "end": round(t + hold, 3)})
        t += hold
    out[-1]["end"] = round(out[-1]["end"] + 0.6, 3)  # the last line holds longer
    return out


def _parse_number(value: str) -> tuple[str, float, str, int]:
    m = re.search(r"-?\d[\d,]*(\.\d+)?", str(value))
    if not m:
        return "", 0.0, str(value), 0
    num = m.group(0)
    return str(value)[:m.start()], float(num.replace(",", "")), str(value)[m.end():], len(m.group(1) or "") - (1 if m.group(1) else 0)


# where each graphic's centre line sits by default (fraction of frame height); vertical keeps text inside
# the band phone apps leave clear (168–1330 px of 1920)
ANCHOR = {"hook_title": (0.30, 0.26), "slam": (0.45, 0.40), "stat_counter": (0.55, 0.52), "phrase_card": (0.62, 0.58),
          "lower_third": (0.80, 0.62), "kinetic_type": (0.50, 0.45), "cta_outro": (0.50, 0.46), "swipe": (0.5, 0.5)}
POSITIONS = {"top": 0.14, "upper": 0.28, "center": 0.50, "lower": 0.68, "bottom": 0.84}


def build(template: str, client: Client, size: tuple[int, int], project: Path, params: dict,
          position: str | None = None, background: str | None = None, speed: float = 1.0,
          gsap: Path | None = None) -> float:
    """Write a HyperFrames project for one template at one size. Returns its duration in seconds."""
    W, H = size
    vertical = H > W
    u = min(W, H) / 1080
    speed = max(0.5, min(2.0, float(speed or 1.0)))
    dur = round(duration(template, params) / speed, 3)
    project.mkdir(parents=True, exist_ok=True)
    (project / "assets").mkdir(exist_ok=True)
    if gsap and gsap.exists():
        shutil.copy2(gsap, project / "assets" / "gsap.min.js")
    c = client.brand["colors"]
    primary, secondary, text = c["primary"], c["secondary"], c.get("text", "#ffffff")
    if _luma(text) < 140 and template not in OPAQUE and not background:
        text = "#ffffff"  # text that floats over footage has to be light to read (dark brand text suits cards)
    faces, head_font, body_font = _fonts(client, project)
    y = POSITIONS[position] if position in POSITIONS else ANCHOR[template][1 if vertical else 0]
    if vertical:
        y = min(max(y, 0.12), 0.70)
    sec = _sections(template)
    fields = dict(params)
    extra: dict = {}
    body = sec["BODY"]
    if template == "stat_counter":
        pre, num, suf, dec = _parse_number(params.get("value", "0"))
        fields.update(prefix=pre, suffix=suf, start="0" if not dec else "0." + "0" * dec)
        extra = {"number": num, "decimals": dec}
        body = body.replace("__LABEL__", f'<div id="sc-label">{html.escape(params["label"])}</div>' if params.get("label") else "")
    elif template == "lower_third":
        body = body.replace("__ROLE__", f'<div id="lt-role">{html.escape(params["title"])}</div>' if params.get("title") else "")
    elif template == "slam":
        fields["word"] = params.get("word") or params.get("text", "")
    elif template == "cta_outro":
        logo = params.get("logo")
        logo_html = ""
        if logo and Path(logo).is_file():
            shutil.copy2(logo, project / "assets" / ("logo" + Path(logo).suffix.lower()))
            logo_html = f'<img id="cta-logo" src="assets/logo{Path(logo).suffix.lower()}" alt="">'
        body = body.replace("__LOGO__", logo_html)
        body = body.replace("__SUB__", f'<div id="cta-sub"><span>{html.escape(params["sub"])}</span><div id="cta-gloss"></div></div>'
                            if params.get("sub") else "")
    elif template == "kinetic_type":
        beats = _beats(params.get("text", ""))
        extra = {"beats": [{"start": b["start"], "end": b["end"]} for b in beats]}
        body = body.replace("__BEATS__", "".join(
            f'<div id="kt-{i}" class="kt-beat"><div class="kt-line">'
            + words_html(b["text"]).replace('<span class="w accent">', '<span class="w accent"><span class="hl"></span>')
            + "</div></div>" for i, b in enumerate(beats)))
    fit = 1.0  # one-line text (a slam word, a big number) shrinks to fit 88% of the frame width
    one_line = {"slam": (str(fields.get("word", "")), 190), "stat_counter": (str(params.get("value", "")), 170)}.get(template)
    if one_line:
        text_, base_px = one_line
        est = sum(0.36 if ch in ",.:;!'" else 0.66 for ch in text_) * base_px * u * (1.3 if vertical else 1)
        fit = min(1.0, 0.88 * W / max(est, 1))
    lt_place = ""
    if template == "lower_third":
        lt_place = (f"left: 50%; top: var(--y); transform: translate(-50%, -50%);" if vertical
                    else f"left: calc(var(--u) * 110); top: var(--y); transform: translateY(-50%);")
    opaque = template in OPAQUE or bool(background)
    bg_fill = background or (secondary if template in OPAQUE else "transparent")
    tokens = {
        "__FONT_FACES__": faces, "__PRIMARY__": primary, "__SECONDARY__": secondary, "__TEXT__": text,
        "__ON_PRIMARY__": on(primary), "__ON_SECONDARY__": on(secondary),
        "__HEADLINE__": head_font, "__BODY__": body_font, "__U__": f"{u:.4f}", "__T__": "1.3" if vertical else "1",
        "__Y__": f"{y * H:.1f}", "__BACKGROUND__": bg_fill,
        "__BG_CLIP__": ('<div id="bg" class="clip" data-start="0" data-duration="__DUR__" data-track-index="0"></div>'
                        if opaque else ""),
        "__MOTION_BLUR__": ' data-motion-blur="on"' if template in ("slam", "swipe") else "",
        "__STYLE__": sec["STYLE"].replace("__LT_PLACE__", lt_place).replace("__LT_SCALE__", "1.3" if vertical else "1")
                                 .replace("__FIT__", f"{fit:.3f}")
                                 .replace("__BG_LIGHT__", _mix(secondary, primary, 0.28)),
        "__BODY_HTML__": _fill(body, fields), "__SCRIPT__": sec["SCRIPT"],
        "__PARAMS__": json.dumps(extra), "__SPEED__": f"{speed:g}",
    }
    page = (TEMPLATE_DIR / "base.html").read_text(encoding="utf-8")
    for k, v in tokens.items():
        page = page.replace(k, v)
    page = page.replace("__DUR__", f"{dur:g}").replace("__W__", str(W)).replace("__H__", str(H))
    (project / "index.html").write_text(page, encoding="utf-8")
    return dur


def make(template: str, client: Client, size: tuple[int, int], fps: float, out: Path, settings: dict,
         position: str | None = None, background: str | None = None, speed: float = 1.0, **params) -> Path:
    project = out.with_name("hf-" + out.stem)
    if project.exists():
        shutil.rmtree(project)
    build(template, client, size, project, params, position=position, background=background, speed=speed,
          gsap=runtime_dir(settings) / "node_modules" / "gsap" / "dist" / "gsap.min.js")
    return render_project(project, out, settings, "mov", fps=fps)


# ---- custom compositions written by the AI -------------------------------------------------------------------

CUSTOM_GUIDE = """You write one HyperFrames composition: a single standalone index.html that HyperFrames renders to
video by seeking a paused GSAP timeline frame by frame in headless Chrome. It must be SUPER clean and
professional: agency-grade motion design, not a template look.

The contract (break any of these and the render fails):
- Load GSAP with exactly <script src="assets/gsap.min.js"></script>. No other scripts, no network, no CDNs,
  no images unless listed under Assets below.
- <div id="root" data-composition-id="main" data-start="0" data-duration="{dur}" data-width="{W}" data-height="{H}">.
  html and body are {W}x{H}px, overflow hidden, background {bg}.
- Every timed element has class="clip", data-start and data-duration in seconds and a data-track-index; it shows over
  [start, start+duration). Wrap everything in one full-length clip unless you need separate timed layers.
- One paused timeline: const tl = gsap.timeline({{paused: true}}); add every tween, then
  window.__timelines = window.__timelines || {{}}; window.__timelines["main"] = tl; at the end of the script.
- Nothing may depend on real time: no Date.now(), Math.random() (use a seeded function), setTimeout, requestAnimationFrame,
  CSS animations or repeat: -1. Everything visible is a function of timeline time.
- Never tween display/visibility on a .clip (animate its children or its opacity). No CSS transform on an element
  GSAP also transforms (set start values inside fromTo). Prefer fromTo over from.
- Fonts: only these resolve: {fonts}. Text stays inside the 90% action-safe box.

Motion craft: arrivals 0.3-0.6 s on long-tailed eases (expo.out, power4.out); exits 40-50% shorter (power3.in);
overlap elements (start the next when the previous is 30-50% done); stagger words 60-120 ms, letters a frame apart;
a landed title holds dead still; blur-in (8-10 px to 0) per word reads premium; springs only on position/scale
(back.out(1.4)); no floating/breathing loops; one accent colour carries meaning. Vertical: text between 9% and 69%
of the height (phone UI covers the rest), titles about 1.3x larger than landscape, nothing read under 28 px.

Brand: primary {primary}, secondary {secondary}, text {text}. Headline font "{head}", body font "{body}".
Size {W}x{H} at {fps} fps, duration {dur} s. {alpha}
Assets you may use: {assets}

Return JSON: {{"html": the complete index.html, "summary": one sentence describing the graphic}}."""

CUSTOM_SCHEMA = {"type": "object", "properties": {"html": {"type": "string"}, "summary": {"type": "string"}},
                 "required": ["html", "summary"]}


def make_custom(brief: str, client: Client, size: tuple[int, int], fps: float, out: Path, settings: dict,
                dur: float = 5.0, background: str | None = None, prefer: str = "cloud",
                graphics: list[Path] | None = None) -> Path:
    """The AI writes the composition; a failed render goes back once with its error for a fix."""
    from .. import brain
    W, H = size
    project = out.with_name("hf-" + out.stem)
    if project.exists():
        shutil.rmtree(project)
    (project / "assets").mkdir(parents=True)
    shutil.copy2(runtime_dir(settings) / "node_modules" / "gsap" / "dist" / "gsap.min.js", project / "assets" / "gsap.min.js")
    faces, head, body = _fonts(client, project)
    assets = ["assets/gsap.min.js"]
    logo = client.path(client.brand["logo"]["file"]) if client.brand["logo"].get("file") else None
    if logo and logo.is_file():
        shutil.copy2(logo, project / "assets" / ("logo" + logo.suffix.lower()))
        assets.append(f"assets/logo{logo.suffix.lower()} (the client's logo)")
    for k, g in enumerate(graphics or []):  # the user's own graphics, to feature in the design
        shutil.copy2(g, project / "assets" / f"graphic{k + 1}{g.suffix.lower()}")
        assets.append(f"assets/graphic{k + 1}{g.suffix.lower()} (their graphic '{g.stem}': feature it)")
    fonts = ", ".join(sorted({head, body} | {"Inter", "Montserrat", "Poppins", "Oswald", "Archivo Black", "Playfair Display"}))
    c = client.brand["colors"]
    system = CUSTOM_GUIDE.format(dur=f"{dur:g}", W=W, H=H, fps=int(fps), fonts=fonts, primary=c["primary"],
                                 secondary=c["secondary"], text=c.get("text", "#ffffff"), head=head, body=body,
                                 bg=background or "transparent", assets=", ".join(assets),
                                 alpha=("Opaque: fill the frame with " + background + ".") if background else
                                 "Transparent background: this is an overlay for footage, so leave the frame clear around the graphic.")
    from .library import registry
    try:
        system += registry.reference_for(brief, settings)  # open-source blocks close to the brief, to adapt
    except Exception:  # offline or the CLI failed: design from scratch
        pass
    request = "Make this motion graphic: " + brief
    last_error = ""
    for attempt in range(2):
        prompt = request if not last_error else (request + "\n\nYour previous composition failed to render:\n" + last_error +
                                                 "\n\nFix it and return the whole corrected file.")
        from .. import marketing
        res = brain.ask(settings, marketing.system_prompt(client.brand, "motion") + "\n\n" + system, prompt, CUSTOM_SCHEMA,
                        prefer=prefer, timeout=300)
        page = (res or {}).get("html") if isinstance(res, dict) else None
        if not page or "<html" not in page.lower():
            raise RuntimeError("The AI didn't write a composition (is Claude set up under This Mac → AI brain?)")
        page = re.sub(r'<script[^>]+src="https?://[^"]*gsap[^"]*"[^>]*></script>', '<script src="assets/gsap.min.js"></script>', page)
        if faces and "@font-face" not in page:
            page = page.replace("<style>", "<style>\n" + faces + "\n", 1)
        (project / "index.html").write_text(page, encoding="utf-8")
        (project / "brief.txt").write_text(brief + "\n\n" + str((res or {}).get("summary", "")), encoding="utf-8")
        try:
            return render_project(project, out, settings, "mov", fps=fps)
        except RuntimeError as e:
            last_error = str(e)
    raise RuntimeError("The AI's composition didn't render after a fix: " + last_error[-600:])
