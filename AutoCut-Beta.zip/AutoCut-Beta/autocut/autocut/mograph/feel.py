"""Motion feel: After Effects-style easing for every motion graphic.

In After Effects the craft is in the speed graph: keyframes with Easy Ease and strong influence, things that overshoot
and settle, scale and rotation that lag a beat behind position, a glow that blooms as something lands, a drop shadow
that tightens as it touches down, and exits that accelerate away. A feel packs one such set of choices:

  in / out / io   cubic-bezier speed curves (the AE graph-editor handles) for entrances, exits and moves
  scale           where scale starts (0.9 grows in, 1.3 slams down from above, 1.08 pushes in from close)
  rotate          a slight starting tilt in degrees that eases out to 0
  glow            how strongly an accent-coloured glow blooms on arrival (then settles to a quarter)
  lift            how far the drop shadow starts "lifted" (bigger, softer), tightening as the element lands
  elastic         scale settles with an elastic spring instead of the curve
  dur             duration multiplier for those secondary layers (they trail the main move, like offset keyframes)
  exit_scale      where scale ends on the way out (ease-in, so it accelerates away)

These layers ride on CSS custom properties (--fs scale, --fr rotation, --fg glow, --fl lift) and the individual
`scale` / `rotate` CSS properties, so they stack on top of each look's own entrance instead of fighting it. Glow and
shadow sit on the element's container (like an AE layer style on a precomp), so they follow what's visible during a
wipe or mask instead of being clipped by it.
Each look has a default feel (LOOK_FEEL); the Create tab, a content pack look (`"feel": …`) or a client's style DNA
can choose another.
"""
from __future__ import annotations

import json

FEELS: dict[str, dict] = {
    "smooth": dict(name="Smooth (Easy Ease)", about="graceful decelerating moves, a soft grow-in and a shadow that settles",
                   inn=[0.22, 1, 0.36, 1], out=[0.64, 0, 0.78, 0], io=[0.65, 0, 0.35, 1],
                   scale=0.94, rotate=0, glow=0, lift=0.6, elastic=False, dur=1.15, exit_scale=0.97),
    "snappy": dict(name="Snappy (exponential)", about="fast-out exponential curves, crisp and confident",
                   inn=[0.16, 1, 0.3, 1], out=[0.7, 0, 0.84, 0], io=[0.87, 0, 0.13, 1],
                   scale=0.88, rotate=0, glow=0, lift=0.8, elastic=False, dur=0.85, exit_scale=0.94),
    "bouncy": dict(name="Bouncy (overshoot)", about="overshoots and settles back, with a little tilt",
                   inn=[0.34, 1.56, 0.64, 1], out=[0.36, 0, 0.66, -0.56], io=[0.68, -0.6, 0.32, 1.6],
                   scale=0.7, rotate=-5, glow=0, lift=1.0, elastic=False, dur=1.0, exit_scale=0.85),
    "elastic": dict(name="Elastic (spring)", about="springs into place, playful",
                    inn=[0.34, 1.56, 0.64, 1], out=[0.36, 0, 0.66, -0.56], io=[0.68, -0.6, 0.32, 1.6],
                    scale=0.6, rotate=4, glow=0, lift=1.0, elastic=True, dur=1.6, exit_scale=0.85),
    "cinematic": dict(name="Cinematic (slow push)", about="slow ease-in-out, pushes in from close with a soft bloom",
                      inn=[0.45, 0, 0.15, 1], out=[0.55, 0, 1, 0.45], io=[0.76, 0, 0.24, 1],
                      scale=1.08, rotate=0, glow=0.55, lift=0, elastic=False, dur=1.6, exit_scale=1.04),
    "punchy": dict(name="Punchy (slam)", about="slams down from above with a big shadow that snaps tight",
                   inn=[0.05, 0.7, 0.1, 1], out=[0.9, 0, 1, 0.3], io=[0.87, 0, 0.13, 1],
                   scale=1.3, rotate=-3, glow=0.35, lift=1.4, elastic=False, dur=0.55, exit_scale=1.1),
    "glow": dict(name="Glow (bloom)", about="smooth curves with a strong accent glow that blooms and settles",
                 inn=[0.22, 1, 0.36, 1], out=[0.64, 0, 0.78, 0], io=[0.65, 0, 0.35, 1],
                 scale=0.96, rotate=0, glow=1.0, lift=0, elastic=False, dur=1.2, exit_scale=0.98),
}
LOOK_FEEL = {"corporate": "smooth", "minimal": "smooth", "editorial": "smooth", "swiss": "snappy", "brutal": "punchy",
             "glass": "glow", "neon": "glow", "glitch": "snappy", "retro": "bouncy", "handmade": "bouncy",
             "luxury": "cinematic", "sport": "punchy", "playful": "elastic", "broadcast": "snappy", "organic": "smooth",
             "mono": "snappy", "gradient": "smooth", "cinematic": "cinematic"}
DEFAULT = "smooth"


def pick(look: dict, override: str | None = None) -> str:
    """The feel for a look: an explicit choice, the look's own `feel` token, its default, or its base look's."""
    for k in (override, look.get("feel"), LOOK_FEEL.get(look.get("key", "")), LOOK_FEEL.get(look.get("base", ""))):
        if k in FEELS:
            return k
    return DEFAULT


def css(glow_color: str = "var(--acc)", unit_px: float = 1.0) -> str:
    """The layers' CSS: individual scale/rotate, and a shadow/glow that the custom properties drive."""
    return f"""
:root {{ --fu: {unit_px:.4f}px; }}
.fe {{ scale: var(--fs, 1); rotate: calc(var(--fr, 0) * 1deg); }}
.feh {{ filter: drop-shadow(0 calc(var(--fl, 0) * 18 * var(--fu, 1px)) calc(var(--fl, 0) * 34 * var(--fu, 1px)) rgba(0, 0, 0, calc(var(--fl, 0) * 0.28)))
          drop-shadow(0 0 calc(var(--fg, 0) * 26 * var(--fu, 1px)) color-mix(in srgb, {glow_color} calc(var(--fg, 0) * 85%), transparent)); }}
"""


JS = r"""
function bez(a, b, c, d) {  // a cubic-bezier speed curve, like an After Effects keyframe's influence handles
  const cx = 3 * a, bx = 3 * (c - a) - cx, ax = 1 - cx - bx, cy = 3 * b, by = 3 * (d - b) - cy, ay = 1 - cy - by;
  const X = (t) => ((ax * t + bx) * t + cx) * t, Y = (t) => ((ay * t + by) * t + cy) * t, dX = (t) => (3 * ax * t + 2 * bx) * t + cx;
  return (x) => {
    if (x <= 0) return 0; if (x >= 1) return 1;
    let t = x;
    for (let i = 0; i < 8; i++) { const e = X(t) - x, s = dX(t); if (Math.abs(e) < 1e-6) return Y(t); if (Math.abs(s) < 1e-6) break; t -= e / s; }
    let lo = 0, hi = 1; t = x;
    for (let i = 0; i < 30; i++) { const v = X(t); if (Math.abs(v - x) < 1e-6) break; if (v < x) lo = t; else hi = t; t = (lo + hi) / 2; }
    return Y(t);
  };
}
const EIN = bez(...F.inn), EOUT = bez(...F.out), EIO = bez(...F.io);
function feel(sel, t, d, w) {  // the secondary keyframe layers: scale, rotation, glow, shadow lift
  const els = gsap.utils.toArray(sel);
  if (!els.length) return;
  w = w === undefined ? 1 : w;
  els.forEach((el) => el.classList.add("fe"));
  const hosts = [...new Set(els.map((el) => el.parentElement).filter(Boolean))];
  hosts.forEach((h) => h.classList.add("feh"));
  const dd = d * F.dur;
  if (F.scale !== 1 && w) tl.fromTo(els, {"--fs": 1 + (F.scale - 1) * w}, {"--fs": 1, duration: dd, ease: F.elastic ? "elastic.out(1, 0.42)" : EIN}, t);
  if (F.rotate && w) tl.fromTo(els, {"--fr": F.rotate * w}, {"--fr": 0, duration: dd * 1.15, ease: EIN}, t);
  if (F.lift) tl.fromTo(hosts, {"--fl": F.lift}, {"--fl": 0, duration: dd * 1.25, ease: EIN}, t);
  if (F.glow) {
    tl.fromTo(hosts, {"--fg": 0}, {"--fg": F.glow, duration: dd * 0.6, ease: EIN}, t);
    tl.to(hosts, {"--fg": F.glow * 0.3, duration: dd * 1.6, ease: EIO, immediateRender: false}, t + dd * 0.6);
  }
}
function feelOut(sel, t, d) {  // exits accelerate away (ease-in), scale and glow with them
  const els = gsap.utils.toArray(sel);
  if (!els.length) return;
  els.forEach((el) => el.classList.add("fe"));
  if (F.exit_scale !== 1) tl.to(els, {"--fs": F.exit_scale, duration: d, ease: EOUT, immediateRender: false}, t);
  if (F.rotate) tl.to(els, {"--fr": -F.rotate * 0.4, duration: d, ease: EOUT, immediateRender: false}, t);
  if (F.glow) tl.to([...new Set(els.map((el) => el.parentElement).filter(Boolean))], {"--fg": 0, duration: d, ease: EOUT, immediateRender: false}, t);
}
"""


def js(name: str) -> str:
    f = FEELS.get(name) or FEELS[DEFAULT]
    cfg = {k: f[k] for k in ("inn", "out", "io", "scale", "rotate", "glow", "lift", "elastic", "dur", "exit_scale")}
    return f"const F = {json.dumps(cfg)};\n" + JS


def choices() -> list[dict]:
    return [{"key": k, "name": v["name"], "about": v["about"]} for k, v in FEELS.items()]
