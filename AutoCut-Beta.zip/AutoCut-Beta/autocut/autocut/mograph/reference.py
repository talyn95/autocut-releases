"""Reference material for the Create tab: drop in an image or a video of a look you like and the
motion graphic is made to match it.

Measured on this Mac (no AI needed):  the palette (k-means on the pixels), light or dark, how
saturated, and for videos the pacing (how much moves, how often it cuts) → a speed for the template.
Read by the AI brain (free local vision model, Claude as backup): mood, typography style, motion
style and which template fits, written into the spec as suggestions.
"""
from __future__ import annotations

import json
import subprocess
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image

from .. import brain

IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".heic", ".gif", ".bmp"}
VIDEO_EXT = {".mp4", ".mov", ".m4v", ".webm", ".mkv", ".gif"}
STYLE_SCHEMA = {"type": "object", "properties": {
    "mood": {"type": "string"},
    "typography": {"type": "string"},
    "motion": {"type": "string"},
    "template": {"type": "string"},
    "notes": {"type": "string"}}, "required": ["mood", "typography", "motion", "template", "notes"]}


def frames_of(path: Path, n: int = 4, width: int = 512) -> list[Image.Image]:
    path = Path(path)
    if path.suffix.lower() in IMAGE_EXT - {".gif"}:
        from ..effects.media import _open
        img = _open(path).convert("RGB")
        img.thumbnail((width, width))
        return [img]
    dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(path)],
                               capture_output=True, text=True).stdout.strip() or 0)
    out = []
    for k in range(n):
        t = dur * (k + 0.5) / n if dur else 0
        r = subprocess.run(["ffmpeg", "-loglevel", "error", "-ss", f"{t:.2f}", "-i", str(path), "-frames:v", "1",
                            "-vf", f"scale={width}:-2", "-f", "image2pipe", "-vcodec", "png", "-"], capture_output=True)
        if r.stdout:
            import io
            out.append(Image.open(io.BytesIO(r.stdout)).convert("RGB"))
    return out


def palette(images: list[Image.Image], k: int = 5) -> list[tuple[str, float]]:
    """Dominant colours as (hex, share), most common first. Plain k-means; no dependencies."""
    px = np.concatenate([np.asarray(im.resize((96, int(96 * im.height / im.width) or 1))).reshape(-1, 3)
                         for im in images]).astype(float)
    rng = np.random.default_rng(0)
    centres = px[rng.choice(len(px), k, replace=False)]
    for _ in range(12):
        d = ((px[:, None, :] - centres[None]) ** 2).sum(axis=2)
        lab = d.argmin(axis=1)
        for j in range(k):
            if (lab == j).any():
                centres[j] = px[lab == j].mean(axis=0)
    shares = np.bincount(lab, minlength=k) / len(lab)
    order = np.argsort(-shares)
    return [("#%02x%02x%02x" % tuple(int(v) for v in centres[j]), float(shares[j])) for j in order]


def _sat(hexc: str) -> float:
    r, g, b = (int(hexc[i:i + 2], 16) / 255 for i in (1, 3, 5))
    mx, mn = max(r, g, b), min(r, g, b)
    return 0.0 if mx == 0 else (mx - mn) / mx


def lightest_of(pal: list[tuple[str, float]]) -> str:
    return max(pal, key=lambda c: _lum(c[0]))[0]


def _lum(hexc: str) -> float:
    r, g, b = (int(hexc[i:i + 2], 16) / 255 for i in (1, 3, 5))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def pacing(path: Path) -> dict:
    """How lively a reference video is: average movement and cuts per second → a template speed."""
    w, h, fps = 96, 54, 6
    r = subprocess.run(["ffmpeg", "-loglevel", "error", "-i", str(path), "-t", "30", "-an", "-vf",
                        f"fps={fps},scale={w}:{h},format=gray", "-f", "rawvideo", "-"], capture_output=True)
    f = np.frombuffer(r.stdout, np.uint8)
    n = len(f) // (w * h)
    if n < 3:
        return {"energy": "medium", "speed": 1.0, "cuts_per_sec": 0.0}
    f = f[: n * w * h].reshape(n, h, w).astype(np.int16)
    diff = np.abs(np.diff(f, axis=0)).mean(axis=(1, 2))
    cuts = int((diff > 40).sum())
    motion = float(np.median(diff))
    cps = cuts / (n / fps)
    score = motion / 6 + cps * 2  # ~0 calm … ~3 frantic
    speed = round(float(np.clip(0.85 + score * 0.15, 0.8, 1.4)), 2)
    energy = "calm" if score < 0.8 else "high" if score > 2 else "medium"
    return {"energy": energy, "speed": speed, "cuts_per_sec": round(cps, 2), "motion": round(motion, 1)}


def analyze(paths: list[Path], settings: dict, prefer: str = "local") -> dict:
    paths = [Path(p) for p in paths]
    imgs = [im for p in paths for im in frames_of(p)]
    if not imgs:
        raise ValueError("Couldn't read that reference. Use an image (PNG/JPG) or a video (MP4/MOV).")
    pal = palette(imgs)
    # brand-ish colours: the most saturated prominent colour leads, a dark tone backs it
    # the accent must read on screen: colourful AND bright enough (a very dark teal is "saturated" but invisible)
    def punch(c):
        v = max(int(c[i:i + 2], 16) for i in (1, 3, 5)) / 255
        return _sat(c) * v * (0.4 + dict(pal)[c]) if _lum(c) > 0.18 else 0.0
    vivid = sorted([c for c, share in pal if share > 0.04], key=lambda c: -punch(c))
    primary = vivid[0] if vivid and punch(vivid[0]) > 0.1 else lightest_of(pal)
    darkest = min(pal, key=lambda c: _lum(c[0]))[0]
    lightest = max(pal, key=lambda c: _lum(c[0]))[0]
    avg_lum = sum(_lum(c) * s for c, s in pal)
    out = {"palette": [c for c, _ in pal], "colors": [primary, darkest if darkest != primary else lightest],
           "dark": avg_lum < 0.45, "saturation": round(sum(_sat(c) * s for c, s in pal), 2),
           "speed": 1.0, "energy": "medium"}
    video = next((p for p in paths if p.suffix.lower() in VIDEO_EXT), None)
    if video:
        out.update(pacing(video))
    # the AI's read of the style (vision): suggestions only; nothing breaks without it
    with tempfile.TemporaryDirectory() as tmp:
        shots = []
        for i, im in enumerate(imgs[:3]):
            fp = Path(tmp) / f"ref{i}.jpg"
            im.save(fp, quality=85)
            shots.append(fp)
        from ..mograph.templates import TEMPLATES
        prompt = ("This is reference material for a motion graphic an agency wants to make. Describe the style so a "
                  "designer can match it: the mood (3-6 words), the typography (e.g. heavy condensed sans, elegant serif, "
                  "rounded friendly sans), the motion style it implies (e.g. snappy and punchy, smooth and premium, bouncy, "
                  f"minimal), which of these templates suits it best: {', '.join(TEMPLATES)}, and one sentence of notes.")
        from .. import marketing
        ai = brain.ask(settings, marketing.knowledge("design", "motion") + "\n\nYou are the agency's senior designer.", prompt, STYLE_SCHEMA, images=shots,
                       prefer=prefer, timeout=180)
    if isinstance(ai, dict):
        out["ai"] = {k: str(ai.get(k, ""))[:200] for k in STYLE_SCHEMA["properties"]}
        out["ai_engine"] = brain.last_engine()
        motion = out["ai"]["motion"].lower()
        if not video:  # no video to measure: take the pacing from the AI's read
            out["speed"] = 1.2 if any(w in motion for w in ("snappy", "punch", "fast", "energetic")) else \
                0.85 if any(w in motion for w in ("smooth", "calm", "premium", "elegant", "minimal")) else 1.0
    return out


def save(folder: Path, analysis: dict) -> Path:
    (folder / "reference.json").write_text(json.dumps(analysis, indent=1))
    return folder / "reference.json"
