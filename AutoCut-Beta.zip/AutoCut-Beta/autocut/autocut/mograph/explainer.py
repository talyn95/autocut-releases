"""Explainer split: a short-form edit style where the graphics explain what the speaker is saying.

The layout (9:16 first) is a clean white canvas:
  top     a graphics zone: the brand mark, then whatever the current sentence needs (see scenes)
  middle  bold word-group captions, two or three words at a time, as they're said
  bottom  the speaker in a rounded panel; their head pops out over the panel's top edge (person cut-out), and the
          shot punches in and out between sentences so the jump cuts read as deliberate

Scenes (one per sentence, planned by rules and refined by the AI when one is running):
  card       a post-style card (the client's mark, name and area) whose text builds word by word as it's said, the
             key words in the brand colour
  media      one of your graphics (a screenshot, a product, a photo) on a card, with a price/stat sticker that counts
             up when a number is said
  interlude  the speaker drops away for a beat: a big serif number on a card while the words land in italic serif
             capitals; a "free / zero / nothing" after the number strikes it through and pops a badge
  step       a framework ("first… next… finally…"): a numbered step tracker with the current step's label, and the
             card text building underneath, the earlier step greyed above it
  intro      "I'm <name>": a name card that types the name, with a verified badge for the business

The take is rough-cut first (fillers, stutters, false starts and long pauses out, edit.plan_edit), so the words,
captions and graphics all run on the cut's timeline. Out: one HyperFrames composition (editable in Studio) and an
MP4 with the voice. Everything uses the client's brand: colours, logo, name, fonts, area.
"""
from __future__ import annotations

import html
import json
import re
import shutil
import subprocess
from pathlib import Path

from ..config import Client
from . import hyper
from .script import NUM, STOP, _keyword, _num_value, beats, clean

NAME = re.compile(r"\b(?i:i'm|i am|my name is|name's)\s+([A-Z][a-z'’-]+(?:\s+[A-Z][a-z'’-]+)?)")
NOT_NAMES = {"Not", "So", "Going", "Here", "The", "A", "Just", "Really", "Gonna", "Sure", "Also", "Very", "Back", "In", "On"}
STEP = re.compile(r"^(first|firstly|second|secondly|third|thirdly|fourth|fifth|next|finally|lastly|step|number)\b", re.I)
FREE = {"free", "zero", "nothing", "$0", "0"}
SERIF = "Playfair Display"
INK, CANVAS, STRIKE = "#111111", "#fbfaf8", "#e5484d"


def _money(token: str) -> bool:
    v = _num_value(token)
    return bool(v) and (v[0] or v[2] in ("%", "k", "m", "x") or v[1] >= 100)


def _text(b: dict) -> str:
    return " ".join(w["word"] for w in b["words"])


def caption_groups(words: list[dict], most: int = 3) -> list[list[dict]]:
    """Two or three words at a time, breaking after punctuation, never leaving one word alone at the end."""
    out, cur = [], []
    for i, w in enumerate(words):
        cur.append(w)
        nxt = words[i + 1] if i + 1 < len(words) else None
        if len(cur) >= most or re.search(r"[,.;:!?]$", w["word"]) or not nxt or nxt["start"] - w["end"] > 0.5:
            out.append(cur)
            cur = []
    for k in range(len(out) - 1, 0, -1):
        if len(out[k]) == 1 and len(out[k - 1]) < most and not re.search(r"[.!?]$", out[k - 1][-1]["word"]):
            out[k - 1] += out.pop(k)
    return out


# ---- the plan ---------------------------------------------------------------------------------------------------------

def plan(words: list[dict], graphics: list[Path], brand: dict, settings: dict | None = None) -> list[dict]:
    """One scene per sentence: rules first, then the AI (when one answers) picks highlights, labels and kinds."""
    sents = beats(words, max_words=12)
    names = {g: {t for t in re.split(r"[^a-z0-9]+", g.stem.lower()) if len(t) > 2} for g in graphics}
    used: set[Path] = set()
    last_interlude = -99.0
    out = []
    for i, b in enumerate(sents):
        ws = [w["word"] for w in b["words"]]
        low = [clean(w).lower() for w in ws]
        nums = [j for j, w in enumerate(ws) if NUM.match(clean(w)) and _money(w)]
        free = [j for j, w in enumerate(low) if w in FREE]
        s = {"words": b["words"], "kind": "card", "hl": sorted({_keyword(ws), *nums})}
        m = NAME.search(_text(b))
        hit = next((g for g in graphics if g not in used and names[g] & set(low)), None)
        if m and m.group(1).split()[0] not in NOT_NAMES:
            s.update(kind="intro", name=m.group(1))
        elif STEP.match(clean(ws[0])) and len(ws) >= 3:
            s.update(kind="step", label=_label(ws))
        elif hit or (i == 0 and graphics):
            g = hit or graphics[0]
            used.add(g)
            s.update(kind="media", image=g)
        elif i and (nums or free) and len(ws) <= 16 and b["words"][0]["start"] - last_interlude > 10 \
                and out[-1]["kind"] != "interlude":
            s.update(kind="interlude")
            last_interlude = b["words"][0]["start"]
        if s["kind"] in ("media", "interlude") and nums:
            s["num"] = nums[0]
            s["label"] = _sticker_label(ws, nums[0])
        if s["kind"] == "interlude" and free and (not nums or free[-1] > nums[0]):
            s["badge"] = free[-1]
            s["strike"] = bool(nums)
        out.append(s)
    # a name card holds through the rest of its sentence ("Hi, I'm Sam, | and I've been doing this for ten years")
    for k in range(len(out) - 2, -1, -1):
        a, b = out[k], out[k + 1]
        if a["kind"] == "intro" and b["kind"] == "card" and not re.search(r"[.!?]$", a["words"][-1]["word"]) \
                and b["words"][0]["start"] - a["words"][-1]["end"] < 0.5:
            a["words"] = a["words"] + b["words"]
            out.pop(k + 1)
    # graphics nobody named still appear, on cards spread through the video
    spare = [g for g in graphics if g not in used]
    cards = [s for s in out[1:] if s["kind"] == "card"]
    for k, g in enumerate(spare):
        if not cards:
            break
        s = cards[min(len(cards) - 1, int((k + 0.5) * len(cards) / len(spare)))]
        if s["kind"] == "card":
            s.update(kind="media", image=g)
    if settings is not None:
        _ai(out, settings, brand)
    return out


VERBS = set("check look walk make get go take use find call put ask start open grab write pick set run try see keep "
             "add cut clean test watch read send book post film shoot plan list measure compare".split())


def _label(ws: list[str]) -> str:
    """A step's tracker label from its words: what the step is about, the first thing named after its verb
    ("First, check the shingles…" → Shingles)."""
    body = [clean(w) for w in ws[1:] if clean(w)]
    skip = STOP | VERBS | {"step", "number", "one", "two", "three", "four", "five", "is", "you", "your", "we", "our", "out"}
    k = next((w for w in body if w.lower() not in skip and not NUM.match(w)), "") or clean(ws[_keyword(ws)])
    return k.capitalize() if k else "Step"


def _sticker_label(ws: list[str], n: int) -> str:
    after = [clean(w) for w in ws[n + 1:n + 4] if clean(w)]
    before = [clean(w) for w in ws[max(0, n - 2):n] if clean(w).lower() not in {"me", "a", "the", "about", "over"}]
    words = after[:3] if after else before
    return " ".join(words).upper()[:22]


AI_SCHEMA = {"type": "object", "properties": {"scenes": {"type": "array", "items": {"type": "object", "properties": {
    "i": {"type": "integer"}, "kind": {"type": "string"}, "highlight": {"type": "array", "items": {"type": "string"}},
    "label": {"type": "string"}}}}}, "required": ["scenes"]}


def _ai(scenes: list[dict], settings: dict, brand: dict) -> None:
    from .. import brain, marketing
    listing = "\n".join(f"{i}: [{s['kind']}] {_text(s)}" for i, s in enumerate(scenes[:80]))
    out = brain.ask(settings, marketing.system_prompt(brand, "motion"),
                    "These are the sentences of a short talking-head video, in order, with the graphic planned for "
                    "each. For each give: highlight = the 1-3 words (copied exactly) that should light up in the "
                    "brand colour; kind = keep the planned one, or 'interlude' for at most one or two big money/stat "
                    "moments (never sentence 0), 'step' for a numbered framework step, else 'card'; label = for steps "
                    "a 1-3 word name for the step (e.g. Hook, Pain point, Who you are), for a number a 2-3 word "
                    "sticker caption (e.g. COST TO LEARN).\n\n" + listing, AI_SCHEMA, timeout=120)
    if not isinstance(out, dict):
        return
    for r in out.get("scenes") or []:
        i = r.get("i")
        if not isinstance(i, int) or not 0 <= i < len(scenes):
            continue
        s = scenes[i]
        low = [clean(w["word"]).lower() for w in s["words"]]
        hl = [low.index(clean(str(h)).lower()) for h in (r.get("highlight") or [])[:3] if clean(str(h)).lower() in low]
        if hl:
            s["hl"] = sorted(set(hl) | ({s["num"]} if "num" in s else set()))
        kind = r.get("kind")
        if kind == "step" and s["kind"] == "card" and len(low) >= 3:
            s["kind"] = "step"
        elif kind == "interlude" and s["kind"] == "card" and i and len(low) <= 12:
            s["kind"] = "interlude"
        elif kind == "card" and s["kind"] in ("step", "interlude"):
            s["kind"] = "card"
        label = str(r.get("label") or "").strip()
        if label and len(label) <= 24 and (s["kind"] == "step" or "num" in s):
            s["label"] = label.upper() if s["kind"] != "step" else label
        s["ai"] = True


# ---- the take: rough cut, framing, pop-out ----------------------------------------------------------------------------

def cut_take(source: Path, words: list[dict], brand: dict, work: Path) -> tuple[Path, list[dict], float]:
    """The take with fillers, stutters, false starts and long pauses cut out. Returns (cut video, its words, length)."""
    from ..edit import plan_edit
    from ..media import probe
    info = probe(source)
    fps = info.fps or 30
    ep = plan_edit(words, info.duration, fps, brand["edit"])
    out = work / "cut.mp4"
    parts, labels = [], []
    for k, sg in enumerate(ep.segments):
        a, b = sg.src_in / fps, sg.src_out / fps
        parts.append(f"[0:v]trim={a:.4f}:{b:.4f},setpts=PTS-STARTPTS[v{k}];[0:a]atrim={a:.4f}:{b:.4f},asetpts=PTS-STARTPTS[a{k}]")
        labels.append(f"[v{k}][a{k}]")
    graph = ";".join(parts) + f";{''.join(labels)}concat=n={len(labels)}:v=1:a=1[v][a];[v]scale=-2:'min(1920,ih)'[vo]"
    subprocess.run(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-i", str(source), "-filter_complex", graph,
                    "-map", "[vo]", "-map", "[a]", "-c:v", "libx264", "-preset", "veryfast", "-crf", "17", "-pix_fmt", "yuv420p",
                    "-r", f"{fps:.3f}", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(out)], check=True)
    return out, ep.words, ep.seconds


def _segmenter():
    try:
        from ..effects.cutout import get_segmenter
        return get_segmenter("auto")
    except Exception:  # noqa: BLE001 - no segmentation here: centred framing, no pop-out
        return None


def framing(video: Path, seg) -> tuple[float, float]:
    """Where the speaker is in the frame: (head top, centre x) as fractions of the frame, from a few frames."""
    import numpy as np
    from ..media import probe
    info = probe(video)
    if seg is None:
        return (0.18 if info.height > info.width else 0.12), 0.5
    W, H = max(2, info.width // 8 * 2), max(2, info.height // 8 * 2)
    tops, xs = [], []
    for k in range(5):
        t = info.duration * (k + 0.5) / 5
        raw = subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-ss", f"{t:.3f}", "-i", str(video), "-frames:v", "1",
                              "-vf", f"scale={W}:{H}", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True).stdout
        if len(raw) < W * H * 3:
            continue
        m = seg(np.frombuffer(raw, np.uint8).reshape(H, W, 3)) > 0.5
        rows = np.where(m.sum(1) > 0.02 * W)[0]
        cols = np.where(m.sum(0) > 0.02 * H)[0]
        if len(rows) and len(cols):
            tops.append(rows[0] / H)
            xs.append((cols[0] + cols[-1]) / 2 / W)
    if not tops:
        return (0.18 if info.height > info.width else 0.12), 0.5
    return float(np.median(tops)), float(np.median(xs))


def geometry(size: tuple[int, int], src: tuple[int, int], frame: tuple[float, float]) -> dict:
    """Where everything sits (1080x1920 reference, scaled): the speaker panel, how the take fills it (scale `s`,
    offsets ox/oy, the head just over the panel edge), the room above it for the pop-out, and the band of source rows
    the pop-out needs (y0, y1)."""
    W, H = size
    u = W / 1080
    sw, sh = src
    head_top, cx = frame
    panel_top = round(0.60 * H)
    margin = round(14 * u)
    pw, ph = W - 2 * margin, H - panel_top + round(80 * u)
    s = max(pw / sw, (H - panel_top) / sh)
    vw, vh = sw * s, sh * s
    oy = min(max(0.0, head_top * vh + 34 * u), max(0.0, vh - (H - panel_top)))
    ox = min(max(0.0, cx * vw - pw / 2), max(0.0, vw - pw))
    room = round(min(260 * u, panel_top * 0.4))
    y0 = max(0, int((oy - room * 1.1) / s) // 2 * 2)
    y1 = min(sh, int((oy + 360 * u) / s + 2) // 2 * 2)
    return dict(u=u, panel_top=panel_top, margin=margin, pw=pw, ph=ph, s=s, vw=vw, vh=vh, oy=oy, ox=ox, room=room,
                origin=(cx * vw, head_top * vh + 300 * u), y0=y0, y1=max(y0 + 2, y1))


def render_popout(video: Path, seg, out: Path, band: tuple[int, int] | None = None) -> Path | None:
    """The speaker alone with transparency (VP9 WebM with alpha, which the HyperFrames renderer reads), so their
    head can rise over the panel edge. Only the band of rows around the panel edge is kept (band = source rows)."""
    import numpy as np
    from PIL import Image, ImageFilter
    from ..media import probe
    info = probe(video)
    W, H, fps = info.width, info.height, info.fps or 30
    y0, y1 = band or (0, H)
    small = (max(2, W // 3), max(2, H // 3))
    dec = subprocess.Popen(["ffmpeg", "-nostdin", "-loglevel", "error", "-i", str(video), "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                           stdout=subprocess.PIPE)
    enc = subprocess.Popen(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgba",
                            "-s", f"{W}x{y1 - y0}", "-r", f"{fps:.3f}", "-i", "-", "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p",
                            "-auto-alt-ref", "0", "-deadline", "realtime", "-cpu-used", "8", "-row-mt", "1", "-crf", "30",
                            "-b:v", "0", "-metadata:s:v:0", "alpha_mode=1", str(out)], stdin=subprocess.PIPE)
    stride = 1 if getattr(seg, "name", "") == "vision" else 2  # the ONNX model is slow on a CPU: a new mask every other frame
    prev, n, m = None, 0, None
    try:
        while True:
            raw = dec.stdout.read(W * H * 3)
            if len(raw) < W * H * 3:
                break
            rgb = np.frombuffer(raw, np.uint8).reshape(H, W, 3)
            if m is None or n % stride == 0:
                m = np.clip((seg(np.asarray(Image.fromarray(rgb).resize(small, Image.BILINEAR))) - 0.3) / 0.4, 0, 1)
            prev = m if prev is None else 0.65 * m + 0.35 * prev
            k0, k1 = int(y0 * small[1] / H), max(int(y0 * small[1] / H) + 1, int(np.ceil(y1 * small[1] / H)))
            band_m = Image.fromarray((prev[k0:k1] * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(0.6))
            alpha = band_m.resize((W, round((k1 - k0) * H / small[1])), Image.BILINEAR)
            off = y0 - round(k0 * H / small[1])
            alpha = np.asarray(alpha)[off:off + (y1 - y0)]
            if alpha.shape[0] < y1 - y0:
                alpha = np.pad(alpha, ((0, y1 - y0 - alpha.shape[0]), (0, 0)))
            enc.stdin.write(np.dstack([rgb[y0:y1], alpha]).tobytes())
            n += 1
    finally:
        dec.stdout.close()
        dec.wait()
        enc.stdin.close()
        enc.wait()
    return out if n and enc.returncode == 0 and out.exists() else None


# ---- the composition --------------------------------------------------------------------------------------------------

def _light(img: Path) -> bool:
    """A white or very light logo, which would vanish on the white canvas: it goes on a dark chip."""
    try:
        import numpy as np
        from PIL import Image
        im = np.asarray(Image.open(img).convert("RGBA").resize((200, 200)), dtype=float)
        a = im[..., 3] > 128
        return bool(a.any()) and float((im[..., :3][a] @ [0.299, 0.587, 0.114]).mean()) > 185
    except Exception:  # noqa: BLE001 - SVG or unreadable: assume it shows on white
        return False


def _initials(name: str) -> str:
    parts = [p for p in re.split(r"[\s&-]+", name) if p and p[0].isalnum()]
    return ("".join(p[0] for p in parts[:2]) or "•").upper()


def build(words: list[dict], scenes: list[dict], client: Client, size: tuple[int, int], project: Path, settings: dict,
          video: Path, length: float, frame: tuple[float, float], pop: Path | None = None, feel: str | None = None,
          band: tuple[int, int] | None = None) -> float:
    """Write the HyperFrames project. Returns the video length in seconds."""
    from . import feel as feel_mod
    from ..media import probe
    W, H = size
    u = W / 1080
    if project.exists():
        shutil.rmtree(project)
    (project / "assets").mkdir(parents=True)
    gsap = hyper.runtime_dir(settings) / "node_modules" / "gsap" / "dist" / "gsap.min.js"
    if gsap.exists():
        shutil.copy2(gsap, project / "assets" / "gsap.min.js")
    shutil.copy2(video, project / "assets" / "take.mp4")
    if pop:
        shutil.copy2(pop, project / "assets" / "take-cutout.webm")
    faces, head_font, body_font = hyper._fonts(client, project)
    brand = client.brand
    primary = brand["colors"]["primary"]
    acc = primary if hyper._luma(primary) < 200 else brand["colors"].get("secondary") or INK
    dark = brand["colors"]["secondary"] if hyper._luma(brand["colors"]["secondary"]) < 110 else INK
    panel = hyper._mix(acc, "#f1ede7", 0.94)
    name = brand.get("client") if brand.get("client") not in (None, "", "Custom") else ""
    area = ((brand.get("marketing") or {}).get("location") or "").strip()
    website = re.sub(r"^https?://(www\.)?|/.*$", "", str(brand.get("website") or ""))
    sub = " · ".join(x for x in (area, website) if x) or (brand.get("tagline") or "")
    logo_src = None
    lf = (brand.get("logo") or {}).get("file")
    if lf and client.path(lf) and client.path(lf).is_file():
        src = client.path(lf)
        logo_src = f"assets/logo{src.suffix.lower()}"
        shutil.copy2(src, project / logo_src)
    light = bool(logo_src) and _light(project / logo_src)
    feel = feel if feel in feel_mod.FEELS else "smooth"

    total = round(min(length, (words[-1]["end"] if words else length) + 0.6), 3)
    starts = [max(0.0, s["words"][0]["start"] - 0.15) for s in scenes]
    for i, s in enumerate(scenes):
        s["a"] = round(starts[i] if i else 0.0, 3)
        s["z"] = round(starts[i + 1] if i + 1 < len(scenes) else total, 3)

    info = probe(video)
    g = geometry(size, (info.width or 1080, info.height or 1920), frame)
    panel_top, margin, pw, ph, room = g["panel_top"], g["margin"], g["pw"], g["ph"], g["room"]
    s_, vw, vhh, ox, oy = g["s"], g["vw"], g["vh"], g["ox"], g["oy"]
    origin = f"{g['origin'][0]:.0f}px {g['origin'][1]:.0f}px"
    y0, y1 = band or (g["y0"], g["y1"])
    cap_y = round(0.485 * H)

    # an interlude holds a beat after its last word (the strike and badge land on it), the next scene starts late
    for i, s in enumerate(scenes[:-1]):
        if s["kind"] == "interlude":
            nxt = scenes[i + 1]
            z = round(min(s["words"][-1]["end"] + 0.9, nxt["words"][-1]["start"] - 0.2), 3)
            if z > s["z"]:
                s["z"] = nxt["a"] = z

    parts, tw, events = [], [], []
    T = lambda x: f"{x:.3f}"  # noqa: E731

    # captions (hidden during interludes)
    inter = [(s["a"], s["z"]) for s in scenes if s["kind"] == "interlude"]
    groups = caption_groups(words)
    for k, g in enumerate(groups):
        a = g[0]["start"] - 0.03
        z = min(groups[k + 1][0]["start"] - 0.03 if k + 1 < len(groups) else total, g[-1]["end"] + 1.0)
        if any(x <= a < y for x, y in inter) or z - a < 0.08:
            continue
        txt = html.escape(" ".join(w["word"].rstrip(",.;:!?") for w in g))
        parts.append(f'<div id="c{k}" class="clip capw" data-start="{T(a)}" data-duration="{T(z - a)}" data-track-index="5">'
                     f'<div class="cap">{txt}</div></div>')
        tw.append(f'tl.fromTo("#c{k} .cap", {{opacity: 0, scale: 0.9, y: {12 * u:.0f}}}, {{opacity: 1, scale: 1, y: 0, duration: 0.16, ease: EIN}}, {T(a)});')

    # the speaker: panel (clipped) + cut-out (unclipped at the top), punched in per sentence
    vid = (f'<video id="take" class="clip" src="assets/take.mp4" data-start="0" data-duration="{total}" data-track-index="1" '
           f'muted playsinline></video>')
    cam_css = f"position: absolute; left: {-ox:.0f}px; width: {vw:.0f}px; height: {vhh:.0f}px; transform-origin: {origin};"
    spk = (f'<div id="spk"><div class="cam" style="{cam_css} top: {-oy:.0f}px">{vid}</div></div>')
    if pop:
        spk += (f'<div id="pop"><div class="cam" style="{cam_css} top: {room - oy:.0f}px">'
                f'<video id="takecut" class="clip band" src="assets/take-cutout.webm" data-start="0" data-duration="{total}" '
                f'data-track-index="2" muted playsinline style="top: {y0 * s_:.1f}px; height: {(y1 - y0) * s_:.1f}px"></video></div></div>')
    zoom, who = 1.0, '["#spk", "#pop"]' if pop else '"#spk"'
    for i, s in enumerate(scenes):
        if s["kind"] == "interlude":
            tw.append(f'tl.to({who}, {{opacity: 0, y: {60 * u:.0f}, duration: 0.18, ease: EOUT}}, {T(s["a"])});')
            nxt = s["z"]
            if nxt < total - 0.05:
                tw.append(f'tl.fromTo({who}, {{opacity: 0, y: {60 * u:.0f}}}, {{opacity: 1, y: 0, duration: 0.3, ease: EIN, immediateRender: false}}, {T(nxt)});')
            continue
        z = 1.0 if i % 2 == 0 else 1.13
        if s["kind"] in ("step", "intro"):
            z = 1.22 if i % 2 else 1.12
        if z != zoom and i:
            tw.append(f'tl.set(".cam", {{scale: {z}}}, {T(s["a"])});')
            zoom = z

    # top: the brand mark (not while the step tracker is up)
    steps = [s for s in scenes if s["kind"] == "step"]
    track = len(steps) >= 2
    t_a = steps[0]["a"] if track else total
    t_z = steps[-1]["z"] if track else total
    if logo_src:
        spans = [(0.0, t_a), (t_z, total)] if track else [(0.0, total)]
        for k, (a, z) in enumerate(spans):
            if z - a > 0.2:
                parts.append(f'<div id="mk{k}" class="clip mark{" chip" if light else ""}" data-start="{T(a)}" data-duration="{T(z - a)}" data-track-index="3">'
                             f'<img src="{logo_src}" alt=""></div>')
                tw.append(f'tl.fromTo("#mk{k} img", {{opacity: 0, y: -{16 * u:.0f}}}, {{opacity: 1, y: 0, duration: 0.4, ease: EIN}}, {T(a + 0.05)});')

    # the step tracker
    if track:
        stops = [s for s in scenes if s["a"] >= t_a and s["z"] <= t_z + 0.01 and s["kind"] in ("step", "intro")]
        n = len(stops)
        for s in stops:
            if s["kind"] == "intro" and not s.get("label"):
                s["label"] = "Who I am"
        dots = []
        for k in range(n):
            dots.append(f'<div class="dot" id="d{k}"><span class="n">{k + 1}</span><span class="ck">✓</span></div>')
            if k < n - 1:
                dots.append(f'<div class="ln"><i id="l{k}"></i></div>')
        labels = "".join(f'<div class="tlab" id="tl{k}" style="left: calc({k} * var(--pitch))">{html.escape(s.get("label") or "")}</div>'
                         for k, s in enumerate(stops))
        parts.append(f'<div id="trk" class="clip" data-start="{T(t_a)}" data-duration="{T(t_z - t_a)}" data-track-index="3">'
                     f'<div class="track" style="--pitch: {min(150, 900 / n) * u:.0f}px"><div class="dots">{"".join(dots)}</div><div class="labs">{labels}</div></div></div>')
        tw.append(f'tl.fromTo("#trk .track", {{opacity: 0, y: -{20 * u:.0f}}}, {{opacity: 1, y: 0, duration: 0.4, ease: EIN}}, {T(t_a)});')
        for k, s in enumerate(stops):
            a = s["a"] + 0.05
            tw.append(f'tl.to("#d{k}", {{backgroundColor: "{acc}", borderColor: "{acc}", color: "#ffffff", duration: 0.2, ease: EIN}}, {T(a)});')
            tw.append(f'feel("#d{k}", {T(a)}, 0.35, 0.6);')
            tw.append(f'tl.fromTo("#tl{k}", {{opacity: 0, y: {8 * u:.0f}}}, {{opacity: 1, y: 0, duration: 0.25, ease: EIN}}, {T(a)});')
            if k:
                tw.append(f'tl.to("#tl{k - 1}", {{opacity: 0, duration: 0.15, ease: EOUT}}, {T(a)});')
                tw.append(f'tl.to("#d{k - 1}", {{backgroundColor: "{INK}", borderColor: "{INK}", duration: 0.2, ease: EIN}}, {T(a)});')
                tw.append(f'tl.to("#d{k - 1} .n", {{opacity: 0, duration: 0.1}}, {T(a)});')
                tw.append(f'tl.fromTo("#d{k - 1} .ck", {{opacity: 0, scale: 0.4}}, {{opacity: 1, scale: 1, duration: 0.3, ease: "back.out(2)"}}, {T(a + 0.05)});')
                tw.append(f'tl.fromTo("#l{k - 1}", {{scaleX: 0}}, {{scaleX: 1, duration: 0.3, ease: EIN}}, {T(a - 0.1)});')
            events.append({"t": a, "kind": "sticker"})

    # scenes in the top zone
    prev_card = None
    for i, s in enumerate(scenes):
        sid = f"s{i}"
        a, z = s["a"], s["z"]
        ws = s["words"]
        hl = set(s.get("hl") or [])
        body = ""
        if s["kind"] in ("card", "step"):
            spans = []
            for j, w in enumerate(ws):
                spans.append(f'<span class="bw" id="{sid}w{j}">{html.escape(w["word"])}</span>')
                tw.append(f'tl.to("#{sid}w{j}", {{color: "{acc if j in hl else INK}", duration: 0.12, ease: EIN}}, {T(w["start"] - 0.02)});')
            earlier = (f'<div class="prev">{html.escape(_text(prev_card))}</div>'
                       if s["kind"] == "step" and prev_card is not None and prev_card["kind"] == "step" else "")
            avatar = (f'<div class="av img{" dk" if light else ""}"><img src="{logo_src}" alt=""></div>' if logo_src else
                      f'<div class="av">{html.escape(_initials(name or "AutoCut"))}</div>')
            head = (f'<div class="hd">{avatar}<div><div class="nm">{html.escape(name)}</div>'
                    f'<div class="sb">{html.escape(sub)}</div></div></div>') if name or logo_src else ""
            fs = 54 if len(_text(s)) < 40 else 46 if len(_text(s)) < 70 else 40
            body = f'<div class="card build">{head}{earlier}<div class="tx" style="font-size:{fs * u:.0f}px">{" ".join(spans)}</div></div>'
            prev_card = s
        elif s["kind"] == "intro":
            letters = "".join(f'<span class="lt" id="{sid}l{k}">{html.escape(ch)}</span>' for k, ch in enumerate(s["name"]))
            nt = next((w["start"] for w in ws if clean(w["word"]) == s["name"].split()[0]), ws[0]["start"] + 0.3)
            for k in range(len(s["name"])):
                tw.append(f'tl.fromTo("#{sid}l{k}", {{opacity: 0}}, {{opacity: 1, duration: 0.05}}, {T(nt + k * 0.045)});')
            co = (f'<div class="ver"><svg viewBox="0 0 24 24" width="{26 * u:.0f}" height="{26 * u:.0f}"><path d="M12 2 4 5v6c0 5 3.4 9.4 8 11 '
                  f'4.6-1.6 8-6 8-11V5l-8-3z" fill="none" stroke="{acc}" stroke-width="2"/><path d="m8.5 12 2.5 2.5 4.5-5" fill="none" '
                  f'stroke="{acc}" stroke-width="2.2" stroke-linecap="round"/></svg>{html.escape(name)}</div>') if name else ""
            body = (f'<div class="card intro"><div class="row"><div class="av big">{html.escape(_initials(s["name"]))}</div>'
                    f'<div><div class="hi">Hi, I\'m</div><div class="who">{letters}</div></div></div>{co}</div>')
            tw.append(f'tl.fromTo("#{sid} .hi", {{opacity: 0, x: -{14 * u:.0f}}}, {{opacity: 1, x: 0, duration: 0.3, ease: EIN}}, {T(a + 0.2)});')
            if co:
                tw.append(f'tl.fromTo("#{sid} .ver", {{opacity: 0, y: {10 * u:.0f}}}, {{opacity: 1, y: 0, duration: 0.35, ease: EIN}}, {T(nt + len(s["name"]) * 0.045 + 0.2)});')
            events.append({"t": nt, "kind": "sticker"})
            prev_card = None
        elif s["kind"] == "media":
            dest = project / "assets" / f"g{i}{s['image'].suffix.lower()}"
            shutil.copy2(s["image"], dest)
            sticker = ""
            if "num" in s and _num_value(ws[s["num"]]["word"]):
                pre, val, suf, dec = _num_value(ws[s["num"]]["word"])
                nt = ws[s["num"]]["start"]
                sticker = (f'<div class="stk"><div class="sl">{html.escape(s.get("label") or "")}</div><div class="sv">'
                           f'{html.escape(pre)}<span id="{sid}n">0</span>{html.escape(suf)}</div></div>')
                tw.append(f'tl.fromTo("#{sid} .stk", {{opacity: 0, scale: 0.5, rotation: -14}}, {{opacity: 1, scale: 1, rotation: -4, duration: 0.45, ease: "back.out(1.7)"}}, {T(nt - 0.25)});')
                tw.append(_count(f"{sid}n", val, dec, nt - 0.1, 1.1))
                events += [{"t": nt - 0.25, "kind": "sticker"}, {"t": nt, "kind": "number"}]
            body = f'<div class="media"><img src="assets/{dest.name}" alt="">{sticker}</div>'
            events.append({"t": a, "kind": "graphic"})
            prev_card = None
        elif s["kind"] == "interlude":
            n = s.get("num")
            if n is not None and _num_value(ws[n]["word"]):
                pre, val, suf, dec = _num_value(ws[n]["word"])
                big = f'{html.escape(pre)}<span id="{sid}n">0</span>{html.escape(suf)}'
                tw.append(_count(f"{sid}n", val, dec, a + 0.1, 0.9))
                events.append({"t": ws[n]["start"], "kind": "number"})
            else:
                big = html.escape(clean(ws[sorted(hl)[0] if hl else _keyword([w["word"] for w in ws])]["word"]).upper())
            badge = ""
            if s.get("badge") is not None:
                st = ws[s["badge"]]["start"]
                badge = f'<div class="badge">{html.escape(clean(ws[s["badge"]]["word"]).upper())}</div>'
                if s.get("strike"):
                    tw.append(f'tl.fromTo("#{sid} .strk", {{scaleX: 0}}, {{scaleX: 1, duration: 0.3, ease: EIN}}, {T(st - 0.3)});')
                    tw.append(f'tl.to("#{sid} .big", {{color: "#b9b4ad", duration: 0.25, ease: EIN}}, {T(st - 0.3)});')
                tw.append(f'tl.fromTo("#{sid} .badge", {{opacity: 0, scale: 0.3, rotation: 12}}, {{opacity: 1, scale: 1, rotation: -5, duration: 0.45, ease: "back.out(2.2)"}}, {T(st)});')
                events.append({"t": st, "kind": "slam"})
            body = (f'<div class="icard"><div class="big">{big}<div class="strk"></div></div>{badge}</div>')
            for k, g in enumerate(caption_groups(ws, 2)):
                ga = g[0]["start"] - 0.05
                gz = min(z, g[-1]["end"] + 0.9)
                nxt = caption_groups(ws, 2)
                if k + 1 < len(nxt):
                    gz = min(gz, nxt[k + 1][0]["start"] - 0.05)
                txt = html.escape(" ".join(clean(w["word"]) for w in g).upper())
                parts.append(f'<div id="{sid}i{k}" class="clip ital" data-start="{T(ga)}" data-duration="{T(max(0.1, gz - ga))}" data-track-index="6">'
                             f'<div class="it">{txt}</div></div>')
                tw.append(f'tl.fromTo("#{sid}i{k} .it", {{opacity: 0, scale: 1.12, filter: "blur(6px)"}}, {{opacity: 1, scale: 1, filter: "blur(0px)", duration: 0.2, ease: EIN, clearProps: "filter"}}, {T(ga)});')
            events.append({"t": a, "kind": "slam"})
            prev_card = None
        if s["kind"] != "intro" and s["kind"] != "interlude" and s["kind"] != "media":
            events.append({"t": a, "kind": "graphic"})
        same_card = s["kind"] == "step" and i and scenes[i - 1]["kind"] == "step"
        enter = 0.12 if same_card else 0.45
        sel = f"#{sid} .zone > *"
        tw.append(f'tl.fromTo("{sel}", {{opacity: 0, y: {(10 if same_card else 50) * u:.0f}}}, {{opacity: 1, y: 0, duration: {enter}, ease: EIN}}, {T(a + 0.02)});')
        if not same_card:
            tw.append(f'feel("{sel}", {T(a + 0.02)}, 0.5);')
        if z < total - 0.05:
            tw.append(f'tl.to("{sel}", {{opacity: 0, y: -{16 * u:.0f}, duration: 0.14, ease: EOUT}}, {T(z - 0.15)});')
        zone_cls = "zone full" if s["kind"] == "interlude" else "zone"
        parts.append(f'<div id="{sid}" class="clip scene" data-start="{T(a)}" data-duration="{T(z - a)}" data-track-index="4">'
                     f'<div class="{zone_cls}">{body}</div></div>')

    zone_top = round((0.215 if track else 0.17) * H)
    page = f"""<!doctype html>
<!-- AutoCut explainer split (HyperFrames). {len(scenes)} scenes, {total:.1f} s. Open in HyperFrames Studio to fine-tune. -->
<html lang="en"><head><meta charset="UTF-8">
<script src="assets/gsap.min.js"></script>
<style>
{faces}
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
html, body {{ width: {W}px; height: {H}px; overflow: hidden; background: {CANVAS}; }}
body {{ font-family: "{body_font}", "Inter", sans-serif; color: {INK}; -webkit-font-smoothing: antialiased; }}
#root {{ position: absolute; inset: 0; }}
#bg {{ position: absolute; inset: 0; background: {CANVAS}; }}
#spk {{ position: absolute; left: {margin}px; top: {panel_top}px; width: {pw}px; height: {ph}px; overflow: hidden;
  border-radius: {56 * u:.0f}px; background: {dark}; }}
#pop {{ position: absolute; left: {margin}px; top: {panel_top - room}px; width: {pw}px; height: {room + ph}px; overflow: hidden; pointer-events: none;
  clip-path: inset(0 0 {ph - round(220 * u)}px 0); }}
.cam video {{ width: 100%; height: 100%; object-fit: fill; display: block; }}
.cam video.band {{ position: absolute; left: 0; }}
.capw, .scene, .ital, .mark, #trk {{ position: absolute; inset: 0; }}
.cap {{ position: absolute; left: 0; right: 0; top: {cap_y}px; transform-origin: 50% 50%; translate: 0 -50%; text-align: center;
  font-family: "{head_font}", "Inter", sans-serif; font-weight: 800; font-size: {74 * u:.0f}px; letter-spacing: -0.035em; line-height: 1; padding: 0 {60 * u:.0f}px; }}
.mark img {{ position: absolute; left: 50%; top: {round(0.105 * H)}px; translate: -50% 0; height: {64 * u:.0f}px; max-width: {300 * u:.0f}px; object-fit: contain; }}
.zone {{ position: absolute; left: {70 * u:.0f}px; right: {70 * u:.0f}px; top: {zone_top}px; height: {round(0.255 * H)}px; display: flex; align-items: center; justify-content: center; }}
.zone.full {{ top: {round(0.17 * H)}px; height: {round(0.26 * H)}px; }}
.card {{ background: {panel}; border-radius: {26 * u:.0f}px; padding: {34 * u:.0f}px {40 * u:.0f}px; width: {round(W * 0.74)}px;
  box-shadow: 0 {14 * u:.0f}px {40 * u:.0f}px rgba(20, 16, 10, 0.16), 0 0 0 {2 * u:.0f}px rgba(20, 16, 10, 0.05); }}
.hd {{ display: flex; align-items: center; gap: {16 * u:.0f}px; margin-bottom: {22 * u:.0f}px; }}
.av {{ width: {58 * u:.0f}px; height: {58 * u:.0f}px; border-radius: 50%; background: {dark}; color: #fff; display: flex; align-items: center;
  justify-content: center; font-weight: 800; font-size: {22 * u:.0f}px; flex: none; overflow: hidden; font-family: "{SERIF}", serif; }}
.av.img {{ background: #fff; box-shadow: 0 0 0 {2 * u:.0f}px rgba(0,0,0,0.08); }}
.av.img.dk {{ background: {dark}; }}
.mark.chip img {{ background: {dark}; padding: {14 * u:.0f}px {26 * u:.0f}px; border-radius: 999px; height: {84 * u:.0f}px; max-width: {360 * u:.0f}px; }}
.av.img img {{ width: 80%; height: 80%; object-fit: contain; }}
.av.big {{ width: {118 * u:.0f}px; height: {118 * u:.0f}px; font-size: {50 * u:.0f}px; font-weight: 700; }}
.nm {{ font-weight: 700; font-size: {27 * u:.0f}px; line-height: 1.1; }}
.sb {{ font-size: {20 * u:.0f}px; color: #8a847c; margin-top: {3 * u:.0f}px; }}
.prev {{ font-size: {27 * u:.0f}px; color: #a29b92; font-weight: 600; margin-bottom: {10 * u:.0f}px; line-height: 1.2; }}
.tx {{ font-weight: 700; line-height: 1.16; letter-spacing: -0.02em; }}
.bw {{ color: #cdc6bc; }}
.intro .row {{ display: flex; align-items: center; gap: {30 * u:.0f}px; }}
.hi {{ font-family: "{SERIF}", serif; font-style: italic; font-size: {34 * u:.0f}px; }}
.who {{ font-weight: 800; font-size: {58 * u:.0f}px; letter-spacing: -0.02em; line-height: 1.1; min-height: 1.1em; }}
.ver {{ display: flex; align-items: center; gap: {12 * u:.0f}px; margin-top: {28 * u:.0f}px; padding-top: {22 * u:.0f}px;
  border-top: {2 * u:.0f}px solid rgba(0,0,0,0.08); font-size: {30 * u:.0f}px; font-weight: 600; }}
.media {{ position: relative; max-width: {round(W * 0.8)}px; }}
.media img {{ display: block; max-width: {round(W * 0.8)}px; max-height: {round(0.24 * H)}px; border-radius: {22 * u:.0f}px; object-fit: contain;
  box-shadow: 0 {18 * u:.0f}px {50 * u:.0f}px rgba(20, 16, 10, 0.2); background: #fff; }}
.stk {{ position: absolute; right: -{36 * u:.0f}px; bottom: -{44 * u:.0f}px; background: {panel}; border-radius: {20 * u:.0f}px; padding: {14 * u:.0f}px {28 * u:.0f}px;
  box-shadow: 0 {12 * u:.0f}px {30 * u:.0f}px rgba(20, 16, 10, 0.25); text-align: center; rotate: -4deg; }}
.sl {{ font-size: {19 * u:.0f}px; letter-spacing: 0.12em; color: #7c766e; font-weight: 600; }}
.sv {{ font-family: "{SERIF}", serif; font-weight: 800; font-size: {66 * u:.0f}px; line-height: 1.05; font-variant-numeric: tabular-nums; }}
.icard {{ position: relative; background: {panel}; border-radius: {22 * u:.0f}px; padding: {34 * u:.0f}px {64 * u:.0f}px;
  box-shadow: 0 {16 * u:.0f}px {44 * u:.0f}px rgba(20, 16, 10, 0.18); }}
.big {{ position: relative; font-family: "{SERIF}", serif; font-weight: 800; font-size: {124 * u:.0f}px; line-height: 1.05; white-space: nowrap; font-variant-numeric: tabular-nums; }}
.strk {{ position: absolute; left: -2%; right: -2%; top: 52%; height: {7 * u:.0f}px; background: {STRIKE}; transform-origin: 0 50%; transform: scaleX(0); border-radius: 9px; }}
.badge {{ position: absolute; right: -{30 * u:.0f}px; bottom: -{38 * u:.0f}px; background: {acc}; color: {hyper.on(acc)}; font-weight: 900;
  font-size: {54 * u:.0f}px; padding: {8 * u:.0f}px {26 * u:.0f}px; border-radius: {14 * u:.0f}px; letter-spacing: 0.01em;
  box-shadow: 0 {10 * u:.0f}px {26 * u:.0f}px rgba(0,0,0,0.22); }}
.it {{ position: absolute; left: 0; right: 0; top: {round(0.64 * H)}px; text-align: center; font-family: "{SERIF}", serif; font-style: italic;
  font-weight: 800; font-size: {104 * u:.0f}px; letter-spacing: -0.01em; line-height: 1; padding: 0 {50 * u:.0f}px; }}
.track {{ position: absolute; left: 50%; top: {round(0.115 * H)}px; translate: -50% 0; }}
.dots {{ display: flex; align-items: center; }}
.dot {{ width: {52 * u:.0f}px; height: {52 * u:.0f}px; border-radius: 50%; border: {2.5 * u:.1f}px solid #cfc9c1; background: #fff; color: #9a948c;
  position: relative; display: flex; align-items: center; justify-content: center; font-size: {22 * u:.0f}px; font-weight: 700; flex: none; }}
.dot .ck {{ position: absolute; color: #fff; opacity: 0; font-size: {20 * u:.0f}px; }}
.ln {{ width: calc(var(--pitch) - {52 * u:.0f}px); height: {3 * u:.0f}px; background: #ddd8d1; position: relative; }}
.ln i {{ position: absolute; inset: 0; background: {INK}; transform-origin: 0 50%; transform: scaleX(0); }}
.labs {{ position: relative; height: {44 * u:.0f}px; margin-top: {10 * u:.0f}px; }}
.tlab {{ position: absolute; top: 0; translate: calc(-50% + {26 * u:.0f}px) 0; white-space: nowrap; font-family: "{SERIF}", serif; font-style: italic;
  font-size: {32 * u:.0f}px; color: #3a3631; opacity: 0; }}
{feel_mod.css(acc, u)}
</style></head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{total}" data-width="{W}" data-height="{H}">
  <div id="bg"></div>
  {spk}
  {''.join(parts)}
</div>
<script>
  window.__timelines = window.__timelines || {{}};
  const tl = gsap.timeline({{ paused: true }});
  {feel_mod.js(feel)}
  {chr(10).join("  " + t for t in tw)}
  window.__timelines["main"] = tl;
</script>
</body></html>"""
    (project / "index.html").write_text(page, encoding="utf-8")
    (project / "events.json").write_text(json.dumps(sorted(events, key=lambda e: e["t"])))
    return total


def _count(el: str, val: float, dec: int, t: float, d: float) -> str:
    return (f'(() => {{ const o = {{v: 0}}, el = document.getElementById("{el}"); '
            f'tl.fromTo(o, {{v: 0}}, {{v: {val}, duration: {d}, ease: "expo.out", onUpdate: () => {{ el.textContent = '
            f'o.v.toLocaleString("en-US", {{minimumFractionDigits: {dec}, maximumFractionDigits: {dec}}}); }}}}, {t:.3f}); }})();')


def make_video(source: Path, client: Client, size: tuple[int, int], out: Path, settings: dict,
               graphics: list[Path] | None = None, fps: float = 30, use_ai: bool = True, pop_out: bool = True,
               transcript: Path | None = None) -> Path:
    """Raw take → rough cut → plan → HyperFrames project → MP4 with the voice."""
    from ..transcribe import load_or_transcribe
    from .customize import VIDEO_EXT
    from .script import finish
    if source.suffix.lower() not in VIDEO_EXT:
        raise ValueError("The explainer style needs the video of the speaker (MP4 or MOV)")
    work = out.with_name("_work-" + out.stem)
    work.mkdir(parents=True, exist_ok=True)
    words = load_or_transcribe(source, work, settings, transcript, client.brand.get("vocabulary") or [])["words"]
    if not words:
        raise ValueError("No speech found in the video")
    video, cut_words, length = cut_take(source, words, client.brand, work)
    scenes = plan(cut_words, graphics or [], client.brand, settings if use_ai else None)
    (work / "plan.json").write_text(json.dumps([{**{k: v for k, v in s.items() if k not in ("words", "image")},
                                                 "image": str(s.get("image") or ""), "text": _text(s)} for s in scenes], indent=1))
    from ..media import probe
    seg = _segmenter()
    frame = framing(video, seg)
    info = probe(video)
    g = geometry(size, (info.width, info.height), frame)
    pop = None
    if pop_out and seg is not None:
        try:
            pop = render_popout(video, seg, work / "cutout.webm", (g["y0"], g["y1"]))
        except Exception:  # noqa: BLE001 - no pop-out, the panel still works
            pop = None
    project = out.with_name("hf-" + out.stem)
    build(cut_words, scenes, client, size, project, settings, video, length, frame, pop, band=(g["y0"], g["y1"]))
    (project / "voice.txt").write_text(str((project / "assets" / "take.mp4").resolve()), encoding="utf-8")
    return finish(project, out, settings, fps)
