"""Transcript → motion graphics video (Katana-style): kinetic typography and motion graphics that follow the words.

In:  a transcript (plain text/script, SRT, VTT, or AutoCut's transcript.json) or an audio/video file (transcribed
     on this computer). Timed sources keep their real timing, so the voice lines up; plain text is paced like
     speech (about 2.7 words a second, longer at commas and full stops).
Plan: the words are grouped into beats (short phrases). Each beat gets a treatment:
      kinetic  words land one by one as they're said, the key word highlighted (the default; three layouts rotate)
      stat     a number/price/percentage counts up big, the rest as its label
      slam     a short punchy line hits big (an exclamation, or a 1-3 word beat)
      list     "first / second / step 3…" gets a numbered badge
      image    one of your graphics, when its name is said (unused ones fill quiet beats so all of them appear)
      end      the logo and the call to action
      The AI (when one is running) picks each beat's key word and treatment; rules do it otherwise.
Out: one HyperFrames composition (editable in Studio) rendered to MP4, with the voice muxed in when there is audio.
"""
from __future__ import annotations

import html
import json
import re
import shutil
import subprocess
from pathlib import Path

from ..config import Client
from . import hyper

FILLERS = {"um", "umm", "uh", "uhh", "uhm", "er", "erm", "ah", "hmm", "mm"}
STOP = set("a an and are as at be but by for from has have i in is it its of on or so that the their there this to was "
           "we were what when with you your our my me they them he she his her not do does did just like".split())
NUM = re.compile(r"^[$€£]?\d[\d,.]*(%|k|m|x)?$|^\d+(st|nd|rd|th)$", re.I)
ORDINAL = re.compile(r"^(first|second|third|fourth|fifth|finally|step|number|#\d)\b|^(one|two|three|four|five)[,:.]", re.I)


# ---- reading transcripts ------------------------------------------------------------------------------------------

def _ts(t: str) -> float:
    t = t.strip().replace(",", ".")
    parts = [float(x) for x in t.split(":")]
    while len(parts) < 3:
        parts.insert(0, 0.0)
    return parts[0] * 3600 + parts[1] * 60 + parts[2]


def _spread(text: str, a: float, b: float) -> list[dict]:
    """Words of a timed cue, spread over its time by length (longer words take longer)."""
    ws = text.split()
    if not ws:
        return []
    weights = [max(2, len(w)) for w in ws]
    total, t, out = sum(weights), a, []
    for w, k in zip(ws, weights):
        d = (b - a) * k / total
        out.append({"word": w, "start": round(t, 3), "end": round(t + d * 0.92, 3)})
        t += d
    return out


def pace(text: str, start: float = 0.4, wps: float = 2.7) -> list[dict]:
    """Plain text → words with speech-like timing."""
    out, t = [], start
    for w in text.split():
        d = max(0.18, (0.25 + 0.035 * len(w)) * 2.7 / wps)
        out.append({"word": w, "start": round(t, 3), "end": round(t + d, 3)})
        t += d + (0.55 if re.search(r"[.!?]$", w) else 0.28 if re.search(r"[,;:—–-]$", w) else 0.04)
    return out


def read_transcript(path: Path) -> tuple[list[dict], bool]:
    """(words, timed). Accepts AutoCut transcript.json, SRT, VTT or plain text."""
    text = path.read_text(encoding="utf-8", errors="replace").lstrip("﻿")
    ext = path.suffix.lower()
    if ext == ".json":
        data = json.loads(text)
        words = data.get("words") if isinstance(data, dict) else data
        return [{"word": str(w["word"]), "start": float(w["start"]), "end": float(w["end"])} for w in words], True
    cue = re.compile(r"(\d[\d:.,]*)\s*-->\s*(\d[\d:.,]*)[^\n]*\n(.*?)(?:\n\s*\n|\Z)", re.S)
    if "-->" in text:
        words = []
        for a, b, body in cue.findall(text):
            body = re.sub(r"<[^>]+>|\{[^}]+\}", "", body)  # tags in VTT/SRT
            words += _spread(" ".join(body.split()), _ts(a), _ts(b))
        return words, True
    text = re.sub(r"^\s*#.*$", "", text, flags=re.M)  # markdown headings
    return pace(" ".join(text.split())), False


# ---- planning beats -----------------------------------------------------------------------------------------------

def clean(w: str) -> str:
    return re.sub(r"[^\w$%'.,-]", "", w).strip(".,")


def beats(words: list[dict], max_words: int = 6) -> list[dict]:
    """Group words into beats: one sentence (or a pause) each, long sentences split at commas or into even parts,
    never leaving a lone word behind."""
    words = [w for w in words if clean(w["word"]).lower() not in FILLERS and clean(w["word"])]
    sents, cur = [], []
    for i, w in enumerate(words):
        cur.append(w)
        nxt = words[i + 1] if i + 1 < len(words) else None
        if re.search(r"[.!?]$", w["word"]) or not nxt or nxt["start"] - w["end"] > 0.6:
            sents.append(cur)
            cur = []
    out = []
    for sent in sents:
        has_num = any(NUM.match(clean(w["word"])) for w in sent)
        if len(sent) <= max_words + 1 or (has_num and len(sent) <= max_words + 3):  # keep a stat with its words
            out.append(sent)
            continue
        pieces, cur = [], []
        for j, w in enumerate(sent):
            cur.append(w)
            if re.search(r"[,;:]$", w["word"]) and len(cur) >= 3 and len(sent) - j - 1 >= 2:
                pieces.append(cur)
                cur = []
        if cur:
            pieces.append(cur)
        for p in pieces:
            n = -(-len(p) // max_words)  # even parts of at most max_words
            k = -(-len(p) // n)
            out += [p[x:x + k] for x in range(0, len(p), k)]
    return [{"words": b} for b in out if b]


def _keyword(ws: list[str]) -> int:
    """The word to highlight: a number first, else the longest meaningful word near the end."""
    for i, w in enumerate(ws):
        if NUM.match(clean(w)):
            return i
    scored = [(len(clean(w)) + 0.4 * i, i) for i, w in enumerate(ws) if clean(w).lower() not in STOP]
    return max(scored)[1] if scored else len(ws) - 1


def plan(words: list[dict], graphics: list[Path], settings: dict | None = None, brand: dict | None = None) -> list[dict]:
    bs = beats(words)
    names = {g: {t for t in re.split(r"[^a-z0-9]+", g.stem.lower()) if len(t) > 2} for g in graphics}
    used: set[Path] = set()
    list_n = 0
    for n, b in enumerate(bs):
        ws = [w["word"] for w in b["words"]]
        low = [clean(w).lower() for w in ws]
        b["key"] = _keyword(ws)
        nums = [i for i, w in enumerate(ws) if NUM.match(clean(w)) and not re.match(r"^\d+(st|nd|rd|th)$", clean(w))]
        hit = next((g for g in graphics if g not in used and names[g] & set(low)), None)
        if hit:
            b["treat"], b["image"] = "image", hit
            used.add(hit)
        elif nums and len(ws) <= 9:
            b["treat"], b["num"] = "stat", nums[0]
        elif ws and ORDINAL.match(ws[0].lower()):
            list_n += 1
            b["treat"], b["n"] = "list", list_n
        elif len(ws) <= 3 and ws[-1].endswith("!"):
            b["treat"] = "slam"
        elif len(ws) <= 2 and not (n and bs[n - 1].get("treat") == "slam") and \
                not (n + 1 < len(bs) and bs[n + 1]["words"][-1]["word"].endswith("!") and len(bs[n + 1]["words"]) <= 3):
            b["treat"] = "slam"  # a punch, but never two in a row
        else:
            b["treat"] = "kinetic"
        b["layout"] = n % 3
    # graphics nobody named still appear: on kinetic beats spread through the video
    spare = [g for g in graphics if g not in used]
    kinetic = [b for b in bs if b["treat"] == "kinetic"]
    for k, g in enumerate(spare):
        if not kinetic:
            break
        b = kinetic[min(len(kinetic) - 1, int((k + 0.5) * len(kinetic) / len(spare)))]
        if b["treat"] == "kinetic":
            b["treat"], b["image"] = "image", g
    if settings is not None:
        _ai_plan(bs, settings, brand)
    return bs


AI_SCHEMA = {"type": "object", "properties": {"beats": {"type": "array", "items": {"type": "object", "properties": {
    "i": {"type": "integer"}, "keyword": {"type": "string"}, "treatment": {"type": "string"}}}}}, "required": ["beats"]}


def _ai_plan(bs: list[dict], settings: dict, brand: dict | None) -> None:
    """The AI picks the word to highlight and, where it helps, a stronger treatment (slam/kinetic). Rules stay as
    they are when no AI answers."""
    from .. import brain, marketing
    listing = "\n".join(f"{i}: {' '.join(w['word'] for w in b['words'])}" for i, b in enumerate(bs[:120]))
    out = brain.ask(settings, marketing.system_prompt(brand, "motion"),
                    "These are the beats of a kinetic typography video, in order. For each, give the single most "
                    "important word to highlight (copied exactly from the beat) and a treatment: 'slam' for a short "
                    "punchline that should hit hard (use sparingly, at most one in five), else 'kinetic'.\n\n" + listing,
                    AI_SCHEMA, timeout=120)
    if not isinstance(out, dict):
        return
    for r in out.get("beats") or []:
        i = r.get("i")
        if not isinstance(i, int) or not 0 <= i < len(bs):
            continue
        b = bs[i]
        ws = [clean(w["word"]).lower() for w in b["words"]]
        kw = clean(str(r.get("keyword", ""))).lower()
        if kw in ws:
            b["key"] = ws.index(kw)
        if r.get("treatment") == "slam" and b["treat"] == "kinetic" and len(ws) <= 4:
            b["treat"] = "slam"
        b["ai"] = True


# ---- the composition ------------------------------------------------------------------------------------------------

def _num_value(token: str) -> tuple[str, float, str, int] | None:
    m = re.match(r"^([$€£]?)(\d[\d,]*)(\.\d+)?(%|k|m|x)?$", clean(token), re.I)
    if not m:
        return None
    dec = len(m.group(3)) - 1 if m.group(3) else 0
    return m.group(1), float(m.group(2).replace(",", "") + (m.group(3) or "")), m.group(4) or "", dec


def build(words: list[dict], bs: list[dict], client: Client, size: tuple[int, int], project: Path, settings: dict,
          cta: str = "", end_seconds: float = 3.2, feel: str | None = None) -> float:
    """Write the HyperFrames project. Returns the video length in seconds."""
    from . import feel as feel_mod
    from .library import dna as dna_mod, looks as looks_mod
    d_ = dna_mod.load(client) if client.folder and (client.folder / "brand.yaml").exists() else None
    feel = feel if feel in feel_mod.FEELS else (d_ or {}).get("feel") if (d_ or {}).get("feel") in feel_mod.FEELS else \
        feel_mod.pick(looks_mod.get((d_ or {}).get("look")) if d_ else {"key": ""})
    W, H = size
    vertical = H > W
    u = min(W, H) / 1080
    tscale = 1.3 if vertical else 1.0
    if project.exists():
        shutil.rmtree(project)
    (project / "assets").mkdir(parents=True)
    gsap = hyper.runtime_dir(settings) / "node_modules" / "gsap" / "dist" / "gsap.min.js"
    if gsap.exists():
        shutil.copy2(gsap, project / "assets" / "gsap.min.js")
    faces, head_font, body_font = hyper._fonts(client, project)
    c = client.brand["colors"]
    primary, secondary = c["primary"], c["secondary"]
    ground = secondary if hyper._luma(secondary) < 120 else "#101318"
    ink = "#ffffff"
    logo_html, logo_src = "", None
    lf = client.brand["logo"].get("file")
    if lf and client.path(lf) and client.path(lf).is_file():
        src = client.path(lf)
        logo_src = f"assets/logo{src.suffix.lower()}"
        shutil.copy2(src, project / logo_src)
    # timing: each beat shows from just before its first word until the next beat starts
    starts = [max(0.0, b["words"][0]["start"] - 0.12) for b in bs]
    last_word_end = bs[-1]["words"][-1]["end"] if bs else 1.0
    end_start = round(last_word_end + 0.5, 3)
    total = round(end_start + end_seconds, 3)
    parts, tw = [], []
    for i, b in enumerate(bs):
        a = starts[i]
        z = min(starts[i + 1] if i + 1 < len(bs) else end_start, b["words"][-1]["end"] + 2.2)
        d = round(max(0.4, z - a), 3)
        b["a"], b["d"] = round(a, 3), d
        ws = b["words"]
        n_chars = sum(len(w["word"]) for w in ws)
        longest = max(len(w["word"]) for w in ws)
        fit = (W / u - 180) / (0.62 * longest)  # the longest word must fit across the frame
        fs = min(max(58, min(150, 168 - 2.4 * n_chars)) * tscale, fit)
        sid = f"b{i}"
        spans = []
        for j, w in enumerate(ws):
            word = html.escape(w["word"])
            if j == b.get("key") and b["treat"] in ("kinetic", "image", "list", "slam"):
                spans.append(f'<span class="w k" id="{sid}w{j}"><span class="hl" id="{sid}h"></span><i>{word}</i></span>')
            else:
                spans.append(f'<span class="w" id="{sid}w{j}">{word}</span>')
        t0 = ws[0]["start"]
        if b["treat"] == "stat" and _num_value(ws[b["num"]]["word"]):
            pre, val, suf, dec = _num_value(ws[b["num"]]["word"])
            label = " ".join(s for j, s in enumerate(spans) if j != b["num"])
            inner = (f'<div class="num" style="font-size:{min(300, 1500 / max(4, len(pre + suf) + len(str(int(val))) + 1)) * u * tscale:.0f}px">'
                     f'<span class="acc">{html.escape(pre)}</span><span id="{sid}n">0</span><span class="acc">{html.escape(suf)}</span></div>'
                     f'<div class="lab" style="font-size:{min(64, fs * 0.45) * u:.0f}px">{label}</div>')
            nt = ws[b["num"]]["start"]
            tw.append(f'tl.fromTo("#{sid} .num", {{opacity: 0, scale: 0.7}}, {{opacity: 1, scale: 1, duration: 0.45, ease: "back.out(1.5)"}}, {max(a + 0.02, nt - 0.2):.3f});')
            tw.append(f'feel("#{sid} .num", {max(a + 0.02, nt - 0.2):.3f}, 0.5);')
            tw.append(f'(() => {{ const o = {{v: 0}}, el = document.getElementById("{sid}n"); '
                      f'tl.fromTo(o, {{v: 0}}, {{v: {val}, duration: 0.9, ease: "expo.out", onUpdate: () => {{ el.textContent = o.v.toLocaleString("en-US", {{minimumFractionDigits: {dec}, maximumFractionDigits: {dec}}}); }}}}, {nt:.3f}); }})();')
            for j, w in enumerate(ws):
                if j != b["num"]:
                    tw.append(f'tl.fromTo("#{sid}w{j}", {{opacity: 0, y: 20}}, {{opacity: 1, y: 0, duration: 0.3, ease: EIN}}, {w["start"]:.3f});')
        elif b["treat"] == "slam":
            inner = f'<div class="ring"></div><div class="slam" style="font-size:{min(230, fs * 1.45, fit * 0.92) * u:.0f}px">{" ".join(spans)}</div>'
            tw.append(f'tl.fromTo("#{sid} .slam", {{scale: 1.9, opacity: 0, filter: "blur(14px)"}}, {{scale: 1, opacity: 1, filter: "blur(0px)", duration: 0.24, ease: "power4.in"}}, {t0 - 0.05:.3f});')
            tw.append(f'tl.fromTo("#{sid} .ring", {{scale: 0.3, opacity: 0.9}}, {{scale: 1.7, opacity: 0, duration: 0.6, ease: EIN}}, {t0 + 0.2:.3f});')
            tw.append(f'feel("#{sid} .slam", {t0 + 0.15:.3f}, 0.4, 0.5);')
        else:
            lay = ["center", "left", "boxed"][b["layout"]] if b["treat"] == "kinetic" else "center"
            top = ""
            if b["treat"] == "list":
                top = f'<div class="badge">{b["n"]}</div>'
                tw.append(f'tl.fromTo("#{sid} .badge", {{scale: 0, rotation: -20}}, {{scale: 1, rotation: 0, duration: 0.45, ease: "back.out(1.8)"}}, {a + 0.02:.3f});')
                tw.append(f'feel("#{sid} .badge", {a + 0.02:.3f}, 0.45, 0.5);')
            if b["treat"] == "image":
                dest = project / "assets" / f"g{i}{b['image'].suffix.lower()}"
                shutil.copy2(b["image"], dest)
                top = f'<div class="pic"><img src="assets/{dest.name}" alt=""></div>'
                tw.append(f'tl.fromTo("#{sid} .pic", {{opacity: 0, y: 40}}, {{opacity: 1, y: 0, duration: 0.55, ease: EIN}}, {a + 0.02:.3f});')
                tw.append(f'feel("#{sid} .pic", {a + 0.02:.3f}, 0.6);')
                fs *= 0.72
            inner = f'{top}<div class="line {lay}" style="font-size:{fs * u:.0f}px">{" ".join(spans)}</div>'
            for j, w in enumerate(ws):
                tw.append(f'tl.fromTo("#{sid}w{j}", {{opacity: 0, y: "0.3em", filter: "blur(8px)"}}, {{opacity: 1, y: 0, filter: "blur(0px)", duration: 0.28, ease: EIN, clearProps: "filter"}}, {w["start"] - 0.04:.3f});')
        if b.get("key") is not None and b["treat"] in ("kinetic", "image", "list", "slam"):
            kt = ws[b["key"]]["start"] + 0.12
            tw.append(f'tl.fromTo("#{sid}h", {{scaleX: 0, transformOrigin: "0% 50%"}}, {{scaleX: 1, duration: 0.32, ease: EIN}}, {kt:.3f});')
            if b["treat"] != "slam":
                tw.append(f'feel("#{sid}w{b["key"]}", {kt - 0.1:.3f}, 0.35);')  # the key word lands with the full feel
        if a + d < total - 0.01:  # leave cleanly just before the next beat
            tw.append(f'tl.to("#{sid} .st > *", {{opacity: 0, filter: "blur(8px)", duration: 0.16, ease: EOUT}}, {a + d - 0.18:.3f});')
        parts.append(f'<div id="{sid}" class="clip beat" data-start="{a:.3f}" data-duration="{d:.3f}" data-track-index="2">'
                     f'<div class="st">{inner}</div></div>')
    # end card
    end_html = (f'<div id="endc" class="clip beat" data-start="{end_start:.3f}" data-duration="{end_seconds:.3f}" data-track-index="2">'
                f'<div class="st end">' + (f'<img class="elogo" src="{logo_src}" alt="">' if logo_src else
                                           f'<div class="ename">{html.escape(client.brand.get("client", "") if client.brand.get("client") != "Custom" else "")}</div>')
                + (f'<div class="ecta">{html.escape(cta)}</div>' if cta else "") + "</div></div>")
    tw.append(f'tl.fromTo("#endc .st > *", {{opacity: 0, y: 30}}, {{opacity: 1, y: 0, duration: 0.6, ease: EIN, stagger: 0.15}}, {end_start + 0.05:.3f});')
    tw.append(f'feel("#endc .st > *", {end_start + 0.05:.3f}, 0.7);')
    if logo_src:
        logo_html = f'<img id="wm" class="clip" src="{logo_src}" data-start="0" data-duration="{end_start:.3f}" data-track-index="3" alt="">'
    page = f"""<!doctype html>
<!-- AutoCut transcript video (HyperFrames). {len(bs)} beats, {total:.1f} s. Open in HyperFrames Studio to fine-tune. -->
<html lang="en"><head><meta charset="UTF-8">
<script src="assets/gsap.min.js"></script>
<style>
{faces}
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
html, body {{ width: {W}px; height: {H}px; overflow: hidden; background: {ground}; }}
body {{ font-family: "{head_font}", "Montserrat", sans-serif; color: {ink}; -webkit-font-smoothing: antialiased; }}
#root {{ position: absolute; inset: 0; }}
#bg {{ position: absolute; inset: 0; background: radial-gradient(110% 80% at 50% 30%, {hyper._mix(ground, primary, 0.22)} 0%, {ground} 70%); }}
.blob {{ position: absolute; border-radius: 50%; filter: blur({90 * u:.0f}px); opacity: 0.35; }}
#bl1 {{ width: {700 * u:.0f}px; height: {700 * u:.0f}px; left: -15%; top: -10%; background: {primary}; }}
#bl2 {{ width: {600 * u:.0f}px; height: {600 * u:.0f}px; right: -18%; bottom: -12%; background: {hyper._mix(primary, '#ffffff', 0.35)}; opacity: 0.18; }}
.beat {{ position: absolute; inset: 0; }}
.st {{ position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center;
  padding: {(170 if vertical else 90) * u:.0f}px {90 * u:.0f}px {(330 if vertical else 90) * u:.0f}px; gap: {30 * u:.0f}px; text-align: center; }}
.line {{ font-weight: 900; line-height: 1.04; letter-spacing: -0.02em; text-wrap: balance; max-width: 100%;
  text-shadow: 0 {6 * u:.0f}px {30 * u:.0f}px rgba(0,0,0,0.35); }}
.line.left {{ align-self: stretch; text-align: left; text-transform: uppercase; }}
.line.boxed {{ text-transform: uppercase; letter-spacing: 0; }}
.line.boxed .w {{ background: {ink}; color: {ground}; padding: 0 0.12em; margin: 0.04em 0; box-decoration-break: clone; }}
.w {{ display: inline-block; position: relative; }}
.w.k {{ color: {hyper.on(primary)}; margin: 0 0.1em; }}
.w.k i {{ font-style: normal; position: relative; z-index: 1; }}
.hl {{ position: absolute; left: -0.1em; right: -0.1em; top: 0.08em; bottom: 0.02em; background: {primary}; border-radius: 0.08em; z-index: 0; }}
.line.boxed .w.k {{ background: {primary}; }}
.slam {{ position: relative; z-index: 1; font-weight: 900; text-transform: uppercase; line-height: 0.95; letter-spacing: -0.03em; color: {primary};
  -webkit-text-stroke: {4 * u:.0f}px {ground}; paint-order: stroke fill; }}
.slam .w.k {{ color: {ink}; }} .slam .hl {{ display: none; }}
.ring {{ position: absolute; width: {560 * u:.0f}px; height: {560 * u:.0f}px; border-radius: 50%; border: {12 * u:.0f}px solid {primary}; }}
.num {{ font-weight: 900; line-height: 1; letter-spacing: -0.04em; white-space: nowrap; font-variant-numeric: tabular-nums; }}
.num .acc {{ color: {primary}; }}
.lab {{ font-weight: 700; line-height: 1.15; max-width: 90%; font-family: "{body_font}", "Montserrat", sans-serif; }}
.badge {{ width: {150 * u:.0f}px; height: {150 * u:.0f}px; border-radius: 50%; background: {primary}; color: {hyper.on(primary)};
  display: flex; align-items: center; justify-content: center; font-weight: 900; font-size: {84 * u:.0f}px; }}
.pic {{ max-width: 82%; max-height: 46%; display: flex; }}
.pic img {{ max-width: 100%; max-height: {(820 if vertical else 520) * u:.0f}px; object-fit: contain; border-radius: {28 * u:.0f}px;
  box-shadow: 0 {30 * u:.0f}px {70 * u:.0f}px rgba(0,0,0,0.45); }}
.end .elogo {{ max-width: 60%; max-height: {260 * u:.0f}px; object-fit: contain; }}
.end .ename {{ font-weight: 900; font-size: {110 * u * tscale:.0f}px; letter-spacing: -0.02em; }}
.end .ecta {{ padding: {22 * u:.0f}px {48 * u:.0f}px; border-radius: 999px; background: {primary}; color: {hyper.on(primary)};
  font-weight: 800; font-size: {44 * u * tscale:.0f}px; font-family: "{body_font}", "Montserrat", sans-serif; }}
{feel_mod.css(primary, u)}
#wm {{ position: absolute; right: {50 * u:.0f}px; top: {(130 if vertical else 44) * u:.0f}px; height: {70 * u:.0f}px; max-width: {260 * u:.0f}px; object-fit: contain; opacity: 0.85; }}
</style></head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{total}" data-width="{W}" data-height="{H}">
  <div id="bgc" class="clip" data-start="0" data-duration="{total}" data-track-index="0" data-layout-allow-overflow>
    <div id="bg"></div><div id="bl1" class="blob"></div><div id="bl2" class="blob"></div></div>
  {''.join(parts)}
  {end_html}
  {logo_html}
</div>
<script>
  window.__timelines = window.__timelines || {{}};
  const tl = gsap.timeline({{ paused: true }});
  {feel_mod.js(feel)}
  tl.fromTo("#bl1", {{x: 0, y: 0}}, {{x: {260 * u:.0f}, y: {180 * u:.0f}, duration: {total}, ease: "none"}}, 0);
  tl.fromTo("#bl2", {{x: 0, y: 0}}, {{x: -{220 * u:.0f}, y: -{160 * u:.0f}, duration: {total}, ease: "none"}}, 0);
  {chr(10).join("  " + t for t in tw)}
  window.__timelines["main"] = tl;
</script>
</body></html>"""
    (project / "index.html").write_text(page, encoding="utf-8")
    events = []  # for the sound designer
    for b in bs:
        t = b["words"][0]["start"]
        kind = {"slam": "slam", "stat": "number", "list": "sticker", "image": "graphic"}.get(b["treat"])
        if kind:
            events.append({"t": t if kind != "number" else b["words"][b.get("num", 0)]["start"], "kind": kind})
    events += [{"t": end_start, "kind": "end"}, {"t": end_start + 0.4, "kind": "logo"}]
    (project / "events.json").write_text(json.dumps(events))
    return total


def make_video(source: Path, client: Client, size: tuple[int, int], out: Path, settings: dict,
               graphics: list[Path] | None = None, audio: Path | None = None, cta: str = "", fps: float = 30,
               use_ai: bool = True) -> Path:
    """The whole thing: read or transcribe → plan → build → render MP4 → mux the voice."""
    from ..transcribe import load_or_transcribe
    from .customize import AUDIO_EXT, VIDEO_EXT
    work = out.with_name("_work-" + out.stem)
    work.mkdir(parents=True, exist_ok=True)
    if source.suffix.lower() in AUDIO_EXT | VIDEO_EXT:
        words = load_or_transcribe(source, work, settings, None, client.brand.get("vocabulary") or [])["words"]
        audio = audio or source
    else:
        words, timed = read_transcript(source)
        if not timed:
            audio = None  # paced text has no voice to line up with
    if not words:
        raise ValueError("The transcript has no words")
    bs = plan(words, graphics or [], settings if use_ai else None, client.brand)
    (work / "plan.json").write_text(json.dumps([{**{k: v for k, v in b.items() if k != "image"},
                                                 "image": str(b.get("image") or ""),
                                                 "text": " ".join(w["word"] for w in b["words"])} for b in bs], indent=1,
                                               default=str))
    project = out.with_name("hf-" + out.stem)
    cta = cta or (client.brand.get("cta") or {}).get("text") or ""
    build(words, bs, client, size, project, settings, cta=cta)
    if audio:
        (project / "voice.txt").write_text(str(Path(audio).resolve()), encoding="utf-8")  # for re-renders
    return finish(project, out, settings, fps, audio)


def finish(project: Path, out: Path, settings: dict, fps: float = 30, audio: Path | None = None) -> Path:
    """Render the project to MP4 and lay the voice under it (also used to re-render after Studio edits)."""
    if audio is None and (project / "voice.txt").exists():
        audio = Path((project / "voice.txt").read_text(encoding="utf-8").strip())
    silent = out.with_name("_silent-" + out.name)
    hyper.render_project(project, silent, settings, "mp4", fps=fps)
    if audio and Path(audio).exists():
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(silent), "-i", str(audio), "-map", "0:v", "-map", "1:a:0",
                        "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", str(out)], check=True)
        silent.unlink()
    else:
        silent.replace(out)
    return out
