"""Building and rendering library graphics: one element (an overlay, or full-frame), a storyboard, or a look sheet."""
from __future__ import annotations

import math
import shutil
from pathlib import Path

from ...config import Client
from .. import hyper
from . import looks
from .compose import Ctx, page, roles
from .elements import DURATION, LAYOUTS

FULL_KINDS = {"end_card", "transition", "media"}  # these fill the frame on their own


def _fonts(c_client: Client, look: dict, project: Path, brand_fonts: bool) -> tuple[str, str, str, str]:
    """(@font-face CSS, headline, body, numbers). The client's own font files win when they have them."""
    faces, head, body = hyper._fonts(c_client, project)
    if c_client.brand["fonts"].get("force"):  # "Match my media": the fonts that fit their media
        return faces, head, body, head
    if brand_fonts and faces:
        return faces, head, body, head
    return faces, look["head"][0], look["body"][0], look["num"][0]


def add_media(c: Ctx, project: Path, media: list[dict] | None) -> None:
    """Copy the media into the project as media1, media2 … (videos made playable) for the media layouts."""
    from ..media_read import prepare_video
    lib = {}
    for k, m in enumerate(media or [], 1):
        src = Path(m["path"])
        if not src.exists():
            continue
        if m.get("kind") == "video":
            dest = project / "assets" / f"media{k}.mp4"
            prepare_video(src, dest)
        else:
            dest = project / "assets" / f"media{k}{src.suffix.lower()}"
            shutil.copy2(src, dest)
        whole = m.get("kind") != "video" and (m.get("role") in ("product", "illustration", "logo")
                                               or (m.get("transparent") or 0) > 0.15)
        lib[f"media{k}"] = {"src": f"assets/{dest.name}", "kind": m.get("kind", "image"), "w": m.get("w") or 1600,
                            "h": m.get("h") or 900, "subject": m.get("subject", ""), "caption": m.get("caption", ""),
                            "fit": "contain" if whole else "cover"}
    c.assets["media"] = lib


def context(client: Client, look_key: str, size: tuple[int, int], project: Path, full: bool, y: float = 0.5,
            brand_fonts: bool = True, gsap: Path | None = None, feel: str | None = None,
            media: list[dict] | None = None) -> tuple[Ctx, str]:
    look = looks.get(look_key)
    W, H = size
    if project.exists():
        shutil.rmtree(project)
    (project / "assets").mkdir(parents=True)
    if gsap and gsap.exists():
        shutil.copy2(gsap, project / "assets" / "gsap.min.js")
    faces, head, body, num = _fonts(client, look, project, brand_fonts)
    c = Ctx(W=W, H=H, look=look, roles=roles(look, client.brand["colors"], overlay=not full), full=full, y=y,
            head=head, body=body, num=num, feel=feel)
    lf = client.brand.get("logo", {}).get("file")
    src = client.path(lf) if lf else None
    if src and src.is_file():
        shutil.copy2(src, project / "assets" / f"logo{src.suffix.lower()}")
        c.assets["logo"] = f"assets/logo{src.suffix.lower()}"
    add_media(c, project, media)
    return c, faces


def default_y(kind: str, vertical: bool) -> float:
    return {"lower_third": 0.62 if vertical else 0.80, "title": 0.32 if vertical else 0.3, "callout": 0.5, "media": 0.5,
            "chart": 0.48, "list": 0.48, "quote": 0.5, "end_card": 0.5}.get(kind, 0.5)


def build_element(kind: str, layout: str, look_key: str, client: Client, size: tuple[int, int], project: Path,
                  params: dict, full: bool | None = None, y: float | None = None, dur: float | None = None,
                  background: str | None = None, brand_fonts: bool = True, gsap: Path | None = None,
                  feel: str | None = None, media: list[dict] | None = None) -> float:
    """One element as its own composition. Overlays are transparent unless background is given. Returns seconds."""
    fn = LAYOUTS[kind].get(layout) or next(iter(LAYOUTS[kind].values()))
    full = kind in FULL_KINDS and kind != "transition" if full is None else full
    vertical = size[1] > size[0]
    c, faces = context(client, look_key, size, project, full, default_y(kind, vertical) if y is None else y, brand_fonts, gsap,
                       feel, media)
    d = float(dur or DURATION[kind])
    part = fn(c, dict(params), "e", 0.0, d)
    transparent = not full and not background
    page_html = page(c, [(0.0, d, part)], d, faces, transparent, background=background)
    (project / "index.html").write_text(page_html.replace('id="sc0"', 'id="e"'), encoding="utf-8")
    return d


FOOTAGE = "linear-gradient(180deg, #4a5a6e 0%, #6b7280 45%, #8a7f70 100%)"  # stands in for footage behind overlays


def sheet_project(items: list[tuple[str, str, dict]], look_key: str, client: Client, size: tuple[int, int], project: Path,
                  hold: float = 2.4, brand_fonts: bool = True, gsap: Path | None = None,
                  feel: str | None = None) -> list[float]:
    """Many elements back to back in one composition (overlays over a footage stand-in). Returns the time of each
    element's settled frame, for a contact sheet."""
    from .elements import LAYOUTS as LY
    vertical = size[1] > size[0]
    c, faces = context(client, look_key, size, project, False, 0.5, brand_fonts, gsap, feel)
    scenes, shots, t = [], [], 0.0
    clips = []
    for i, (kind, layout, params) in enumerate(items):
        full = kind in FULL_KINDS and kind != "transition"
        c.full, c.y = full, default_y(kind, vertical)
        c.roles = roles(c.look, client.brand["colors"], overlay=not full)
        h = max(hold, DURATION[kind] * 0.75)
        part = LY[kind][layout](c, dict(params), f"sc{i}", t, h)
        if full:  # full-frame scenes carry their own ground
            part.html = f'<div style="position:absolute;inset:0;background:{c.roles["stage"]}"></div>' + part.html
            part.html = f'<div class="full" style="position:absolute;inset:0">{part.html}</div>'
        else:
            part.html = f'<div style="position:absolute;inset:0;background:{FOOTAGE}"></div>' + part.html
        scenes.append((t, h, part))
        shots.append(round(t + h - 0.6, 3))
        t += h
    c.full = False
    c.roles = roles(c.look, client.brand["colors"], overlay=True)
    (project / "index.html").write_text(page(c, scenes, t, faces, True), encoding="utf-8")
    return shots


def render_sheet(project: Path, shots: list[float], settings: dict, out_png: Path, cols: int = 5, tile_w: int = 480,
                 labels: list[str] | None = None) -> Path:
    """Render a sheet project and tile the settled frames into one PNG."""
    import subprocess
    from PIL import Image, ImageDraw
    mp4 = project / "_sheet.mp4"
    hyper.render_project(project, mp4, settings, "mp4", fps=10)
    tiles = []
    for k, s in enumerate(shots):
        png = project / f"_f{k}.png"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{s:.2f}", "-i", str(mp4), "-frames:v", "1", str(png)], check=True)
        im = Image.open(png).convert("RGB")
        im = im.resize((tile_w, int(im.height * tile_w / im.width)))
        if labels:
            d = ImageDraw.Draw(im)
            d.rectangle((0, 0, tile_w, 22), fill=(0, 0, 0))
            d.text((6, 4), labels[k], fill=(255, 255, 255))
        tiles.append(im)
        png.unlink()
    rows = math.ceil(len(tiles) / cols) if tiles else 1
    th = tiles[0].height if tiles else 10
    sheet = Image.new("RGB", (cols * tile_w + (cols - 1) * 6, rows * th + (rows - 1) * 6), (255, 255, 255))
    for k, im in enumerate(tiles):
        sheet.paste(im, ((k % cols) * (tile_w + 6), (k // cols) * (th + 6)))
    sheet.save(out_png)
    mp4.unlink(missing_ok=True)
    return out_png


def samples(client: Client, d: dict | None = None) -> list[tuple[str, str, dict]]:
    """A look preview: one of each kind of graphic, in this client's look, layouts and colours."""
    from . import dna as dna_mod
    name = client.brand.get("client") if client.brand.get("client") not in (None, "Custom") else "Your Brand"
    if d is None and client.folder and (client.folder / "brand.yaml").exists():
        d = dna_mod.load(client)
    lay = lambda kind, k=0: dna_mod.layout_for(d, kind, k)  # noqa: E731
    sub = (client.brand.get("cta") or {}).get("sub", "") or client.brand.get("website", "") or ""
    return [("lower_third", lay("lower_third"), {"name": "Jordan Reyes", "title": f"Founder, {name}"}),
            ("title", lay("title"), {"text": "Built *for* the way you work", "kicker": name}),
            ("chart", lay("chart"), {"title": "Results this year", "items": "Q1: 120\nQ2: 180\nQ3: 260\nQ4: 410",
                                     "value": "72%", "label": "of clients come back"}),
            ("list", lay("list"), {"title": "How it works", "items": "Book online\nWe get to work\nYou see results"}),
            ("quote", lay("quote"), {"text": "Honestly the *best* decision we made all year.", "author": "A happy client",
                                     "role": "Verified review", "stars": 5}),
            ("callout", lay("callout"), {"text": "Look here", "x": 64, "y": 40}),
            ("lower_third", lay("lower_third", 1), {"name": "Sam Patel", "title": "Head of Service"}),
            ("title", lay("title", 1), {"text": "Ready when *you* are", "kicker": "Next step"}),
            ("end_card", lay("end_card"), {"text": "Book your free call", "sub": sub, "name": name})]
