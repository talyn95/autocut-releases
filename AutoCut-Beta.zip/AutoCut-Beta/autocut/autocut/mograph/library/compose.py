"""Turning a look + a client's colours into a HyperFrames page: colour roles, global CSS, the motion kit (JS) every
layout calls, text markup, and the page that holds one element or a whole storyboard.

Times: layouts schedule in seconds on the page's one timeline (absolute), already scaled by the look's pace (Ctx.D).
"""
from __future__ import annotations

import html
import json
import re
from dataclasses import dataclass, field

from .. import feel as feel_mod
from ..hyper import _luma, _mix, on

# how panels come in, per look (text entrances are the look's own `enter`)
BOX = {"corporate": "clip", "minimal": "grow", "editorial": "fade", "swiss": "slide", "brutal": "stamp", "glass": "fade",
       "neon": "flicker", "glitch": "glitch", "retro": "scale", "handmade": "scale", "luxury": "fade", "sport": "slide",
       "playful": "scale", "broadcast": "clip", "organic": "scale", "mono": "grow", "gradient": "scale",
       "cinematic": "fade"}


@dataclass
class Ctx:
    W: int
    H: int
    look: dict
    roles: dict
    full: bool = False            # a full-frame scene (storyboards, end cards) rather than an overlay on footage
    y: float = 0.5                # the element's centre line, fraction of the frame height (overlays)
    head: str = "Inter"
    body: str = "Inter"
    num: str = "Inter"
    assets: dict = field(default_factory=dict)  # logo path in the project, graphics …
    feel: str | None = None       # motion feel override (mograph/feel.py); None = the look's own

    @property
    def u(self) -> float:
        return min(self.W, self.H) / 1080

    @property
    def vertical(self) -> bool:
        return self.H > self.W

    @property
    def D(self) -> float:          # duration multiplier from the look's pace
        return 1 / float(self.look.get("speed") or 1)


@dataclass
class Part:
    html: str
    css: str = ""
    js: str = ""
    css_key: str = ""             # identical layout CSS is written once per page
    videos: list = field(default_factory=list)  # media layouts: video windows, placed as their own clips (page())


# ---- colours --------------------------------------------------------------------------------------------------

def _contrast(a: str, b: str) -> float:
    return abs(_luma(a) - _luma(b))


def _lift(c: str, floor: float = 95) -> str:
    """A brand colour bright enough to read on a dark ground."""
    k = 0.0
    while _luma(_mix(c, "#ffffff", k)) < floor and k < 0.8:
        k += 0.1
    return _mix(c, "#ffffff", k)


def _sink(c: str, ceil: float = 150) -> str:
    """A brand colour dark enough to read on a light ground."""
    k = 0.0
    while _luma(_mix(c, "#000000", k)) > ceil and k < 0.8:
        k += 0.1
    return _mix(c, "#000000", k)


def roles(look: dict, colors: dict, overlay: bool = True) -> dict:
    """Panel, ink, accent… for this look in this client's colours. Every pair is readable. overlay: text without a
    panel floats over footage, so it is white with a bright accent."""
    p, s = colors["primary"], colors["secondary"]
    pal = look["palette"]
    r: dict = {}
    if pal == "panel":
        r.update(panel=s, ink=on(s), accent=p if _contrast(p, s) > 60 else (_lift(p) if _luma(s) < 128 else _sink(p)))
    elif pal == "accent":
        alt = s if _contrast(s, p) > 90 else on(p)
        r.update(panel=p, ink=on(p), accent=alt)
    elif pal == "mono-dark":
        r.update(panel="rgba(12,13,17,0.86)", ink="#ffffff", accent=_lift(p, 110))
    elif pal == "mono-light":
        r.update(panel="#ffffff", ink="#121316", accent=_sink(p))
    elif pal == "duo":
        b = _mix(p, s, 0.55) if _contrast(_mix(p, s, 0.55), on(p)) > 70 else _mix(p, "#000000", 0.35)
        r.update(panel=f"linear-gradient(135deg, {p} 0%, {b} 100%)", panel_flat=p, ink=on(p),
                 accent=s if _contrast(s, p) > 90 else on(p))
    elif pal == "neon":
        r.update(panel="rgba(8,8,14,0.74)", ink="#ffffff", accent=_lift(p, 150))
    elif pal == "ink":
        r.update(panel="#f6f1e7", ink="#1e1a16", accent=_sink(p, 140))
    elif pal == "glass":
        r.update(panel="rgba(255,255,255,0.13)", ink="#ffffff", accent=_lift(p, 165))
    if overlay and look["panel"] == "none":
        r.update(ink="#ffffff", accent=_lift(p, 150))
    r.setdefault("panel_flat", r["panel"] if r["panel"].startswith("#") else p)
    r["float_accent"] = _lift(p, 150)
    r["accent_ink"] = on(r["accent"]) if r["accent"].startswith("#") else "#111111"
    # the full-frame ground (storyboards, end cards): the look's own, tinted with the brand
    if look.get("dark"):
        base = s if _luma(s) < 70 else "#0f1116"
        r.update(stage=f"radial-gradient(120% 90% at 30% 20%, {_mix(base, p, 0.22)} 0%, {base} 65%)", stage_flat=base,
                 stage_ink="#ffffff", stage_accent=_lift(p, 110))
    else:
        base = "#f6f1e7" if pal == "ink" else (s if _luma(s) > 200 else _mix("#ffffff", p, 0.06))
        r.update(stage=f"linear-gradient(160deg, {base} 0%, {_mix(base, p, 0.10)} 100%)", stage_flat=base,
                 stage_ink="#15161a", stage_accent=_sink(p, 140))
    r["primary"], r["secondary"] = p, s
    return r


# ---- text ----------------------------------------------------------------------------------------------------

def words(text: str, chars: bool = False) -> str:
    """Words in spans for per-word motion (.w > .wi); *keyword* gets the accent (.w.k). chars: per-letter spans too."""
    out = []
    for w in str(text or "").split():
        k = w.startswith("*") and w.rstrip(".,!?;:").endswith("*") and len(w.strip("*.,!?;:")) > 0
        clean = w.replace("*", "")
        inner = "".join(f'<span class="c">{html.escape(ch)}</span>' for ch in clean) if chars else html.escape(clean)
        out.append(f'<span class="w{" k" if k else ""}"><span class="wi">{inner}</span></span>')
    return " ".join(out)


def esc(text) -> str:
    return html.escape(str(text or ""))


def plain(text) -> str:
    return str(text or "").replace("*", "")


# ---- global CSS for a look -----------------------------------------------------------------------------------

GRAIN = ("url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='220' height='220'>"
         "<filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' seed='7'/>"
         "<feColorMatrix values='0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.55 0'/></filter>"
         "<rect width='100%' height='100%' filter='url(%23n)'/></svg>\")")


def look_css(c: Ctx) -> str:
    L, r, u = c.look, c.roles, c.u
    case = {"upper": "uppercase", "none": "none"}[L["case"]]
    radius = f"{L['radius'] * u:.1f}px" if L["radius"] < 999 else "999px"
    card_radius = f"{min(L['radius'], 36) * u:.1f}px"  # big panels never turn into ovals
    sw = max(1.0, L["stroke"] * u)
    panel_bg = r["panel"]
    extra = ""
    if L["panel"] == "glass":
        extra = f"backdrop-filter: blur({18 * u:.0f}px); border: {sw:.1f}px solid rgba(255,255,255,0.35);"
    elif L["panel"] == "outline":
        extra = f"border: {sw:.1f}px solid {r['accent']}; background: {panel_bg};"
    elif L["panel"] == "neon":
        extra = (f"border: {sw:.1f}px solid {r['accent']}; box-shadow: 0 0 {14 * u:.0f}px {r['accent']}, "
                 f"inset 0 0 {12 * u:.0f}px {r['accent']}55;")
    elif L["panel"] == "paper":
        extra = f"background-image: {GRAIN}; background-blend-mode: multiply;"
    elif L["panel"] == "none":
        panel_bg = "transparent"
    if L["stroke"] and L["panel"] in ("solid", "block") and L["key"] == "brutal":
        extra += f"border: {sw:.1f}px solid #111111;"
    shadow = {"none": "none", "soft": f"0 {14 * u:.0f}px {44 * u:.0f}px rgba(0,0,0,0.30)",
              "hard": f"{10 * u:.0f}px {10 * u:.0f}px 0 #111111",
              "glow": f"0 0 {36 * u:.0f}px {r['accent']}66"}[L["shadow"]]
    float_shadow = "none" if L["panel"] != "none" or c.full else f"0 {3 * u:.0f}px {18 * u:.0f}px rgba(0,0,0,0.55)"
    mask = "overflow: hidden; vertical-align: top; padding-bottom: 0.08em;" if L["enter"] == "mask" else ""
    tex = ""
    if L.get("texture") == "grain":
        tex = f".tex {{ background-image: {GRAIN}; opacity: 0.22; mix-blend-mode: overlay; }}"
    elif L.get("texture") == "scanlines":
        tex = (f".tex {{ background: repeating-linear-gradient(0deg, rgba(0,0,0,0.22) 0 {2 * u:.1f}px, transparent "
               f"{2 * u:.1f}px {5 * u:.1f}px); opacity: 0.6; }}")
    elif L.get("texture") == "paper":
        tex = f".tex {{ background-image: {GRAIN}; opacity: 0.35; mix-blend-mode: multiply; }}"
    return f"""
:root {{ --p: {r['primary']}; --s: {r['secondary']}; --panel: {panel_bg}; --panel-flat: {r['panel_flat']}; --ink: {r['ink']};
  --acc: {r['accent']}; --acc-ink: {r['accent_ink']}; --facc: {r['float_accent']}; --stage-ink: {r['stage_ink']}; --stage-acc: {r['stage_accent']};
  --r: {radius}; --rc: {card_radius}; --sw: {sw:.1f}px; --sh: {shadow}; --u: {u:.4f}px; }}
.hd {{ font-family: "{c.head}", "Montserrat", sans-serif; font-weight: {L['head'][1]}; text-transform: {case};
  letter-spacing: {L['track']}; line-height: {1.0 if L['case'] == 'upper' else 1.06}; {"font-style: italic;" if L['italic'] else ""} }}
.bd {{ font-family: "{c.body}", "Montserrat", sans-serif; font-weight: {L['body'][1]}; line-height: 1.25; }}
.nm {{ font-family: "{c.num}", "Montserrat", sans-serif; font-weight: {L['num'][1]}; font-variant-numeric: tabular-nums;
  letter-spacing: {"-0.03em" if L['case'] != 'upper' else "0"}; line-height: 1; white-space: nowrap; }}
.pn {{ background: var(--panel); color: var(--ink); border-radius: var(--rc); box-shadow: var(--sh); {extra} }}
.fl {{ text-shadow: {float_shadow}; }}
.acc {{ color: var(--acc); }}
.accb {{ background: var(--acc); color: var(--acc-ink); }}
.w {{ display: inline-block; position: relative; {mask} }}
.wi {{ display: inline-block; }}
.w.k {{ color: var(--acc); }}
.pn .w.k {{ color: var(--acc); }}
.full .w.k {{ color: var(--stage-acc); }}
.c {{ display: inline-block; white-space: pre; }}
.anc {{ position: absolute; }}
.full {{ color: var(--stage-ink); }}
.float {{ color: #ffffff; text-shadow: 0 {3 * u:.0f}px {18 * u:.0f}px rgba(0,0,0,0.55); }}
.float .acc, .float .w.k {{ color: var(--facc); }}
.full .float {{ color: var(--stage-ink); text-shadow: none; }}
.full .float .acc, .full .float .w.k {{ color: var(--stage-acc); }}
{".full .pn { color: var(--stage-ink); } .full .pn .acc, .full .pn .w.k { color: var(--stage-acc); }" if L['panel'] == 'none' else ""}
.tex {{ position: absolute; inset: 0; pointer-events: none; }}
.ch-card {{ padding: {40 * u:.0f}px {52 * u:.0f}px; display: flex; flex-direction: column; gap: {22 * u:.0f}px; }}
.ch-title {{ font-size: calc(var(--u) * var(--t) * 52); text-align: left; }}
.ch-lab {{ font-size: calc(var(--u) * var(--t) * 30); opacity: 0.85; }} .ch-val {{ font-size: calc(var(--u) * var(--t) * 34); }}
{tex}
{"" if L['palette'] != 'neon' else f".acc, .w.k {{ text-shadow: 0 0 {10 * u:.0f}px var(--acc), 0 0 {26 * u:.0f}px var(--acc); }}"}
{feel_mod.css("var(--stage-acc)" if c.full else "var(--acc)", u)}
"""


# ---- the motion kit ------------------------------------------------------------------------------------------

KIT = r"""
const q = (s) => gsap.utils.toArray(s);
const JIT = [-7, 5, -3, 8, -5, 3, -8, 6, -2, 4];
function textIn(sel, t, how) {
  const kind = how || L.enter, words = q(sel + " .w"), inner = q(sel + " .wi"), chars = q(sel + " .c");
  const st = L.stagger * D, d = 0.6 * D;
  if (!words.length) return;
  switch (kind) {
    case "rise": tl.fromTo(words, {y: "0.45em", opacity: 0}, {y: 0, opacity: 1, duration: d, ease: E, stagger: st}, t); break;
    case "mask": tl.fromTo(inner, {yPercent: 110}, {yPercent: 0, duration: d * 1.15, ease: E, stagger: st}, t); break;
    case "pop": tl.fromTo(words, {scale: 0.3, opacity: 0}, {scale: 1, opacity: 1, duration: d * 0.8, ease: E, stagger: st}, t); break;
    case "bounce": tl.fromTo(words, {y: "-1.1em", opacity: 0}, {y: 0, opacity: 1, duration: d * 1.3, ease: "bounce.out", stagger: st}, t); break;
    case "blur": tl.fromTo(words, {opacity: 0, filter: "blur(14px)", scale: 1.06}, {opacity: 1, filter: "blur(0px)", scale: 1, duration: d * 1.3, ease: E, stagger: st}, t); break;
    case "type": {
      const cs = chars.length ? chars : words;
      tl.fromTo(cs, {opacity: 0}, {opacity: 1, duration: 0.01, stagger: 0.035 * D, ease: "none"}, t);
      break; }
    case "glitch": {
      const cs = chars.length ? chars : words;
      cs.forEach((el, i) => tl.fromTo(el, {opacity: 0, x: JIT[i % 10] * U}, {opacity: 1, x: 0, duration: 0.3 * D, ease: "steps(5)"}, t + (i % 7) * 0.025 * D));
      tl.fromTo(sel, {textShadow: `${6 * U}px 0 #ff2a6d, ${-6 * U}px 0 #05d9e8`}, {textShadow: "0px 0 #ff2a6d, 0px 0 #05d9e8", duration: 0.55 * D, ease: "steps(6)"}, t);
      break; }
    case "stamp":
      tl.fromTo(words, {scale: 2.2, opacity: 0}, {scale: 1, opacity: 1, duration: 0.22 * D, ease: "power4.in", stagger: st * 2}, t);
      tl.fromTo(sel, {x: -6 * U}, {x: 0, duration: 0.35 * D, ease: "elastic.out(1, 0.3)"}, t + 0.22 * D + st * 2 * (words.length - 1));
      break;
    case "slide": tl.fromTo(words, {x: "-0.9em", opacity: 0}, {x: 0, opacity: 1, duration: d * 0.8, ease: E, stagger: st}, t); break;
    case "flicker":
      words.forEach((w, i) => {
        const s = t + i * 0.07 * D;
        tl.set(w, {opacity: 0}, 0); tl.set(w, {opacity: 1}, s); tl.set(w, {opacity: 0.15}, s + 0.05);
        tl.set(w, {opacity: 1}, s + 0.09); tl.set(w, {opacity: 0.4}, s + 0.16); tl.set(w, {opacity: 1}, s + 0.21);
      });
      break;
    case "draw":
      tl.fromTo(words, {opacity: 0, y: "0.35em", rotation: (i) => [-4, 3, -2, 4, -3][i % 5]},
        {opacity: 1, y: 0, rotation: (i) => [-1.2, 0.7, -0.5, 1, -0.8][i % 5], duration: d, ease: E, stagger: st}, t);
      break;
    case "fade": tl.fromTo(words, {opacity: 0, y: "0.15em"}, {opacity: 1, y: 0, duration: d * 1.6, ease: E, stagger: st}, t); break;
    default: tl.fromTo(sel, {clipPath: "inset(0 100% 0 0)"}, {clipPath: "inset(0 0% 0 0)", duration: d, ease: E, clearProps: "clipPath"}, t);
  }
  feel(sel, t, d);
}
function boxIn(sel, t, from) {
  const d = 0.55 * D, side = from || "left";
  const clip0 = {left: "inset(0 100% 0 0)", right: "inset(0 0 0 100%)", up: "inset(100% 0 0 0)", down: "inset(0 0 100% 0)"}[side];
  switch (L.box) {
    case "clip": tl.fromTo(sel, {clipPath: clip0}, {clipPath: "inset(0 0% 0 0%)", duration: d, ease: E, clearProps: "clipPath"}, t); break;
    case "grow": tl.fromTo(sel, {scaleX: 0, transformOrigin: side === "right" ? "100% 50%" : "0% 50%"}, {scaleX: 1, duration: d * 1.2, ease: EIO}, t); break;
    case "slide": tl.fromTo(sel, {x: (side === "right" ? 1 : -1) * 120 * U, opacity: 0}, {x: 0, opacity: 1, duration: d, ease: E}, t); break;
    case "stamp": tl.fromTo(sel, {scale: 1.35, opacity: 0, rotation: -2}, {scale: 1, opacity: 1, rotation: 0, duration: 0.24 * D, ease: "power4.in"}, t); break;
    case "scale": tl.fromTo(sel, {scale: 0.55, opacity: 0}, {scale: 1, opacity: 1, duration: d * 1.1, ease: "back.out(1.7)"}, t); break;
    case "flicker":
      tl.set(sel, {opacity: 0}, 0); tl.set(sel, {opacity: 1}, t); tl.set(sel, {opacity: 0.2}, t + 0.06);
      tl.set(sel, {opacity: 1}, t + 0.11); tl.set(sel, {opacity: 0.5}, t + 0.2); tl.set(sel, {opacity: 1}, t + 0.26); break;
    case "glitch":
      tl.fromTo(sel, {clipPath: "inset(40% 0 45% 0)", x: 14 * U, opacity: 0}, {clipPath: "inset(0% 0 0% 0)", x: 0, opacity: 1, duration: 0.32 * D, ease: "steps(5)", clearProps: "clipPath"}, t); break;
    default: tl.fromTo(sel, {opacity: 0, filter: "blur(10px)"}, {opacity: 1, filter: "blur(0px)", duration: d * 1.4, ease: E, clearProps: "filter"}, t);
  }
  feel(sel, t, d, ["stamp", "scale"].includes(L.box) ? 0.4 : 1);
}
function lineIn(sel, t, origin) {
  tl.fromTo(sel, {scaleX: 0, transformOrigin: origin || "0% 50%"}, {scaleX: 1, duration: 0.7 * D, ease: EIO}, t);
}
function strokeIn(sel, t, d) {
  q(sel).forEach((el) => {
    const n = el.getTotalLength ? el.getTotalLength() : 1000;
    el.style.strokeDasharray = n; tl.fromTo(el, {strokeDashoffset: n}, {strokeDashoffset: 0, duration: (d || 0.9) * D, ease: EIO}, t);
  });
}
function popIn(sel, t, stagger) {
  tl.fromTo(sel, {scale: 0, opacity: 0}, {scale: 1, opacity: 1, duration: 0.45 * D, ease: "back.out(2)", stagger: (stagger || 0.08) * D}, t);
  feel(sel, t, 0.45 * D, 0.5);
}
function countUp(sel, to, dec, t, d) {
  const el = document.querySelector(sel), o = {v: 0};
  if (!el) return;
  tl.fromTo(o, {v: 0}, {v: to, duration: (d || 1.2) * D, ease: "expo.out", onUpdate: () => {
    el.textContent = o.v.toLocaleString("en-US", {minimumFractionDigits: dec, maximumFractionDigits: dec}); }}, t);
}
function out(sel, t) {
  const d = 0.35 * D;
  switch (L.exit) {
    case "wipe": tl.to(sel, {clipPath: "inset(0 0 0 100%)", duration: d, ease: EOUT}, t); break;
    case "drop": tl.to(sel, {y: 50 * U, opacity: 0, duration: d, ease: EOUT}, t); break;
    case "shrink": tl.to(sel, {scale: 0.85, opacity: 0, duration: d, ease: "back.in(1.6)"}, t); break;
    case "slide": tl.to(sel, {x: -80 * U, opacity: 0, duration: d, ease: EOUT}, t); break;
    case "cut": tl.set(sel, {opacity: 0.3}, t + 0.1); tl.set(sel, {opacity: 1}, t + 0.15); tl.set(sel, {opacity: 0}, t + 0.3); return;
    default: tl.to(sel, {opacity: 0, duration: d * 1.2, ease: EOUT}, t);
  }
  feelOut(sel, t, d);
}
"""


def kit(c: Ctx) -> str:
    L = c.look
    cfg = {"enter": L["enter"], "exit": L["exit"], "ease": L["ease"], "stagger": L["stagger"], "box": BOX.get(L["key"], "clip")}
    return (f"const L = {json.dumps(cfg)};\nconst D = {c.D:.4f};\nconst U = {c.u:.4f};\n"
            + feel_mod.js(feel_mod.pick(L, c.feel)) + "const E = EIN;\n" + KIT)


# ---- the page ------------------------------------------------------------------------------------------------

def page(c: Ctx, scenes: list[tuple[float, float, Part]], total: float, faces: str, transparent: bool,
         extra_clips: str = "", background: str | None = None) -> str:
    """scenes: (start, duration, part). Overlays (transparent) have no ground; full-frame pages get the look's stage."""
    css, seen = [], set()
    for _, _, p in scenes:
        key = p.css_key or p.css
        if p.css and key not in seen:
            seen.add(key)
            css.append(p.css)
    clips = "\n".join(
        f'<div id="sc{i}" class="clip scene{" full" if c.full else ""}" data-start="{a:.3f}" data-duration="{d:.3f}" '
        f'data-track-index="1" data-layout-allow-overflow>{p.html}</div>' for i, (a, d, p) in enumerate(scenes))
    # videos can't be timed inside a timed scene: each is its own clip, in an untimed holder at the window's rect
    # (the layout animates the holder together with the window drawn in the scene)
    for a, d, p in scenes:
        for v in p.videos:
            clips += (f'\n<div class="mvh"><div id="{v["id"]}" class="mvid {v.get("cls", "")}" style="{v["style"]}">'
                      f'<video id="{v["id"]}x" class="clip" src="{v["src"]}" data-start="{a:.3f}" data-duration="{d:.3f}" '
                      f'data-track-index="2" muted playsinline></video></div></div>')
    js = "\n".join(p.js for _, _, p in scenes)
    ground = ""
    if not transparent:
        bg = background or c.roles["stage"]
        ground = (f'<div id="ground" class="clip" data-start="0" data-duration="{total:.3f}" data-track-index="0" '
                  f'style="position:absolute;inset:0;background:{bg}"></div>')
        if c.look.get("texture"):
            ground += (f'<div class="clip tex" data-start="0" data-duration="{total:.3f}" data-track-index="5"></div>')
    W, H = c.W, c.H
    return f"""<!doctype html>
<!-- AutoCut motion library · look: {esc(c.look['name'])} · open in HyperFrames Studio to keep editing -->
<html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width={W}, height={H}">
<script src="assets/gsap.min.js"></script>
<style>
{faces}
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
html, body {{ width: {W}px; height: {H}px; overflow: hidden; background: transparent; }}
body {{ font-family: "{c.body}", "Montserrat", sans-serif; color: var(--ink); -webkit-font-smoothing: antialiased; }}
#root {{ position: absolute; inset: 0; }}
.scene {{ position: absolute; inset: 0; --t: {1.3 if c.vertical else 1}; }}
.scene.full {{ color: var(--stage-ink); --t: {1.4 if c.vertical else 1.5}; }}
{look_css(c)}
{"".join(css)}
</style></head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{total:.3f}" data-width="{W}" data-height="{H}">
{ground}
{clips}
{extra_clips}
</div>
<script>
window.__timelines = window.__timelines || {{}};
const tl = gsap.timeline({{ paused: true }});
{kit(c)}
{js}
window.__timelines["main"] = tl;
</script>
</body></html>"""


def parse_items(items) -> list[dict]:
    """'Label: value' lines (or a list of dicts) → [{label, value, num, pre, suf, dec}]."""
    if isinstance(items, list):
        rows = [i if isinstance(i, dict) else {"label": str(i)} for i in items]
    else:
        rows = []
        for line in re.split(r"\n|;", str(items or "")):
            line = line.strip(" -•\t")
            if not line:
                continue
            m = re.match(r"^(.*?)\s*[:=|]\s*(.+)$", line)
            rows.append({"label": m.group(1).strip(), "value": m.group(2).strip()} if m else {"label": line, "value": ""})
    out = []
    for r in rows:
        v = str(r.get("value", "")).strip()
        m = re.search(r"-?\d[\d,]*(\.\d+)?", v)
        num = float(m.group(0).replace(",", "")) if m else None
        out.append({"label": str(r.get("label", "")), "value": v, "num": num,
                    "pre": v[:m.start()] if m else "", "suf": v[m.end():] if m else "",
                    "dec": len(m.group(1)) - 1 if m and m.group(1) else 0})
    return out
