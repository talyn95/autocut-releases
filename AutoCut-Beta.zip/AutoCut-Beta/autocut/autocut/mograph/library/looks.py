"""Looks: the style families every motion graphic is drawn in.

Each look is a design system distilled from a best-selling category on the big template marketplaces (Envato Elements,
Motion Array, the HyperFrames registry) or a current trend, written from scratch: typefaces, shape language, panel
treatment, texture and a motion vocabulary (how things enter and leave, the easing, the pace). The client's own
colours always fill it in, so a look is a way of drawing, never a palette. Layouts (elements.py) × looks × each
client's colours is what keeps two clients from looking alike (dna.py hands them out).

Tokens:
  head/body/num  (family, weight) from the fonts HyperFrames bundles (hyper.BUNDLED_FONTS); the client's own font
                 files win when they have them (dna.fonts)
  case, track, italic   headline casing, letter-spacing, slant
  radius, stroke        corner radius and outline width at 1080 px
  panel                 solid | glass | outline | none | paper | gradient | neon | block
  shadow                none | soft | hard (offset, no blur) | glow
  motif                 the accent shape the layouts draw: tab | rule | bracket | slash | dot | ticks | stripes |
                        scribble | chrome | corners | cursor | blob
  texture               None | grain | scanlines | paper | halftone
  enter / exit          text entrance: wipe | rise | mask | pop | bounce | blur | type | glitch | stamp | slide |
                        flip | flicker | fade | draw;  exit: wipe | fade | drop | shrink | slide | cut
  ease, speed, stagger  GSAP ease for entrances, pace multiplier, gap between words
  palette               how the brand colours are used: panel | accent | mono-dark | mono-light | duo | neon | ink | glass
  dark                  the look's own full-frame background is dark (storyboards, end cards)
"""
from __future__ import annotations

from ... import content

LOOKS: dict[str, dict] = {
    "corporate": dict(
        name="Corporate Clean", inspired_by="'Clean corporate lower thirds' and broadcast packages (Envato, Motion Array)",
        mood=["trustworthy", "calm", "professional"], fits=["finance", "law", "insurance", "dental", "medical", "b2b",
                                                            "consulting", "accounting", "healthcare"],
        head=("Inter", 700), body=("Inter", 400), num=("Inter", 800), case="none", track="-0.015em", italic=False,
        radius=14, stroke=0, panel="solid", shadow="soft", motif="tab", texture=None,
        enter="rise", exit="wipe", ease="expo.out", speed=1.0, stagger=0.05, palette="panel", dark=True),
    "minimal": dict(
        name="Minimal Line", inspired_by="'Minimal titles' packs: thin animated lines that stay out of the footage's way",
        mood=["calm", "modern", "premium"], fits=["architecture", "interior", "design", "photography", "wellness", "spa",
                                                   "skincare", "real estate"],
        head=("Outfit", 500), body=("Outfit", 300), num=("Outfit", 600), case="none", track="0em", italic=False,
        radius=0, stroke=2, panel="none", shadow="none", motif="rule", texture=None,
        enter="mask", exit="fade", ease="power3.out", speed=0.85, stagger=0.07, palette="mono-dark", dark=True),
    "editorial": dict(
        name="Editorial Serif", inspired_by="Magazine and documentary title packs: big serif, italic accents, rules",
        mood=["thoughtful", "premium", "storytelling"], fits=["restaurant", "food", "hospitality", "publishing", "boutique",
                                                              "wine", "coffee", "bakery", "florist"],
        head=("Playfair Display", 700), body=("Lato", 400), num=("Playfair Display", 700), case="none", track="-0.01em",
        italic=True, radius=0, stroke=1, panel="none", shadow="none", motif="rule", texture="grain",
        enter="rise", exit="fade", ease="power3.out", speed=0.9, stagger=0.06, palette="ink", dark=False),
    "swiss": dict(
        name="Swiss Grid", inspired_by="International-style typographic packs: grids, flush-left caps, hard blocks",
        mood=["confident", "structured", "modern"], fits=["agency", "architecture", "saas", "engineering", "manufacturing",
                                                          "logistics", "construction", "roofing", "contractor",
                                                          "home services", "hvac", "plumbing", "electrician",
                                                          "landscaping", "remodel"],
        head=("Archivo Black", 400), body=("Inter", 500), num=("Archivo Black", 400), case="upper", track="-0.02em",
        italic=False, radius=0, stroke=0, panel="block", shadow="none", motif="ticks", texture=None,
        enter="slide", exit="slide", ease="power4.out", speed=1.15, stagger=0.04, palette="accent", dark=False),
    "brutal": dict(
        name="Neo-Brutalist", inspired_by="Bold social packs: thick outlines, hard offset shadows, stamped type",
        mood=["loud", "playful", "youthful"], fits=["streetwear", "gaming", "creator", "music", "events", "bar",
                                                   "fitness", "food truck"],
        head=("Archivo Black", 400), body=("Space Mono", 700), num=("Archivo Black", 400), case="upper", track="0em",
        italic=False, radius=0, stroke=5, panel="solid", shadow="hard", motif="stripes", texture=None,
        enter="stamp", exit="cut", ease="back.out(2)", speed=1.2, stagger=0.05, palette="accent", dark=False),
    "glass": dict(
        name="Glass Tech", inspired_by="SaaS/app promo packs: frosted panels, soft glows, blur-ins",
        mood=["modern", "techy", "clean"], fits=["saas", "software", "app", "fintech", "ai", "startup", "crypto",
                                                 "telecom"],
        head=("Outfit", 600), body=("Inter", 400), num=("Outfit", 700), case="none", track="-0.02em", italic=False,
        radius=28, stroke=1, panel="glass", shadow="glow", motif="dot", texture=None,
        enter="blur", exit="fade", ease="power3.out", speed=1.0, stagger=0.06, palette="glass", dark=True),
    "neon": dict(
        name="Neon Night", inspired_by="Neon/night-life title packs: glowing outlines that flicker on",
        mood=["electric", "nightlife", "energetic"], fits=["bar", "nightclub", "dj", "music", "gaming", "esports",
                                                           "tattoo", "barber"],
        head=("Oswald", 600), body=("Oswald", 400), num=("Oswald", 700), case="upper", track="0.08em", italic=False,
        radius=12, stroke=3, panel="neon", shadow="glow", motif="corners", texture="scanlines",
        enter="flicker", exit="fade", ease="power2.out", speed=1.0, stagger=0.05, palette="neon", dark=True),
    "glitch": dict(
        name="Glitch Digital", inspired_by="Glitch title/transition packs: RGB split, slices, scanlines, mono type",
        mood=["edgy", "digital", "techy"], fits=["cybersecurity", "it", "gaming", "tech", "electronics", "esports"],
        head=("Space Mono", 700), body=("IBM Plex Mono", 400), num=("Space Mono", 700), case="upper", track="0.02em",
        italic=False, radius=0, stroke=2, panel="outline", shadow="none", motif="slash", texture="scanlines",
        enter="glitch", exit="cut", ease="steps(6)", speed=1.2, stagger=0.03, palette="mono-dark", dark=True),
    "retro": dict(
        name="Retro 70s", inspired_by="Retro/vintage packs: chunky type, sunset stripes, bouncy motion",
        mood=["warm", "nostalgic", "fun"], fits=["cafe", "coffee", "ice cream", "vintage", "skate", "surf", "bakery",
                                                 "brewery", "pizza"],
        head=("Archivo Black", 400), body=("Nunito", 700), num=("Archivo Black", 400), case="none", track="-0.01em",
        italic=False, radius=22, stroke=0, panel="solid", shadow="hard", motif="stripes", texture="grain",
        enter="bounce", exit="drop", ease="back.out(1.6)", speed=0.95, stagger=0.06, palette="duo", dark=False),
    "handmade": dict(
        name="Hand-made Paper", inspired_by="2026's swing to imperfect motion: paper, grain, scribbles, slight jitter",
        mood=["human", "warm", "authentic"], fits=["nonprofit", "education", "kids", "craft", "farm", "organic", "therapy",
                                                    "coaching", "church", "pet"],
        head=("EB Garamond", 700), body=("Nunito", 600), num=("EB Garamond", 700), case="none", track="0em", italic=True,
        radius=6, stroke=0, panel="paper", shadow="soft", motif="scribble", texture="paper",
        enter="draw", exit="fade", ease="power2.out", speed=0.9, stagger=0.08, palette="ink", dark=False),
    "luxury": dict(
        name="Luxury Serif", inspired_by="Luxury/fashion/real-estate packs: tracked serif caps, hairlines, slow fades",
        mood=["elegant", "exclusive", "slow"], fits=["luxury", "real estate", "jewelry", "fashion", "hotel", "wedding",
                                                     "med spa", "plastic surgery", "watches", "yacht"],
        head=("EB Garamond", 500), body=("Lato", 300), num=("EB Garamond", 500), case="upper", track="0.18em",
        italic=False, radius=0, stroke=1, panel="none", shadow="none", motif="corners", texture=None,
        enter="fade", exit="fade", ease="power2.inOut", speed=0.75, stagger=0.09, palette="mono-dark", dark=True),
    "sport": dict(
        name="Sport Bold", inspired_by="Sports broadcast and fitness promo packs: italic condensed caps, slashes, speed",
        mood=["fast", "aggressive", "energetic"], fits=["fitness", "gym", "sports", "crossfit", "martial arts",
                                                        "automotive", "racing", "supplements", "coach"],
        head=("Oswald", 700), body=("Oswald", 500), num=("Oswald", 700), case="upper", track="0.01em", italic=True,
        radius=0, stroke=0, panel="block", shadow="none", motif="slash", texture=None,
        enter="slide", exit="slide", ease="expo.out", speed=1.35, stagger=0.03, palette="accent", dark=True),
    "playful": dict(
        name="Playful Pop", inspired_by="Social media packs: rounded pills, bouncy pops, dots and stickers",
        mood=["friendly", "fun", "approachable"], fits=["kids", "pet", "daycare", "dentist", "bakery", "ecommerce",
                                                        "creator", "toys", "cleaning"],
        head=("Nunito", 900), body=("Nunito", 700), num=("Nunito", 900), case="none", track="-0.01em", italic=False,
        radius=999, stroke=0, panel="solid", shadow="soft", motif="dot", texture=None,
        enter="pop", exit="shrink", ease="back.out(2.2)", speed=1.1, stagger=0.05, palette="accent", dark=False),
    "broadcast": dict(
        name="Broadcast News", inspired_by="News/broadcast packages: two-tier bars, tickers, hard cuts, live tags",
        mood=["urgent", "credible", "informative"], fits=["news", "media", "politics", "podcast", "public sector",
                                                           "local", "radio", "weather"],
        head=("Roboto", 700), body=("Roboto", 400), num=("Roboto", 900), case="upper", track="0.01em", italic=False,
        radius=4, stroke=0, panel="solid", shadow="soft", motif="tab", texture=None,
        enter="wipe", exit="wipe", ease="power4.out", speed=1.2, stagger=0.0, palette="panel", dark=True),
    "organic": dict(
        name="Soft Organic", inspired_by="Wellness/beauty packs: blobs, soft gradients, floating rises",
        mood=["soft", "caring", "natural"], fits=["wellness", "yoga", "skincare", "salon", "spa", "nutrition", "midwife",
                                                  "therapy", "chiropractor", "massage"],
        head=("Poppins", 600), body=("Poppins", 400), num=("Poppins", 700), case="none", track="-0.01em", italic=False,
        radius=40, stroke=0, panel="gradient", shadow="soft", motif="blob", texture=None,
        enter="rise", exit="fade", ease="sine.out", speed=0.85, stagger=0.08, palette="duo", dark=False),
    "mono": dict(
        name="Mono Developer", inspired_by="Code/terminal packs: monospace, outline boxes, type-on with a cursor",
        mood=["precise", "nerdy", "honest"], fits=["developer", "devtools", "saas", "api", "data", "cloud", "hosting"],
        head=("JetBrains Mono", 700), body=("JetBrains Mono", 400), num=("JetBrains Mono", 700), case="none",
        track="-0.02em", italic=False, radius=8, stroke=2, panel="outline", shadow="none", motif="cursor",
        texture=None, enter="type", exit="cut", ease="none", speed=1.1, stagger=0.0, palette="mono-dark", dark=True),
    "gradient": dict(
        name="Maximal Gradient", inspired_by="2026's bold-colour trend: saturated layered gradients, heavy type, pops",
        mood=["bold", "vibrant", "modern"], fits=["marketing", "agency", "events", "beauty", "fashion", "ecommerce",
                                                  "influencer", "festival"],
        head=("Montserrat", 900), body=("Montserrat", 500), num=("Montserrat", 900), case="none", track="-0.03em",
        italic=False, radius=24, stroke=0, panel="gradient", shadow="soft", motif="chrome", texture="grain",
        enter="pop", exit="shrink", ease="back.out(1.7)", speed=1.05, stagger=0.04, palette="duo", dark=True),
    "cinematic": dict(
        name="Cinematic", inspired_by="Trailer/opener title packs: wide-tracked light caps, letterbox bars, slow blur",
        mood=["dramatic", "premium", "story"], fits=["film", "production", "wedding", "travel", "automotive", "hotel",
                                                      "documentary", "photography", "videography"],
        head=("Montserrat", 300), body=("Montserrat", 400), num=("Montserrat", 200), case="upper", track="0.32em",
        italic=False, radius=0, stroke=1, panel="none", shadow="none", motif="rule", texture="grain",
        enter="blur", exit="fade", ease="power2.out", speed=0.7, stagger=0.12, palette="mono-dark", dark=True),
}

content.register("looks", LOOKS)  # + looks from content packs (content.py)
DEFAULT = "corporate"


def get(key: str | None) -> dict:
    return {"key": key if key in LOOKS else DEFAULT, **LOOKS.get(key or "", LOOKS[DEFAULT])}
