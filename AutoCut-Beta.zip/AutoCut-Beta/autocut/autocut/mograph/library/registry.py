"""The HyperFrames registry (about 450 open-source blocks and components, Apache-2.0) as a reference library.

registry.json is the catalog (names, descriptions, tags), shipped with AutoCut so search works offline. The custom
designer (hyper.make_custom) looks up the blocks closest to a brief and, when this computer is online, installs their
source with `hyperframes add` into a scratch project and hands it to the AI as a starting point to adapt: the
registry's craft, the client's brand. Nothing from the registry is copied into AutoCut itself.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
from functools import lru_cache
from pathlib import Path

HERE = Path(__file__).parent
STOP = set("a an and the of for to in on with by at is it this that from as or be your our my their".split())
SYN = {"lower": "lower-third", "third": "lower-third", "graph": "chart", "chart": "data", "stats": "data", "stat": "data",
       "map": "map", "intro": "title-card", "title": "title-card", "headline": "title-card", "caption": "captions",
       "subtitle": "captions", "transition": "transition", "logo": "logo", "phone": "mock-ui", "app": "mock-ui",
       "chat": "chat", "tweet": "social", "instagram": "social", "review": "social", "code": "code"}


@lru_cache(maxsize=1)
def catalog() -> list[dict]:
    return json.loads((HERE / "registry.json").read_text())["items"]


def _tokens(text: str) -> set[str]:
    ws = {w for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in STOP and len(w) > 2}
    return ws | {SYN[w] for w in ws if w in SYN}


def search(query: str, limit: int = 8, kind: str | None = None) -> list[dict]:
    q = _tokens(query)
    out = []
    for it in catalog():
        if kind and it["type"] != kind:
            continue
        tags = set(it.get("tags") or [])
        words = _tokens(" ".join([it["name"].replace("-", " "), it.get("title") or "", it.get("description") or ""]))
        score = 3 * len(q & tags) + len(q & words) + (2 if any(w in it["name"] for w in q) else 0)
        if score:
            out.append((score, it))
    out.sort(key=lambda x: (-x[0], x[1]["name"]))
    return [it for _, it in out[:limit]]


def fetch(name: str, settings: dict, timeout: int = 90) -> str | None:
    """The block's source, installed with the HyperFrames CLI into a scratch project (needs the internet)."""
    from .. import hyper
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{1,80}", name or "") or not hyper.available(settings):
        return None
    work = hyper.runtime_dir(settings) / "_registry"
    work.mkdir(parents=True, exist_ok=True)
    cached = next(iter(work.glob(f"**/{name}.html")), None)
    if cached:
        return cached.read_text(encoding="utf-8", errors="replace")
    if not (work / "hyperframes.json").exists():
        (work / "hyperframes.json").write_text("{}")
    try:
        subprocess.run([hyper._node(), str(hyper._cli(settings)), "add", name, "--json"], cwd=work, env={**os.environ, **hyper.ENV},
                       capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired):
        return None
    found = next(iter(work.glob(f"**/{name}.html")), None)
    return found.read_text(encoding="utf-8", errors="replace") if found else None


def reference_for(brief: str, settings: dict, limit: int = 2, max_chars: int = 9000) -> str:
    """Text for the custom designer: the closest registry blocks' source, to adapt (empty when offline/none)."""
    named = re.findall(r"registry block ['\"]?([a-z0-9-]+)", brief)
    picks = [n for n in named if any(i["name"] == n for i in catalog())] or [i["name"] for i in search(brief, limit, "block")]
    parts = []
    for n in picks[:limit]:
        src = fetch(n, settings)
        if not src:
            continue
        src = re.sub(r'<script src="https://cdn\.jsdelivr\.net/npm/gsap[^"]*"></script>', '<script src="assets/gsap.min.js"></script>', src)
        parts.append(f"--- registry block '{n}' (HyperFrames registry, Apache-2.0) ---\n{src[:max_chars]}")
    if not parts:
        return ""
    return ("\n\nREFERENCE: open-source HyperFrames registry blocks close to this brief. Use them as a starting point for "
            "craft (structure, motion, timing): adapt them to this brief and brand, keep only what serves it, and still "
            "follow every rule above (local assets/gsap.min.js, no CDNs, fonts from the list).\n" + "\n\n".join(parts))
