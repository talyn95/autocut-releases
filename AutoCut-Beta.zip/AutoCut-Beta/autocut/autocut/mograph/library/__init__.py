"""AutoCut's motion library: looks (style families) × layouts × storyboards, handed out per client by style DNA.

See looks.py (the families and where each comes from), elements.py (every layout), storyboards.py (multi-scene
recipes), dna.py (keeping clients apart), build.py (projects and look sheets) and docs/LIBRARY.md.
"""
from __future__ import annotations

from pathlib import Path

from ...config import Client
from . import dna as dna_mod
from . import looks
from .elements import DURATION, LAYOUTS, PARAMS

# Create-tab templates the library draws. Existing templates are drawn by the library too when a look applies
# (a client with DNA, or a look picked by hand); slam and kinetic typography keep their own engines.
LIB_TEMPLATES = {"chart", "list", "quote", "callout", "media", "storyboard", "lookbook"}
MAP = {"lower_third": "lower_third", "hook_title": "title", "phrase_card": "title", "stat_counter": "chart",
       "cta_outro": "end_card", "swipe": "transition", "chart": "chart", "list": "list", "quote": "quote",
       "callout": "callout", "media": "media"}
PREFER = {"phrase_card": ["boxed", "mask", "stack"], "stat_counter": ["counters"]}
VIDEO_TEMPLATES = {"storyboard", "lookbook", "media"}  # opaque MP4s, not overlays


def resolve(spec: dict, client: Client, settings: dict) -> tuple[str | None, dict | None]:
    """(look key or None for AutoCut's original templates, the client's DNA)."""
    want = spec.get("look") or ""
    if want == "original" and spec["template"] not in LIB_TEMPLATES:
        return None, None
    d = dna_mod.get(client, settings)
    if want in looks.LOOKS:
        return want, d
    if d:
        return d["look"], d
    return (looks.DEFAULT, None) if spec["template"] in LIB_TEMPLATES else (None, None)


def kind_params(template: str, params: dict) -> tuple[str, dict, list[str] | None]:
    """A Create-tab template + its fields → library kind, params and the layouts that suit it."""
    kind = MAP[template]
    p = dict(params)
    allowed = PREFER.get(template)
    if template == "stat_counter":
        v = str(p.get("value", ""))
        if v.strip().endswith("%"):
            p = {"value": v, "label": p.get("label", "")}
            allowed = ["donut", "meter", "waffle", "counters"]
        else:
            p = {"items": f"{p.get('label') or ' '}: {v}"}
    elif template == "cta_outro":
        p = {"text": p.get("text", ""), "sub": p.get("sub", "")}
    elif template == "media":
        p = {k: p.get(k, "") for k in ("title", "caption", "kicker", "src") if p.get(k)}
    return kind, p, allowed


def pick_layout(spec: dict, kind: str, d: dict | None, allowed: list[str] | None) -> str:
    if spec.get("layout") in LAYOUTS[kind]:
        return spec["layout"]
    order = [dna_mod.layout_for(d, kind, k) for k in range(len(LAYOUTS[kind]))]
    order = [x for x in order if not allowed or x in allowed] or list(LAYOUTS[kind])
    return order[0]


def info(client: Client | None, settings: dict) -> dict:
    from .storyboards import RECIPES
    from .. import feel
    return {"looks": [{"key": k, "name": v["name"], "inspired_by": v["inspired_by"], "mood": v["mood"], "fits": v["fits"],
                       "feel": feel.pick({**v, "key": k})} for k, v in looks.LOOKS.items()],
            "feels": feel.choices(),
            "layouts": {k: list(v) for k, v in LAYOUTS.items()}, "params": PARAMS,
            "recipes": [{"key": k, "name": r["name"], "use": r["use"], "slots": [{"name": n, "hint": h} for n, h, _ in r["slots"]]}
                        for k, r in RECIPES.items()],
            "dna": dna_mod.get(client, settings) if client else None}
