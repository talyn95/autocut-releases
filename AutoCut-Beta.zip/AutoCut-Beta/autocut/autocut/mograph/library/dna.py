"""Style DNA: each client's own way of drawing motion graphics, so two clients on the same AutoCut never look alike.

A client's DNA (motion-style.json in the client folder) is a look plus an order of layouts for every element kind and
a transition. It is handed out once, the first time the client needs it: the look that suits the client's industry
and is least used by the other clients, and for every kind the layouts other clients lead with least. "Shuffle" picks
the next-best; any of it can be set by hand. Storyboards and every library element read it.
"""
from __future__ import annotations

import hashlib
import json
import re
from datetime import date
from pathlib import Path

from ...config import Client, list_clients, load_client
from . import looks
from .elements import LAYOUTS

FILE = "motion-style.json"
KINDS = [k for k in LAYOUTS if k != "transition"]


def _h(*parts) -> int:
    return int(hashlib.sha1("|".join(map(str, parts)).encode()).hexdigest()[:8], 16)


def load(client: Client | Path) -> dict | None:
    folder = client.folder if isinstance(client, Client) else Path(client)
    f = folder / FILE
    try:
        d = json.loads(f.read_text())
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(d, dict) or not d.get("look"):
        return None
    if d["look"] not in looks.LOOKS:  # its content pack is switched off or gone: stand in with the look it was
        base = d.get("look_base") if d.get("look_base") in looks.LOOKS else looks.DEFAULT  # built on (not saved,
        d = {**d, "look": base, "look_unavailable": d["look"]}                              # so it comes back)
    return d


def save(client: Client, dna: dict) -> dict:
    d = dict(dna)
    gone = d.pop("look_unavailable", None)
    if gone and d["look"] == (d.get("look_base") if d.get("look_base") in looks.LOOKS else looks.DEFAULT):
        d["look"] = gone  # only the stand-in changed hands: keep the client's own look for when its pack is back
    (client.folder / FILE).write_text(json.dumps(d, indent=2))
    return dna


def layout_for(dna: dict | None, kind: str, k: int = 0) -> str:
    order = [x for x in ((dna or {}).get("layouts") or {}).get(kind, []) if x in LAYOUTS[kind]] or list(LAYOUTS[kind])
    return order[k % len(order)]


def _others(client: Client, settings: dict) -> list[dict]:
    out = []
    for folder in list_clients(settings):
        if folder.resolve() == client.folder.resolve():
            continue
        d = load(folder)
        if d:
            out.append(d)
    return out


def fit(look: dict, brand: dict) -> int:
    """How well a look suits a business, from its industry, name and tone."""
    text = " ".join(str(x) for x in (brand.get("client"), (brand.get("marketing") or {}).get("industry"),
                                     (brand.get("marketing") or {}).get("tone"), brand.get("industry"))).lower()
    score = 0
    for f in look["fits"]:
        if re.search(rf"\b{re.escape(f)}", text):
            score += 3
    for m in look["mood"]:
        if re.search(rf"\b{re.escape(m)}", text):
            score += 1
    return score


def assign(client: Client, settings: dict, shuffle: int = 0, others: list[dict] | None = None) -> dict:
    others = _others(client, settings) if others is None else others
    used: dict[str, int] = {}
    for d in others:
        used[d["look"]] = used.get(d["look"], 0) + 1
    ranked = sorted(looks.LOOKS, key=lambda k: (used.get(k, 0) * 4 - fit(looks.LOOKS[k], client.brand) * 2,
                                                 _h(client.slug, k)))
    look = ranked[shuffle % len(ranked)]
    layouts = {}
    for kind in KINDS:
        lead: dict[str, int] = {}
        for d in others:
            first = layout_for(d, kind)
            lead[first] = lead.get(first, 0) + 1 + (2 if d["look"] == look else 0)  # same look: avoid its layouts harder
        layouts[kind] = sorted(LAYOUTS[kind], key=lambda l: (lead.get(l, 0), _h(client.slug, kind, l, shuffle)))
    tr_lead = {}
    for d in others:
        tr_lead[d.get("transition")] = tr_lead.get(d.get("transition"), 0) + 1
    transition = sorted(LAYOUTS["transition"], key=lambda l: (tr_lead.get(l, 0), _h(client.slug, "tr", l, shuffle)))[0]
    out = {"look": look, "layouts": layouts, "transition": transition, "brand_fonts": True, "shuffle": shuffle,
           "assigned": date.today().isoformat()}
    if looks.LOOKS[look].get("pack"):  # a content-pack look: remember what it's built on, in case the pack goes
        out["look_base"] = looks.LOOKS[look].get("base") or looks.DEFAULT
    return out


def get(client: Client | None, settings: dict, create: bool = True) -> dict | None:
    """The client's DNA, handing it out the first time. None for no client."""
    if client is None or client.slug.startswith("_") or not (client.folder / "brand.yaml").exists():
        return None
    d = load(client)
    if d is None and create:
        d = assign(client, settings)
        from ...config import clients_dir
        try:
            if clients_dir(settings).resolve() in client.folder.resolve().parents:  # real clients keep it
                save(client, d)
        except (KeyError, OSError):
            pass
    return d


def similarity(a: dict, b: dict) -> float:
    """0 (nothing in common) … 1 (identical): the look counts for half, each kind's lead layout shares the rest."""
    s = 0.5 if a["look"] == b["look"] else 0.0
    s += 0.5 * sum(layout_for(a, k) == layout_for(b, k) for k in KINDS) / len(KINDS)
    return round(s, 3)


def overview(settings: dict) -> list[dict]:
    """Every client's look, lead layouts and the closest other client."""
    rows = []
    for folder in list_clients(settings):
        try:
            c = load_client(str(folder), settings)
        except Exception:
            continue
        rows.append({"slug": c.slug, "name": c.brand.get("client", c.slug), "dna": get(c, settings)})
    for r in rows:
        best = max(((similarity(r["dna"], o["dna"]), o["name"]) for o in rows if o is not r and o["dna"] and r["dna"]),
                   default=(0.0, ""))
        r["closest"], r["closest_name"] = best
        r["look_name"] = looks.LOOKS[r["dna"]["look"]]["name"] if r["dna"] else ""
    return rows
