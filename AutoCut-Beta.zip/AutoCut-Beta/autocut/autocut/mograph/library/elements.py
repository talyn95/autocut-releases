"""Layouts: every motion element AutoCut can draw, each in several distinct layouts. A layout is structure and its own
signature move; the look (looks.py) supplies type, shapes, colour roles and the entrance vocabulary, so each layout
reads differently in every look.

Kinds (and what they're for):
  lower_third   name + role over a speaker              tab underline bracket pills split slash dot badge bars outline
  title         hook / headline / section title         stack mask outline boxed split bignum
  chart         numbers people should remember           bars columns line donut meter compare counters waffle timeline funnel
  callout       point at something in the shot          arrow ring tag
  list          steps, checklists, features              steps checklist cards
  quote         testimonials and pull quotes             quote review
  end_card      logo + call to action                    center split stack
  transition    a full-frame cover between shots         wipe slats iris diagonal

Every layout is `fn(c: Ctx, p: params, sid: scene id, t0: start s, dur: s) -> Part`; times are absolute.
"""
from __future__ import annotations

import math

from .compose import Ctx, Part, esc, parse_items, plain, words

PARAMS = {
    "lower_third": [("name", "Name"), ("title", "Role / title")],
    "title": [("text", "Title (*word* = accent)"), ("kicker", "Kicker (small line above)"), ("sub", "Subtitle")],
    "chart": [("title", "Chart title"), ("items", "Data, one per line: Label: value"), ("value", "Single value (donut, meter, waffle)"),
              ("label", "Label for the single value")],
    "callout": [("text", "Label"), ("x", "Points at x % (0-100)"), ("y", "Points at y % (0-100)")],
    "list": [("title", "Title"), ("items", "Items, one per line")],
    "quote": [("text", "Quote"), ("author", "Who said it"), ("role", "Their role / place"), ("stars", "Stars (0-5)")],
    "end_card": [("text", "Call to action"), ("sub", "Website / handle")],
    "transition": [],
}
DURATION = {"lower_third": 4.5, "title": 3.0, "chart": 5.0, "callout": 3.5, "list": 5.5, "quote": 5.0, "end_card": 3.6,
            "transition": 0.9}
EXIT = 0.45


def _fs(n: float) -> str:
    """A type size in 1080-px units, scaled by the frame and by --t (larger on vertical)."""
    return f"calc(var(--u) * var(--t) * {n:g})"


def _anchor_lt(c: Ctx) -> str:
    if c.vertical:
        return f"left: 50%; top: {c.y * 100:.1f}%; transform: translate(-50%, -50%);"
    return f"left: calc(var(--u) * 110); top: {c.y * 100:.1f}%; transform: translateY(-50%);"


def _anchor_mid(c: Ctx) -> str:
    return (f"left: 50%; top: {c.y * 100:.1f}%; transform: translate(-50%, -50%); width: {86 if c.vertical else 80}%;"
            " display: flex; flex-direction: column; align-items: center; text-align: center;")


def _chars(c: Ctx) -> bool:
    return c.look["enter"] in ("type", "glitch")


def _w(c: Ctx, text) -> str:
    return words(text, _chars(c))


def _exit(sid: str, t0: float, dur: float, c: Ctx, sel: str = "") -> str:
    return f'out("#{sid} {sel or ".anc"}", {t0 + dur - EXIT * min(1.0, c.D) - 0.05:.3f});'


def _title_size(text: str, big: float = 140, small: float = 64) -> float:
    n = len(plain(text))
    return max(small, min(big, big - (n - 10) * 1.8))


def _initials(name: str) -> str:
    parts = [w for w in plain(name).split() if w[:1].isalpha()]
    return "".join(w[0].upper() for w in parts[:2]) or "•"


# ---- lower thirds --------------------------------------------------------------------------------------------

def lt_tab(c, p, sid, t0, dur):
    role = f'<div class="bd acc ltt-role">{_w(c, p.get("title"))}</div>' if p.get("title") else ""
    h = (f'<div class="anc" style="{_anchor_lt(c)}"><div class="pn ltt"><div class="accb ltt-tab"></div>'
         f'<div class="ltt-body"><div class="hd ltt-name">{_w(c, p.get("name"))}</div>{role}</div></div></div>')
    css = (f".ltt {{ display: flex; align-items: stretch; overflow: hidden; }} .ltt-tab {{ width: calc(var(--u) * 14); flex-shrink: 0; }}"
           f".ltt-body {{ padding: calc(var(--u) * 24) calc(var(--u) * 46) calc(var(--u) * 26) calc(var(--u) * 30); text-align: left; }}"
           f".ltt-name {{ font-size: {_fs(54)}; white-space: nowrap; }} .ltt-role {{ font-size: {_fs(29)}; margin-top: calc(var(--u) * 8); white-space: nowrap; }}")
    js = (f'boxIn("#{sid} .ltt", {t0 + 0.1:.3f}); tl.fromTo("#{sid} .ltt-tab", {{scaleY: 0, transformOrigin: "50% 0%"}}, '
          f'{{scaleY: 1, duration: 0.45 * D, ease: "power3.out"}}, {t0 + 0.25:.3f});'
          f'textIn("#{sid} .ltt-name", {t0 + 0.3:.3f}); textIn("#{sid} .ltt-role", {t0 + 0.45:.3f});' + _exit(sid, t0, dur, c))
    return Part(h, css, js, "lt_tab")


def lt_underline(c, p, sid, t0, dur):
    role = f'<div class="bd ltu-role">{_w(c, p.get("title"))}</div>' if p.get("title") else ""
    h = (f'<div class="anc float fl" style="{_anchor_lt(c)}"><div class="ltu"><div class="hd ltu-name">{_w(c, p.get("name"))}</div>'
         f'<div class="ltu-rule"></div>{role}</div></div>')
    css = (f".ltu {{ text-align: left; display: inline-flex; flex-direction: column; }} .ltu-name {{ font-size: {_fs(62)}; white-space: nowrap; }}"
           f".ltu-rule {{ height: calc(var(--u) * 7); background: var(--facc); margin: calc(var(--u) * 12) 0; border-radius: 99px; }}"
           f".full .ltu-rule {{ background: var(--stage-acc); }} .ltu-role {{ font-size: {_fs(30)}; opacity: 0.92; white-space: nowrap; }}")
    js = (f'textIn("#{sid} .ltu-name", {t0 + 0.1:.3f}); lineIn("#{sid} .ltu-rule", {t0 + 0.3:.3f});'
          f'textIn("#{sid} .ltu-role", {t0 + 0.55:.3f}, "fade");' + _exit(sid, t0, dur, c))
    return Part(h, css, js, "lt_underline")


def lt_bracket(c, p, sid, t0, dur):
    role = f'<div class="bd acc ltb-role">{_w(c, p.get("title"))}</div>' if p.get("title") else ""
    h = (f'<div class="anc" style="{_anchor_lt(c)}"><div class="ltb pn"><i class="ltb-c a"></i><i class="ltb-c b"></i>'
         f'<div class="hd ltb-name">{_w(c, p.get("name"))}</div>{role}</div></div>')
    css = (".ltb { position: relative; padding: calc(var(--u) * 26) calc(var(--u) * 48); text-align: left; box-shadow: none; }"
           ".ltb-c { position: absolute; width: calc(var(--u) * 46); height: calc(var(--u) * 46); border: 0 solid var(--acc); }"
           ".ltb-c.a { left: 0; top: 0; border-left-width: calc(var(--u) * 7); border-top-width: calc(var(--u) * 7); }"
           ".ltb-c.b { right: 0; bottom: 0; border-right-width: calc(var(--u) * 7); border-bottom-width: calc(var(--u) * 7); }"
           f".ltb-name {{ font-size: {_fs(56)}; white-space: nowrap; }} .ltb-role {{ font-size: {_fs(28)}; margin-top: calc(var(--u) * 8); white-space: nowrap; }}"
           ".ltb { background: transparent; } .ltb .hd { color: inherit; }")
    js = (f'tl.fromTo("#{sid} .ltb-c.a", {{x: 60 * U, y: 30 * U, opacity: 0}}, {{x: 0, y: 0, opacity: 1, duration: 0.6 * D, ease: "expo.out"}}, {t0 + 0.1:.3f});'
          f'tl.fromTo("#{sid} .ltb-c.b", {{x: -60 * U, y: -30 * U, opacity: 0}}, {{x: 0, y: 0, opacity: 1, duration: 0.6 * D, ease: "expo.out"}}, {t0 + 0.1:.3f});'
          f'textIn("#{sid} .ltb-name", {t0 + 0.3:.3f}); textIn("#{sid} .ltb-role", {t0 + 0.45:.3f});' + _exit(sid, t0, dur, c))
    return Part(h.replace('class="ltb pn"', 'class="ltb float fl"'), css, js, "lt_bracket")


def lt_pills(c, p, sid, t0, dur):
    role = f'<div class="ltp-role accb bd">{_w(c, p.get("title"))}</div>' if p.get("title") else ""
    h = (f'<div class="anc" style="{_anchor_lt(c)}"><div class="ltp"><div class="pn ltp-name hd">{_w(c, p.get("name"))}</div>{role}</div></div>')
    css = (".ltp { display: flex; flex-direction: column; align-items: flex-start; gap: calc(var(--u) * 10); }"
           f".ltp-name {{ border-radius: 999px; padding: calc(var(--u) * 18) calc(var(--u) * 44); font-size: {_fs(50)}; white-space: nowrap; }}"
           f".ltp-role {{ border-radius: 999px; padding: calc(var(--u) * 10) calc(var(--u) * 30); margin-left: calc(var(--u) * 46); font-size: {_fs(27)}; white-space: nowrap; }}")
    js = (f'boxIn("#{sid} .ltp-name", {t0 + 0.1:.3f}); textIn("#{sid} .ltp-name", {t0 + 0.25:.3f});'
          f'popIn("#{sid} .ltp-role", {t0 + 0.45:.3f}); textIn("#{sid} .ltp-role", {t0 + 0.55:.3f});' + _exit(sid, t0, dur, c))
    return Part(h, css, js, "lt_pills")


def lt_split(c, p, sid, t0, dur):
    role = f'<div class="lts-role accb bd">{_w(c, p.get("title"))}</div>' if p.get("title") else ""
    h = f'<div class="anc" style="{_anchor_lt(c)}"><div class="lts"><div class="pn lts-name hd">{_w(c, p.get("name"))}</div>{role}</div></div>'
    css = (".lts { display: flex; align-items: flex-end; }"
           f".lts-name {{ padding: calc(var(--u) * 22) calc(var(--u) * 36); font-size: {_fs(54)}; white-space: nowrap; position: relative; z-index: 2; }}"
           f".lts-role {{ padding: calc(var(--u) * 12) calc(var(--u) * 26); font-size: {_fs(26)}; white-space: nowrap; transform: translateY(calc(var(--u) * 18));"
           " border-radius: 0 var(--r) var(--r) 0; }")
    js = (f'boxIn("#{sid} .lts-name", {t0 + 0.1:.3f}); textIn("#{sid} .lts-name", {t0 + 0.25:.3f});'
          f'tl.fromTo("#{sid} .lts-role", {{xPercent: -100, opacity: 0}}, {{xPercent: 0, opacity: 1, duration: 0.55 * D, ease: "expo.out"}}, {t0 + 0.45:.3f});'
          + _exit(sid, t0, dur, c))
    return Part(h, css, js, "lt_split")


def lt_slash(c, p, sid, t0, dur):
    role = f'<div class="lth-role accb bd"><span>{_w(c, p.get("title"))}</span></div>' if p.get("title") else ""
    h = f'<div class="anc float fl" style="{_anchor_lt(c)}"><div class="lth">{role}<div class="hd lth-name">{_w(c, p.get("name"))}</div></div></div>'
    css = (".lth { display: flex; flex-direction: column; align-items: flex-start; }"
           f".lth-role {{ transform: skewX(-14deg); padding: calc(var(--u) * 8) calc(var(--u) * 26); font-size: {_fs(26)}; font-weight: 700;"
           " text-transform: uppercase; letter-spacing: 0.08em; white-space: nowrap; margin-bottom: calc(var(--u) * 10); text-shadow: none; }"
           ".lth-role > span { display: inline-block; transform: skewX(14deg); }"
           f".lth-name {{ font-size: {_fs(76)}; white-space: nowrap; font-style: italic; }}")
    js = (f'tl.fromTo("#{sid} .lth-role", {{clipPath: "polygon(0 0, 0 0, 0 100%, 0 100%)"}}, '
          f'{{clipPath: "polygon(0 0, 100% 0, 100% 100%, 0 100%)", duration: 0.45 * D, ease: "power4.out"}}, {t0 + 0.1:.3f});'
          f'textIn("#{sid} .lth-name", {t0 + 0.25:.3f}, "slide");' + _exit(sid, t0, dur, c))
    return Part(h, css, js, "lt_slash")


def lt_dot(c, p, sid, t0, dur):
    role = (f'<i class="ltd-div"></i><span class="bd ltd-role">{_w(c, p.get("title"))}</span>') if p.get("title") else ""
    h = (f'<div class="anc" style="{_anchor_lt(c)}"><div class="pn ltd"><i class="ltd-dot accb"></i><i class="ltd-ring"></i>'
         f'<span class="hd ltd-name">{_w(c, p.get("name"))}</span>{role}</div></div>')
    css = (".ltd { position: relative; display: flex; align-items: center; gap: calc(var(--u) * 20); border-radius: 999px;"
           " padding: calc(var(--u) * 18) calc(var(--u) * 40) calc(var(--u) * 18) calc(var(--u) * 26); white-space: nowrap; }"
           ".ltd-dot { width: calc(var(--u) * 20); height: calc(var(--u) * 20); border-radius: 50%; flex-shrink: 0; }"
           ".ltd-ring { position: absolute; left: calc(var(--u) * 16); width: calc(var(--u) * 40); height: calc(var(--u) * 40); border-radius: 50%;"
           " border: calc(var(--u) * 3) solid var(--acc); }"
           f".ltd-name {{ font-size: {_fs(42)}; }} .ltd-div {{ width: calc(var(--u) * 2); height: calc(var(--u) * 40); background: currentColor; opacity: 0.35; }}"
           f".ltd-role {{ font-size: {_fs(30)}; opacity: 0.85; }}")
    js = (f'boxIn("#{sid} .ltd", {t0 + 0.1:.3f}); popIn("#{sid} .ltd-dot", {t0 + 0.2:.3f});'
          f'tl.fromTo("#{sid} .ltd-ring", {{scale: 0.4, opacity: 1}}, {{scale: 1.6, opacity: 0, duration: 1.2 * D, ease: "power2.out", repeat: 2}}, {t0 + 0.3:.3f});'
          f'textIn("#{sid} .ltd-name", {t0 + 0.3:.3f}); textIn("#{sid} .ltd-role", {t0 + 0.5:.3f}, "fade");' + _exit(sid, t0, dur, c))
    return Part(h, css, js, "lt_dot")


def lt_badge(c, p, sid, t0, dur):
    logo = c.assets.get("logo")
    mark = f'<img src="{logo}" alt="">' if logo else f'<span class="hd">{esc(_initials(p.get("name", "")))}</span>'
    role = f'<div class="bd ltg-role">{_w(c, p.get("title"))}</div>' if p.get("title") else ""
    h = (f'<div class="anc" style="{_anchor_lt(c)}"><div class="ltg"><div class="ltg-mark accb">{mark}</div>'
         f'<div class="ltg-text pn"><div class="hd ltg-name">{_w(c, p.get("name"))}</div>{role}</div></div></div>')
    css = (".ltg { display: flex; align-items: center; }"
           ".ltg-mark { width: calc(var(--u) * 132); height: calc(var(--u) * 132); border-radius: 50%; display: flex; align-items: center;"
           " justify-content: center; flex-shrink: 0; position: relative; z-index: 2; overflow: hidden; box-shadow: var(--sh); }"
           f".ltg-mark span {{ font-size: {_fs(52)}; }} .ltg-mark img {{ width: 70%; height: 70%; object-fit: contain; }}"
           ".ltg-text { margin-left: calc(var(--u) * -40); padding: calc(var(--u) * 20) calc(var(--u) * 44) calc(var(--u) * 20) calc(var(--u) * 64);"
           " text-align: left; white-space: nowrap; }"
           f".ltg-name {{ font-size: {_fs(48)}; }} .ltg-role {{ font-size: {_fs(27)}; opacity: 0.85; margin-top: calc(var(--u) * 6); }}")
    js = (f'tl.fromTo("#{sid} .ltg-mark", {{scale: 0, rotation: -90}}, {{scale: 1, rotation: 0, duration: 0.6 * D, ease: "back.out(1.8)"}}, {t0 + 0.1:.3f});'
          f'tl.fromTo("#{sid} .ltg-text", {{clipPath: "inset(0 100% 0 0)"}}, {{clipPath: "inset(0 0% 0 0)", duration: 0.6 * D, ease: "expo.out"}}, {t0 + 0.35:.3f});'
          f'textIn("#{sid} .ltg-name", {t0 + 0.45:.3f}); textIn("#{sid} .ltg-role", {t0 + 0.6:.3f}, "fade");' + _exit(sid, t0, dur, c))
    return Part(h, css, js, "lt_badge")


def lt_bars(c, p, sid, t0, dur):
    role = f'<div class="ltr-top accb bd">{_w(c, p.get("title"))}</div>' if p.get("title") else ""
    h = f'<div class="anc" style="{_anchor_lt(c)}"><div class="ltr">{role}<div class="ltr-main pn hd">{_w(c, p.get("name"))}</div></div></div>'
    css = (".ltr { display: flex; flex-direction: column; align-items: flex-start; }"
           f".ltr-top {{ padding: calc(var(--u) * 8) calc(var(--u) * 24); font-size: {_fs(24)}; font-weight: 700; text-transform: uppercase;"
           " letter-spacing: 0.1em; white-space: nowrap; border-radius: var(--r) var(--r) 0 0; }"
           f".ltr-main {{ padding: calc(var(--u) * 16) calc(var(--u) * 40) calc(var(--u) * 16) calc(var(--u) * 24); font-size: {_fs(52)};"
           " white-space: nowrap; border-radius: 0 var(--r) var(--r) var(--r); min-width: calc(var(--u) * 420); }")
    js = (f'boxIn("#{sid} .ltr-main", {t0 + 0.1:.3f}); boxIn("#{sid} .ltr-top", {t0 + 0.25:.3f}, "up");'
          f'textIn("#{sid} .ltr-main", {t0 + 0.3:.3f});' + _exit(sid, t0, dur, c))
    return Part(h, css, js, "lt_bars")


def lt_outline(c, p, sid, t0, dur):
    role = f'<div class="bd ltl-kick">{_w(c, p.get("title"))}</div>' if p.get("title") else ""
    h = (f'<div class="anc float fl" style="{_anchor_lt(c)}"><div class="ltl">{role}<div class="ltl-box"><div class="hd ltl-name">'
         f'{_w(c, p.get("name"))}</div></div></div></div>')
    css = (f".ltl-kick {{ font-size: {_fs(24)}; text-transform: uppercase; letter-spacing: 0.22em; color: var(--facc); margin-bottom: calc(var(--u) * 10); white-space: nowrap; }}"
           ".full .ltl-kick { color: var(--stage-acc); }"
           ".ltl-box { border: calc(var(--u) * 4) solid var(--facc); padding: calc(var(--u) * 16) calc(var(--u) * 34); display: inline-block;"
           " border-radius: var(--r); } .full .ltl-box { border-color: var(--stage-acc); }"
           f".ltl-name {{ font-size: {_fs(54)}; white-space: nowrap; }} .ltl {{ text-align: left; }}")
    js = (f'tl.fromTo("#{sid} .ltl-box", {{clipPath: "inset(0 50% 0 50%)"}}, {{clipPath: "inset(0 0% 0 0%)", duration: 0.6 * D, ease: "power3.inOut"}}, {t0 + 0.1:.3f});'
          f'textIn("#{sid} .ltl-name", {t0 + 0.35:.3f}); textIn("#{sid} .ltl-kick", {t0 + 0.2:.3f}, "fade");' + _exit(sid, t0, dur, c))
    return Part(h, css, js, "lt_outline")


LAYOUTS: dict[str, dict] = {"lower_third": {"tab": lt_tab, "underline": lt_underline, "bracket": lt_bracket, "pills": lt_pills,
                                            "split": lt_split, "slash": lt_slash, "dot": lt_dot, "badge": lt_badge,
                                            "bars": lt_bars, "outline": lt_outline}}


# ---- titles --------------------------------------------------------------------------------------------------

def _title_wrap(c: Ctx, cls: str) -> str:
    return "float fl" if not c.full else "float"


def ti_stack(c, p, sid, t0, dur):
    text = p.get("text") or p.get("title") or ""
    fs = _title_size(text)
    kick = f'<div class="bd tis-kick">{_w(c, p.get("kicker"))}</div>' if p.get("kicker") else ""
    sub = f'<div class="bd tis-sub">{_w(c, p.get("sub"))}</div>' if p.get("sub") else ""
    h = (f'<div class="anc {_title_wrap(c, "tis")}" style="{_anchor_mid(c)}">{kick}<div class="hd tis-t" style="font-size:{_fs(fs)}">'
         f'{_w(c, text)}</div><div class="tis-rule"></div>{sub}</div>')
    css = (f".tis-kick {{ font-size: {_fs(28)}; text-transform: uppercase; letter-spacing: 0.24em; color: var(--facc); margin-bottom: calc(var(--u) * 18); }}"
           ".full .tis-kick { color: var(--stage-acc); }"
           ".tis-t { text-wrap: balance; max-width: 100%; } .tis-rule { width: calc(var(--u) * 120); height: calc(var(--u) * 8); background: var(--facc);"
           " margin-top: calc(var(--u) * 26); border-radius: 99px; } .full .tis-rule { background: var(--stage-acc); }"
           f".tis-sub {{ font-size: {_fs(34)}; margin-top: calc(var(--u) * 20); opacity: 0.9; }}")
    js = (f'textIn("#{sid} .tis-kick", {t0 + 0.05:.3f}, "fade"); textIn("#{sid} .tis-t", {t0 + 0.15:.3f});'
          f'lineIn("#{sid} .tis-rule", {t0 + 0.5:.3f}, "50% 50%"); textIn("#{sid} .tis-sub", {t0 + 0.7:.3f}, "fade");' + _exit(sid, t0, dur, c))
    return Part(h, css, js, "ti_stack")


def ti_mask(c, p, sid, t0, dur):
    text = p.get("text") or ""
    fs = _title_size(text, 118)
    sub = f'<div class="bd tim-sub">{_w(c, p.get("sub") or p.get("kicker"))}</div>' if (p.get("sub") or p.get("kicker")) else ""
    body = _w(c, text).replace('<span class="w k"><span class="wi">', '<span class="w k"><i class="tim-hl"></i><span class="wi">')
    h = (f'<div class="anc {_title_wrap(c, "tim")}" style="{_anchor_mid(c)}"><div class="hd tim-t" style="font-size:{_fs(fs)}">{body}</div>{sub}</div>')
    css = (".tim-t { text-wrap: balance; } .tim-t .w { overflow: hidden; vertical-align: top; padding: 0 0.04em 0.06em; }"
           ".tim-t .w.k { overflow: visible; color: var(--acc-ink) !important; text-shadow: none; }"
           ".tim-hl { position: absolute; left: -0.06em; right: -0.06em; top: 0.06em; bottom: 0.02em; background: var(--acc); z-index: -1; }"
           ".tim-t .w.k .wi { position: relative; z-index: 1; }"
           f".tim-sub {{ font-size: {_fs(34)}; margin-top: calc(var(--u) * 24); opacity: 0.9; }}")
    js = (f'tl.fromTo("#{sid} .tim-t .wi", {{yPercent: 115}}, {{yPercent: 0, duration: 0.7 * D, ease: "expo.out", stagger: 0.06 * D}}, {t0 + 0.1:.3f});'
          f'tl.fromTo("#{sid} .tim-hl", {{scaleX: 0, transformOrigin: "0% 50%"}}, {{scaleX: 1, duration: 0.45 * D, ease: "power3.out"}}, {t0 + 0.55:.3f});'
          f'textIn("#{sid} .tim-sub", {t0 + 0.75:.3f}, "fade");' + _exit(sid, t0, dur, c))
    return Part(h, css, js, "ti_mask")


def ti_outline(c, p, sid, t0, dur):
    text = plain(p.get("text") or "")
    fs = _title_size(text, 140)
    h = (f'<div class="anc {_title_wrap(c, "tio")}" style="{_anchor_mid(c)}"><div class="tio">'
         f'<div class="hd tio-ghost" style="font-size:{_fs(fs)}">{esc(text)}</div>'
         f'<div class="hd tio-t" style="font-size:{_fs(fs)}">{_w(c, p.get("text"))}</div></div>'
         + (f'<div class="bd tio-sub">{_w(c, p.get("sub") or p.get("kicker"))}</div>' if (p.get("sub") or p.get("kicker")) else "") + "</div>")
    css = (".tio { position: relative; display: grid; } .tio > * { grid-area: 1 / 1; text-wrap: balance; }"
           ".tio-ghost { color: transparent; -webkit-text-stroke: calc(var(--u) * 2.5) var(--facc); text-shadow: none; transform: translate(calc(var(--u) * 14), calc(var(--u) * 14)); }"
           ".full .tio-ghost { -webkit-text-stroke-color: var(--stage-acc); }"
           f".tio-sub {{ font-size: {_fs(32)}; margin-top: calc(var(--u) * 26); opacity: 0.9; }}")
    js = (f'tl.fromTo("#{sid} .tio-ghost", {{x: 70 * U, y: 40 * U, opacity: 0}}, {{x: 14 * U, y: 14 * U, opacity: 1, duration: 0.8 * D, ease: "expo.out"}}, {t0 + 0.1:.3f});'
          f'textIn("#{sid} .tio-t", {t0 + 0.25:.3f}); textIn("#{sid} .tio-sub", {t0 + 0.7:.3f}, "fade");' + _exit(sid, t0, dur, c))
    return Part(h, css, js, "ti_outline")


def _lines(text: str, n: int = 3) -> list[str]:
    raw = [x.strip() for x in str(text or "").split(" / ") if x.strip()]
    if len(raw) > 1:
        return raw[:4]
    ws = str(text or "").split()
    if len(ws) <= 3:
        return [" ".join(ws)]
    k = 2 if len(ws) <= 7 else 3
    size = math.ceil(len(ws) / k)
    return [" ".join(ws[i:i + size]) for i in range(0, len(ws), size)]


def ti_boxed(c, p, sid, t0, dur):
    lines = _lines(p.get("text") or "")
    longest = max(len(plain(x)) for x in lines)
    fs = max(54, min(110, 110 - (longest - 10) * 3))
    rows = "".join(f'<div class="tib-row" style="margin-left:{(i % 2) * 6}%"><div class="pn tib-box hd" style="font-size:{_fs(fs)}">{_w(c, ln)}</div></div>'
                   for i, ln in enumerate(lines))
    h = f'<div class="anc" style="{_anchor_mid(c)}"><div class="tib">{rows}</div></div>'
    css = (".tib { display: flex; flex-direction: column; align-items: center; gap: calc(var(--u) * 10); }"
           ".tib-box { display: inline-block; padding: calc(var(--u) * 10) calc(var(--u) * 30); white-space: nowrap; }")
    js = "".join(f'boxIn("#{sid} .tib-row:nth-child({i + 1}) .tib-box", {t0 + 0.1 + i * 0.16:.3f}, "{["left", "right"][i % 2]}");'
                 f'textIn("#{sid} .tib-row:nth-child({i + 1}) .tib-box", {t0 + 0.25 + i * 0.16:.3f});' for i in range(len(lines)))
    return Part(h, css, js + _exit(sid, t0, dur, c), "ti_boxed")


def ti_split(c, p, sid, t0, dur):
    ws = str(p.get("text") or "").split()
    half = max(1, len(ws) // 2)
    a, b = " ".join(ws[:half]), " ".join(ws[half:])
    fs = _title_size(p.get("text") or "", 120)
    h = (f'<div class="anc {_title_wrap(c, "tip")}" style="{_anchor_mid(c)}"><div class="hd tip-a" style="font-size:{_fs(fs)}">{_w(c, a)}</div>'
         f'<div class="tip-bar"></div><div class="hd tip-b" style="font-size:{_fs(fs)}">{_w(c, b)}</div></div>')
    css = (".tip-bar { width: 70%; height: calc(var(--u) * 6); background: var(--facc); margin: calc(var(--u) * 14) 0; } .full .tip-bar { background: var(--stage-acc); }"
           ".tip-a, .tip-b { text-wrap: balance; }")
    js = (f'lineIn("#{sid} .tip-bar", {t0 + 0.05:.3f}, "50% 50%");'
          f'tl.fromTo("#{sid} .tip-a", {{x: -160 * U, opacity: 0}}, {{x: 0, opacity: 1, duration: 0.7 * D, ease: "expo.out"}}, {t0 + 0.25:.3f});'
          f'tl.fromTo("#{sid} .tip-b", {{x: 160 * U, opacity: 0}}, {{x: 0, opacity: 1, duration: 0.7 * D, ease: "expo.out"}}, {t0 + 0.32:.3f});'
          + _exit(sid, t0, dur, c))
    return Part(h, css, js, "ti_split")


def ti_bignum(c, p, sid, t0, dur):
    text = p.get("text") or ""
    big = plain(p.get("kicker") or (str(text).split() or [""])[0])
    bfs = max(160, min(420, 1800 / max(2, len(big))))
    fs = _title_size(text, 100)
    h = (f'<div class="anc {_title_wrap(c, "tin")}" style="{_anchor_mid(c)}"><div class="tin"><div class="nm tin-big" style="font-size:{_fs(bfs)}">{esc(big)}</div>'
         f'<div class="hd tin-t" style="font-size:{_fs(fs)}">{_w(c, text)}</div></div></div>')
    css = (".tin { position: relative; display: grid; place-items: center; } .tin > * { grid-area: 1 / 1; }"
           ".tin-big { color: var(--facc); opacity: 0.2; text-shadow: none; } .full .tin-big { color: var(--stage-acc); opacity: 0.18; }"
           ".tin-t { position: relative; text-wrap: balance; }")
    js = (f'tl.fromTo("#{sid} .tin-big", {{scale: 1.4, opacity: 0}}, {{scale: 1, opacity: {0.18 if c.full else 0.22}, duration: 1.0 * D, ease: "expo.out"}}, {t0 + 0.05:.3f});'
          f'tl.to("#{sid} .tin-big", {{scale: 1.06, duration: {dur:.2f}, ease: "none"}}, {t0 + 1.0:.3f});'
          f'textIn("#{sid} .tin-t", {t0 + 0.3:.3f});' + _exit(sid, t0, dur, c))
    return Part(h, css, js, "ti_bignum")


LAYOUTS["title"] = {"stack": ti_stack, "mask": ti_mask, "outline": ti_outline, "boxed": ti_boxed, "split": ti_split,
                    "bignum": ti_bignum}


# ---- charts --------------------------------------------------------------------------------------------------

def _items(p, n=6):
    rows = [r for r in parse_items(p.get("items")) if r["num"] is not None][:n]
    return rows or [{"label": "A", "value": "40", "num": 40.0, "pre": "", "suf": "", "dec": 0},
                    {"label": "B", "value": "70", "num": 70.0, "pre": "", "suf": "", "dec": 0}]


def _single(p):
    rows = parse_items(f"x: {p.get('value')}") if p.get("value") else [r for r in _items(p)][:1]
    r = rows[0] if rows and rows[0]["num"] is not None else {"num": 50.0, "pre": "", "suf": "%", "dec": 0, "label": ""}
    return r, (p.get("label") or ("" if p.get("value") else r.get("label", "")))


def _card(c: Ctx) -> str:
    """Charts sit on the look's panel over footage; on a full-frame scene they sit on the stage."""
    return "pn ch-card" if not c.full or c.look["panel"] not in ("none",) else "ch-card"


def _chart_head(c, p):
    return f'<div class="hd ch-title">{_w(c, p.get("title"))}</div>' if p.get("title") else ""


CH_CSS = ""  # shared chart CSS lives in compose.look_css (written once per page)


def _num_html(sid: str, k: int, r: dict, cls: str = "nm") -> str:
    return (f'<span class="{cls}"><span>{esc(r["pre"])}</span><span id="{sid}n{k}">0</span><span>{esc(r["suf"])}</span></span>')


def _count_js(sid: str, k: int, r: dict, t: float, d: float = 1.2) -> str:
    return f'countUp("#{sid}n{k}", {r["num"]}, {r["dec"]}, {t:.3f}, {d});'


def _chart_anchor(c: Ctx, w_land: int = 62, w_vert: int = 86) -> str:
    return (f"left: 50%; top: {c.y * 100:.1f}%; transform: translate(-50%, -50%); width: {w_vert if c.vertical else w_land}%;")


def ch_bars(c, p, sid, t0, dur):
    rows = _items(p)
    top = max(r["num"] for r in rows) or 1
    bars = "".join(f'<div class="chb-row"><div class="bd ch-lab">{esc(r["label"])}</div><div class="chb-track"><div class="chb-bar accb" '
                   f'style="width:{max(4, 100 * r["num"] / top):.1f}%"></div>{_num_html(sid, k, r, "nm ch-val chb-v")}</div></div>'
                   for k, r in enumerate(rows))
    h = f'<div class="anc" style="{_chart_anchor(c)}"><div class="{_card(c)}">{_chart_head(c, p)}<div class="chb">{bars}</div></div></div>'
    css = CH_CSS + (".chb { display: flex; flex-direction: column; gap: calc(var(--u) * 18); text-align: left; }"
                    ".chb-track { display: flex; align-items: center; gap: calc(var(--u) * 16); }"
                    ".chb-bar { height: calc(var(--u) * 38); border-radius: calc(var(--rc) * 0.4); flex-shrink: 0; max-width: 80%; }"
                    ".chb-v { white-space: nowrap; }")
    js = f'boxIn("#{sid} .ch-card", {t0 + 0.05:.3f}); textIn("#{sid} .ch-title", {t0 + 0.2:.3f});'
    for k, r in enumerate(rows):
        t = t0 + 0.45 + k * 0.14
        js += (f'tl.fromTo("#{sid} .chb-row:nth-child({k + 1}) .chb-bar", {{scaleX: 0, transformOrigin: "0% 50%"}}, {{scaleX: 1, duration: 0.9 * D, ease: "expo.out"}}, {t:.3f});'
               f'tl.fromTo("#{sid} .chb-row:nth-child({k + 1}) .ch-lab", {{opacity: 0}}, {{opacity: 0.85, duration: 0.3 * D}}, {t:.3f});' + _count_js(sid, k, r, t))
    return Part(h, css, js + _exit(sid, t0, dur, c), "ch_bars")


def ch_columns(c, p, sid, t0, dur):
    rows = _items(p)
    top = max(r["num"] for r in rows) or 1
    cols = "".join(f'<div class="chc-col">{_num_html(sid, k, r, "nm ch-val")}<div class="chc-bar accb" style="height:{max(3, 100 * r["num"] / top):.1f}%"></div>'
                   f'<div class="bd ch-lab">{esc(r["label"])}</div></div>' for k, r in enumerate(rows))
    h = f'<div class="anc" style="{_chart_anchor(c, 56)}"><div class="{_card(c)}">{_chart_head(c, p)}<div class="chc">{cols}</div></div></div>'
    css = CH_CSS + (".chc { display: flex; align-items: flex-end; gap: calc(var(--u) * 24); height: calc(var(--u) * 380);"
                    " border-bottom: calc(var(--u) * 3) solid currentColor; padding-bottom: 0; }"
                    ".chc-col { flex: 1; height: 100%; display: flex; flex-direction: column; justify-content: flex-end; align-items: center; gap: calc(var(--u) * 10); }"
                    ".chc-bar { width: 100%; border-radius: calc(var(--rc) * 0.4) calc(var(--rc) * 0.4) 0 0; } .chc .ch-lab { margin-bottom: calc(var(--u) * -44); }"
                    ".chc + * { } .ch-card:has(.chc) { padding-bottom: calc(var(--u) * 70); }")
    js = f'boxIn("#{sid} .ch-card", {t0 + 0.05:.3f}); textIn("#{sid} .ch-title", {t0 + 0.2:.3f});'
    for k, r in enumerate(rows):
        t = t0 + 0.45 + k * 0.12
        js += (f'tl.fromTo("#{sid} .chc-col:nth-child({k + 1}) .chc-bar", {{scaleY: 0, transformOrigin: "50% 100%"}}, {{scaleY: 1, duration: 0.9 * D, ease: "expo.out"}}, {t:.3f});'
               + _count_js(sid, k, r, t))
    return Part(h, css, js + _exit(sid, t0, dur, c), "ch_columns")


def ch_line(c, p, sid, t0, dur):
    rows = _items(p, 8)
    vals = [r["num"] for r in rows]
    lo, hi = min(vals + [0]), max(vals) or 1
    Wv, Hv = 1000, 420
    pts = [(40 + i * (Wv - 80) / max(1, len(vals) - 1), Hv - 30 - (v - lo) / ((hi - lo) or 1) * (Hv - 80)) for i, v in enumerate(vals)]
    path = "M" + " L".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    area = path + f" L{pts[-1][0]:.1f},{Hv} L{pts[0][0]:.1f},{Hv} Z"
    dots = "".join(f'<circle class="chl-dot" cx="{x:.1f}" cy="{y:.1f}" r="10"/>' for x, y in pts)
    labels = "".join(f'<span class="bd ch-lab" style="left:{x / Wv * 100:.1f}%">{esc(r["label"])}</span>' for (x, _), r in zip(pts, rows))
    last = rows[-1]
    h = (f'<div class="anc" style="{_chart_anchor(c, 60)}"><div class="{_card(c)}">{_chart_head(c, p)}'
         f'<div class="chl"><svg viewBox="0 0 {Wv} {Hv}" preserveAspectRatio="none"><defs><linearGradient id="{sid}g" x1="0" y1="0" x2="0" y2="1">'
         f'<stop offset="0" stop-color="var(--acc)" stop-opacity="0.45"/><stop offset="1" stop-color="var(--acc)" stop-opacity="0"/></linearGradient></defs>'
         f'<path class="chl-area" d="{area}" fill="url(#{sid}g)"/><path class="chl-path" d="{path}"/>{dots}</svg>'
         f'<div class="chl-labs">{labels}</div><div class="chl-end accb" style="left:{pts[-1][0] / Wv * 100:.1f}%;top:{pts[-1][1] / Hv * 100:.1f}%">'
         f'{_num_html(sid, 0, last, "nm ch-val")}</div></div></div></div>')
    css = CH_CSS + (".chl { position: relative; height: calc(var(--u) * 360); } .chl svg { width: 100%; height: 100%; overflow: visible; }"
                    ".chl-path { fill: none; stroke: var(--acc); stroke-width: 7; stroke-linecap: round; stroke-linejoin: round; vector-effect: non-scaling-stroke; }"
                    ".chl-dot { fill: var(--acc); } .chl-labs { position: relative; height: calc(var(--u) * 40); }"
                    ".chl-labs .ch-lab { position: absolute; transform: translateX(-50%); top: calc(var(--u) * 10); }"
                    ".chl-end { position: absolute; transform: translate(-50%, -150%); padding: calc(var(--u) * 8) calc(var(--u) * 18); border-radius: calc(var(--u) * 12); }")
    js = (f'boxIn("#{sid} .ch-card", {t0 + 0.05:.3f}); textIn("#{sid} .ch-title", {t0 + 0.2:.3f});'
          f'strokeIn("#{sid} .chl-path", {t0 + 0.45:.3f}, 1.4);'
          f'tl.fromTo("#{sid} .chl-area", {{opacity: 0}}, {{opacity: 1, duration: 0.8 * D}}, {t0 + 1.2:.3f});'
          f'popIn("#{sid} .chl-dot", {t0 + 0.5:.3f}, {1.2 / max(1, len(pts)):.3f});'
          f'tl.fromTo("#{sid} .chl-labs .ch-lab", {{opacity: 0}}, {{opacity: 0.85, duration: 0.4 * D, stagger: 0.1 * D}}, {t0 + 0.5:.3f});'
          f'popIn("#{sid} .chl-end", {t0 + 1.6:.3f});' + _count_js(sid, 0, last, t0 + 1.6, 0.9))
    return Part(h, css, js + _exit(sid, t0, dur, c), "ch_line")


def ch_donut(c, p, sid, t0, dur):
    r, label = _single(p)
    pct = max(0.0, min(100.0, r["num"] if r["suf"].strip() == "%" or r["num"] <= 100 else 100))
    R = 160
    circ = 2 * math.pi * R
    h = (f'<div class="anc" style="{_chart_anchor(c, 36, 70)}"><div class="{_card(c)} chd-card">{_chart_head(c, p)}<div class="chd">'
         f'<svg viewBox="0 0 400 400"><circle class="chd-track" cx="200" cy="200" r="{R}"/><circle class="chd-arc" cx="200" cy="200" r="{R}" '
         f'style="stroke-dasharray:{circ:.1f};stroke-dashoffset:{circ:.1f}"/></svg><div class="chd-mid">{_num_html(sid, 0, r, "nm chd-n")}</div></div>'
         + (f'<div class="bd chd-lab">{_w(c, label)}</div>' if label else "") + "</div></div>")
    css = CH_CSS + (".chd-card { align-items: center; text-align: center; } .chd { position: relative; width: calc(var(--u) * 400); height: calc(var(--u) * 400); }"
                    ".chd svg { width: 100%; height: 100%; transform: rotate(-90deg); }"
                    ".chd-track { fill: none; stroke: currentColor; opacity: 0.15; stroke-width: 34; }"
                    ".chd-arc { fill: none; stroke: var(--acc); stroke-width: 34; stroke-linecap: round; }"
                    f".chd-mid {{ position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; }} .chd-n {{ font-size: {_fs(96)}; }}"
                    f".chd-lab {{ font-size: {_fs(34)}; max-width: calc(var(--u) * 520); }}")
    js = (f'boxIn("#{sid} .ch-card", {t0 + 0.05:.3f}); textIn("#{sid} .ch-title", {t0 + 0.15:.3f});'
          f'tl.to("#{sid} .chd-arc", {{strokeDashoffset: {circ * (1 - pct / 100):.1f}, duration: 1.4 * D, ease: "power3.inOut"}}, {t0 + 0.35:.3f});'
          + _count_js(sid, 0, r, t0 + 0.35, 1.4) + f'textIn("#{sid} .chd-lab", {t0 + 0.8:.3f}, "fade");')
    return Part(h, css, js + _exit(sid, t0, dur, c), "ch_donut")


def ch_meter(c, p, sid, t0, dur):
    r, label = _single(p)
    pct = max(0.0, min(100.0, r["num"]))
    h = (f'<div class="anc" style="{_chart_anchor(c, 56)}"><div class="{_card(c)}">{_chart_head(c, p)}<div class="chm-top">{_num_html(sid, 0, r, "nm chm-n")}'
         + (f'<div class="bd chm-lab">{_w(c, label)}</div>' if label else "")
         + f'</div><div class="chm-track"><div class="chm-fill accb" style="width:{pct:.1f}%"><i class="chm-tip"></i></div></div></div></div>')
    css = CH_CSS + (".chm-top { display: flex; align-items: baseline; gap: calc(var(--u) * 24); text-align: left; flex-wrap: wrap; }"
                    f".chm-n {{ font-size: {_fs(150)}; }} .chm-n span:first-child, .chm-n span:last-child {{ color: var(--acc); }}"
                    f".chm-lab {{ font-size: {_fs(36)}; flex: 1; min-width: 40%; }}"
                    ".chm-track { height: calc(var(--u) * 30); border-radius: 999px; background: rgba(127,127,127,0.25); overflow: hidden; }"
                    ".chm-fill { height: 100%; border-radius: 999px; position: relative; }"
                    ".chm-tip { position: absolute; right: 0; top: 0; bottom: 0; width: calc(var(--u) * 30); background: rgba(255,255,255,0.5); border-radius: 999px; }")
    js = (f'boxIn("#{sid} .ch-card", {t0 + 0.05:.3f}); textIn("#{sid} .ch-title", {t0 + 0.15:.3f});'
          f'tl.fromTo("#{sid} .chm-fill", {{scaleX: 0, transformOrigin: "0% 50%"}}, {{scaleX: 1, duration: 1.4 * D, ease: "power3.inOut"}}, {t0 + 0.4:.3f});'
          + _count_js(sid, 0, r, t0 + 0.4, 1.4) + f'textIn("#{sid} .chm-lab", {t0 + 0.6:.3f}, "fade");')
    return Part(h, css, js + _exit(sid, t0, dur, c), "ch_meter")


def ch_compare(c, p, sid, t0, dur):
    rows = _items(p)[:2]
    if len(rows) < 2:
        rows = rows + [{"label": "After", "value": "0", "num": 0.0, "pre": "", "suf": "", "dec": 0}]
    top = max(r["num"] for r in rows) or 1
    best = 1 if p.get("lower_is_better") else max(range(2), key=lambda i: rows[i]["num"])
    if p.get("lower_is_better"):
        best = min(range(2), key=lambda i: rows[i]["num"])
    cols = "".join(f'<div class="chv-col{" best" if i == best else ""}">{_num_html(sid, i, r, "nm chv-n")}<div class="chv-bar" style="height:{max(4, 100 * r["num"] / top):.1f}%"></div>'
                   f'<div class="bd chv-lab">{esc(r["label"])}</div></div>' for i, r in enumerate(rows))
    h = (f'<div class="anc" style="{_chart_anchor(c, 48, 80)}"><div class="{_card(c)}">{_chart_head(c, p)}<div class="chv">{cols}'
         f'<div class="hd chv-vs">vs</div></div></div></div>')
    css = CH_CSS + (".chv { position: relative; display: flex; gap: calc(var(--u) * 70); height: calc(var(--u) * 460); align-items: flex-end; padding-bottom: calc(var(--u) * 54); }"
                    ".chv-col { flex: 1; height: 100%; display: flex; flex-direction: column; justify-content: flex-end; align-items: center; gap: calc(var(--u) * 12); position: relative; }"
                    ".chv-bar { width: 100%; background: rgba(127,127,127,0.45); border-radius: var(--rc) var(--rc) 0 0; max-height: 78%; }"
                    ".chv-col.best .chv-bar { background: var(--acc); } .chv-col.best .chv-n { color: var(--acc); }"
                    f".chv-n {{ font-size: {_fs(64)}; }} .chv-lab {{ position: absolute; bottom: calc(var(--u) * -50); font-size: {_fs(30)}; }}"
                    f".chv-vs {{ position: absolute; left: 50%; top: 40%; transform: translate(-50%, -50%); font-size: {_fs(40)}; opacity: 0.6; }}")
    js = f'boxIn("#{sid} .ch-card", {t0 + 0.05:.3f}); textIn("#{sid} .ch-title", {t0 + 0.15:.3f}); popIn("#{sid} .chv-vs", {t0 + 0.3:.3f});'
    for i, r in enumerate(rows):
        t = t0 + 0.45 + i * 0.5
        js += (f'tl.fromTo("#{sid} .chv-col:nth-child({i + 1}) .chv-bar", {{scaleY: 0, transformOrigin: "50% 100%"}}, {{scaleY: 1, duration: 1.0 * D, ease: "expo.out"}}, {t:.3f});'
               + _count_js(sid, i, r, t, 1.0))
    return Part(h, css, js + _exit(sid, t0, dur, c), "ch_compare")


def ch_counters(c, p, sid, t0, dur):
    rows = _items(p, 4)
    tiles = "".join(f'<div class="cht pn">{_num_html(sid, k, r, "nm cht-n")}<div class="bd ch-lab">{esc(r["label"])}</div></div>' for k, r in enumerate(rows))
    h = f'<div class="anc" style="{_chart_anchor(c, 80, 88)}">{_chart_head(c, p).replace("ch-title", "ch-title float fl cht-title")}<div class="chtg n{len(rows)}">{tiles}</div></div>'
    css = CH_CSS + (".chtg { display: grid; gap: calc(var(--u) * 22); grid-template-columns: repeat(var(--n), 1fr); }"
                    ".chtg.n1 { --n: 1; } .chtg.n2 { --n: 2; } .chtg.n3 { --n: 3; } .chtg.n4 { --n: 4; }"
                    + (".chtg.n3, .chtg.n4 { --n: 2; }" if c.vertical else "") +
                    ".cht { padding: calc(var(--u) * 34) calc(var(--u) * 26); display: flex; flex-direction: column; align-items: center; gap: calc(var(--u) * 10); text-align: center; }"
                    f".cht-n {{ font-size: {_fs(84)}; }} .cht-n span:first-child, .cht-n span:last-child {{ color: var(--acc); }}"
                    ".cht-title { text-align: center; margin-bottom: calc(var(--u) * 24); }")
    js = f'textIn("#{sid} .cht-title", {t0 + 0.05:.3f});'
    for k, r in enumerate(rows):
        t = t0 + 0.2 + k * 0.15
        js += f'boxIn("#{sid} .cht:nth-child({k + 1})", {t:.3f}, "up");' + _count_js(sid, k, r, t + 0.15)
    return Part(h, css, js + _exit(sid, t0, dur, c), "ch_counters")


def ch_waffle(c, p, sid, t0, dur):
    r, label = _single(p)
    n = int(round(max(0, min(100, r["num"]))))
    dots = "".join(f'<i class="chw-d{" on" if k < n else ""}"></i>' for k in range(100))
    h = (f'<div class="anc" style="{_chart_anchor(c, 60, 86)}"><div class="{_card(c)} chw-card"><div class="chw">{dots}</div><div class="chw-side">'
         f'{_chart_head(c, p)}{_num_html(sid, 0, r, "nm chw-n")}' + (f'<div class="bd chw-lab">{_w(c, label)}</div>' if label else "") + "</div></div></div>")
    css = CH_CSS + (".chw-card { flex-direction: row; align-items: center; gap: calc(var(--u) * 46); }"
                    + (".chw-card { flex-direction: column; }" if c.vertical else "") +
                    ".chw { display: grid; grid-template-columns: repeat(10, 1fr); gap: calc(var(--u) * 9); width: calc(var(--u) * 380); flex-shrink: 0; }"
                    ".chw-d { aspect-ratio: 1; border-radius: 50%; background: rgba(127,127,127,0.3); } .chw-d.on { background: var(--acc); }"
                    f".chw-side {{ text-align: left; display: flex; flex-direction: column; gap: calc(var(--u) * 10); }} .chw-n {{ font-size: {_fs(120)}; color: var(--acc); }}"
                    f".chw-lab {{ font-size: {_fs(34)}; }}")
    js = (f'boxIn("#{sid} .ch-card", {t0 + 0.05:.3f});'
          f'tl.fromTo("#{sid} .chw-d", {{scale: 0}}, {{scale: 1, duration: 0.3 * D, ease: "back.out(2)", stagger: {{each: 0.008 * D, grid: [10, 10], from: "start"}}}}, {t0 + 0.2:.3f});'
          f'textIn("#{sid} .ch-title", {t0 + 0.3:.3f});' + _count_js(sid, 0, r, t0 + 0.4, 1.2) + f'textIn("#{sid} .chw-lab", {t0 + 0.7:.3f}, "fade");')
    return Part(h, css, js + _exit(sid, t0, dur, c), "ch_waffle")


def ch_timeline(c, p, sid, t0, dur):
    rows = parse_items(p.get("items"))[:6] or [{"label": "Founded", "value": "2019"}, {"label": "Today", "value": "2026"}]
    vert = c.vertical
    stops = "".join(f'<div class="chtl-s"><i class="chtl-dot accb"></i><div class="nm chtl-y">{esc(r["value"] or r["label"])}</div>'
                    f'<div class="bd chtl-l">{esc(r["label"] if r["value"] else "")}</div></div>' for r in rows)
    h = (f'<div class="anc" style="{_chart_anchor(c, 84, 80)}"><div class="{_card(c)}">{_chart_head(c, p)}<div class="chtl{" v" if vert else ""}">'
         f'<i class="chtl-line"></i>{stops}</div></div></div>')
    css = CH_CSS + (".chtl { position: relative; display: flex; justify-content: space-between; padding-top: calc(var(--u) * 30); }"
                    ".chtl-line { position: absolute; left: 0; right: 0; top: calc(var(--u) * 41); height: calc(var(--u) * 4); background: currentColor; opacity: 0.4; }"
                    ".chtl-s { position: relative; display: flex; flex-direction: column; align-items: center; gap: calc(var(--u) * 10); flex: 1; text-align: center; }"
                    ".chtl-dot { width: calc(var(--u) * 26); height: calc(var(--u) * 26); border-radius: 50%; }"
                    f".chtl-y {{ font-size: {_fs(44)}; color: var(--acc); }} .chtl-l {{ font-size: {_fs(24)}; opacity: 0.85; max-width: 90%; }}"
                    ".chtl.v { flex-direction: column; gap: calc(var(--u) * 34); padding: 0 0 0 calc(var(--u) * 10); }"
                    ".chtl.v .chtl-line { left: calc(var(--u) * 22); right: auto; top: 0; bottom: 0; width: calc(var(--u) * 4); height: auto; }"
                    ".chtl.v .chtl-s { flex-direction: row; align-items: center; gap: calc(var(--u) * 24); text-align: left; }"
                    ".chtl.v .chtl-dot { flex-shrink: 0; }")
    js = (f'boxIn("#{sid} .ch-card", {t0 + 0.05:.3f}); textIn("#{sid} .ch-title", {t0 + 0.15:.3f});'
          + (f'tl.fromTo("#{sid} .chtl-line", {{scaleY: 0, transformOrigin: "50% 0%"}}, {{scaleY: 1, duration: 1.4 * D, ease: "power2.inOut"}}, {t0 + 0.3:.3f});' if vert
             else f'lineIn("#{sid} .chtl-line", {t0 + 0.3:.3f});'))
    for k in range(len(rows)):
        t = t0 + 0.4 + k * (1.3 / max(1, len(rows)))
        js += (f'popIn("#{sid} .chtl-s:nth-of-type({k + 1}) .chtl-dot", {t:.3f});'
               f'tl.fromTo("#{sid} .chtl-s:nth-of-type({k + 1}) > div", {{y: 16 * U, opacity: 0}}, {{y: 0, opacity: 1, duration: 0.5 * D, ease: "expo.out", stagger: 0.06}}, {t + 0.08:.3f});')
    return Part(h, css, js + _exit(sid, t0, dur, c), "ch_timeline")


def ch_funnel(c, p, sid, t0, dur):
    rows = _items(p, 5)
    top = max(r["num"] for r in rows) or 1
    bars = "".join(f'<div class="chf-row"><div class="chf-bar" style="width:{max(28, 100 * r["num"] / top):.1f}%;opacity:{1 - k * 0.13:.2f}">'
                   f'<span class="bd chf-l">{esc(r["label"])}</span>{_num_html(sid, k, r, "nm chf-n")}</div></div>' for k, r in enumerate(rows))
    h = f'<div class="anc" style="{_chart_anchor(c, 56)}"><div class="{_card(c)}">{_chart_head(c, p)}<div class="chf">{bars}</div></div></div>'
    css = CH_CSS + (".chf { display: flex; flex-direction: column; align-items: center; gap: calc(var(--u) * 10); }"
                    ".chf-row { width: 100%; display: flex; justify-content: center; }"
                    ".chf-bar { background: var(--acc); color: var(--acc-ink); display: flex; justify-content: space-between; align-items: center;"
                    " padding: calc(var(--u) * 16) calc(var(--u) * 28); border-radius: calc(var(--rc) * 0.5); white-space: nowrap; gap: calc(var(--u) * 20); }"
                    f".chf-l {{ font-size: {_fs(28)}; }} .chf-n {{ font-size: {_fs(36)}; }}")
    js = f'boxIn("#{sid} .ch-card", {t0 + 0.05:.3f}); textIn("#{sid} .ch-title", {t0 + 0.15:.3f});'
    for k, r in enumerate(rows):
        t = t0 + 0.35 + k * 0.16
        js += (f'tl.fromTo("#{sid} .chf-row:nth-child({k + 1}) .chf-bar", {{scaleX: 0, transformOrigin: "50% 50%"}}, {{scaleX: 1, duration: 0.7 * D, ease: "expo.out"}}, {t:.3f});'
               + _count_js(sid, k, r, t, 1.0))
    return Part(h, css, js + _exit(sid, t0, dur, c), "ch_funnel")


LAYOUTS["chart"] = {"bars": ch_bars, "columns": ch_columns, "line": ch_line, "donut": ch_donut, "meter": ch_meter,
                    "compare": ch_compare, "counters": ch_counters, "waffle": ch_waffle, "timeline": ch_timeline,
                    "funnel": ch_funnel}


# ---- callouts ------------------------------------------------------------------------------------------------

def _target(c: Ctx, p) -> tuple[float, float]:
    def f(v, d):
        try:
            return max(5.0, min(95.0, float(v)))
        except (TypeError, ValueError):
            return d
    return f(p.get("x"), 62.0), f(p.get("y"), 42.0)


def co_arrow(c, p, sid, t0, dur):
    x, y = _target(c, p)
    lx = x - 22 if x > 50 else x + 22
    ly = y + 16 if y < 60 else y - 16
    W, H = c.W, c.H
    side = "right" if lx < x else "left"
    h = (f'<div class="anc" style="inset:0"><svg class="coa-svg" viewBox="0 0 {W} {H}"><line class="coa-line" x1="{lx / 100 * W:.0f}" y1="{ly / 100 * H:.0f}" '
         f'x2="{x / 100 * W:.0f}" y2="{y / 100 * H:.0f}"/></svg><i class="coa-dot" style="left:{x}%;top:{y}%"></i><i class="coa-pulse" style="left:{x}%;top:{y}%"></i>'
         f'<div class="pn coa-lab hd" style="left:{lx}%;top:{ly}%;transform:translate({"-100%" if side == "right" else "0"}, -50%)">{_w(c, p.get("text"))}</div></div>')
    css = (".coa-svg { position: absolute; inset: 0; width: 100%; height: 100%; overflow: visible; }"
           ".coa-line { stroke: var(--facc); stroke-width: calc(var(--u) * 5); stroke-linecap: round; }"
           ".coa-dot, .coa-pulse { position: absolute; width: calc(var(--u) * 26); height: calc(var(--u) * 26); border-radius: 50%; transform: translate(-50%, -50%); }"
           ".coa-dot { background: var(--facc); box-shadow: 0 0 0 calc(var(--u) * 6) rgba(255,255,255,0.85); } .coa-pulse { border: calc(var(--u) * 4) solid var(--facc); }"
           f".coa-lab {{ position: absolute; padding: calc(var(--u) * 16) calc(var(--u) * 30); font-size: {_fs(40)}; white-space: nowrap; }}"
           + (".coa-lab { background: rgba(10,10,14,0.7); color: #fff; border-radius: calc(var(--u) * 12); }" if c.look["panel"] == "none" else ""))
    js = (f'popIn("#{sid} .coa-dot", {t0 + 0.1:.3f});'
          f'tl.fromTo("#{sid} .coa-pulse", {{scale: 0.5, opacity: 1}}, {{scale: 3, opacity: 0, duration: 1.1 * D, ease: "power2.out", repeat: 2}}, {t0 + 0.15:.3f});'
          f'strokeIn("#{sid} .coa-line", {t0 + 0.2:.3f}, 0.5); boxIn("#{sid} .coa-lab", {t0 + 0.55:.3f}, "{side}"); textIn("#{sid} .coa-lab", {t0 + 0.65:.3f});'
          + _exit(sid, t0, dur, c))
    return Part(h, css, js, "co_arrow")


def co_ring(c, p, sid, t0, dur):
    x, y = _target(c, p)
    R = 95 * c.u
    below = y < 55
    h = (f'<div class="anc" style="inset:0"><svg class="cor-svg" viewBox="0 0 {c.W} {c.H}"><circle class="cor-c" cx="{x / 100 * c.W:.0f}" cy="{y / 100 * c.H:.0f}" r="{R:.0f}"/>'
         f'<line class="cor-l" x1="{x / 100 * c.W:.0f}" y1="{y / 100 * c.H + (R if below else -R):.0f}" x2="{x / 100 * c.W:.0f}" '
         f'y2="{y / 100 * c.H + (R + 90 * c.u if below else -R - 90 * c.u):.0f}"/></svg>'
         f'<div class="hd cor-lab float fl" style="left:{x}%;top:calc({y}% + {(R + 100 * c.u) if below else -(R + 100 * c.u):.0f}px);'
         f'transform:translate(-50%, {"0" if below else "-100%"})">{_w(c, p.get("text"))}</div></div>')
    css = (".cor-svg { position: absolute; inset: 0; width: 100%; height: 100%; overflow: visible; }"
           ".cor-c, .cor-l { fill: none; stroke: var(--facc); stroke-width: calc(var(--u) * 7); stroke-linecap: round; }"
           f".cor-lab {{ position: absolute; font-size: {_fs(46)}; white-space: nowrap; }}")
    js = (f'strokeIn("#{sid} .cor-c", {t0 + 0.1:.3f}, 0.7); strokeIn("#{sid} .cor-l", {t0 + 0.7:.3f}, 0.3);'
          f'textIn("#{sid} .cor-lab", {t0 + 0.9:.3f});' + _exit(sid, t0, dur, c))
    return Part(h, css, js, "co_ring")


def co_tag(c, p, sid, t0, dur):
    x, y = _target(c, p)
    h = (f'<div class="anc" style="left:{x}%;top:{y}%"><div class="cot"><div class="pn cot-card hd">{_w(c, p.get("text"))}</div>'
         f'<i class="cot-stem"></i><i class="cot-pin accb"></i></div></div>')
    css = (".cot { position: absolute; left: 0; bottom: 0; transform: translateX(-50%); display: flex; flex-direction: column; align-items: center; }"
           f".cot-card {{ padding: calc(var(--u) * 16) calc(var(--u) * 30); font-size: {_fs(40)}; white-space: nowrap; }}"
           + (".cot-card { background: rgba(10,10,14,0.72); color: #fff; border-radius: calc(var(--u) * 12); }" if c.look["panel"] == "none" else "") +
           ".cot-stem { width: calc(var(--u) * 4); height: calc(var(--u) * 70); background: var(--facc); }"
           ".cot-pin { width: calc(var(--u) * 28); height: calc(var(--u) * 28); border-radius: 50%; transform: translateY(50%); box-shadow: 0 0 0 calc(var(--u) * 6) rgba(255,255,255,0.8); }")
    js = (f'tl.fromTo("#{sid} .cot-pin", {{y: -200 * U, opacity: 0}}, {{y: 0, opacity: 1, duration: 0.5 * D, ease: "bounce.out"}}, {t0 + 0.1:.3f});'
          f'tl.fromTo("#{sid} .cot-stem", {{scaleY: 0, transformOrigin: "50% 100%"}}, {{scaleY: 1, duration: 0.35 * D, ease: "power3.out"}}, {t0 + 0.55:.3f});'
          f'boxIn("#{sid} .cot-card", {t0 + 0.8:.3f}, "up"); textIn("#{sid} .cot-card", {t0 + 0.9:.3f});' + _exit(sid, t0, dur, c))
    return Part(h, css, js, "co_tag")


LAYOUTS["callout"] = {"arrow": co_arrow, "ring": co_ring, "tag": co_tag}


# ---- lists ---------------------------------------------------------------------------------------------------

def _list_items(p) -> list[str]:
    return [r["label"] + (f": {r['value']}" if r["value"] else "") for r in parse_items(p.get("items"))][:6] or ["First", "Second", "Third"]


def _list_times(t0: float, dur: float, n: int) -> list[float]:
    span = max(0.6, dur - EXIT - 1.2)
    return [t0 + 0.5 + k * span / max(1, n) for k in range(n)]


def li_steps(c, p, sid, t0, dur):
    items = _list_items(p)
    rows = "".join(f'<div class="lis-row"><span class="lis-n accb nm">{k + 1}</span><span class="bd lis-t">{_w(c, it)}</span></div>' for k, it in enumerate(items))
    h = (f'<div class="anc" style="{_chart_anchor(c, 58, 86)}"><div class="{_card(c)}">{_chart_head(c, p)}<div class="lis">{rows}</div></div></div>')
    css = (".lis { display: flex; flex-direction: column; gap: calc(var(--u) * 20); text-align: left; }"
           ".lis-row { display: flex; align-items: center; gap: calc(var(--u) * 24); }"
           f".lis-n {{ width: calc(var(--u) * 70); height: calc(var(--u) * 70); border-radius: min(var(--r), 50%); display: flex; align-items: center; justify-content: center; font-size: {_fs(36)}; flex-shrink: 0; }}"
           f".lis-t {{ font-size: {_fs(40)}; font-weight: 700; }}")
    js = f'boxIn("#{sid} .ch-card", {t0 + 0.05:.3f}); textIn("#{sid} .ch-title", {t0 + 0.15:.3f});'
    for k, t in enumerate(_list_times(t0, dur, len(items))):
        js += f'popIn("#{sid} .lis-row:nth-child({k + 1}) .lis-n", {t:.3f}); textIn("#{sid} .lis-row:nth-child({k + 1}) .lis-t", {t + 0.1:.3f});'
    return Part(h, css, js + _exit(sid, t0, dur, c), "li_steps")


def li_checklist(c, p, sid, t0, dur):
    items = _list_items(p)
    check = '<svg viewBox="0 0 40 40"><path class="lic-p" d="M9 21 L17 29 L32 12"/></svg>'
    rows = "".join(f'<div class="lic-row"><span class="lic-box">{check}</span><span class="bd lic-t">{_w(c, it)}</span></div>' for it in items)
    h = (f'<div class="anc" style="{_chart_anchor(c, 58, 86)}"><div class="{_card(c)}">{_chart_head(c, p)}<div class="lic">{rows}</div></div></div>')
    css = (".lic { display: flex; flex-direction: column; gap: calc(var(--u) * 18); text-align: left; }"
           ".lic-row { display: flex; align-items: center; gap: calc(var(--u) * 22); }"
           ".lic-box { width: calc(var(--u) * 58); height: calc(var(--u) * 58); border: calc(var(--u) * 4) solid var(--acc); border-radius: calc(min(var(--r), 18px)); flex-shrink: 0; }"
           ".lic-box svg { width: 100%; height: 100%; } .lic-p { fill: none; stroke: var(--acc); stroke-width: 5; stroke-linecap: round; stroke-linejoin: round; }"
           f".lic-t {{ font-size: {_fs(40)}; font-weight: 600; }}")
    js = f'boxIn("#{sid} .ch-card", {t0 + 0.05:.3f}); textIn("#{sid} .ch-title", {t0 + 0.15:.3f}); popIn("#{sid} .lic-box", {t0 + 0.3:.3f}, 0.05);'
    for k, t in enumerate(_list_times(t0, dur, len(items))):
        js += (f'textIn("#{sid} .lic-row:nth-child({k + 1}) .lic-t", {t:.3f}); strokeIn("#{sid} .lic-row:nth-child({k + 1}) .lic-p", {t + 0.2:.3f}, 0.35);')
    return Part(h, css, js + _exit(sid, t0, dur, c), "li_checklist")


def li_cards(c, p, sid, t0, dur):
    items = _list_items(p)[:4]
    cards = "".join(f'<div class="pn lid-card"><div class="nm lid-n">{k + 1:02d}</div><div class="bd lid-t">{_w(c, it)}</div></div>' for k, it in enumerate(items))
    head = _chart_head(c, p).replace("ch-title", "ch-title float fl lid-title")
    h = f'<div class="anc" style="{_chart_anchor(c, 86, 86)}">{head}<div class="lid n{len(items)}">{cards}</div></div>'
    css = (".lid { display: grid; gap: calc(var(--u) * 20); grid-template-columns: repeat(var(--n), 1fr); }"
           ".lid.n1 { --n: 1; } .lid.n2 { --n: 2; } .lid.n3 { --n: 3; } .lid.n4 { --n: 4; }"
           + (".lid { grid-template-columns: 1fr; }" if c.vertical else "") +
           ".lid-card { padding: calc(var(--u) * 30); display: flex; flex-direction: column; gap: calc(var(--u) * 14); text-align: left; min-height: calc(var(--u) * 200); }"
           + (".lid-card { min-height: 0; flex-direction: row; align-items: center; }" if c.vertical else "") +
           f".lid-n {{ font-size: {_fs(56)}; color: var(--acc); }} .lid-t {{ font-size: {_fs(34)}; font-weight: 700; }}"
           ".lid-title { text-align: center; margin-bottom: calc(var(--u) * 24); }")
    js = f'textIn("#{sid} .lid-title", {t0 + 0.05:.3f});'
    for k, t in enumerate(_list_times(t0, dur, len(items))):
        js += f'boxIn("#{sid} .lid-card:nth-child({k + 1})", {t - 0.2:.3f}, "up"); textIn("#{sid} .lid-card:nth-child({k + 1}) .lid-t", {t:.3f});'
    return Part(h, css, js + _exit(sid, t0, dur, c), "li_cards")


LAYOUTS["list"] = {"steps": li_steps, "checklist": li_checklist, "cards": li_cards}


# ---- quotes --------------------------------------------------------------------------------------------------

def _who(c, p) -> str:
    if not p.get("author"):
        return ""
    role = f'<span class="qt-role"> · {esc(p.get("role"))}</span>' if p.get("role") else ""
    return f'<div class="bd qt-who"><i class="qt-rule"></i><span>{esc(p.get("author"))}</span>{role}</div>'


QT_CSS = (".qt-who { display: flex; align-items: center; gap: calc(var(--u) * 16); font-weight: 700; margin-top: calc(var(--u) * 26); }"
          ".qt-rule { width: calc(var(--u) * 50); height: calc(var(--u) * 4); background: var(--acc); display: inline-block; }"
          ".qt-role { opacity: 0.7; font-weight: 400; }")


def qu_quote(c, p, sid, t0, dur):
    text = p.get("text") or ""
    fs = max(46, min(84, 92 - len(plain(text)) * 0.45))
    h = (f'<div class="anc {"float fl" if not c.full else "float"}" style="{_chart_anchor(c, 70, 86)}"><div class="quq"><div class="quq-mark">&ldquo;</div>'
         f'<div class="hd quq-t" style="font-size:{_fs(fs)}">{_w(c, text)}</div>{_who(c, p).replace("qt-who", f"qt-who quq-who")}</div></div>')
    css = QT_CSS + (".quq { position: relative; text-align: left; padding-top: calc(var(--u) * 60); }"
                    f".quq-mark {{ position: absolute; left: calc(var(--u) * -10); top: calc(var(--u) * -70); font-family: Georgia, 'EB Garamond', serif; font-size: {_fs(260)};"
                    " line-height: 1; color: var(--facc); } .full .quq-mark { color: var(--stage-acc); }"
                    f".quq-t {{ text-wrap: pretty; }} .quq-who {{ font-size: {_fs(30)}; }} .quq .qt-rule {{ background: var(--facc); }}")
    js = (f'tl.fromTo("#{sid} .quq-mark", {{scale: 0, rotation: -30, opacity: 0}}, {{scale: 1, rotation: 0, opacity: 1, duration: 0.6 * D, ease: "back.out(2)"}}, {t0 + 0.05:.3f});'
          f'textIn("#{sid} .quq-t", {t0 + 0.3:.3f}); lineIn("#{sid} .qt-rule", {t0 + 1.0:.3f}); textIn("#{sid} .quq-who span", {t0 + 1.1:.3f}, "fade");'
          f'tl.fromTo("#{sid} .quq-who span", {{opacity: 0}}, {{opacity: 1, duration: 0.5 * D}}, {t0 + 1.1:.3f});' + _exit(sid, t0, dur, c))
    return Part(h, css, js, "qu_quote")


def qu_review(c, p, sid, t0, dur):
    text = p.get("text") or ""
    try:
        stars = max(0, min(5, int(float(p.get("stars", 5)))))
    except (TypeError, ValueError):
        stars = 5
    fs = max(38, min(62, 70 - len(plain(text)) * 0.3))
    star_html = "".join('<i class="qur-s">★</i>' for _ in range(stars))
    h = (f'<div class="anc" style="{_chart_anchor(c, 58, 86)}"><div class="pn qur"><div class="qur-stars">{star_html}</div>'
         f'<div class="hd qur-t" style="font-size:{_fs(fs)}">{_w(c, text)}</div>{_who(c, p)}</div></div>')
    css = QT_CSS + (".qur { padding: calc(var(--u) * 46) calc(var(--u) * 54); text-align: left; }"
                    f".qur-stars {{ display: flex; gap: calc(var(--u) * 8); margin-bottom: calc(var(--u) * 20); font-size: {_fs(48)}; color: var(--acc); font-style: normal; }}"
                    ".qur-s { display: inline-block; font-style: normal; }"
                    f".qur .qt-who {{ font-size: {_fs(28)}; }}"
                    + (".qur { background: rgba(10,10,14,0.66); color: #fff; border-radius: calc(var(--u) * 18); }" if c.look["panel"] == "none" and not c.full else ""))
    js = (f'boxIn("#{sid} .qur", {t0 + 0.05:.3f}); popIn("#{sid} .qur-s", {t0 + 0.25:.3f}, 0.09);'
          f'textIn("#{sid} .qur-t", {t0 + 0.6:.3f}); lineIn("#{sid} .qt-rule", {t0 + 1.2:.3f});'
          f'tl.fromTo("#{sid} .qt-who span", {{opacity: 0}}, {{opacity: 1, duration: 0.5 * D}}, {t0 + 1.25:.3f});' + _exit(sid, t0, dur, c))
    return Part(h, css, js, "qu_review")


LAYOUTS["quote"] = {"quote": qu_quote, "review": qu_review}


# ---- end cards (full frame) ----------------------------------------------------------------------------------

def _logo(c: Ctx, cls: str, fallback_name: str = "") -> str:
    if c.assets.get("logo"):
        return f'<img class="{cls}" src="{c.assets["logo"]}" alt="">'
    return f'<div class="hd {cls}-name">{esc(fallback_name)}</div>' if fallback_name else ""


def en_center(c, p, sid, t0, dur):
    sub = f'<div class="bd enc-sub">{esc(p.get("sub"))}</div>' if p.get("sub") else ""
    h = (f'<div class="anc" style="left:50%;top:50%;transform:translate(-50%,-50%);width:86%;display:flex;flex-direction:column;align-items:center;gap:calc(var(--u)*40)">'
         f'{_logo(c, "enc-logo", p.get("name", ""))}<div class="enc-cta accb hd">{_w(c, p.get("text") or "Get in touch")}</div>{sub}</div>')
    css = (".enc-logo { max-width: 56%; max-height: calc(var(--u) * 240); object-fit: contain; }"
           f".enc-logo-name {{ font-size: {_fs(100)}; }}"
           f".enc-cta {{ padding: calc(var(--u) * 24) calc(var(--u) * 56); border-radius: var(--r); font-size: {_fs(48)}; white-space: nowrap; }}"
           ".enc-cta { box-shadow: var(--sh); }"
           f".enc-sub {{ font-size: {_fs(32)}; opacity: 0.85; letter-spacing: 0.04em; }}")
    js = (f'tl.fromTo("#{sid} .enc-logo, #{sid} .enc-logo-name", {{opacity: 0, scale: 0.85, filter: "blur(10px)"}}, {{opacity: 1, scale: 1, filter: "blur(0px)", duration: 0.8 * D, ease: "expo.out"}}, {t0 + 0.1:.3f});'
          f'boxIn("#{sid} .enc-cta", {t0 + 0.45:.3f}); textIn("#{sid} .enc-cta", {t0 + 0.55:.3f});'
          f'tl.fromTo("#{sid} .enc-sub", {{opacity: 0, y: 10 * U}}, {{opacity: 0.85, y: 0, duration: 0.6 * D}}, {t0 + 0.8:.3f});'
          f'tl.to("#{sid} .enc-cta", {{scale: 1.04, duration: 0.5 * D, ease: "sine.inOut", yoyo: true, repeat: 1}}, {t0 + 1.6:.3f});')
    return Part(h, css, js, "en_center")


def en_split(c, p, sid, t0, dur):
    sub = f'<div class="bd ens-sub">{esc(p.get("sub"))}</div>' if p.get("sub") else ""
    v = c.vertical
    h = (f'<div class="ens{" v" if v else ""}"><div class="ens-a accb"><div class="hd ens-cta">{_w(c, p.get("text") or "Get in touch")}</div>{sub}</div>'
         f'<div class="ens-b">{_logo(c, "ens-logo", p.get("name", ""))}</div></div>')
    css = (".ens { position: absolute; inset: 0; display: flex; } .ens.v { flex-direction: column-reverse; }"
           ".ens-a { flex: 1.1; display: flex; flex-direction: column; justify-content: center; padding: calc(var(--u) * 90); gap: calc(var(--u) * 24); text-align: left; }"
           f".ens-cta {{ font-size: {_fs(84)}; text-wrap: balance; }} .ens-sub {{ font-size: {_fs(32)}; opacity: 0.85; }}"
           ".ens-b { flex: 1; display: flex; align-items: center; justify-content: center; }"
           ".ens-logo { max-width: 66%; max-height: 40%; object-fit: contain; }" f".ens-logo-name {{ font-size: {_fs(80)}; }}")
    js = (f'tl.fromTo("#{sid} .ens-a", {{{"yPercent: 100" if v else "xPercent: -100"}}}, {{{"yPercent: 0" if v else "xPercent: 0"}, duration: 0.7 * D, ease: "expo.inOut"}}, {t0 + 0.05:.3f});'
          f'textIn("#{sid} .ens-cta", {t0 + 0.55:.3f});'
          f'tl.fromTo("#{sid} .ens-sub", {{opacity: 0}}, {{opacity: 0.85, duration: 0.5 * D}}, {t0 + 0.9:.3f});'
          f'tl.fromTo("#{sid} .ens-logo, #{sid} .ens-logo-name", {{opacity: 0, scale: 0.8}}, {{opacity: 1, scale: 1, duration: 0.8 * D, ease: "back.out(1.6)"}}, {t0 + 0.5:.3f});')
    return Part(h, css, js, "en_split")


def en_stack(c, p, sid, t0, dur):
    sub = f'<div class="bd enk-sub">{esc(p.get("sub"))}</div>' if p.get("sub") else ""
    text = p.get("text") or "Get in touch"
    h = (f'<div class="anc" style="left:50%;top:50%;transform:translate(-50%,-50%);width:84%;text-align:center">'
         f'<div class="hd enk-cta" style="font-size:{_fs(_title_size(text, 150))}">{_w(c, text)}</div><i class="enk-rule"></i>'
         f'<div class="enk-foot">{_logo(c, "enk-logo", p.get("name", ""))}{sub}</div></div>')
    css = (".enk-cta { text-wrap: balance; } .enk-rule { display: block; width: calc(var(--u) * 160); height: calc(var(--u) * 8); background: var(--stage-acc);"
           " margin: calc(var(--u) * 40) auto; border-radius: 99px; }"
           ".enk-foot { display: flex; align-items: center; justify-content: center; gap: calc(var(--u) * 30); }"
           ".enk-logo { max-height: calc(var(--u) * 110); max-width: 40%; object-fit: contain; }"
           f".enk-logo-name {{ font-size: {_fs(44)}; }} .enk-sub {{ font-size: {_fs(30)}; opacity: 0.85; }}")
    js = (f'textIn("#{sid} .enk-cta", {t0 + 0.1:.3f}); lineIn("#{sid} .enk-rule", {t0 + 0.6:.3f}, "50% 50%");'
          f'tl.fromTo("#{sid} .enk-foot", {{opacity: 0, y: 20 * U}}, {{opacity: 1, y: 0, duration: 0.7 * D, ease: "expo.out"}}, {t0 + 0.8:.3f});')
    return Part(h, css, js, "en_stack")


LAYOUTS["end_card"] = {"center": en_center, "split": en_split, "stack": en_stack}


# ---- transitions (a full-frame cover; the cut sits at the midpoint) --------------------------------------------

def tr_wipe(c, p, sid, t0, dur):
    h = '<i class="trw a accb"></i><i class="trw b"></i>'
    css = ".trw { position: absolute; inset: -2%; } .trw.b { background: var(--panel-flat); }"
    m = dur / 2
    js = (f'tl.fromTo("#{sid} .trw.a", {{xPercent: -102}}, {{xPercent: 0, duration: {m * 0.8:.3f}, ease: "power3.in"}}, {t0:.3f});'
          f'tl.fromTo("#{sid} .trw.b", {{xPercent: -102}}, {{xPercent: 0, duration: {m * 0.8:.3f}, ease: "power3.in"}}, {t0 + m * 0.2:.3f});'
          f'tl.to("#{sid} .trw.b", {{xPercent: 102, duration: {m * 0.8:.3f}, ease: "power3.out"}}, {t0 + m:.3f});'
          f'tl.to("#{sid} .trw.a", {{xPercent: 102, duration: {m * 0.8:.3f}, ease: "power3.out"}}, {t0 + m + m * 0.2:.3f});')
    return Part(h, css, js, "tr_wipe")


def tr_slats(c, p, sid, t0, dur):
    n = 6
    h = "".join(f'<i class="trs{" accb" if k % 2 == 0 else ""}" style="left:{k * 100 / n:.3f}%;width:{100 / n + 0.2:.3f}%"></i>' for k in range(n))
    css = ".trs { position: absolute; top: 0; bottom: 0; background: var(--panel-flat); }"
    m = dur / 2
    js = (f'tl.fromTo("#{sid} .trs", {{scaleY: 0, transformOrigin: "50% 100%"}}, {{scaleY: 1, duration: {m * 0.7:.3f}, ease: "power3.in", stagger: {m * 0.3 / n:.3f}}}, {t0:.3f});'
          f'tl.to("#{sid} .trs", {{scaleY: 0, transformOrigin: "50% 0%", duration: {m * 0.7:.3f}, ease: "power3.out", stagger: {m * 0.3 / n:.3f}}}, {t0 + m:.3f});')
    return Part(h, css, js, "tr_slats")


def tr_iris(c, p, sid, t0, dur):
    d = math.hypot(c.W, c.H) * 1.05
    h = f'<i class="tri accb" style="width:{d:.0f}px;height:{d:.0f}px"></i>'
    css = ".tri { position: absolute; left: 50%; top: 50%; border-radius: 50%; transform: translate(-50%, -50%); }"
    m = dur / 2
    js = (f'tl.fromTo("#{sid} .tri", {{scale: 0}}, {{scale: 1, duration: {m:.3f}, ease: "power3.in"}}, {t0:.3f});'
          f'tl.to("#{sid} .tri", {{opacity: 0, scale: 1.1, duration: {m:.3f}, ease: "power2.out"}}, {t0 + m:.3f});')
    return Part(h, css, js, "tr_iris")


def tr_diagonal(c, p, sid, t0, dur):
    h = '<i class="trd accb"></i>'
    css = ".trd { position: absolute; top: -30%; bottom: -30%; left: -20%; width: 140%; transform: skewX(-20deg); }"
    m = dur / 2
    js = (f'tl.fromTo("#{sid} .trd", {{xPercent: -130}}, {{xPercent: 0, duration: {m:.3f}, ease: "power4.in"}}, {t0:.3f});'
          f'tl.to("#{sid} .trd", {{xPercent: 130, duration: {m:.3f}, ease: "power4.out"}}, {t0 + m:.3f});')
    return Part(h, css, js, "tr_diagonal")


LAYOUTS["transition"] = {"wipe": tr_wipe, "slats": tr_slats, "iris": tr_iris, "diagonal": tr_diagonal}
KINDS = list(LAYOUTS)
