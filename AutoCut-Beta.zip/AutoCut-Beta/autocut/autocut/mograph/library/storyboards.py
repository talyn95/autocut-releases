"""Storyboards: whole short videos built from library elements, scene by scene, with transitions between.

A recipe is a proven marketing structure (problem-agitate-solve, listicle, testimonial, before/after, launch, event,
stat story, how-to, explainer, hiring, listing, limited offer). Its slots are the copy; the AI writes them from a
one-line brief in the client's voice (rules fill them from quotes and numbers in the brief otherwise). Scenes name an
element kind; the layout comes from the client's style DNA (dna.py), so the same recipe looks different per client.
`plan()` gives an editable scene list; `build()` writes one HyperFrames composition from it.
"""
from __future__ import annotations

import re
from pathlib import Path

from ...config import Client
from ... import content
from .build import context
from .compose import page, roles
from .elements import DURATION, LAYOUTS

S = dict  # a scene: kind, params (with {slot} placeholders), layouts (the ones that suit it; the client's DNA picks among
#           them), dur, each (repeat per line of a slot)
ONE = ["donut", "meter", "waffle"]                 # charts of a single number
MANY = ["bars", "columns", "line", "funnel"]        # charts of a series
HOOK = ["mask", "stack", "outline", "split", "boxed"]  # titles with a *keyword*
BIG = ["bignum", "stack", "outline"]                # titles with a kicker word

RECIPES: dict[str, dict] = {
    "pas_ad": dict(
        name="Problem → agitate → solve ad", use="paid social ads, 15–25 s",
        slots=[("problem", "the pain, as a hook (max 8 words, *one keyword*)", "Still paying too much for *this*?"),
               ("stat_value", "a number that makes the pain real (e.g. 68%)", "68%"),
               ("stat_label", "what the number means (max 8 words)", "of customers overpay every year"),
               ("solution", "the offer as the fix (max 8 words, *one keyword*)", "{brand} fixes it *fast*"),
               ("proof", "a short customer quote (max 18 words)", "Quick, honest and half the price we expected."),
               ("proof_author", "who said it", "A happy customer"),
               ("cta", "call to action (max 5 words)", "Book a free quote"), ("sub", "website or handle", "")],
        scenes=[S(kind="title", layouts=HOOK, params={"text": "{problem}"}, dur=3.0),
                S(kind="chart", layouts=ONE, params={"value": "{stat_value}", "label": "{stat_label}"}, dur=4.2),
                S(kind="title", params={"text": "{solution}", "kicker": "{brand}"}, dur=3.0),
                S(kind="quote", layouts=["review"], params={"text": "{proof}", "author": "{proof_author}", "stars": 5}, dur=4.8),
                S(kind="end_card", params={"text": "{cta}", "sub": "{sub}"}, dur=3.8)]),
    "listicle": dict(
        name="Tips listicle", use="organic reels and shorts, 20–40 s",
        slots=[("title", "the list's headline (max 8 words, *one keyword*)", "3 things to check *before* you buy"),
               ("items", "3–5 tips, one per line, max 7 words each", "Ask for references\nGet it in writing\nCheck the warranty"),
               ("cta", "call to action (max 5 words)", "Follow for more"), ("sub", "website or handle", "")],
        scenes=[S(kind="title", layouts=BIG, params={"text": "{title}", "kicker": "{count}"}, dur=3.0),
                S(kind="title", each="items", params={"text": "{item}", "kicker": "Tip {n}"}, dur=2.8),
                S(kind="list", params={"title": "Recap", "items": "{items}"}, dur=5.0),
                S(kind="end_card", params={"text": "{cta}", "sub": "{sub}"}, dur=3.6)]),
    "testimonial": dict(
        name="Client testimonial", use="trust content, retargeting, 20–30 s",
        slots=[("headline", "the result in a headline (max 7 words)", "How the Okafors sold in *9 days*"),
               ("quote", "the client's words (max 24 words)", "They priced it right, marketed it beautifully and we had three offers in a week."),
               ("author", "client name", "The Okafor family"), ("role", "who they are", "Homeowners"),
               ("result_value", "the measurable result (e.g. 9)", "9"), ("result_label", "what it measures", "days on market"),
               ("cta", "call to action", "Get your free valuation"), ("sub", "website or handle", "")],
        scenes=[S(kind="title", params={"text": "{headline}", "kicker": "Client story"}, dur=3.0),
                S(kind="quote", layouts=["quote"], params={"text": "{quote}", "author": "{author}", "role": "{role}"}, dur=5.5),
                S(kind="chart", layouts=["counters"], params={"items": "{result_label}: {result_value}"}, dur=3.6),
                S(kind="end_card", params={"text": "{cta}", "sub": "{sub}"}, dur=3.8)]),
    "before_after": dict(
        name="Before / after", use="results content and ads, 15–25 s",
        slots=[("title", "the transformation as a hook (max 8 words)", "From *$310* to $190 a month"),
               ("before_label", "label for before", "Before"), ("before_value", "before number", "310"),
               ("after_label", "label for after", "After"), ("after_value", "after number", "190"),
               ("benefits", "2–4 benefits, one per line", "Lower bills\nQuieter home\nNo upfront cost"),
               ("cta", "call to action", "See your savings"), ("sub", "website or handle", "")],
        scenes=[S(kind="title", params={"text": "{title}"}, dur=3.0),
                S(kind="chart", layouts=["compare"], params={"items": "{before_label}: {before_value}\n{after_label}: {after_value}"}, dur=4.5),
                S(kind="list", layouts=["checklist", "steps", "cards"], params={"items": "{benefits}"}, dur=4.8),
                S(kind="end_card", params={"text": "{cta}", "sub": "{sub}"}, dur=3.6)]),
    "launch": dict(
        name="Product launch", use="launches and new services, 20–30 s",
        slots=[("product", "product or service name", "The {brand} App"),
               ("tagline", "the promise (max 8 words, *one keyword*)", "Everything you need, *one* tap away"),
               ("features", "3 features, one per line, max 5 words", "Book in seconds\nTrack every job\nPay securely"),
               ("stat_value", "a proof number", "4.9"), ("stat_label", "what it means", "average rating"),
               ("cta", "call to action", "Download free today"), ("sub", "website or handle", "")],
        scenes=[S(kind="title", layouts=BIG, params={"text": "{product}", "kicker": "NEW"}, dur=3.0),
                S(kind="title", layouts=HOOK, params={"text": "{tagline}"}, dur=3.0),
                S(kind="list", layouts=["cards", "checklist", "steps"], params={"items": "{features}"}, dur=5.0),
                S(kind="chart", layouts=["counters"], params={"items": "{stat_label}: {stat_value}"}, dur=3.4),
                S(kind="end_card", params={"text": "{cta}", "sub": "{sub}"}, dur=3.8)]),
    "event": dict(
        name="Event promo", use="events, open houses, workshops, 15–25 s",
        slots=[("event", "event name (max 6 words)", "Spring open house"), ("date", "date", "Sat, May 9"),
               ("time", "time", "1–4 PM"), ("place", "place", "14 Seawatch Lane"),
               ("highlights", "2–4 highlights, one per line", "Tour every room\nMeet the team\nFree refreshments"),
               ("cta", "call to action", "RSVP today"), ("sub", "website or handle", "")],
        scenes=[S(kind="title", params={"text": "{event}", "kicker": "{date}"}, dur=3.0),
                S(kind="list", layouts=["checklist", "steps", "cards"], params={"title": "What's on", "items": "{highlights}"}, dur=4.8),
                S(kind="title", layouts=["boxed", "stack", "split"], params={"text": "{date} / {time} / {place}"}, dur=3.4),
                S(kind="end_card", params={"text": "{cta}", "sub": "{sub}"}, dur=3.6)]),
    "stat_story": dict(
        name="Data story", use="thought leadership, reports, 20–30 s",
        slots=[("headline", "the question the data answers (max 8 words)", "Where do our leads *come from*?"),
               ("data", "3–5 rows 'Label: number', one per line", "Google: 42\nReferrals: 31\nInstagram: 18\nOther: 9"),
               ("chart_title", "chart title (max 4 words)", "Leads by source (%)"),
               ("insight", "the takeaway (max 9 words, *one keyword*)", "Referrals are our *fastest* growing channel"),
               ("cta", "call to action", "Get the full report"), ("sub", "website or handle", "")],
        scenes=[S(kind="title", params={"text": "{headline}"}, dur=3.0),
                S(kind="chart", layouts=MANY, params={"title": "{chart_title}", "items": "{data}"}, dur=5.0),
                S(kind="title", layouts=HOOK, params={"text": "{insight}"}, dur=3.2),
                S(kind="end_card", params={"text": "{cta}", "sub": "{sub}"}, dur=3.6)]),
    "how_to": dict(
        name="How-to in steps", use="educational reels, 20–40 s",
        slots=[("title", "what they'll learn (max 8 words)", "How to *prep* for your first visit"),
               ("steps", "3–5 steps, one per line, max 6 words", "Book online in 60 seconds\nFill in the short form\nArrive 10 minutes early"),
               ("cta", "call to action", "Book your first visit"), ("sub", "website or handle", "")],
        scenes=[S(kind="title", params={"text": "{title}", "kicker": "How to"}, dur=3.0),
                S(kind="title", each="steps", params={"text": "{item}", "kicker": "Step {n}"}, dur=2.8),
                S(kind="list", layouts=["steps", "cards"], params={"title": "Recap", "items": "{steps}"}, dur=5.0),
                S(kind="end_card", params={"text": "{cta}", "sub": "{sub}"}, dur=3.6)]),
    "explainer": dict(
        name="Explainer", use="FAQ answers, service explainers, 20–30 s",
        slots=[("question", "the customer's question (max 9 words)", "Do I really need a new roof?"),
               ("answer", "the short answer (max 9 words, *one keyword*)", "Not always. *Most* roofs just need repairs."),
               ("points", "3 supporting points, one per line", "Free inspection first\nPhoto report you can keep\nRepair before replace"),
               ("proof_value", "a percentage that backs it (e.g. 70%)", "70%"), ("proof_label", "what it measures", "of our visits end in a repair"),
               ("cta", "call to action", "Book a free inspection"), ("sub", "website or handle", "")],
        scenes=[S(kind="title", layouts=HOOK, params={"text": "{question}"}, dur=3.2),
                S(kind="title", layouts=HOOK, params={"text": "{answer}"}, dur=3.2),
                S(kind="list", layouts=["checklist", "steps", "cards"], params={"items": "{points}"}, dur=4.8),
                S(kind="chart", layouts=ONE, params={"value": "{proof_value}", "label": "{proof_label}"}, dur=4.0),
                S(kind="end_card", params={"text": "{cta}", "sub": "{sub}"}, dur=3.6)]),
    "hiring": dict(
        name="We're hiring", use="recruitment, 15–25 s",
        slots=[("role", "the role", "Lead Technician"),
               ("pitch", "why join (max 9 words, *one keyword*)", "Join a team that *actually* has your back"),
               ("perks", "3–4 perks, one per line", "Top-of-market pay\n4-day weeks\nPaid training"),
               ("cta", "call to action", "Apply in 2 minutes"), ("sub", "website or handle", "")],
        scenes=[S(kind="title", layouts=BIG, params={"text": "We're hiring: *{role}*", "kicker": "HIRING"}, dur=3.0),
                S(kind="title", params={"text": "{pitch}"}, dur=3.0),
                S(kind="list", layouts=["checklist", "steps", "cards"], params={"title": "Perks", "items": "{perks}"}, dur=4.8),
                S(kind="end_card", params={"text": "{cta}", "sub": "{sub}"}, dur=3.6)]),
    "listing": dict(
        name="Property listing", use="real estate listings, 20–30 s",
        slots=[("address", "the address", "14 Seawatch Lane"), ("price", "asking price", "$1,250,000"),
               ("specs", "3–4 specs 'Label: number', one per line", "Beds: 4\nBaths: 3\nSq ft: 2,850"),
               ("features", "3 features, one per line", "Ocean views\nChef's kitchen\nPrivate dock"),
               ("cta", "call to action", "Book a private tour"), ("sub", "website or handle", "")],
        scenes=[S(kind="title", layouts=["boxed", "stack", "split"], params={"text": "Just listed / {address}"}, dur=3.2),
                S(kind="chart", layouts=["counters"], params={"items": "{specs}"}, dur=4.0),
                S(kind="list", params={"items": "{features}"}, dur=4.8),
                S(kind="title", layouts=["stack", "bignum"], params={"text": "*{price}*", "kicker": "Offered at"}, dur=3.0),
                S(kind="end_card", params={"text": "{cta}", "sub": "{sub}"}, dur=3.6)]),
    "offer": dict(
        name="Limited-time offer", use="promotions and sales, 10–20 s",
        slots=[("offer", "the offer (max 6 words, *one keyword*)", "*20% off* every service"),
               ("deadline", "the urgency line (max 7 words)", "This weekend only"),
               ("spots_value", "how full it is, as a % (e.g. 80%)", "80%"), ("spots_label", "what that means", "of spots already booked"),
               ("cta", "call to action", "Claim your spot"), ("sub", "website or handle", "")],
        scenes=[S(kind="title", layouts=BIG, params={"text": "{offer}", "kicker": "SALE"}, dur=3.0),
                S(kind="chart", layouts=ONE, params={"value": "{spots_value}", "label": "{spots_label}"}, dur=3.8),
                S(kind="title", layouts=HOOK, params={"text": "{deadline}"}, dur=2.8),
                S(kind="end_card", params={"text": "{cta}", "sub": "{sub}"}, dur=3.6)]),
}
content.register("storyboards", RECIPES)  # + recipes from content packs (content.py)


def _lines(v: str) -> list[str]:
    return [x.strip(" -•\t") for x in re.split(r"\n|;", str(v or "")) if x.strip(" -•\t")]


def rule_slots(recipe: dict, brief: str, brand_name: str) -> dict:
    """Without an AI: quoted phrases fill the text slots in order, numbers fill *_value slots, the rest keep their
    defaults (with the brand's name)."""
    quotes = [a or b or c for a, b, c in re.findall(r'"([^"]+)"|“([^”]+)”|‘([^’]+)’', brief or "")]
    bare = re.sub(r'"[^"]*"|“[^”]*”', "", brief or "")
    pairs = re.findall(r"([A-Za-z][A-Za-z &'/-]{0,24}?)\s*[:=]?\s+([$€£]?\d[\d,.]*%?)(?=[\s,;.]|$)", bare)
    out = {}
    if len(pairs) >= 2:  # "Search 46, Referrals 28 …" is the data for a series slot
        for name in ("data", "specs"):
            if any(n == name for n, _, _ in recipe["slots"]):
                out[name] = "\n".join(f"{a.strip().title() if a.islower() else a.strip()}: {b.rstrip(',.')}" for a, b in pairs)
                bare = ""
                break
    nums = re.findall(r"[$€£]?\d[\d,.]*%?", bare)
    for name, _, default in recipe["slots"]:
        if name in out:
            continue
        if name.endswith("_value") and nums:
            out[name] = nums.pop(0)
        elif name not in ("sub",) and quotes and not name.endswith("_label"):
            out[name] = quotes.pop(0)
        else:
            out[name] = default.replace("{brand}", brand_name or "Us")
    return out


def ai_slots(recipe: dict, brief: str, brand: dict, settings: dict) -> dict | None:
    from ... import brain, marketing
    props = {name: {"type": "string"} for name, _, _ in recipe["slots"]}
    guide = "\n".join(f"- {name}: {desc}" for name, desc, _ in recipe["slots"])
    out = brain.ask(settings, marketing.system_prompt(brand, "motion"),
                    f"Write the on-screen copy for a '{recipe['name']}' motion graphics video ({recipe['use']}) for "
                    f"{brand.get('client') or 'this business'}.\nBrief: {brief}\n\nFill every slot. Short, punchy, "
                    f"specific; use real numbers from the brief, never invent statistics (leave a number slot as the "
                    f"example if the brief has none). Lists: one item per line.\n{guide}",
                    {"type": "object", "properties": props, "required": list(props)}, timeout=120)
    return out if isinstance(out, dict) else None


def plan(recipe_key: str, brief: str, client: Client, settings: dict | None, dna: dict | None = None) -> dict:
    """The editable scene list for a storyboard."""
    recipe = RECIPES[recipe_key]
    brand_name = client.brand.get("client") if client.brand.get("client") != "Custom" else ""
    slots = rule_slots(recipe, brief, brand_name)
    via = "rules"
    if settings is not None:
        ai = ai_slots(recipe, brief, client.brand, settings)
        if ai:
            slots.update({k: str(v) for k, v in ai.items() if k in slots and str(v).strip()})
            via = "ai"
    if not slots.get("sub"):
        slots["sub"] = (client.brand.get("cta") or {}).get("sub", "") or client.brand.get("website", "") or ""
    slots["brand"] = brand_name
    return {"recipe": recipe_key, "slots": slots, "scenes": expand(recipe, slots, dna), "via": via}


def _fmt(v, slots: dict, extra: dict | None = None) -> str:
    vals = {**slots, **(extra or {})}
    return re.sub(r"\{(\w+)\}", lambda m: str(vals.get(m.group(1), "")), str(v))


def expand(recipe: dict, slots: dict, dna: dict | None = None) -> list[dict]:
    """Recipe + copy → concrete scenes, layouts picked from the client's DNA (each kind's next layout in turn)."""
    from .dna import layout_for
    used: dict[str, int] = {}
    counts = {"count": str(len(_lines(slots.get("items", ""))) or "")}
    scenes = []
    for sc in recipe["scenes"]:
        reps = [{}]
        if sc.get("each"):
            reps = [{"item": it, "n": str(k + 1)} for k, it in enumerate(_lines(slots.get(sc["each"], "")))]
        for extra in reps:
            kind = sc["kind"]
            allowed = [x for x in sc.get("layouts") or [] if x in LAYOUTS[kind]] or list(LAYOUTS[kind])
            order = [x for x in (layout_for(dna, kind, k) for k in range(len(LAYOUTS[kind]))) if x in allowed]
            layout = order[used.get(kind, 0) % len(order)]
            used[kind] = used.get(kind, 0) + 1
            params = {k: _fmt(v, slots, {**counts, **extra}) for k, v in sc["params"].items()}
            scenes.append({"kind": kind, "layout": layout, "params": params, "dur": float(sc.get("dur") or DURATION[kind])})
    return scenes


TRANSITION = 0.8


def build(scenes: list[dict], look_key: str, client: Client, size: tuple[int, int], project: Path,
          transition: str | None = "wipe", brand_fonts: bool = True, gsap: Path | None = None,
          feel: str | None = None) -> float:
    """One full-frame composition: every scene on the look's stage, a transition over each cut."""
    c, faces = context(client, look_key, size, project, True, 0.5, brand_fonts, gsap, feel)
    c.roles = roles(c.look, client.brand["colors"], overlay=False)
    parts, t = [], 0.0
    for i, sc in enumerate(scenes):
        kind = sc["kind"]
        fn = LAYOUTS[kind].get(sc.get("layout")) or next(iter(LAYOUTS[kind].values()))
        d = max(1.0, float(sc.get("dur") or DURATION[kind]))
        c.y = 0.5 if kind != "lower_third" else (0.62 if c.vertical else 0.8)
        parts.append((t, d, fn(c, dict(sc.get("params") or {}), f"sc{i}", t, d)))
        t += d
    total = round(t, 3)
    # what happens on screen, for the sound designer (sound/design.py)
    events = []
    for i, (a, d, _) in enumerate(parts):
        kind = scenes[i]["kind"]
        if i:
            events.append({"t": a, "kind": "transition"})
        if kind == "chart":
            events.append({"t": a + 0.5, "kind": "number"})
        elif kind == "list":
            events.append({"t": a + 0.55, "kind": "sticker"})
        elif kind == "title" and scenes[i].get("layout") in ("bignum", "boxed"):
            events.append({"t": a + 0.3, "kind": "slam"})
        elif kind == "end_card":
            events += [{"t": a + 0.5, "kind": "end"}, {"t": a + 0.9, "kind": "logo"}]
    if parts:
        events.append({"t": 0.1, "kind": "reveal", "boost": -1})
    import json as _json
    (project / "events.json").write_text(_json.dumps(events))
    extra = ""
    js_extra = []
    if transition and transition in LAYOUTS["transition"]:
        tr = LAYOUTS["transition"][transition]
        for i, (a, d, _) in enumerate(parts[1:], 1):
            s0 = max(0.0, a - TRANSITION / 2)
            p = tr(c, {}, f"tr{i}", s0, TRANSITION)
            extra += (f'<div id="tr{i}" class="clip" data-start="{s0:.3f}" data-duration="{TRANSITION:.3f}" data-track-index="3" '
                      f'style="position:absolute;inset:0;overflow:hidden">{p.html}</div>')
            js_extra.append(p)
    from .compose import Part
    holder = Part("", "".join({p.css_key: p.css for p in js_extra}.values()), "\n".join(p.js for p in js_extra), "transitions")
    html_page = page(c, parts + ([(0.0, 0.0, holder)] if js_extra else []), total, faces, False, extra_clips=extra)
    # the holder only carries CSS/JS; drop its empty clip
    html_page = html_page.replace(f'<div id="sc{len(parts)}" class="clip scene full" data-start="0.000" data-duration="0.000" '
                                  'data-track-index="1" data-layout-allow-overflow></div>', "")
    (project / "index.html").write_text(html_page, encoding="utf-8")
    return total
