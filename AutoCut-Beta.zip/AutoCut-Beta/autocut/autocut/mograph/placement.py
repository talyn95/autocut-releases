"""Where the AutoCut Motion pack goes in a video (used by pipeline.run_job)."""
from __future__ import annotations

from pathlib import Path

from ..edit import norm
from .engine import Look
from .templates import make


def _clear(start: float, end: float, busy: list[tuple[float, float]], gap: float = 0.25) -> bool:
    return all(end + gap <= s or start >= e + gap for s, e in busy)


def builtin_pieces(plan, client, hook: str, busy: list[tuple[float, float]], has_cutout_hook: bool,
                   fxdir: Path, size: tuple[int, int], fps: float, samples: int) -> list[dict]:
    """Hook title, keyword slams and swipe transitions. Returns [{path, start, duration, name}]."""
    from ..effects.cutout import auto_hook_text
    cfg = client.brand["motion"]
    look = Look(client, size, fps)
    total = plan.seconds
    keys = {norm(k) for k in client.brand["captions"]["highlight_words"]}
    pieces: list[dict] = []

    def add(template: str, start: float, name: str, **params):
        out = make(template, look, fps, fxdir / f"motion_{len(pieces)}_{template}.mov", samples=samples, **params)
        from ..media import probe
        dur = probe(out).duration
        pieces.append({"path": out, "start": start, "duration": dur, "name": name})
        busy.append((start, start + dur))

    if cfg["hook_title"] and not has_cutout_hook:
        text = hook or auto_hook_text(plan.words, keys)
        if text and total > 4:
            add("hook_title", 0.25, f"Hook title: {text}", text=text)

    if cfg["slams"]:
        last = -1e9
        for w in plan.words:
            if len([p for p in pieces if p["name"].startswith("Slam")]) >= cfg["slams"]:
                break
            if norm(w["word"]) not in keys or w["start"] < 2.0 or w["start"] - last < cfg["slam_every_seconds"]:
                continue
            start = max(0.0, w["start"] - 0.05)
            if start + 1.5 > total or not _clear(start, start + 1.4, busy):
                continue
            add("slam", start, f"Slam: {w['word'].strip(',.!?')}", word=w["word"])
            last = start

    if cfg["swipes"]:
        last = -1e9
        for seg in plan.segments[1:]:
            if len([p for p in pieces if p["name"] == "Swipe transition"]) >= cfg["swipes"]:
                break
            cut = seg.rec_in / plan.fps
            start = cut - 0.35  # the swipe fully covers the frame exactly on the cut
            if cut < 3.0 or cut > total - 2.0 or cut - last < cfg["swipe_every_seconds"] \
                    or not _clear(start, start + 0.7, busy, 0.1):
                continue
            add("swipe", start, "Swipe transition")
            last = cut
    return pieces


def cta_outro(client, size: tuple[int, int], fps: float, out: Path, samples: int) -> Path | None:
    cta = client.brand["cta"]
    if not cta["text"]:
        return None
    look = Look(client, size, fps)
    logo = client.path(client.brand["logo"]["file"])
    return make("cta_outro", look, fps, out, samples=samples, text=cta["text"], sub=cta["subtext"],
                logo=logo, dur=max(2.6, float(cta["duration"]) + 0.4))


def card(client, card: dict, size: tuple[int, int], fps: float, out: Path, samples: int) -> Path:
    """Pro graphic card: numbers count up in a stat panel, phrases get a brand pill."""
    look = Look(client, size, fps)
    if any(ch.isdigit() for ch in card["value"]):
        return make("stat_counter", look, fps, out, samples=samples, value=card["value"], label=card["label"])
    return make("phrase_card", look, fps, out, samples=samples, text=card["value"])


def lower_third(client, size: tuple[int, int], fps: float, out: Path, samples: int) -> Path | None:
    cfg = client.brand["lower_third"]
    if not cfg["name"]:
        return None
    return make("lower_third", Look(client, size, fps), fps, out, samples=samples,
                name=cfg["name"], title=cfg["title"], dur=max(3.0, float(cfg["seconds"])))
