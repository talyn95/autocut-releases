"""Effects edit: a short-form edit style where every sentence of a talking-head take gets its own camera-and-graphics
effect, so the video never sits still (Create tab → Transcript to video → Style "Effects edit"; MCP make_effects_video).

The take is rough-cut first (explainer.cut_take), the speaker is cut out once for the whole take (a VP9-alpha WebM the
renderer reads, explainer.render_popout), and each sentence becomes one scene. Every scene plays its own slice of the
take (the <video> clips start at the sentence, so the lips stay in sync) and wraps it in one of these effects:

  paper_cutout     the speaker as a white-bordered paper cut-out on a paper backdrop, moving in stop-motion steps
  magazine_cover   a cover: a huge masthead word behind the speaker's head, cover lines, issue number
  screen_wall      a wall of screens all playing the take; the camera pulls out from one of them
  pixel_zoom       the shot resolves out of big pixels into sharp focus while it punches in
  sketch_boil      the shot as a boiling ink sketch on paper (edge lines redrawn at 8 frames a second)
  graph_rise       bars rise behind the speaker, the sentence's number counts up on top
  glass_text       a frosted-glass panel over the shot with the key words on it
  orbit_spin       the shot spins in 3D on a card while key words orbit it
  pull_out_reveal  the full-frame shot pulls back into a card and reveals the point underneath
  phone_frame      the take inside a phone, the headline above it
  dolly_zoom       vertigo: the background stretches away while the speaker stays the same size
  news_wall        a news set: the take in the main monitor, headline tiles, a breaking-news ticker
  frame_pop        the take in a tilted photo frame and the speaker's head breaks out over its top edge
  punch_through    a paper sheet with the key word covers the screen and the speaker bursts through it
  green_screen     the speaker in front of a brand-coloured set instead of their room
  interface_world  the take lives inside an app window: sidebar, toolbar, a cursor that clicks
  tick_list        a taped paper checklist; each item ticks off as it's said

Effects that need the cut-out (marked CUTOUT) are skipped when no segmentation is available. Which effect goes where:
rules from what the sentence says (lists, numbers, apps, phones, "imagine", "but"…), never the same one twice in a row,
the unused ones first; the AI brain refines the choice (knowledge/motion.md), with the rules as the fallback.
Big bold word-group captions run on top throughout, and an effect counter chip (03/09) can sit in the corner.
"""
from __future__ import annotations

import html
import json
import re
import shutil
import subprocess
from pathlib import Path

from ..config import Client
from . import hyper
from .explainer import INK, caption_groups, cut_take, render_popout
from .script import NUM, STOP, _num_value, beats, clean

EFFECTS = {  # name: (label, needs the cut-out, sound event for its entrance)
    "paper_cutout": ("Paper cut-out", True, "sticker"),
    "magazine_cover": ("Magazine cover", True, "slam"),
    "screen_wall": ("Screen wall", False, "transition"),
    "pixel_zoom": ("Pixel zoom", False, "glitch"),
    "sketch_boil": ("Sketch boil", False, "transition"),
    "graph_rise": ("Graph rise", True, "number"),
    "glass_text": ("Glass text", False, "swipe"),
    "orbit_spin": ("Orbit spin", False, "transition"),
    "pull_out_reveal": ("Pull-out reveal", False, "reveal"),
    "phone_frame": ("Phone frame", False, "swipe"),
    "dolly_zoom": ("Dolly zoom", True, "reveal"),
    "news_wall": ("News wall", False, "hit"),
    "frame_pop": ("Frame pop", True, "sticker"),
    "punch_through": ("Punch-through cut", True, "slam"),
    "green_screen": ("Green screen", True, "transition"),
    "interface_world": ("Interface world", False, "ui"),
    "tick_list": ("Tick list", False, "ui"),
}
RULES = [  # (effect, words that call for it)
    ("tick_list", r"\b(first|second|third|next|then|finally|steps?|list|checklist|tips?|ways|things|reasons)\b"),
    ("graph_rise", r"\b(grow|grew|growth|more|increase|double|triple|revenue|sales|results?|percent|profit|up)\b"),
    ("interface_world", r"\b(app|website|site|online|software|dashboard|click|tool|platform|portal|book online|link)\b"),
    ("phone_frame", r"\b(phone|text|call|instagram|tiktok|reels?|social|dm|message|scroll|mobile)\b"),
    ("news_wall", r"\b(news|breaking|announce|announcing|launch|update|new|just)\b"),
    ("dolly_zoom", r"\b(imagine|picture|suddenly|realize|realise|shock|scary|wait|moment)\b"),
    ("punch_through", r"\b(but|actually|truth|stop|never|wrong|myth|instead|break)\b"),
    ("screen_wall", r"\b(everyone|everybody|thousands|millions|people|customers|clients|all)\b"),
    ("magazine_cover", r"\b(story|brand|famous|featured|best|top|award|premium|luxury)\b"),
    ("glass_text", r"\b(clear|simple|easy|transparent|honest|exactly|clarity)\b"),
    ("orbit_spin", r"\b(around|every angle|everywhere|world|360|whole|complete|full)\b"),
    ("pixel_zoom", r"\b(zoom|closer|detail|look|see|notice|hidden|hides?)\b"),
    ("sketch_boil", r"\b(plan|idea|draw|design|sketch|blueprint|build|create|think)\b"),
    ("green_screen", r"\b(anywhere|location|place|area|city|town|here in|local)\b"),
    ("pull_out_reveal", r"\b(here's|reveal|turns out|result|secret|answer|that's why)\b"),
    ("frame_pop", r"\b(i'm|i am|me|my|myself|we're|our team)\b"),
]
OPENERS = ["magazine_cover", "frame_pop", "punch_through", "paper_cutout"]
PAPER, TAPE = "#f5f0e6", "rgba(236, 220, 170, 0.78)"


# ---- planning --------------------------------------------------------------------------------------------------

def _text(b: dict) -> str:
    return " ".join(w["word"] for w in b["words"]).strip()


def keyword(b: dict) -> str:
    """The word that names the sentence: a number first, else the longest meaningful word."""
    ws = [clean(w["word"]) for w in b["words"]]
    for w in ws:
        if NUM.match(w):
            return w
    cand = [w for w in ws if w.lower() not in STOP and len(w) > 2]
    return max(cand, key=len) if cand else (ws[-1] if ws else "")


def list_items(b: dict, most: int = 4) -> list[str]:
    """Short checklist items from a sentence: split at commas/and/then, else its meaningful words."""
    t = re.sub(r"\b(first|second|third|next|then|finally|and|also)\b", ",", _text(b), flags=re.I)
    parts = [re.sub(r"[^\w$%' -]", "", p).strip() for p in t.split(",")]
    parts = [" ".join(p.split()[:4]) for p in parts if len(p.split()) >= 1 and p.lower() not in STOP]
    if len(parts) >= 2:
        return parts[:most]
    words = [clean(w["word"]) for w in b["words"] if clean(w["word"]).lower() not in STOP and len(clean(w["word"])) > 2]
    return [w.capitalize() for w in words[:most]] or [keyword(b)]


def rules_plan(bs: list[dict], cutout: bool = True, wanted: list[str] | None = None) -> list[str]:
    """One effect per beat: what the sentence says first, then variety (never the same twice in a row, unused first)."""
    pool = [e for e in (wanted or list(EFFECTS)) if e in EFFECTS and (cutout or not EFFECTS[e][1])]
    if not pool:
        pool = [e for e in EFFECTS if not EFFECTS[e][1]]
    used: dict[str, int] = {}
    out: list[str] = []
    for i, b in enumerate(bs):
        t = _text(b).lower()
        prev = out[-1] if out else None
        cands = []
        if i == 0:
            cands += [e for e in OPENERS if e in pool]
        cands += [e for e, rx in RULES if e in pool and re.search(rx, t)]
        if any(NUM.match(clean(w["word"])) for w in b["words"]) and "graph_rise" in pool:
            cands.insert(0, "graph_rise")
        cands = [e for e in cands if e != prev]
        fresh = [e for e in cands if not used.get(e)]
        if fresh:
            pick = fresh[0]
        else:
            rest = sorted((e for e in pool if e != prev), key=lambda e: (used.get(e, 0), list(EFFECTS).index(e)))
            pick = cands[0] if cands and used.get(cands[0], 0) <= min(used.get(e, 0) for e in rest) else rest[0]
        out.append(pick)
        used[pick] = used.get(pick, 0) + 1
    return out


PLAN_SCHEMA = {"type": "object", "properties": {"effects": {"type": "array", "items": {"type": "string"}}},
               "required": ["effects"]}


def plan(bs: list[dict], settings: dict | None = None, brand: dict | None = None, cutout: bool = True,
         wanted: list[str] | None = None) -> list[str]:
    """The effect for each beat. The AI picks from the rules' shortlist; anything invalid falls back to the rules."""
    base = rules_plan(bs, cutout, wanted)
    if not settings or len(bs) < 2:
        return base
    pool = [e for e in (wanted or list(EFFECTS)) if e in EFFECTS and (cutout or not EFFECTS[e][1])]
    try:
        from .. import brain, marketing
        lines = "\n".join(f"{i + 1}. {_text(b)}" for i, b in enumerate(bs))
        ai = brain.ask(settings, marketing.system_prompt(brand, "motion"),
                       "Pick one video effect per sentence of this talking-head short so each effect illustrates what is said "
                       "and the video never repeats an effect back to back (use as many different ones as fit). Effects: "
                       + ", ".join(f"{e} ({EFFECTS[e][0]})" for e in pool)
                       + f". Return exactly {len(bs)} effect names in order.\n{lines}", PLAN_SCHEMA, timeout=60)
    except Exception:  # noqa: BLE001 - no AI: the rules' plan
        return base
    got = ai.get("effects") if isinstance(ai, dict) else None
    if not isinstance(got, list) or len(got) != len(bs):
        return base
    out = []
    for i, e in enumerate(got):
        e = str(e).strip().lower()
        out.append(e if e in pool and (not out or out[-1] != e) else base[i] if (not out or base[i] != out[-1]) else
                   next(x for x in pool if x != out[-1]))
    return out


# ---- pre-rendered looks (ffmpeg) ---------------------------------------------------------------------------------

def _ff(*args: str) -> None:
    subprocess.run(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", *args], check=True)


def render_sketch(video: Path, a: float, z: float, out: Path) -> Path:
    """Ink-sketch boil: noisy edges redrawn at 8 fps, dark lines on warm paper."""
    _ff("-ss", f"{a:.3f}", "-t", f"{max(0.1, z - a):.3f}", "-i", str(video), "-an", "-vf",
        "fps=8,noise=alls=14:allf=t,edgedetect=low=0.05:high=0.16,negate,"
        "colorchannelmixer=rr=0.96:gg=0.92:bb=0.84,fps=30", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
        "-pix_fmt", "yuv420p", str(out))
    return out


def render_pixel(video: Path, a: float, out: Path, steps=(64, 32, 16, 8), each: float = 0.14) -> Path:
    """The first moments of a shot in big pixels getting smaller, then sharp (concatenated stills of motion)."""
    from ..media import probe
    info = probe(video)
    W, H = info.width or 1080, info.height or 1920
    parts, n = [], len(steps)
    for k, s in enumerate(steps):
        parts.append(f"[0:v]trim={a + k * each:.3f}:{a + (k + 1) * each:.3f},setpts=PTS-STARTPTS,"
                     f"scale={max(2, W // s)}:{max(2, H // s)}:flags=area,scale={W}:{H}:flags=neighbor,setsar=1[p{k}]")
    graph = ";".join(parts) + ";" + "".join(f"[p{k}]" for k in range(n)) + f"concat=n={n}:v=1:a=0[v]"
    _ff("-i", str(video), "-filter_complex", graph, "-map", "[v]", "-an", "-c:v", "libx264", "-preset", "veryfast",
        "-crf", "20", "-pix_fmt", "yuv420p", str(out))
    return out


def render_blur(video: Path, a: float, z: float, out: Path) -> Path:
    """A heavily blurred slice of the take: the frost behind glass, the stretching background of a dolly zoom."""
    _ff("-ss", f"{a:.3f}", "-t", f"{max(0.1, z - a):.3f}", "-i", str(video), "-an", "-vf",
        "scale=iw/4:-2,boxblur=12:2,scale=iw*4:-2,eq=saturation=1.15", "-c:v", "libx264", "-preset", "veryfast",
        "-crf", "24", "-pix_fmt", "yuv420p", str(out))
    return out


# ---- the composition ---------------------------------------------------------------------------------------------

def build(words: list[dict], scenes: list[dict], client: Client, size: tuple[int, int], project: Path, settings: dict,
          video: Path, length: float, pop: Path | None = None, counter: bool = True,
          frame: tuple[float, float] = (0.3, 0.5)) -> float:
    """Write the HyperFrames project. scenes: [{"words": [...], "effect": name}, ...]. Returns the length in seconds."""
    from ..media import probe
    W, H = size
    u = W / 1080
    if project.exists():
        shutil.rmtree(project)
    (project / "assets").mkdir(parents=True)
    gsap = hyper.runtime_dir(settings) / "node_modules" / "gsap" / "dist" / "gsap.min.js"
    if gsap.exists():
        shutil.copy2(gsap, project / "assets" / "gsap.min.js")
    shutil.copy2(video, project / "assets" / "take.mp4")
    if pop:
        shutil.copy2(pop, project / "assets" / "cut.webm")
    faces, head_font, body_font = hyper._fonts(client, project)
    brand = client.brand
    primary = brand["colors"]["primary"]
    acc = primary if hyper._luma(primary) < 200 else brand["colors"].get("secondary") or INK
    dark = brand["colors"]["secondary"] if hyper._luma(brand["colors"]["secondary"]) < 110 else INK
    light = hyper._mix(acc, "#f4f1ec", 0.9)
    on_acc = hyper.on(acc)
    name = brand.get("client") if brand.get("client") not in (None, "", "Custom") else "AutoCut"
    info = probe(video)
    vw_, vh_ = info.width or W, info.height or H

    total = round(min(length, (words[-1]["end"] if words else length) + 0.6), 3)
    for i, s in enumerate(scenes):
        s["a"] = round(0.0 if i == 0 else max(0.0, s["words"][0]["start"] - 0.12), 3)
    for i, s in enumerate(scenes):
        s["z"] = scenes[i + 1]["a"] if i + 1 < len(scenes) else total

    T = lambda x: f"{x:.3f}"  # noqa: E731
    E = html.escape
    tw: list[str] = []
    events: list[dict] = []
    layers: list[str] = []

    vid_n = [0]

    def vid_id() -> str:
        vid_n[0] += 1
        return f"v{vid_n[0]}"

    def take(a: float, z: float, cls: str = "v", src: str = "assets/take.mp4", track: int = 1, style: str = "") -> str:
        return (f'<video id="{vid_id()}" class="clip {cls}" src="{src}" data-start="{T(a)}" data-duration="{T(z - a)}" data-media-start="{T(a)}" '
                f'data-track-index="{track}" muted playsinline{f" style={chr(34)}{style}{chr(34)}" if style else ""}></video>')

    def person(a: float, z: float, style: str = "") -> str:
        return take(a, z, "v", "assets/cut.webm", 2, style) if pop else ""

    def asset_clip(path: Path, a: float, z: float, nm: str, track: int = 1) -> str:
        shutil.copy2(path, project / "assets" / nm)
        return (f'<video id="{vid_id()}" class="clip v" src="assets/{nm}" data-start="{T(a)}" data-duration="{T(z - a)}" data-track-index="{track}" '
                f'muted playsinline></video>')

    for i, s in enumerate(scenes):
        e, a, z, sid = s["effect"], s["a"], s["z"], f"f{i}"
        kw = E(keyword(s).upper().strip(".,"))
        txt = E(_text(s))
        d = z - a
        body = ""
        if e == "paper_cutout":
            body = (f'<div class="paper"></div><div class="torn" style="background:{acc}"></div>'
                    f'<div class="pc">{person(a, z)}</div><div class="marker"><span>{kw}</span></div>')
            k, t = 0, a + 0.05
            while t < z - 0.1:  # stop-motion: the cut-out shifts in steps
                tw.append(f'tl.set("#{sid} .pc", {{rotation: {[-1.6, 1.2, -0.8, 1.5][k % 4]}, x: {[-6, 4, 2, -3][k % 4] * u:.0f}}}, {T(t)});')
                k, t = k + 1, t + 0.17
            tw.append(f'tl.fromTo("#{sid} .marker span", {{clipPath: "inset(0 100% 0 0)"}}, {{clipPath: "inset(0 0% 0 0)", duration: 0.4, ease: "power2.out"}}, {T(a + 0.25)});')
        elif e == "magazine_cover":
            lines = list_items(s, 3)
            body = (f'<div class="solid" style="background:{acc}"></div><div class="mast" style="color:{on_acc}">{kw[:10]}</div>'
                    f'<div class="cam">{person(a, z)}</div>'
                    f'<div class="issue" style="color:{on_acc}">ISSUE {i + 1:02d} · {E(name.upper())}</div>'
                    + "".join(f'<div class="cl" style="top:{(0.40 + k * 0.065) * H:.0f}px">{E(x.upper())}</div>' for k, x in enumerate(lines)))
            tw.append(f'tl.fromTo("#{sid} .mast", {{y: {-80 * u:.0f}, opacity: 0}}, {{y: 0, opacity: 1, duration: 0.5, ease: "expo.out"}}, {T(a)});')
            tw.append(f'tl.fromTo("#{sid} .cam", {{scale: 1}}, {{scale: 1.06, duration: {T(d)}, ease: "none"}}, {T(a)});')
            tw.append(f'tl.fromTo("#{sid} .cl", {{x: {-60 * u:.0f}, opacity: 0}}, {{x: 0, opacity: 1, duration: 0.35, ease: "power3.out", stagger: 0.15}}, {T(a + 0.35)});')
        elif e == "screen_wall":
            tiles = "".join(f'<div class="tile">{take(a, z, "v", track=1 if k == 4 else 3)}</div>' for k in range(9))
            body = f'<div class="solid" style="background:#0c0d10"></div><div class="wall">{tiles}</div>'
            tw.append(f'tl.fromTo("#{sid} .wall", {{scale: 3.05}}, {{scale: 1, duration: {T(min(1.6, d * 0.6))}, ease: "expo.inOut"}}, {T(a + 0.15)});')
        elif e == "pixel_zoom":
            px = render_pixel(video, a, project / f"_{sid}px.mp4")
            body = (f'<div class="cam">{take(a, z)}</div><div class="full">{asset_clip(px, a, min(z, a + 0.56), f"{sid}px.mp4", 3)}</div>')
            tw.append(f'tl.fromTo("#{sid} .cam", {{scale: 1.35}}, {{scale: 1, duration: 0.9, ease: "expo.out"}}, {T(a + 0.5)});')
        elif e == "sketch_boil":
            sk = render_sketch(video, a, z, project / f"_{sid}sk.mp4")
            body = f'<div class="full">{asset_clip(sk, a, z, f"{sid}sk.mp4")}</div><div class="marker ink"><span>{kw}</span></div>'
            tw.append(f'tl.fromTo("#{sid} .marker span", {{clipPath: "inset(0 100% 0 0)"}}, {{clipPath: "inset(0 0% 0 0)", duration: 0.5, ease: "power2.out"}}, {T(a + 0.3)});')
        elif e == "graph_rise":
            nums = [w for w in s["words"] if _num_value(w["word"])]
            n = nums[0] if nums else None
            bars = "".join(f'<i style="height:{h}%;left:{8 + k * 17}%"></i>' for k, h in enumerate((22, 34, 48, 66, 92)))
            label = ""
            if n:
                pre, val, suf, dec = _num_value(n["word"])
                label = f'<div class="gval">{E(pre)}<span id="{sid}n">0</span>{E(suf)}</div>'
                tw.append(_count(f"{sid}n", val, dec, n["start"] - 0.2, 1.0))
                events.append({"t": n["start"], "kind": "number"})
            else:
                label = f'<div class="gval">{kw}</div>'
            body = (f'<div class="solid" style="background:{dark}"></div><div class="graph" style="--c:{acc}">{bars}</div>'
                    f'<div class="cam">{person(a, z)}</div>{label}')
            tw.append(f'tl.fromTo("#{sid} .graph i", {{scaleY: 0}}, {{scaleY: 1, duration: 0.7, ease: "expo.out", stagger: 0.09}}, {T(a + 0.1)});')
            tw.append(f'tl.fromTo("#{sid} .gval", {{y: {40 * u:.0f}, opacity: 0}}, {{y: 0, opacity: 1, duration: 0.4, ease: "back.out(1.8)"}}, {T(a + 0.3)});')
        elif e == "glass_text":
            bl = render_blur(video, a, z, project / f"_{sid}bl.mp4")
            body = (f'<div class="cam">{take(a, z)}</div><div class="glass">{asset_clip(bl, a, z, f"{sid}bl.mp4", 3)}'
                    f'<div class="gt">{kw}</div><div class="gs">{E(" ".join(_text(s).split()[:7]))}</div></div>')
            tw.append(f'tl.fromTo("#{sid} .glass", {{y: {H * 0.3:.0f}, opacity: 0}}, {{y: 0, opacity: 1, duration: 0.55, ease: "expo.out"}}, {T(a + 0.1)});')
        elif e == "orbit_spin":
            chips = list_items(s, 3)
            body = (f'<div class="solid" style="background:{light}"></div><div class="persp"><div class="card3d">{take(a, z)}</div></div>'
                    f'<div class="orbit">' + "".join(f'<div class="ochip" style="rotate:{k * 120}deg"><span style="rotate:{-k * 120}deg;background:{acc};color:{on_acc}">{E(x)}</span></div>'
                                                     for k, x in enumerate(chips)) + '</div>')
            tw.append(f'tl.fromTo("#{sid} .card3d", {{rotationY: -180, scale: 0.7}}, {{rotationY: 0, scale: 1, duration: 0.9, ease: "expo.out"}}, {T(a)});')
            tw.append(f'tl.fromTo("#{sid} .orbit", {{rotation: 0}}, {{rotation: 120, duration: {T(d)}, ease: "none"}}, {T(a)});')
        elif e == "pull_out_reveal":
            pts = list_items(s, 2)
            body = (f'<div class="solid" style="background:{light}"></div>'
                    f'<div class="rev">' + "".join(f'<div class="rp"><b style="background:{acc};color:{on_acc}">{k + 1}</b>{E(x)}</div>' for k, x in enumerate(pts)) + '</div>'
                    f'<div class="pull">{take(a, z)}</div>')
            tw.append(f'tl.fromTo("#{sid} .pull", {{scale: 1, y: 0, borderRadius: 0}}, {{scale: 0.56, y: {-H * 0.2:.0f}, borderRadius: {40 * u:.0f}, duration: 0.8, ease: "expo.inOut"}}, {T(a + 0.35)});')
            tw.append(f'tl.fromTo("#{sid} .rp", {{y: {30 * u:.0f}, opacity: 0}}, {{y: 0, opacity: 1, duration: 0.4, ease: "power3.out", stagger: 0.18}}, {T(a + 0.9)});')
        elif e == "phone_frame":
            body = (f'<div class="solid" style="background:{light}"></div><div class="head" style="color:{INK}">{kw}</div>'
                    f'<div class="phone"><div class="scr">{take(a, z)}</div><i class="notch"></i></div>')
            tw.append(f'tl.fromTo("#{sid} .phone", {{y: {H * 0.5:.0f}, rotation: -10}}, {{y: 0, rotation: 0, duration: 0.7, ease: "expo.out"}}, {T(a)});')
            tw.append(f'tl.fromTo("#{sid} .head", {{opacity: 0, y: {-30 * u:.0f}}}, {{opacity: 1, y: 0, duration: 0.4, ease: "power3.out"}}, {T(a + 0.25)});')
        elif e == "dolly_zoom":
            bl = render_blur(video, a, z, project / f"_{sid}bl.mp4")
            body = (f'<div class="cam bgz">{asset_clip(bl, a, z, f"{sid}bl.mp4")}</div><div class="cam fgz">{person(a, z)}</div>')
            tw.append(f'tl.fromTo("#{sid} .bgz", {{scale: 1}}, {{scale: 1.45, duration: {T(d)}, ease: "power1.inOut"}}, {T(a)});')
            tw.append(f'tl.fromTo("#{sid} .fgz", {{scale: 1.04}}, {{scale: 0.96, duration: {T(d)}, ease: "power1.inOut"}}, {T(a)});')
        elif e == "news_wall":
            heads = list_items(s, 3)
            body = (f'<div class="solid" style="background:#0f1420"></div><div class="mon">{take(a, z)}</div>'
                    f'<div class="nh">' + "".join(f'<div class="nt" style="border-color:{acc}">{E(x.upper())}</div>' for x in heads) + '</div>'
                    f'<div class="ticker"><b style="background:{acc};color:{on_acc}">BREAKING</b><span>{txt.upper()} · {E(name.upper())} · {txt.upper()}</span></div>')
            tw.append(f'tl.fromTo("#{sid} .mon", {{rotationX: 70, opacity: 0}}, {{rotationX: 0, opacity: 1, duration: 0.6, ease: "expo.out"}}, {T(a)});')
            tw.append(f'tl.fromTo("#{sid} .nt", {{x: {80 * u:.0f}, opacity: 0}}, {{x: 0, opacity: 1, duration: 0.35, ease: "power3.out", stagger: 0.14}}, {T(a + 0.3)});')
            tw.append(f'tl.fromTo("#{sid} .ticker span", {{x: 0}}, {{x: {-W * 1.2:.0f}, duration: {T(d)}, ease: "none"}}, {T(a)});')
        elif e == "frame_pop":
            # the frame shows the lower part of a taller shot; the cut-out of that same shot rises over its top edge
            body = (f'<div class="solid" style="background:{light}"></div><div class="fpw"><div class="frame">{take(a, z)}</div>'
                    f'<div class="popc">{person(a, z)}</div></div>')
            tw.append(f'tl.fromTo("#{sid} .fpw", {{scale: 0.6, rotation: -8, opacity: 0}}, {{scale: 1, rotation: -3, opacity: 1, duration: 0.6, ease: "back.out(1.5)"}}, {T(a)});')
        elif e == "punch_through":
            sheet = f'<div class="sk" style="color:{on_acc}">{kw}</div>'
            body = (f'<div class="cam">{take(a, z)}</div><div class="sheet tl" style="background:{acc}">{sheet}</div>'
                    f'<div class="sheet tr" style="background:{acc}">{sheet}</div><div class="cam burst">{person(a, z)}</div>')
            tw.append(f'tl.to("#{sid} .tl", {{x: {-W * 0.75:.0f}, rotation: -14, duration: 0.45, ease: "expo.in"}}, {T(a + 0.5)});')
            tw.append(f'tl.to("#{sid} .tr", {{x: {W * 0.75:.0f}, rotation: 14, duration: 0.45, ease: "expo.in"}}, {T(a + 0.5)});')
            tw.append(f'tl.fromTo("#{sid} .burst", {{scale: 1.4, opacity: 0}}, {{scale: 1, opacity: 1, duration: 0.5, ease: "expo.out"}}, {T(a + 0.6)});')
        elif e == "green_screen":
            body = (f'<div class="set" style="--a:{acc};--b:{dark}"></div><div class="setw" style="color:{on_acc}">{kw} · {kw}</div>'
                    f'<div class="cam">{person(a, z)}</div>')
            tw.append(f'tl.fromTo("#{sid} .setw", {{x: {W * 0.1:.0f}}}, {{x: {-W * 0.1:.0f}, duration: {T(d)}, ease: "none"}}, {T(a)});')
        elif e == "interface_world":
            side = list_items(s, 4)
            body = (f'<div class="solid" style="background:{light}"></div><div class="app"><div class="bar"><i></i><i></i><i></i><span>{E(name)}</span></div>'
                    f'<div class="side">' + "".join(f'<div class="si{" on" if k == 0 else ""}" style="{f"background:{acc};color:{on_acc}" if k == 0 else ""}">{E(x)}</div>' for k, x in enumerate(side)) + '</div>'
                    f'<div class="main"><div class="drop">⇪ Drop files here</div><div class="vp">{take(a, z)}</div></div></div><div class="cursor"></div>')
            tw.append(f'tl.fromTo("#{sid} .app", {{scale: 0.85, opacity: 0}}, {{scale: 1, opacity: 1, duration: 0.6, ease: "expo.out"}}, {T(a)});')
            tw.append(f'tl.fromTo("#{sid} .cursor", {{x: {W * 0.5:.0f}, y: {H * 0.3:.0f}}}, {{x: 0, y: 0, duration: 0.7, ease: "power3.inOut"}}, {T(a + 0.4)});')
            tw.append(f'tl.fromTo("#{sid} .cursor", {{scale: 1}}, {{scale: 0.8, duration: 0.08, yoyo: true, repeat: 1}}, {T(a + 1.1)});')
            events.append({"t": a + 1.1, "kind": "ui"})
        elif e == "tick_list":
            items = list_items(s, 4)
            ts = [w["start"] for w in s["words"]]
            body = (f'<div class="cam">{take(a, z)}</div><div class="note"><i class="tape"></i><div class="nh2">THE LIST · {i + 1:02d}</div>'
                    + "".join(f'<div class="li" id="{sid}i{k}"><b class="tk">✓</b>{E(x)}</div>' for k, x in enumerate(items)) + '</div>')
            tw.append(f'tl.fromTo("#{sid} .note", {{rotation: -12, y: {-H * 0.3:.0f}}}, {{rotation: -3, y: 0, duration: 0.6, ease: "back.out(1.4)"}}, {T(a)});')
            for k in range(len(items)):
                tk = min(z - 0.2, ts[min(len(ts) - 1, int((k + 1) * len(ts) / (len(items) + 0.5)))])
                tw.append(f'tl.fromTo("#{sid}i{k} .tk", {{scale: 0, opacity: 0}}, {{scale: 1, opacity: 1, duration: 0.25, ease: "back.out(2.5)"}}, {T(tk)});')
                events.append({"t": tk, "kind": "ui"})
        layers.append(f'<div class="fx" id="{sid}" style="z-index:{10 + i}">{body}</div>')
        # in and out: each scene cuts in with a quick scale settle; the cut is the transition
        tw.append(f'tl.set("#{sid}", {{opacity: 1}}, {T(a)});')
        if i:
            tw.append(f'tl.fromTo("#{sid}", {{scale: 1.08}}, {{scale: 1, duration: 0.35, ease: "expo.out"}}, {T(a)});')
        if i + 1 < len(scenes):
            tw.append(f'tl.set("#{sid}", {{opacity: 0}}, {T(z)});')
        events.append({"t": a, "kind": EFFECTS[e][2]})
        if counter:
            layers.append(f'<div id="n{i}" class="cnt clip" data-start="{T(a)}" data-duration="{T(z - a)}" data-track-index="6"><b>{i + 1:02d}</b>/{len(scenes):02d}</div>')

    # captions: bold word groups, low on the frame (above the platform buttons)
    caps = []
    groups = caption_groups(words)
    for k, g in enumerate(groups):
        a = g[0]["start"] - 0.03
        z = min(groups[k + 1][0]["start"] - 0.03 if k + 1 < len(groups) else total, g[-1]["end"] + 0.8)
        if z - a < 0.08:
            continue
        caps.append(f'<div id="c{k}" class="clip capw" data-start="{T(a)}" data-duration="{T(z - a)}" data-track-index="5">'
                    f'<div class="cap">{E(" ".join(w["word"].rstrip(",.;:!?") for w in g)).upper()}</div></div>')
        tw.append(f'tl.fromTo("#c{k} .cap", {{opacity: 0, scale: 0.85}}, {{opacity: 1, scale: 1, duration: 0.14, ease: "back.out(2)"}}, {T(a)});')

    vr = vw_ / max(1, vh_)
    k_face = min(0.7, max(0.2, frame[0] + 0.12))  # mid-face, as a fraction of the shot's height
    lift = k_face * 0.50 * H / (1 - k_face)       # how far the shot rises above the frame so the face meets its top edge
    page = f"""<!doctype html>
<!-- AutoCut effects edit (HyperFrames). {len(scenes)} scenes: {", ".join(s["effect"] for s in scenes)}. Open in HyperFrames Studio to fine-tune. -->
<html lang="en"><head><meta charset="UTF-8">
<script src="assets/gsap.min.js"></script>
<style>
{faces}
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
html, body {{ width: {W}px; height: {H}px; overflow: hidden; background: #0c0d10; }}
body {{ font-family: "{body_font}", "Inter", sans-serif; color: {INK}; -webkit-font-smoothing: antialiased; }}
#root {{ position: absolute; inset: 0; overflow: hidden; }}
.fx {{ position: absolute; inset: 0; overflow: hidden; opacity: 0; }}
.fx video {{ position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; display: block; }}
.cam, .full, .solid {{ position: absolute; inset: 0; }}
.capw {{ position: absolute; inset: 0; z-index: 60; }}
.cap {{ position: absolute; left: 0; right: 0; top: {round(0.70 * H)}px; text-align: center; padding: 0 {60 * u:.0f}px;
  font-family: "{head_font}", "Inter", sans-serif; font-weight: 900; font-size: {78 * u:.0f}px; letter-spacing: -0.02em; line-height: 1.02;
  color: #fff; text-shadow: 0 {4 * u:.0f}px 0 rgba(0,0,0,0.35), 0 0 {24 * u:.0f}px rgba(0,0,0,0.45); }}
.cnt {{ position: absolute; right: {48 * u:.0f}px; top: {round(0.045 * H)}px; z-index: 61; background: rgba(17,17,17,0.82); color: #bdb7ae;
  font-weight: 700; font-size: {30 * u:.0f}px; padding: {8 * u:.0f}px {18 * u:.0f}px; border-radius: 999px; font-variant-numeric: tabular-nums; }}
.cnt b {{ color: #fff; }}
/* paper cut-out */
.paper {{ position: absolute; inset: 0; background: {PAPER}; background-image: radial-gradient(rgba(120,100,70,0.08) 1px, transparent 1.4px);
  background-size: {9 * u:.0f}px {9 * u:.0f}px; }}
.torn {{ position: absolute; left: -5%; right: -5%; top: 34%; height: 30%; rotate: -4deg;
  clip-path: polygon(0 8%,6% 0,13% 7%,21% 1%,30% 9%,38% 2%,47% 8%,56% 0,64% 7%,73% 2%,82% 9%,91% 1%,100% 6%,100% 94%,92% 100%,83% 92%,74% 99%,64% 93%,55% 100%,46% 92%,37% 99%,27% 92%,18% 100%,9% 93%,0 99%); }}
.pc {{ position: absolute; inset: 0; filter: drop-shadow(0 0 {5 * u:.0f}px #fff) drop-shadow(0 0 {3 * u:.0f}px #fff) drop-shadow({10 * u:.0f}px {14 * u:.0f}px 0 rgba(40,30,20,0.28)); }}
.marker {{ position: absolute; left: 0; right: 0; top: {round(0.13 * H)}px; text-align: center; }}
.marker span {{ display: inline-block; font-family: "{head_font}", sans-serif; font-weight: 900; font-size: {96 * u:.0f}px; letter-spacing: -0.02em;
  background: linear-gradient(transparent 55%, {TAPE} 55%); padding: 0 {14 * u:.0f}px; color: {INK}; }}
.marker.ink span {{ background: none; color: {INK}; font-size: {110 * u:.0f}px; }}
/* magazine */
.mast {{ position: absolute; left: 0; right: 0; top: {round(0.075 * H)}px; text-align: center; font-family: "{head_font}", serif; font-weight: 900;
  font-size: {230 * u:.0f}px; letter-spacing: -0.05em; line-height: 0.9; white-space: nowrap; }}
.issue {{ position: absolute; left: {50 * u:.0f}px; top: {round(0.05 * H)}px; font-weight: 800; font-size: {24 * u:.0f}px; letter-spacing: 0.2em; }}
.cl {{ position: absolute; left: {50 * u:.0f}px; max-width: {480 * u:.0f}px; background: #fff; color: {INK}; font-weight: 900; font-size: {34 * u:.0f}px;
  padding: {8 * u:.0f}px {16 * u:.0f}px; line-height: 1.05; }}
/* screen wall */
.wall {{ position: absolute; inset: 0; transform-origin: 50% 50%; display: grid; grid-template-columns: repeat(3, 1fr); gap: {14 * u:.0f}px; }}
.tile {{ position: relative; overflow: hidden; border-radius: {14 * u:.0f}px; box-shadow: 0 0 0 {3 * u:.0f}px #22252c; }}
/* graph */
.graph {{ position: absolute; left: 6%; right: 6%; top: 18%; height: 46%; }}
.graph i {{ position: absolute; bottom: 0; width: 13%; background: var(--c); border-radius: {12 * u:.0f}px {12 * u:.0f}px 0 0; transform-origin: 50% 100%; opacity: 0.9; }}
.gval {{ position: absolute; left: 0; right: 0; top: {round(0.08 * H)}px; text-align: center; font-family: "{head_font}", sans-serif; font-weight: 900;
  font-size: {150 * u:.0f}px; color: #fff; letter-spacing: -0.03em; font-variant-numeric: tabular-nums; }}
/* glass */
.glass {{ position: absolute; left: {60 * u:.0f}px; right: {60 * u:.0f}px; top: {round(0.12 * H)}px; height: {round(0.3 * H)}px; overflow: hidden;
  border-radius: {36 * u:.0f}px; box-shadow: inset 0 0 0 {2 * u:.0f}px rgba(255,255,255,0.55), 0 {20 * u:.0f}px {60 * u:.0f}px rgba(0,0,0,0.3); }}
.glass video {{ opacity: 0.92; }}
.gt {{ position: absolute; left: 0; right: 0; top: 22%; text-align: center; font-family: "{head_font}", sans-serif; font-weight: 900; font-size: {120 * u:.0f}px;
  color: #fff; letter-spacing: -0.03em; text-shadow: 0 {3 * u:.0f}px {14 * u:.0f}px rgba(0,0,0,0.25); }}
.gs {{ position: absolute; left: 8%; right: 8%; bottom: 14%; text-align: center; color: rgba(255,255,255,0.92); font-weight: 600; font-size: {34 * u:.0f}px; }}
/* orbit */
.persp {{ position: absolute; inset: 0; perspective: {1600 * u:.0f}px; }}
.card3d {{ position: absolute; left: 14%; right: 14%; top: 16%; bottom: 30%; overflow: hidden; border-radius: {40 * u:.0f}px;
  box-shadow: 0 {30 * u:.0f}px {80 * u:.0f}px rgba(0,0,0,0.3); backface-visibility: hidden; }}
.orbit {{ position: absolute; left: 50%; top: 40%; width: 0; height: 0; }}
.ochip {{ position: absolute; left: 0; top: 0; transform-origin: 0 0; }}
.ochip span {{ position: absolute; left: -{120 * u:.0f}px; top: -{560 * u:.0f}px; width: {240 * u:.0f}px; text-align: center; font-weight: 900;
  font-size: {32 * u:.0f}px; padding: {12 * u:.0f}px 0; border-radius: 999px; box-shadow: 0 {10 * u:.0f}px {30 * u:.0f}px rgba(0,0,0,0.25); }}
/* pull-out */
.pull {{ position: absolute; inset: 0; overflow: hidden; transform-origin: 50% 50%; box-shadow: 0 {30 * u:.0f}px {80 * u:.0f}px rgba(0,0,0,0.3); }}
.rev {{ position: absolute; left: {80 * u:.0f}px; right: {80 * u:.0f}px; top: {round(0.585 * H)}px; display: flex; flex-direction: column; gap: {22 * u:.0f}px; }}
.rp {{ display: flex; align-items: center; gap: {22 * u:.0f}px; font-weight: 800; font-size: {44 * u:.0f}px; color: {INK}; }}
.rp b {{ width: {64 * u:.0f}px; height: {64 * u:.0f}px; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex: none; }}
/* phone */
.head {{ position: absolute; left: 0; right: 0; top: {round(0.06 * H)}px; text-align: center; font-family: "{head_font}", sans-serif; font-weight: 900;
  font-size: {110 * u:.0f}px; letter-spacing: -0.03em; }}
.phone {{ position: absolute; left: 50%; top: {round(0.17 * H)}px; width: {560 * u:.0f}px; height: {1120 * u:.0f}px; margin-left: -{280 * u:.0f}px;
  background: #0d0d0f; border-radius: {80 * u:.0f}px; padding: {18 * u:.0f}px; box-shadow: 0 {40 * u:.0f}px {90 * u:.0f}px rgba(0,0,0,0.35); }}
.phone .scr {{ position: absolute; inset: {18 * u:.0f}px; overflow: hidden; border-radius: {64 * u:.0f}px; }}
.notch {{ position: absolute; left: 50%; top: {34 * u:.0f}px; width: {150 * u:.0f}px; height: {40 * u:.0f}px; margin-left: -{75 * u:.0f}px; background: #0d0d0f; border-radius: 999px; }}
/* dolly */
.bgz, .fgz {{ transform-origin: 50% 40%; }}
/* news */
.mon {{ position: absolute; left: {50 * u:.0f}px; right: {50 * u:.0f}px; top: {round(0.12 * H)}px; height: {round(0.42 * H)}px; overflow: hidden;
  border-radius: {18 * u:.0f}px; box-shadow: 0 0 0 {6 * u:.0f}px #1d2433, 0 {24 * u:.0f}px {60 * u:.0f}px rgba(0,0,0,0.5); transform-origin: 50% 100%; }}
.nh {{ position: absolute; left: {50 * u:.0f}px; right: {50 * u:.0f}px; top: {round(0.57 * H)}px; display: flex; flex-direction: column; gap: {12 * u:.0f}px; }}
.nt {{ background: #1a2131; color: #fff; font-weight: 800; font-size: {32 * u:.0f}px; padding: {14 * u:.0f}px {20 * u:.0f}px; border-left: {10 * u:.0f}px solid; }}
.ticker {{ position: absolute; left: 0; right: 0; bottom: {round(0.12 * H)}px; height: {74 * u:.0f}px; background: #fff; overflow: hidden; display: flex; align-items: center; }}
.ticker b {{ position: relative; z-index: 2; height: 100%; display: flex; align-items: center; padding: 0 {22 * u:.0f}px; font-weight: 900; font-size: {30 * u:.0f}px; letter-spacing: 0.06em; }}
.ticker span {{ white-space: nowrap; font-weight: 800; font-size: {32 * u:.0f}px; color: {INK}; padding-left: {30 * u:.0f}px; }}
/* frame pop */
.fpw {{ position: absolute; inset: 0; transform-origin: 50% 65%; }}
.frame {{ position: absolute; left: {0.12 * W:.0f}px; width: {0.76 * W:.0f}px; top: {0.40 * H:.0f}px; height: {0.50 * H:.0f}px; overflow: hidden;
  outline: {22 * u:.0f}px solid #fff; box-shadow: 0 {30 * u:.0f}px {70 * u:.0f}px rgba(0,0,0,0.28); }}
.fx .frame video {{ top: -{lift:.0f}px; height: {0.50 * H + lift:.0f}px; inset: auto; left: 0; width: 100%; }}
.popc {{ position: absolute; left: {0.12 * W:.0f}px; width: {0.76 * W:.0f}px; top: {0.40 * H - lift:.0f}px; height: {0.50 * H + lift:.0f}px; }}
/* punch-through */
.sheet {{ position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; }}
.sheet.tl {{ clip-path: polygon(0 0, 52% 0, 47% 14%, 54% 30%, 46% 46%, 53% 62%, 47% 78%, 52% 100%, 0 100%); transform-origin: 0 50%; }}
.sheet.tr {{ clip-path: polygon(52% 0, 100% 0, 100% 100%, 52% 100%, 47% 78%, 53% 62%, 46% 46%, 54% 30%, 47% 14%); transform-origin: 100% 50%; }}
.sk {{ font-family: "{head_font}", sans-serif; font-weight: 900; font-size: {170 * u:.0f}px; letter-spacing: -0.04em; }}
/* green screen set */
.set {{ position: absolute; inset: 0; background: radial-gradient(circle at 50% 35%, var(--a) 0%, var(--b) 75%); }}
.setw {{ position: absolute; left: -20%; right: -20%; top: {round(0.16 * H)}px; text-align: center; font-family: "{head_font}", sans-serif; font-weight: 900;
  font-size: {210 * u:.0f}px; letter-spacing: -0.04em; opacity: 0.22; white-space: nowrap; }}
/* interface world */
.app {{ position: absolute; left: {40 * u:.0f}px; right: {40 * u:.0f}px; top: {round(0.1 * H)}px; bottom: {round(0.33 * H)}px; background: #fff;
  border-radius: {30 * u:.0f}px; overflow: hidden; box-shadow: 0 {30 * u:.0f}px {80 * u:.0f}px rgba(0,0,0,0.22); }}
.bar {{ height: {64 * u:.0f}px; display: flex; align-items: center; gap: {10 * u:.0f}px; padding: 0 {24 * u:.0f}px; border-bottom: {2 * u:.0f}px solid #eee; }}
.bar i {{ width: {16 * u:.0f}px; height: {16 * u:.0f}px; border-radius: 50%; background: #e2ddd5; }}
.bar span {{ margin-left: auto; margin-right: auto; font-weight: 800; font-size: {26 * u:.0f}px; color: #6b665f; }}
.side {{ position: absolute; left: 0; top: {64 * u:.0f}px; bottom: 0; width: 30%; border-right: {2 * u:.0f}px solid #eee; padding: {20 * u:.0f}px; display: flex; flex-direction: column; gap: {10 * u:.0f}px; }}
.si {{ font-weight: 700; font-size: {26 * u:.0f}px; color: #4a453f; padding: {10 * u:.0f}px {14 * u:.0f}px; border-radius: {12 * u:.0f}px; }}
.main {{ position: absolute; left: 30%; right: 0; top: {64 * u:.0f}px; bottom: 0; padding: {24 * u:.0f}px; }}
.drop {{ height: 18%; border: {3 * u:.0f}px dashed #d8d2c8; border-radius: {18 * u:.0f}px; display: flex; align-items: center; justify-content: center;
  color: #8f897f; font-weight: 700; font-size: {26 * u:.0f}px; }}
.vp {{ position: absolute; left: {24 * u:.0f}px; right: {24 * u:.0f}px; top: 26%; bottom: {24 * u:.0f}px; overflow: hidden; border-radius: {18 * u:.0f}px; }}
.cursor {{ position: absolute; left: 62%; top: 22%; width: {44 * u:.0f}px; height: {44 * u:.0f}px; background: {INK};
  clip-path: polygon(0 0, 0 80%, 24% 62%, 40% 100%, 54% 94%, 38% 58%, 70% 58%); }}
/* tick list */
.note {{ position: absolute; left: {50 * u:.0f}px; top: {round(0.1 * H)}px; width: {560 * u:.0f}px; background: {PAPER}; padding: {34 * u:.0f}px {34 * u:.0f}px {28 * u:.0f}px;
  box-shadow: 0 {18 * u:.0f}px {40 * u:.0f}px rgba(0,0,0,0.28); }}
.tape {{ position: absolute; left: 50%; top: -{22 * u:.0f}px; width: {170 * u:.0f}px; height: {46 * u:.0f}px; margin-left: -{85 * u:.0f}px; background: {TAPE}; rotate: -3deg; }}
.nh2 {{ font-family: ui-monospace, "JetBrains Mono", monospace; font-size: {22 * u:.0f}px; letter-spacing: 0.22em; color: #8a8378; margin-bottom: {14 * u:.0f}px; }}
.li {{ display: flex; align-items: center; gap: {16 * u:.0f}px; font-weight: 800; font-size: {40 * u:.0f}px; color: #4b4740; padding: {6 * u:.0f}px 0; }}
.tk {{ width: {36 * u:.0f}px; color: {acc}; font-size: {36 * u:.0f}px; display: inline-block; }}
</style></head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{total}" data-width="{W}" data-height="{H}">
  {''.join(layers)}
  {''.join(caps)}
</div>
<script>
  window.__timelines = window.__timelines || {{}};
  const tl = gsap.timeline({{ paused: true }});
  {chr(10).join("  " + t for t in tw)}
  window.__timelines["main"] = tl;
</script>
</body></html>"""
    (project / "index.html").write_text(page, encoding="utf-8")
    for f in project.glob("_*.mp4"):
        f.unlink()
    (project / "events.json").write_text(json.dumps(sorted(events, key=lambda e: e["t"])))
    (project / "scenes.json").write_text(json.dumps([{"effect": s["effect"], "a": s["a"], "z": s["z"], "text": _text(s)} for s in scenes], indent=1))
    _ = vr
    return total


def _count(el: str, val: float, dec: int, t: float, d: float) -> str:
    return (f'(() => {{ const o = {{v: 0}}, el = document.getElementById("{el}"); '
            f'tl.fromTo(o, {{v: 0}}, {{v: {val}, duration: {d}, ease: "expo.out", onUpdate: () => {{ el.textContent = '
            f'o.v.toLocaleString("en-US", {{minimumFractionDigits: {dec}, maximumFractionDigits: {dec}}}); }}}}, {t:.3f}); }})();')


def make_video(source: Path, client: Client, size: tuple[int, int], out: Path, settings: dict, fps: float = 30,
               use_ai: bool = True, effects: list[str] | None = None, transcript: Path | None = None,
               counter: bool = True, sound: bool = True) -> Path:
    """Raw take → rough cut → one effect per sentence → HyperFrames project → MP4 with the voice (+ music and sound design)."""
    from ..media import probe
    from ..transcribe import load_or_transcribe
    from .customize import VIDEO_EXT
    from .explainer import _segmenter
    from .script import finish
    if source.suffix.lower() not in VIDEO_EXT:
        raise ValueError("The effects edit needs the video of the speaker (MP4 or MOV)")
    work = out.with_name("_work-" + out.stem)
    work.mkdir(parents=True, exist_ok=True)
    words = load_or_transcribe(source, work, settings, transcript, client.brand.get("vocabulary") or [])["words"]
    if not words:
        raise ValueError("No speech found in the video")
    video, cut_words, length = cut_take(source, words, client.brand, work)
    bs = beats(cut_words, max_words=9)
    seg = _segmenter()
    pop = None
    if seg is not None:
        try:
            pop = render_popout(video, seg, work / "cut.webm")
        except Exception:  # noqa: BLE001 - no cut-out: only the effects that don't need one
            pop = None
    names = plan(bs, settings if use_ai else None, client.brand, cutout=pop is not None, wanted=effects)
    scenes = [{**b, "effect": e} for b, e in zip(bs, names)]
    project = out.with_name("hf-" + out.stem)
    from .explainer import framing
    build(cut_words, scenes, client, size, project, settings, video, length, pop, counter, framing(video, seg))
    (project / "voice.txt").write_text(str((project / "assets" / "take.mp4").resolve()), encoding="utf-8")
    finish(project, out, settings, fps)
    if sound:
        try:
            from .. import sound as snd
            tmp = out.with_name(out.stem + "-scored.mp4")
            lines = [{"t": s["a"], "text": _text(s)} for s in scenes]
            snd.mix_video(out, tmp, client, settings, json.loads((project / "events.json").read_text()),
                          " ".join(x["text"] for x in lines), "short", lines=lines)
            tmp.replace(out)
        except Exception as e:  # noqa: BLE001 - sound is a bonus
            print(f"  ! sound skipped: {e}")
    _ = probe
    return out
