"""Create tab: turn a plain-English request into motion graphics, at any size, and render them.

    "lower third for 'Jordan Reyes' 'Owner, Acme Roofing' in square and vertical, green screen"
    "stat counter '$3,000' 'average saved' 4:5 at the top, blue #1d4ed8"
    "hook title 'Stop overpaying for roofs' all sizes, 3 seconds"

Reading the prompt: a local AI model via Ollama (if one is running on this Mac) for loose
wording, with built-in rules as the fallback and for anything the model leaves out.
"""
from __future__ import annotations

import copy
import json
import re
import shutil
import subprocess
import time
import urllib.request
from datetime import datetime
from pathlib import Path

from ..config import brand_backdrop, DEFAULT_BRAND, TEMPLATE_DIR, Client, clients_dir, deep_merge, load_client
from ..media import video_encoder
from . import customize, hyper, script
from .engine import Look
from .templates import POSITIONS, TEMPLATES, make

SIZES = {"vertical": (1080, 1920), "square": (1080, 1080), "portrait": (1080, 1350), "landscape": (1920, 1080),
         "4k": (3840, 2160), "4k-vertical": (2160, 3840)}
SIZE_WORDS = [
    (r"\b4k\b.*\b(vertical|9:16|reel|tiktok|story|shorts)\b|\b(vertical|9:16|reel|tiktok|story|shorts)\b.*\b4k\b", "4k-vertical"),
    (r"\b4k\b|\buhd\b", "4k"),
    (r"\bvertical\b|9:16|\breels?\b|\btiktok\b|\bstory\b|\bstories\b|\bshorts\b", "vertical"),
    (r"\bsquare\b|1:1", "square"),
    (r"4:5|\bportrait\b|\bfeed\b", "portrait"),
    (r"\blandscape\b|16:9|\byoutube\b|\bhorizontal\b|\bwidescreen\b", "landscape"),
]
TEMPLATE_WORDS = [
    ("chart", r"\b(bar|line|pie|donut|doughnut|column|area) ?(chart|graph)|\bchart\b|\bgraph\b|infographic|\bfunnel\b|"
              r"\btimeline\b|\bwaffle\b|progress (bar|ring|meter)"),
    ("quote", r"testimonial|review card|quote card|pull ?quote|\breview\b"),
    ("callout", r"call ?-?out|arrow pointing|pointing (at|to)|\bpin\b|annotat"),
    ("list", r"checklist|\bsteps\b|numbered list|\blist\b|\btop \d+\b|\bfeatures\b"),
    ("kinetic_type", r"kinetic|typograph|text animation|animated (text|quote|words|message)|\bquote\b|word[- ]by[- ]word"),
    ("lower_third", r"lower[- ]?third|name ?(tag|bar|plate)|title bar|nameplate"),
    ("stat_counter", r"counter|count(ing)? up|\bstat(istic)?s?\b|number card"),
    ("cta_outro", r"end ?card|outro|\bcta\b|call to action|end screen"),
    ("swipe", r"transition|swipe|\bwipe\b"),
    ("slam", r"\bslam\b|punch|\bhype\b|impact|\bboom\b"),
    ("phrase_card", r"\bpill\b|badge|phrase|\btag\b|callout|label"),
    ("hook_title", r"title|headline|\bhook\b|\bintro\b|heading"),
]
COLOR_NAMES = {
    "red": "#e63946", "blue": "#1d4ed8", "navy": "#1d3557", "green": "#16a34a", "yellow": "#facc15",
    "orange": "#f97316", "purple": "#7c3aed", "pink": "#ec4899", "teal": "#0d9488", "black": "#111111",
    "white": "#ffffff", "gold": "#d4a017", "gray": "#6b7280", "grey": "#6b7280", "brown": "#7c4a2d",
}
BACKGROUNDS = {"green": "#00b140", "black": "#000000", "white": "#ffffff", "blue": "#0047bb"}


def _quotes(prompt: str) -> list[str]:
    # an apostrophe inside a word ("who'd", "Reyes's") doesn't end a single-quoted phrase
    return [a or b or c or d for a, b, c, d in re.findall(
        r'"([^"]+)"|“([^”]+)”|‘([^’]+)’|(?<![A-Za-z])\'((?:[^\']|\'(?=[A-Za-z]))+)\'', prompt)]


# motion feel words (feel.py): how things ease, AE-style
FEEL_WORDS = [("elastic", r"\belastic|\bspring"), ("bouncy", r"\bbounc|overshoot"), ("punchy", r"\bpunchy\b|\bslam"),
              ("snappy", r"\bsnappy\b|\bsnap\b|\bcrisp\b"), ("cinematic", r"\bslow push|\bdreamy\b"),
              ("glow", r"\bglow(ing|y)?\b|\bbloom"), ("smooth", r"\bsmooth|easy ease|\bgentle\b")]
LOOK_WORDS = [("neon", r"\bneon\b"), ("luxury", r"\bluxur|\belegant\b|\bgold\b"), ("retro", r"\bretro\b|\bvintage\b|70s"),
              ("glitch", r"\bglitch"), ("minimal", r"\bminimal"), ("editorial", r"\beditorial\b|\bmagazine\b|\bserif\b"),
              ("brutal", r"brutalis"), ("glass", r"\bglass|frosted"), ("sport", r"\bsport|athletic"), ("playful", r"\bplayful\b|\bfun\b|bubbly"),
              ("cinematic", r"cinematic|trailer|\bfilm\b"), ("handmade", r"hand-?made|\bpaper\b|scribble|hand-?drawn"),
              ("swiss", r"\bswiss\b|\bgrid\b"), ("corporate", r"\bcorporate\b|\bclean\b"), ("broadcast", r"broadcast|\bnews\b"),
              ("gradient", r"gradient|vibrant"), ("organic", r"\borganic\b|\bsoft\b|wellness"), ("mono", r"\bterminal\b|monospace|\bcode\b")]
CHART_WORDS = [("line", r"line (chart|graph)|\btrend\b|area chart"), ("donut", r"\bpie\b|donut|doughnut|ring chart"),
               ("columns", r"column"), ("bars", r"bar (chart|graph)|\bbars\b"), ("timeline", r"timeline|milestone"),
               ("funnel", r"funnel"), ("waffle", r"waffle|dots? chart"), ("meter", r"progress|\bmeter\b"),
               ("compare", r"\bvs\.?\b|versus|compar|before.{0,20}after")]


def rule_parse(prompt: str) -> dict:
    p = prompt.lower()
    template = next((t for t, rx in TEMPLATE_WORDS if re.search(rx, p)), "hook_title")
    if re.search(r"\ball (sizes|formats|shapes|ratios)\b|\bevery (size|format)\b", p):
        sizes = ["vertical", "square", "portrait", "landscape"]
    else:
        sizes = []
        for rx, name in SIZE_WORDS:
            if re.search(rx, p) and name not in sizes:
                if name == "vertical" and "4k-vertical" in sizes or name == "landscape" and "4k" in sizes:
                    continue
                sizes.append(name)
        sizes = sizes or ["vertical"]
    position = next((k for k in ("top", "upper", "center", "lower", "bottom")
                     if re.search(rf"\b(at the |at |in the )?{k}\b", p) and not re.search(r"lower[- ]?third", p) or
                     (k == "lower" and re.search(r"\bat the lower\b", p))), None)
    if re.search(r"\bmiddle\b", p):
        position = "center"
    background = None
    if re.search(r"green ?screen|chroma", p):
        background = BACKGROUNDS["green"]
    else:
        m = re.search(r"\bon (a |an )?(black|white|blue|green)( background)?\b", p)
        if m:
            background = BACKGROUNDS[m.group(2)]
    dur = None
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:s|sec|secs|seconds)\b", p)
    if m:
        dur = max(0.6, min(20.0, float(m.group(1))))
    fps = 60 if re.search(r"\b60 ?fps\b", p) else 24 if re.search(r"\b24 ?fps\b", p) else 30
    found = [(m.start(), m.group(0).lower()) for m in re.finditer(r"#[0-9a-fA-F]{6}\b", prompt)]
    for name, hexv in COLOR_NAMES.items():
        for m in re.finditer(rf"\b{name}\b", p):
            if re.match(rf"{name}\s+#[0-9a-f]{{6}}", p[m.start():]):  # "blue #1d4ed8": the hex wins
                continue
            if background and re.search(rf"on (a |an )?{name}\b", p[max(0, m.start() - 6):m.end()]):
                continue
            if not re.match(rf"{name} ?screen", p[m.start():]):
                found.append((m.start(), hexv))
    colors = []
    for _, c in sorted(found):  # in the order they were written
        if c not in colors:
            colors.append(c)
    quotes = _quotes(prompt)
    params: dict = {}
    if template == "lower_third":
        if quotes:
            params["name"] = quotes[0]
            params["title"] = quotes[1] if len(quotes) > 1 else ""
        else:
            m = re.search(r"\bfor ([A-Z][\w'.-]+(?: [A-Z][\w'.-]+)*)(?:,\s*([^,]+?))?(?: in | at | on |,|$)", prompt)
            params["name"] = m.group(1) if m else "Your Name"
            params["title"] = (m.group(2) or "").strip() if m else ""
    elif template == "stat_counter":
        m = re.search(r"\$?\d[\d,]*(?:\.\d+)?%?", " ".join(quotes) or prompt)
        params["value"] = m.group(0) if m else "100"
        rest = [q for q in quotes if q != params["value"]]
        if rest:
            params["label"] = rest[0]
        else:
            after = re.search(re.escape(params["value"]) + r"\s+([a-z][a-z ]{2,30}?)(?: in | at | on |,|\.|$)", prompt, re.I)
            label = after.group(1).strip() if after else ""
            # drop trailing size/colour/position words ("happy customers vertical" → "happy customers")
            noise = {w for rx, _ in SIZE_WORDS for w in re.findall(r"[a-z]+", rx)} | set(COLOR_NAMES) | set(POSITIONS)
            words = label.split()
            while words and words[-1].lower() in noise:
                words.pop()
            params["label"] = " ".join(words)
    elif template == "chart":
        rest = re.sub(r'"[^"]*"|“[^”]*”', "", prompt)
        pairs = re.findall(r"(?:^|(?<=[\s,;]))([A-Za-z][\w&'/-]*(?: [A-Za-z][\w&'/-]*){0,2}?)\s*[:=]?\s+([$€£]?\d[\d,.]*%?)"
                           r"(?=[\s,;.]|$)", rest)
        def tidy(label: str) -> str:  # "monthly sales Jan" → "Jan" (keep a run of Capitalised words)
            ws = label.split()
            if all(w[:1].isupper() for w in ws):
                return label
            run = []
            for w in reversed(ws):
                if not w[:1].isupper():
                    break
                run.insert(0, w)
            return " ".join(run) or ws[-1]
        pairs = [(tidy(a.strip()), b.rstrip(",.")) for a, b in pairs]
        if len(pairs) >= 2:
            params["items"] = "\n".join(f"{a}: {b}" for a, b in pairs)
            if quotes:
                params["title"] = quotes[0]
        elif pairs or re.search(r"\d+%", prompt):
            m = re.search(r"\d[\d.]*%", prompt)
            params["value"] = m.group(0) if m else pairs[0][1]
            params["label"] = quotes[0] if quotes else ""
        elif quotes:
            params["title"] = quotes[0]
    elif template == "list":
        if len(quotes) > 1:
            params["title"], params["items"] = (quotes[0], "\n".join(quotes[1:])) if len(quotes) > 3 else ("", "\n".join(quotes))
        elif quotes:
            params["items"] = "\n".join(x.strip() for x in re.split(r"\s*/\s*|\n|;", quotes[0]) if x.strip())
    elif template == "quote":
        params["text"] = quotes[0] if quotes else "Your customer's words here"
        if len(quotes) > 1:
            params["author"] = quotes[1]
        if len(quotes) > 2:
            params["role"] = quotes[2]
        params["stars"] = 5
    elif template == "callout":
        params["text"] = quotes[0] if quotes else "Look here"
    elif template == "slam":
        params["word"] = quotes[0] if quotes else (re.findall(r"\b[A-Z]{2,}\b", prompt) or ["WOW"])[0]
    elif template == "cta_outro":
        params["text"] = quotes[0] if quotes else "Book today"
        params["sub"] = quotes[1] if len(quotes) > 1 else "Link in bio"
    elif template != "swipe":
        key = "text"
        if quotes:
            params[key] = quotes[0]
        else:
            m = re.search(r"(?:saying|says|that reads|reading|:)\s+(.+?)(?: in | at | on |,|$)", prompt, re.I)
            params[key] = m.group(1).strip() if m else "Your title here"
    if dur:
        params["dur"] = dur
    out = {"template": template, "params": params, "sizes": sizes, "position": position,
           "background": background, "colors": colors[:2], "fps": fps}
    look = next((k for k, rx in LOOK_WORDS if re.search(rx, p)), None)
    if look:
        out["look"] = look
    feel = next((k for k, rx in FEEL_WORDS if re.search(rx, p)), None)
    if feel:
        out["feel"] = feel
    if template == "chart":
        out["layout"] = next((k for k, rx in CHART_WORDS if re.search(rx, p)), "")
    return out


SPEC_SCHEMA = {"type": "object", "properties": {
    "template": {"type": "string"}, "params": {"type": "object", "properties": {
        "text": {"type": "string"}, "word": {"type": "string"}, "value": {"type": "string"}, "label": {"type": "string"},
        "name": {"type": "string"}, "title": {"type": "string"}, "sub": {"type": "string"}, "dur": {"type": "number"},
        "brief": {"type": "string"}, "items": {"type": "string"}, "author": {"type": "string"},
        "role": {"type": "string"}}},
    "sizes": {"type": "array", "items": {"type": "string"}}, "position": {"type": "string"},
    "background": {"type": "string"}, "colors": {"type": "array", "items": {"type": "string"}}, "fps": {"type": "integer"}},
    "required": ["template", "params"]}


def llm_parse(prompt: str, settings: dict) -> dict | None:
    """The AI brain (free local model first, Claude as backup) fills the same spec. None if no AI is available."""
    from .. import brain
    from . import hyper
    names = list(TEMPLATES) + (["chart", "list", "quote", "callout", "custom"] if hyper.available(settings) else [])
    guide = ("Turn a motion-graphics request into a spec. template: one of " + json.dumps(names) +
             ". params by template: hook_title {text}, slam {word}, stat_counter {value, label}, phrase_card {text}, "
             "lower_third {name, title}, cta_outro {text, sub}, swipe {}, chart {title, items: 'Label: number' lines, or value + label for one "
             "percentage}, list {title, items: one per line}, quote {text, author, role}, callout {text}, kinetic_type {text: the message, beats split "
             "with ' / ', a *keyword* in asterisks gets the brand colour}; any may add dur (seconds). sizes: any of "
             + json.dumps(list(SIZES)) + ". position: one of " + json.dumps(list(POSITIONS)) + " or empty. "
             "background: a #rrggbb colour only if they asked for a solid/green-screen background, else empty. "
             "colors: #rrggbb colours they named, else empty. fps: 24, 30 or 60. Use only text the user wrote; "
             "for kinetic_type you may split their message into punchy beats." +
             (" custom {brief: the whole request in your words, with every piece of text it should show}: only when none "
              "of the other templates fits (a chart, a list, a map, a logo reveal, a multi-part animation, a "
              "particular style)." if "custom" in names else ""))
    from .. import marketing
    out = brain.ask(settings, marketing.knowledge("motion", "hooks") + "\n\nYou are the agency's motion designer. " + guide,
                    "Request: " + prompt, SPEC_SCHEMA,
                    timeout=90)
    return out if isinstance(out, dict) else None


def parse(prompt: str, settings: dict, reference: dict | None = None) -> dict:
    spec = rule_parse(prompt)
    named_template = any(re.search(rx, prompt.lower()) for _, rx in TEMPLATE_WORDS)
    from . import hyper
    custom_ok = hyper.available(settings)
    if custom_ok and re.match(r"\s*custom\b\s*:?", prompt, re.I):  # "custom: …" always goes to the AI designer
        spec.update(template="custom", params={"brief": re.sub(r"^\s*custom\b\s*:?\s*", "", prompt, flags=re.I)})
        named_template = True
    ai = llm_parse(prompt, settings)
    if isinstance(ai, dict) and spec["template"] == "custom":
        sizes = [x for x in (ai.get("sizes") or []) if x in SIZES]
        spec["sizes"] = sizes or spec["sizes"]
    elif isinstance(ai, dict):
        if ai.get("template") == "custom" and custom_ok:
            spec["template"], spec["params"] = "custom", {"brief": (ai.get("params") or {}).get("brief") or prompt}
        if ai.get("template") in TEMPLATES or (custom_ok and ai.get("template") in ("chart", "list", "quote", "callout")):
            if ai["template"] != spec["template"]:
                spec["params"] = {}
            spec["template"] = ai["template"]
        if isinstance(ai.get("params"), dict):
            spec["params"].update({k: v for k, v in ai["params"].items() if v not in (None, "")})
        sizes = [s for s in (ai.get("sizes") or []) if s in SIZES]
        spec["sizes"] = sizes or spec["sizes"]
        spec["position"] = ai.get("position") if ai.get("position") in POSITIONS else spec["position"]
        for k in ("background",):
            if isinstance(ai.get(k), str) and re.fullmatch(r"#[0-9a-fA-F]{6}", ai[k]):
                spec[k] = ai[k]
        cols = [c for c in (ai.get("colors") or []) if isinstance(c, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", c)]
        spec["colors"] = cols[:2] or spec["colors"]
        from .. import brain
        spec["via"] = brain.last_engine() if brain.last_engine() in ("claude", "chatgpt", "grok") else "ai"
    if reference:  # match a reference: its colours (unless the prompt named some), pacing, and look
        spec["reference"] = reference.get("id")
        if not spec["colors"] and reference.get("colors"):
            spec["colors"] = reference["colors"][:2]
        spec["speed"] = reference.get("speed", 1.0)
        suggested = (reference.get("ai") or {}).get("template", "")
        if not named_template and suggested in TEMPLATES and suggested != spec["template"]:
            spec["template"], spec["params"] = suggested, {k: v for k, v in spec["params"].items() if k in ("text", "dur")}
            if suggested != "swipe" and "text" not in spec["params"]:
                q = _quotes(prompt)
                spec["params"]["text"] = q[0] if q else prompt[:80]
    spec["prompt"] = prompt
    spec["engine"] = "hyperframes" if hyper.available(settings) else "classic"
    return spec


# ---- rendering --------------------------------------------------------------------------

def library_dir(settings: dict) -> Path:
    return clients_dir(settings).parent / "motion-library"


def brand_client(spec: dict, settings: dict) -> Client:
    """The client's brand kit, or a neutral custom one, with any colours from the prompt on top."""
    if spec.get("client"):
        client = load_client(spec["client"], settings)
        brand = copy.deepcopy(client.brand)
    else:
        client = None
        brand = copy.deepcopy(DEFAULT_BRAND)
        brand["fonts"]["caption"] = brand["fonts"]["headline"] = "Helvetica Neue"
        brand["client"] = "Custom"
    cols = spec.get("colors") or []
    if cols:
        brand["colors"]["primary"] = cols[0]
    if len(cols) > 1:
        brand["colors"]["secondary"] = cols[1]
    return Client(slug=client.slug if client else "_custom", folder=client.folder if client else TEMPLATE_DIR,
                  brand=deep_merge(DEFAULT_BRAND, brand))


def new_item(spec: dict, settings: dict) -> Path:
    named = (Path(spec["params"]["source"]).stem[16:] if spec["template"] == "transcript" else
             str(spec["params"].get("style") or "client-sound") if spec["template"] == "music" else
             str(spec["params"].get("recipe", "")) if spec["template"] == "storyboard" else
             str(spec.get("look") or "client-look") if spec["template"] == "lookbook" else json.dumps(spec["params"]))
    label = re.sub(r"[^a-z0-9]+", "-", named.lower())[:40].strip("-") or spec["template"]
    item = library_dir(settings) / f"{datetime.now():%Y%m%d-%H%M%S}-{spec['template']}-{label}"
    item.mkdir(parents=True, exist_ok=True)
    (item / "spec.json").write_text(json.dumps(spec, indent=2))
    _status(item, state="queued")
    return item


def _status(item: Path, **fields):
    p = item / "status.json"
    data = json.loads(p.read_text()) if p.exists() else {}
    data.update(fields, updated=time.time())
    p.write_text(json.dumps(data, indent=2))


def render_item(item: Path, settings: dict) -> None:
    """Render every requested size + format for one Create-tab item (run by the worker)."""
    if (item / ".rerender").exists():
        (item / ".rerender").unlink()
        return rerender_item(item, settings)
    spec = json.loads((item / "spec.json").read_text())
    client = brand_client(spec, settings)
    assets = spec.get("assets") or []
    client = customize.apply(client, assets, item / "_custom")  # their own logo and fonts
    fps = float(spec.get("fps") or 30)
    formats = spec.get("formats") or ["mov"]
    samples = int(settings["motion_blur_samples"])
    params = dict(spec["params"])
    engine = spec.get("engine") or "classic"
    if engine == "hyperframes" and not hyper.available(settings):
        engine = "classic"  # made on a computer with HyperFrames, rendering on one without
    if spec["template"] == "cta_outro" and spec.get("client"):
        params.setdefault("logo", client.path(client.brand["logo"]["file"]))
    files = []
    if spec["template"] == "music":
        return _render_music(item, spec, client, settings)
    try:
        if spec["template"] in ("custom", "transcript") and not hyper.available(settings):
            raise RuntimeError("This needs HyperFrames on this computer: run `autocut hyperframes-setup`")
        for n, size_name in enumerate(spec["sizes"]):
            _status(item, state="rendering", step=f"{size_name} ({n + 1}/{len(spec['sizes'])})")
            W, H = SIZES[size_name]
            base = item / f"{spec['template']}-{size_name}"
            lib = _library_render(spec, client, params, size_name, (W, H), fps, base, item, settings, assets)
            if lib is not None:
                files += lib
                continue
            if spec["template"] == "transcript" and params.get("style") == "explainer":
                from . import explainer
                mp4 = explainer.make_video(Path(params["source"]), client, (W, H), base.with_suffix(".mp4"), settings,
                                           customize.graphics(assets), fps=fps, use_ai=params.get("ai", True) is not False,
                                           pop_out=params.get("pop_out", True) is not False)
                mp4 = _add_sound(spec, client, settings, item / f"hf-{base.name}", mp4, item)
                files += _video_outputs(item, mp4, size_name)
                continue
            if spec["template"] == "transcript":
                mp4 = script.make_video(Path(params["source"]), client, (W, H), base.with_suffix(".mp4"), settings,
                                        customize.graphics(assets), cta=params.get("cta") or "", fps=fps,
                                        use_ai=params.get("ai", True) is not False)
                mp4 = _add_sound(spec, client, settings, item / f"hf-{base.name}", mp4, item)
                files += _video_outputs(item, mp4, size_name)
                continue
            if spec["template"] == "custom":
                mov = hyper.make_custom(params.get("brief") or spec.get("prompt", ""), client, (W, H), fps,
                                        base.with_suffix(".mov"), settings, dur=float(params.get("dur") or 5),
                                        background=spec.get("background"), graphics=customize.graphics(assets))
            elif engine == "hyperframes":
                mov = hyper.make(spec["template"], client, (W, H), fps, base.with_suffix(".mov"), settings,
                                 position=spec.get("position"), background=spec.get("background"),
                                 speed=float(spec.get("speed") or 1.0), **params)
            else:
                look = Look(client, (W, H), fps)
                mov = make(spec["template"], look, fps, base.with_suffix(".mov"), samples=samples,
                           position=spec.get("position"), background=spec.get("background"),
                           speed=float(spec.get("speed") or 1.0), **params)
            files += _outputs(item, base, mov, size_name, (W, H), fps, formats, client,
                              alpha=not spec.get("background") and spec["template"] != "cta_outro")
        _status(item, state="done", files=files)
    except Exception as e:
        _status(item, state="error", error=str(e)[:400])
        raise


def _library_render(spec: dict, client: Client, params: dict, size_name: str, size: tuple[int, int], fps: float,
                    base: Path, item: Path, settings: dict, assets: list) -> list[str] | None:
    """Draw it with the motion library (looks × layouts, the client's style DNA). None: not a library graphic."""
    from . import library
    from .library import build as lb
    t = spec["template"]
    if t not in library.MAP and t not in library.LIB_TEMPLATES:
        return None
    look, d = library.resolve(spec, client, settings)
    if look is None or not hyper.available(settings):
        return None
    gsap = hyper.runtime_dir(settings) / "node_modules" / "gsap" / "dist" / "gsap.min.js"
    project = item / f"hf-{base.name}"
    brand_fonts = (d or {}).get("brand_fonts", True)
    from .feel import FEELS
    feel = spec.get("feel") if spec.get("feel") in FEELS else (d or {}).get("feel") if (d or {}).get("feel") in FEELS else None
    if t == "storyboard":
        from .library import storyboards
        scenes = params.get("scenes") or storyboards.plan(params.get("recipe") or "pas_ad", params.get("brief", ""),
                                                           client, settings, d)["scenes"]
        transition = spec.get("transition") or (d or {}).get("transition") or "wipe"
        storyboards.build(scenes, look, client, size, project, transition, brand_fonts, gsap, feel)
        _status(item, look=look)
        mp4 = hyper.render_project(project, base.with_suffix(".mp4"), settings, "mp4", fps=fps)
        return _video_outputs(item, _add_sound(spec, client, settings, project, mp4, item), size_name)
    if t == "lookbook":
        shots = lb.sheet_project(lb.samples(client), look, client, size, project, brand_fonts=brand_fonts, gsap=gsap, feel=feel)
        (project / "shots.json").write_text(json.dumps(shots))
        _status(item, look=look)
        return _video_outputs(item, hyper.render_project(project, base.with_suffix(".mp4"), settings, "mp4", fps=fps), size_name)
    kind, kp, allowed = library.kind_params(t, params)
    layout = library.pick_layout(spec, kind, d, allowed)
    full = kind == "end_card"
    y = hyper.POSITIONS.get(spec.get("position") or "")
    lb.build_element(kind, layout, look, client, size, project, kp, full=full, y=y, dur=params.get("dur"),
                     background=spec.get("background"), brand_fonts=brand_fonts, gsap=gsap, feel=feel)
    mov = hyper.render_project(project, base.with_suffix(".mov"), settings, "mov", fps=fps)
    _status(item, look=look, layout=layout)
    return _outputs(item, base, mov, size_name, size, fps, spec.get("formats") or ["mov"], client,
                    alpha=not full and not spec.get("background"))


def _render_music(item: Path, spec: dict, client: Client, settings: dict) -> None:
    """Create tab → Music: an original bed for the client (+ stems, + their sound effects pack), with a waveform
    video so the gallery can play it."""
    import zipfile
    from .. import sound
    from ..sound import director, sfx
    p = spec.get("params") or {}
    try:
        seconds = max(5.0, min(600.0, float(p.get("seconds") or 30)))
        _status(item, state="rendering", step="composing")
        meta = sound.score(client, settings, seconds, item / "music.wav", str(p.get("notes", "")), "short",
                           stems_dir=item / "stems", override={"style": p.get("style") or None, "energy": p.get("energy") or None},
                           use_ai_brain=bool(p.get("notes")))
        files = ["music.wav"]
        if (item / "stems").is_dir():
            with zipfile.ZipFile(item / "music-stems.zip", "w") as z:
                for f in sorted((item / "stems").glob("*.wav")):
                    z.write(f, f.name)
            files.append("music-stems.zip")
        if p.get("sfx_pack", True):
            ident = director.identity(client, settings)
            pack = sfx.pack(item / "sfx", ident.get("flavour", "clean"), ident.get("seed", 1))
            with zipfile.ZipFile(item / "sound-effects.zip", "w") as z:
                for k, f in pack.items():
                    z.write(f, f"{k}.wav")
            files.append("sound-effects.zip")
        _status(item, step="drawing the waveform")
        from ..config import hex_to_rgb
        r, g, b = (c / 255 for c in hex_to_rgb(client.brand["colors"]["primary"]))
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(item / "music.wav"), "-f", "lavfi", "-i",
                        f"color=c=0x0f1116:s=1280x720:r=30:d={seconds:.3f}", "-filter_complex",
                        f"[0:a]showwaves=s=1280x720:mode=cline:rate=30:colors=white:scale=sqrt,format=rgba,"
                        f"colorchannelmixer=rr={r:.3f}:gg={g:.3f}:bb={b:.3f}[w];[1:v][w]overlay=format=auto,format=yuv420p[v]",
                        "-map", "[v]", "-map", "0:a", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
                        "-movflags", "+faststart", str(item / "preview-music.mp4")], check=True)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", f"{seconds * 0.4:.2f}", "-i", str(item / "preview-music.mp4"),
                        "-frames:v", "1", "-vf", "scale=540:-2", str(item / "poster-music.jpg")])
        _status(item, state="done", files=files, look=meta.get("style_name") or meta["brief"]["style"],
                layout=f"{meta.get('bpm', meta['brief'].get('bpm'))} BPM · {meta['brief']['key']} · {meta['engine']}")
    except Exception as e:
        _status(item, state="error", error=str(e)[:400])
        raise


def _add_sound(spec: dict, client: Client, settings: dict, project: Path, mp4: Path, item: Path | None = None) -> Path:
    """Score a rendered video (storyboards, transcript videos): music + effects on its events. On by default;
    spec["sound"] = {"music": false} / {"effects": false} / false turns parts off."""
    want = spec.get("sound", True)
    if want is False:
        return mp4
    want = want if isinstance(want, dict) else {}
    try:
        from .. import sound
        ev_file = project / "events.json"
        events = json.loads(ev_file.read_text()) if ev_file.exists() else []
        p = spec.get("params") or {}
        text = " ".join(str(v) for v in [p.get("brief", ""), json.dumps(p.get("scenes", ""))[:1200], p.get("cta", "")])
        if item is not None:
            _status(item, step="adding music and sound design")
        tmp = mp4.with_name(mp4.stem + "-scored.mp4")
        sound.mix_video(mp4, tmp, client, settings, events, text, "motion" if spec["template"] != "transcript" else "short",
                        music=want.get("music", True), effects=want.get("effects", True))
        tmp.replace(mp4)
    except Exception as e:  # sound is a bonus; never lose the video over it
        print(f"  ! sound skipped: {e}")
    return mp4


def _video_outputs(item: Path, mp4: Path, size_name: str) -> list[str]:
    """A finished, opaque video with sound (transcript videos): it is its own preview; plus the poster."""
    preview = item / f"preview-{size_name}.mp4"
    shutil.copy2(mp4, preview)
    dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of",
                                "csv=p=0", str(mp4)], capture_output=True, text=True).stdout or 1)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", f"{dur * 0.3:.2f}", "-i", str(mp4),
                    "-frames:v", "1", "-vf", "scale=540:-2", str(item / f"poster-{size_name}.jpg")])
    return [mp4.name]


def _outputs(item: Path, base: Path, mov: Path, size_name: str, size: tuple[int, int], fps: float, formats: list[str],
             client: Client, alpha: bool) -> list[str]:
    """From one rendered .mov: the requested formats, the browser preview and the poster."""
    W, H = size
    files = [mov.name]
    if "webm" in formats:
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(mov), "-c:v", "libvpx-vp9",
                        "-pix_fmt", "yuva420p" if alpha else "yuv420p", "-b:v", "0", "-crf", "24",
                        "-row-mt", "1", "-deadline", "good", "-cpu-used", "4",
                        str(base.with_suffix(".webm"))], check=True)
        files.append(base.with_suffix(".webm").name)
    # browser preview (and the MP4 export): over a brand-tinted gradient when transparent
    preview = item / f"preview-{size_name}.mp4"
    if alpha:
        c0, c1 = brand_backdrop(client.brand)
        graph = (f"gradients=s={W}x{H}:c0={c0}:c1={c1}:r={fps}:speed=0.004,format=rgb24[bg];"
                 f"[bg][0]overlay=shortest=1,format=yuv420p")
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(mov), "-filter_complex",
                        graph, *video_encoder("high"), "-movflags", "+faststart", str(preview)], check=True)
    else:
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(mov), *video_encoder("high"),
                        "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(preview)], check=True)
    dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of",
                                "csv=p=0", str(preview)], capture_output=True, text=True).stdout or 1)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", f"{dur * 0.55:.2f}", "-i", str(preview),
                    "-frames:v", "1", "-vf", "scale=540:-2", str(item / f"poster-{size_name}.jpg")])
    if "mp4" in formats:
        mp4 = base.with_suffix(".mp4")
        mp4.write_bytes(preview.read_bytes())
        files.append(mp4.name)
    if "gif" in formats:
        gif = base.with_suffix(".gif")
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(preview), "-vf",
                        f"fps=15,scale={min(W, 540)}:-1:flags=lanczos,split[a][b];[a]palettegen[p];[b][p]paletteuse",
                        str(gif)], check=True)
        files.append(gif.name)
    if "mov" not in formats:
        files.remove(mov.name)
        mov.unlink()
    return files


def rerender_item(item: Path, settings: dict) -> None:
    """Render a HyperFrames item again from its project folders, e.g. after editing them in HyperFrames Studio."""
    spec = json.loads((item / "spec.json").read_text())
    client = brand_client(spec, settings)
    fps = float(spec.get("fps") or 30)
    files = []
    try:
        for n, size_name in enumerate(spec["sizes"]):
            _status(item, state="rendering", step=f"re-rendering {size_name} ({n + 1}/{len(spec['sizes'])})", error=None)
            base = item / f"{spec['template']}-{size_name}"
            project = item / f"hf-{base.name}"
            if not (project / "index.html").exists():
                raise RuntimeError(f"No HyperFrames project for {size_name}")
            if spec["template"] == "transcript":
                mp4 = _add_sound(spec, client, settings, project, script.finish(project, base.with_suffix(".mp4"), settings, fps), item)
                files += _video_outputs(item, mp4, size_name)
                continue
            if spec["template"] in ("storyboard", "lookbook"):
                mp4 = hyper.render_project(project, base.with_suffix(".mp4"), settings, "mp4", fps=fps)
                if spec["template"] == "storyboard":
                    mp4 = _add_sound(spec, client, settings, project, mp4, item)
                files += _video_outputs(item, mp4, size_name)
                continue
            mov = hyper.render_project(project, base.with_suffix(".mov"), settings, "mov", fps=fps)
            files += _outputs(item, base, mov, size_name, SIZES[size_name], fps, spec.get("formats") or ["mov"], client,
                              alpha=not spec.get("background") and spec["template"] != "cta_outro")
        _status(item, state="done", files=files, edited=True)
    except Exception as e:
        _status(item, state="error", error=str(e)[:400])
        raise


def list_items(settings: dict, limit: int = 60) -> list[dict]:
    root = library_dir(settings)
    out = []
    for d in sorted(root.glob("*/spec.json"), reverse=True)[:limit]:
        item = d.parent
        try:
            spec = json.loads(d.read_text())
            st = json.loads((item / "status.json").read_text()) if (item / "status.json").exists() else {}
        except json.JSONDecodeError:
            continue
        previews = sorted(str(p) for p in item.glob("preview-*.mp4"))
        posters = sorted(str(p) for p in item.glob("poster-*.jpg"))
        files = [str(item / f) for f in st.get("files", []) if (item / f).exists()]
        projects = sorted(d.name[len("hf-"):] for d in item.glob("hf-*") if (d / "index.html").exists())
        out.append({"dir": str(item), "name": item.name, "spec": spec, "state": st.get("state"), "posters": posters,
                    "studio": projects, "edited": bool(st.get("edited")), "look": st.get("look"), "layout": st.get("layout"),
                    "step": st.get("step"), "error": st.get("error"), "previews": previews, "files": files})
    return out
