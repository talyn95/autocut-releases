"""Full customization for the Motion graphic generator: your own logo, fonts and graphics, plus the transcript,
audio or video a transcript video is made from.

Uploads land in <motion library>/_uploads. Each has a kind (font, image, transcript, audio, video) and, for images,
a role: "logo" (replaces the client's logo: end cards, watermark) or "graphic" (shown in the video: picture cards in
a transcript video, assets for AI custom designs). Fonts become the headline font (the first) and body font (the
second), for every engine.
"""
from __future__ import annotations

import copy
import shutil
from pathlib import Path

from ..config import Client

FONT_EXT = {".ttf", ".otf", ".woff", ".woff2"}
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg"}
TRANSCRIPT_EXT = {".txt", ".srt", ".vtt", ".json", ".md"}
AUDIO_EXT = {".mp3", ".wav", ".m4a", ".aac", ".aif", ".aiff", ".flac", ".ogg"}
VIDEO_EXT = {".mp4", ".mov", ".m4v", ".mkv", ".webm"}
ALL_EXT = FONT_EXT | IMAGE_EXT | TRANSCRIPT_EXT | AUDIO_EXT | VIDEO_EXT


def kind_of(path: Path) -> str | None:
    ext = path.suffix.lower()
    for kind, exts in (("font", FONT_EXT), ("image", IMAGE_EXT), ("transcript", TRANSCRIPT_EXT),
                       ("audio", AUDIO_EXT), ("video", VIDEO_EXT)):
        if ext in exts:
            return kind
    return None


def font_family(path: Path) -> tuple[str, int]:
    from .engine import family_from_filename
    try:
        from fontTools.ttLib import TTFont
        tt = TTFont(path, lazy=True)
        names = {r.nameID: r.toUnicode() for r in tt["name"].names if r.nameID in (1, 16)}
        return names.get(16) or names.get(1) or path.stem, tt["OS/2"].usWeightClass if "OS/2" in tt else 400
    except Exception:
        return family_from_filename(path)


def describe(path: Path) -> dict:
    kind = kind_of(path)
    out = {"path": str(path), "kind": kind, "name": path.name}
    if kind == "font":
        out["family"], out["weight"] = font_family(path)
        out["role"] = "font"
    elif kind == "image":
        out["role"] = "logo" if any(w in path.stem.lower() for w in ("logo", "wordmark", "brandmark")) else "graphic"
    else:
        out["role"] = kind
    return out


def apply(client: Client, assets: list[dict], work: Path) -> Client:
    """A copy of the client with this item's logo and fonts in place of the brand kit's."""
    assets = [a for a in assets or [] if a.get("path") and Path(a["path"]).exists()]
    brand = copy.deepcopy(client.brand)
    logo = next((a["path"] for a in assets if a.get("role") == "logo"), None)
    if logo:
        brand["logo"] = {**brand["logo"], "file": str(Path(logo).resolve())}
    fonts = [a for a in assets if a.get("role") == "font" or (a.get("kind") == "font")]
    if fonts:
        folder = work / "fonts"
        folder.mkdir(parents=True, exist_ok=True)
        # keep the brand kit's own fonts too (body text may still use them)
        old = client.path(client.brand["fonts"]["folder"])
        if old and old.is_dir():
            for f in old.iterdir():
                if f.suffix.lower() in FONT_EXT:
                    shutil.copy2(f, folder / f.name)
        fams = []
        for a in fonts:
            src = Path(a["path"])
            shutil.copy2(src, folder / src.name)
            fam = a.get("family") or font_family(src)[0]
            if fam not in fams:
                fams.append(fam)
        brand["fonts"] = {**brand["fonts"], "folder": str(folder.resolve()), "headline": fams[0],
                          "caption": fams[1] if len(fams) > 1 else brand["fonts"].get("caption", fams[0])}
    return Client(slug=client.slug, folder=client.folder, brand=brand)


def graphics(assets: list[dict]) -> list[Path]:
    return [Path(a["path"]) for a in assets or [] if a.get("role") == "graphic" and Path(a["path"]).exists()]
