"""The AutoCut Motion pack: brand-driven templates with After Effects-style motion.

Every template is `name(look, **params) -> (duration, draw)` where draw(canvas, t) paints
one moment. `make()` renders any of them to an alpha ProRes clip (CTA outro is opaque).
"""
from __future__ import annotations

import math
import re
from pathlib import Path

import skia

from .ease import in_cubic, in_expo, in_out_cubic, in_out_expo, out_back, out_cubic, out_expo, progress, tween
from .engine import Look, color, render, shade

# ---- drawing helpers ------------------------------------------------------------------


def P(col: int, *, stroke: float = 0, blur: float = 0, cap_round: bool = True) -> skia.Paint:
    p = skia.Paint(AntiAlias=True, Color=col)
    if stroke:
        p.setStyle(skia.Paint.kStroke_Style)
        p.setStrokeWidth(stroke)
        if cap_round:
            p.setStrokeCap(skia.Paint.kRound_Cap)
    if blur:
        p.setMaskFilter(skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, blur))
    return p


def soft_shadow(look: Look, strength: float = 1.0) -> skia.ImageFilter:
    u = look.u
    return skia.ImageFilters.DropShadow(0, 8 * u, 18 * u, 18 * u, skia.ColorSetARGB(int(110 * strength), 0, 0, 0))


def rrect(x: float, y: float, w: float, h: float, r: float) -> skia.RRect:
    return skia.RRect.MakeRectXY(skia.Rect.MakeXYWH(x, y, w, h), r, r)


def wrap(words: list[str], font: skia.Font, max_w: float, max_lines: int = 3) -> list[list[str]]:
    lines, cur = [], []
    for w in words:
        trial = " ".join(cur + [w])
        if cur and font.measureText(trial) > max_w:
            lines.append(cur)
            cur = [w]
        else:
            cur.append(w)
    if cur:
        lines.append(cur)
    return lines[:max_lines]


def fit_size(lines: list[str], tf_font, max_w: float, start: float, floor: float = 30) -> float:
    size = start
    while size > floor and max(tf_font(size).measureText(l) for l in lines) > max_w:
        size *= 0.94
    return size


def light_sweep(canvas: skia.Canvas, rect: skia.Rect, k: float, strength: float = 0.55):
    """A diagonal highlight band passing across whatever was drawn in the current layer (k: 0→1)."""
    if not 0 < k < 1:
        return
    w = rect.width()
    x = rect.left() - w * 0.4 + (w * 1.8) * k
    band = w * 0.18
    shader = skia.GradientShader.MakeLinear(
        [skia.Point(x - band, rect.top()), skia.Point(x + band, rect.bottom())],
        [skia.ColorSetARGB(0, 255, 255, 255), skia.ColorSetARGB(int(255 * strength), 255, 255, 255),
         skia.ColorSetARGB(0, 255, 255, 255)], [0.0, 0.5, 1.0])
    p = skia.Paint(AntiAlias=True, Shader=shader)
    p.setBlendMode(skia.BlendMode.kSrcATop)
    canvas.drawRect(rect, p)


def tracked(canvas: skia.Canvas, text: str, cx: float, y: float, font: skia.Font, paint: skia.Paint, spacing: float):
    """Centered text with extra letter spacing (for the AE "tracking in" look)."""
    widths = [font.measureText(ch) for ch in text]
    total = sum(widths) + spacing * (len(text) - 1)
    x = cx - total / 2
    for ch, w in zip(text, widths):
        canvas.drawString(ch, x, y, font, paint)
        x += w + spacing


def parse_number(value: str) -> tuple[str, float, str, int]:
    """"$3,000" → ("$", 3000, "", 0);  "12.5%" → ("", 12.5, "%", 1)."""
    m = re.search(r"([\d,]*\.?\d+)", value)
    if not m:
        return "", 0.0, value, 0
    raw = m.group(1).replace(",", "")
    decimals = len(raw.split(".")[1]) if "." in raw else 0
    return value[:m.start()], float(raw), value[m.end():], decimals


def fmt_number(n: float, decimals: int) -> str:
    return f"{n:,.{decimals}f}"


# ---- templates --------------------------------------------------------------------------


def hook_title(look: Look, text: str, dur: float = 2.8):
    """Opening title: each centred line rises out of an invisible mask as one piece, an accent bar draws on
    underneath, a light sweep glints across, then everything lifts away."""
    u, W, H = look.u, look.W, look.H
    words = text.upper().split()
    big = lambda s: look.font(s)  # noqa: E731
    size = fit_size([" ".join(words[i:i + 2]) for i in range(0, len(words), 2)] or [text], big, W * 0.84, 150 * u)
    font = big(size)
    lines = wrap(words, font, W * 0.86, max_lines=99)
    while len(lines) > 3 and size > 40 * u:  # shrink rather than drop words
        size *= 0.9
        font = big(size)
        lines = wrap(words, font, W * 0.86, max_lines=99)
    lh = size * 1.02
    top = H * (0.24 if look.vertical else 0.30) - (len(lines) - 1) * lh / 2
    widths = [font.measureText(" ".join(l)) for l in lines]
    block_w = max(widths)
    space = font.measureText(" ")
    accent_y = top + (len(lines) - 1) * lh + size * 0.46
    highlight = len(words) - 1  # last word in the brand colour

    def draw(c: skia.Canvas, t: float):
        bounds = skia.Rect.MakeXYWH((W - block_w) / 2 - 40 * u, top - size, block_w + 80 * u, lh * len(lines) + size)
        c.saveLayer(bounds, None)
        k = 0
        for li, line in enumerate(lines):
            y = top + li * lh
            x = (W - widths[li]) / 2
            for w in line:
                ww = font.measureText(w)
                t_in = 0.12 + 0.06 * li  # whole lines, never word-by-word: stays centred, no stagger
                rise = tween(t, t_in, 0.6, size * 1.05, 0, out_expo)
                fall = tween(t, dur - 0.45, 0.35, 0, -size * 1.05, in_expo)
                c.save()
                c.clipRect(skia.Rect.MakeLTRB(x - 10 * u, y - size * 0.98, x + ww + 10 * u, y + size * 0.26))
                p = P(look.c("primary") if k == highlight else look.c("text"))
                p.setImageFilter(soft_shadow(look, 0.8))
                c.drawString(w, x, y + rise + fall, font, p)
                c.restore()
                x += ww + space
                k += 1
        light_sweep(c, bounds, progress(t, 1.05, 0.7))
        c.restore()
        # accent bar draws on from the left, retracts to the right at the end
        grow = in_out_expo(progress(t, 0.35, 0.6))
        gone = in_out_expo(progress(t, dur - 0.5, 0.4))
        bar_w = block_w * 0.42
        x0 = (W - bar_w) / 2
        if grow > gone:
            c.drawRRect(rrect(x0 + bar_w * gone, accent_y, bar_w * (grow - gone), 12 * u, 6 * u), P(look.c("primary")))
    return dur, draw


def slam(look: Look, word: str, dur: float = 1.4):
    """A word punches in from huge, the camera shakes, a shockwave ring blows out."""
    u, W, H = look.u, look.W, look.H
    word = word.strip(",.!?").upper()
    font = look.font(min(230 * u, W * 0.88 / max(1, len(word)) / 0.62), weight=900)
    tw = font.measureText(word)
    cx, cy = W / 2, H * (0.40 if look.vertical else 0.45)
    impact = 0.22

    def draw(c: skia.Canvas, t: float):
        scale = tween(t, 0, impact, 2.6, 1.0, out_expo) * tween(t, dur - 0.25, 0.25, 1.0, 0.82, in_cubic)
        alpha = min(1.0, t / 0.08) * (1 - in_cubic(progress(t, dur - 0.25, 0.25)))
        shake = 0.0 if t < impact else 16 * u * math.exp(-11 * (t - impact)) * math.sin((t - impact) * 95)
        # shockwave ring
        rk = progress(t, impact - 0.02, 0.5)
        if 0 < rk < 1:
            r = tw * 0.35 + tw * 0.9 * out_cubic(rk)
            c.drawCircle(cx, cy - font.getSize() * 0.32, r, P(look.c("primary", 1 - rk), stroke=22 * u * (1 - rk) + 1))
        c.save()
        c.translate(cx + shake, cy + shake * 0.6)
        c.scale(scale, scale)
        c.saveLayerAlpha(None, int(255 * alpha))
        c.drawString(word, -tw / 2, font.getSize() * 0.35, font, P(look.c("primary", 0.85), blur=26 * u))  # glow
        stroke = P(look.c("outline"), stroke=10 * u)
        stroke.setStrokeJoin(skia.Paint.kRound_Join)
        c.drawString(word, -tw / 2, font.getSize() * 0.35, font, stroke)
        c.drawString(word, -tw / 2, font.getSize() * 0.35, font, P(look.c("text")))
        c.restore()
        c.restore()
    return dur, draw


def stat_counter(look: Look, value: str, label: str = "", dur: float = 2.6):
    """A gradient panel springs in, the number counts up with a progress bar, the label tracks in."""
    u, W, H = look.u, look.W, look.H
    prefix, number, suffix, decimals = parse_number(value)
    big = look.font(150 * u, weight=900)
    small = look.font(40 * u, role="caption", weight=700)
    final = prefix + fmt_number(number, decimals) + suffix
    pw = max(big.measureText(final) + 140 * u, small.measureText(label) + 200 * u if label else 0, W * 0.5)
    pw = min(pw, W * 0.9)
    ph = (330 if label else 250) * u
    cx, cy = W / 2, H * (0.60 if look.vertical else 0.62)
    x0, y0 = cx - pw / 2, cy - ph / 2
    grad = skia.GradientShader.MakeLinear([skia.Point(x0, y0), skia.Point(x0 + pw, y0 + ph)],
                                          [look.c("primary"), color(shade(look.hex("primary"), 0.62))])

    def draw(c: skia.Canvas, t: float):
        s_in = out_back(progress(t, 0.0, 0.42), 1.9)
        s_out = in_cubic(progress(t, dur - 0.3, 0.3))
        s = max(0.0, s_in * (1 - s_out))
        if s <= 0.001:
            return
        c.save()
        c.translate(cx, cy)
        c.scale(s, s)
        c.translate(-cx, -cy)
        c.saveLayer(None, None)
        panel = skia.Paint(AntiAlias=True, Shader=grad)
        panel.setImageFilter(soft_shadow(look))
        c.drawRRect(rrect(x0, y0, pw, ph, 36 * u), panel)
        # count up
        k = out_expo(progress(t, 0.25, 1.1))
        tf = round(t * look.fps) / look.fps  # digits change once per frame, like an AE counter
        txt = prefix + fmt_number(number * out_expo(progress(tf, 0.25, 1.1)), decimals) + suffix
        num_y = y0 + (150 if label else 165) * u + 20 * u
        c.drawString(txt, cx - big.measureText(txt) / 2, num_y, big, P(look.c("text")))
        # progress bar along the bottom
        bar_y = y0 + ph - 46 * u
        c.drawRRect(rrect(x0 + 50 * u, bar_y, pw - 100 * u, 10 * u, 5 * u), P(skia.ColorSetARGB(60, 255, 255, 255)))
        c.drawRRect(rrect(x0 + 50 * u, bar_y, (pw - 100 * u) * k, 10 * u, 5 * u), P(look.c("text")))
        if label:
            lk = out_cubic(progress(t, 0.55, 0.6))
            tracked(c, label.upper(), cx, num_y + 70 * u, small, P(look.c("text", lk)), tween(t, 0.55, 0.7, 26 * u, 4 * u, out_expo))
        light_sweep(c, skia.Rect.MakeXYWH(x0, y0, pw, ph), progress(t, 1.35, 0.6), 0.35)
        c.restore()
        c.restore()
    return dur, draw


def phrase_card(look: Look, text: str, dur: float = 2.4):
    """Key phrase in a brand pill: the pill opens from the centre, text rises in, underline sweeps."""
    u, W, H = look.u, look.W, look.H
    text = text.upper()
    font = look.font(min(84 * u, W * 0.8 / max(1, len(text)) / 0.6))
    tw = font.measureText(text)
    pw, ph = tw + 90 * u, font.getSize() * 1.7
    cx, cy = W / 2, H * (0.60 if look.vertical else 0.62)
    x0, y0 = cx - pw / 2, cy - ph / 2

    def draw(c: skia.Canvas, t: float):
        open_k = out_expo(progress(t, 0, 0.45)) * (1 - in_out_cubic(progress(t, dur - 0.35, 0.35)))
        if open_k <= 0.002:
            return
        w = pw * open_k
        pill = P(look.c("primary"))
        pill.setImageFilter(soft_shadow(look))
        c.drawRRect(rrect(cx - w / 2, y0, w, ph, ph / 2), pill)
        c.save()
        c.clipRect(skia.Rect.MakeXYWH(cx - w / 2, y0, w, ph))
        rise = tween(t, 0.18, 0.5, ph, 0, out_expo) + tween(t, dur - 0.4, 0.3, 0, -ph, in_expo)
        c.drawString(text, cx - tw / 2, cy + font.getSize() * 0.35 + rise, font, P(look.c("text")))
        c.restore()
        sweep = in_out_expo(progress(t, 0.45, 0.6))
        if sweep > 0 and t < dur - 0.35:
            c.drawRRect(rrect(x0 + 30 * u, y0 + ph + 14 * u, (pw - 60 * u) * sweep, 8 * u, 4 * u), P(look.c("text", 0.9)))
    return dur, draw


def lower_third(look: Look, name: str, title: str = "", dur: float = 4.5):
    """Accent line grows, a panel wipes in, the name rises out of a mask, the title tracks in."""
    u, W, H = look.u, look.W, look.H
    nf = look.font(66 * u)
    tf = look.font(36 * u, role="caption", weight=600)
    low_caps = look.client.brand["captions"]["position"] == "lower"
    x = W * 0.07
    y = H * ((0.56 if low_caps else 0.74) if look.vertical else (0.62 if low_caps else 0.80))
    name_w = nf.measureText(name)
    title_w = tf.measureText(title.upper()) + len(title) * 3 * u if title else 0
    pw = max(name_w, title_w) + 70 * u
    ph = 96 * u
    th = 54 * u if title else 0

    def draw(c: skia.Canvas, t: float):
        out_k = in_out_expo(progress(t, dur - 0.55, 0.5))
        line_k = out_expo(progress(t, 0.0, 0.4)) * (1 - out_k)
        if line_k > 0:
            c.drawRRect(rrect(x, y, 10 * u, (ph + th) * line_k, 5 * u), P(look.c("primary")))
        wipe = in_out_expo(progress(t, 0.15, 0.5))
        right = x + 22 * u + pw * wipe
        left = x + 22 * u + pw * out_k
        if right > left:
            panel = P(color(look.hex("secondary"), 0.94))
            panel.setImageFilter(soft_shadow(look, 0.7))
            c.drawRect(skia.Rect.MakeLTRB(left, y, right, y + ph), panel)
            c.save()
            c.clipRect(skia.Rect.MakeLTRB(left, y, right, y + ph))
            rise = tween(t, 0.35, 0.55, ph, 0, out_expo)
            c.drawString(name, x + 22 * u + 32 * u, y + ph * 0.68 + rise, nf, P(look.c("text")))
            c.restore()
        if title:
            tw_k = in_out_expo(progress(t, 0.45, 0.45))
            t_right = x + 22 * u + (title_w + 64 * u) * tw_k
            t_left = x + 22 * u + (title_w + 64 * u) * out_k
            if t_right > t_left:
                c.drawRect(skia.Rect.MakeLTRB(t_left, y + ph, t_right, y + ph + th), P(look.c("primary")))
                c.save()
                c.clipRect(skia.Rect.MakeLTRB(t_left, y + ph, t_right, y + ph + th))
                tk = out_cubic(progress(t, 0.6, 0.5))
                ty = y + ph + th * 0.68 + (1 - tk) * th
                sp = tween(t, 0.6, 0.8, 16 * u, 3 * u, out_expo)
                tx = x + 22 * u + 32 * u
                for ch in title.upper():
                    c.drawString(ch, tx, ty, tf, P(look.c("text")))
                    tx += tf.measureText(ch) + sp
                c.restore()
    return dur, draw


def swipe(look: Look, dur: float = 0.7):
    """Transition: two brand-colour diagonal bands sweep across; the frame is fully covered at dur/2
    (put the cut there)."""
    W, H = look.W, look.H
    slope = H * 0.35                      # how far the bottom edge trails the top (the diagonal)
    width = W + 2 * slope + 40 * look.u   # wide enough to cover the whole frame at the midpoint

    def band(c, k, col):
        x = -width + (W + slope + width) * k   # k=0 fully off left, k=1 fully off right, k=.5 covers all
        path = skia.Path()
        path.moveTo(x, -10)
        path.lineTo(x + width, -10)
        path.lineTo(x + width - slope, H + 10)
        path.lineTo(x - slope, H + 10)
        path.close()
        c.drawPath(path, P(col))

    def draw(c: skia.Canvas, t: float):
        k = progress(t, 0, dur)
        band(c, in_out_expo(min(1.0, max(0.0, k * 1.12))), look.c("secondary"))       # leads
        band(c, in_out_expo(min(1.0, max(0.0, k * 1.12 - 0.12))), look.c("primary"))  # follows, covers at the cut
    return dur, draw


def cta_outro(look: Look, text: str, sub: str = "", logo: Path | None = None, dur: float = 3.4):
    """End card: drifting brand shapes, logo springs in, CTA rises word by word, a button pops and pulses."""
    u, W, H = look.u, look.W, look.H
    words = text.upper().split()
    font = look.font(fit_size([" ".join(words[i:i + 3]) for i in range(0, len(words), 3)] or [text],
                              look.font, W * 0.82, 104 * u))
    lines = wrap(words, font, W * 0.84)
    lh = font.getSize() * 1.05
    space = font.measureText(" ")
    text_top = H * (0.47 if look.vertical else 0.50)
    bf = look.font(54 * u, role="caption", weight=700)
    logo_img = skia.Image.open(str(logo)) if logo and Path(logo).exists() and Path(logo).suffix.lower() != ".svg" else None
    bg = skia.GradientShader.MakeRadial(skia.Point(W / 2, H * 0.38), max(W, H) * 0.75,
                                        [color(shade(look.hex("secondary"), 1.18)), look.c("secondary"),
                                         color(shade(look.hex("secondary"), 0.6))], [0.0, 0.55, 1.0])

    def draw(c: skia.Canvas, t: float):
        c.drawPaint(skia.Paint(Shader=bg))
        # slow parallax shapes
        for i, (sx, sy, sw, sh, a, spd) in enumerate([(0.78, 0.12, 0.9, 0.22, 0.20, 40), (-0.1, 0.78, 1.0, 0.18, 0.14, -30),
                                                     (0.55, 0.92, 0.6, 0.10, 0.10, 55)]):
            c.save()
            c.translate(W * sx + spd * u * t, H * sy - spd * 0.4 * u * t)
            c.rotate(-24)
            c.drawRRect(rrect(-W * sw / 2, -H * sh / 2, W * sw, H * sh, 40 * u), P(look.c("primary", a)))
            c.restore()
        if logo_img:
            k = out_back(progress(t, 0.1, 0.55), 1.6)
            lw = W * 0.42
            lh_ = lw * logo_img.height() / logo_img.width()
            if lh_ > H * 0.16:
                lh_, lw = H * 0.16, H * 0.16 * logo_img.width() / logo_img.height()
            c.save()
            c.translate(W / 2, H * 0.26)
            c.scale(k, k)
            p = skia.Paint(AntiAlias=True)
            p.setAlphaf(min(1.0, progress(t, 0.1, 0.25)))
            c.drawImageRect(logo_img, skia.Rect.MakeXYWH(-lw / 2, -lh_ / 2, lw, lh_),
                            skia.SamplingOptions(skia.FilterMode.kLinear, skia.MipmapMode.kLinear), p)
            c.restore()
        k = 0
        for li, line in enumerate(lines):
            lw_ = font.measureText(" ".join(line))
            x = (W - lw_) / 2
            y = text_top + li * lh
            for w in line:
                ww = font.measureText(w)
                c.save()
                c.clipRect(skia.Rect.MakeLTRB(x - 8 * u, y - font.getSize(), x + ww + 8 * u, y + font.getSize() * 0.3))
                rise = tween(t, 0.45 + 0.06 * li, 0.6, font.getSize() * 1.1, 0, out_expo)
                c.drawString(w, x, y + rise, font, P(look.c("text")))
                c.restore()
                x += ww + space
                k += 1
        under_y = text_top + (len(lines) - 1) * lh + font.getSize() * 0.38
        uk = in_out_expo(progress(t, 0.8, 0.6))
        if uk > 0:
            c.drawRRect(rrect(W / 2 - W * 0.18 * uk, under_y, W * 0.36 * uk, 10 * u, 5 * u), P(look.c("primary")))
        if sub:
            label = sub + "  →"
            bw, bh = bf.measureText(label) + 110 * u, 122 * u
            by = H * (0.70 if look.vertical else 0.74)
            s = out_back(progress(t, 1.15, 0.5), 2.2)
            if s > 0:
                pulse = 0.5 + 0.5 * math.sin(max(0.0, t - 1.7) * 5) if t > 1.7 else 0
                c.save()
                c.translate(W / 2, by + bh / 2)
                c.scale(s, s)
                c.drawRRect(rrect(-bw / 2 - 10 * u, -bh / 2 - 10 * u, bw + 20 * u, bh + 20 * u, bh / 2 + 10 * u),
                            P(look.c("primary", 0.25 + 0.35 * pulse), blur=18 * u))
                btn = P(look.c("primary"))
                btn.setImageFilter(soft_shadow(look))
                c.drawRRect(rrect(-bw / 2, -bh / 2, bw, bh, bh / 2), btn)
                nudge = 6 * u * math.sin(max(0.0, t - 1.7) * 7) if t > 1.7 else 0
                c.drawString(sub, -bw / 2 + 55 * u, bf.getSize() * 0.36, bf, P(look.c("text")))
                arrow_x = -bw / 2 + 55 * u + bf.measureText(sub + "  ") + nudge
                c.drawString("→", arrow_x, bf.getSize() * 0.36, bf, P(look.c("text")))
                c.restore()
    return dur, draw


def kinetic_type(look: Look, text: str, dur: float | None = None):
    """Kinetic typography: the message plays out beat by beat, each beat a centred phrase with its own
    entrance (masked rise, punch-in, brand-colour bar wipe, tracking-in) and a quick exit as the next
    arrives. Keywords (wrap them in *asterisks*, or numbers) take the brand colour."""
    u, W, H = look.u, look.W, look.H
    raw = [x.strip() for x in re.split(r"\s*[/|]\s*|(?<=[.!?;:])\s+", text) if x.strip()]
    phrases: list[str] = []
    for ph in raw:  # long phrases become beats of 2-3 words
        ws = ph.split()
        while len(ws) > 4:
            phrases.append(" ".join(ws[:3]))
            ws = ws[3:]
        if ws:
            phrases.append(" ".join(ws))
    phrases = phrases[:12] or ["Your", "message"]
    beats = [0.55 + 0.17 * len(ph.split()) for ph in phrases]
    total = sum(beats) + 0.55
    if dur:
        k = max(0.4, dur / total)
        beats, total = [b * k for b in beats], dur
    starts = [sum(beats[:i]) + 0.1 for i in range(len(beats))]
    styles = ["punch", "rise", "wipe", "track"]
    cy = H * 0.5
    prepared = []
    for ph in phrases:
        words = ph.split()
        marked = [w.startswith("*") and w.rstrip(",.!?").endswith("*") for w in words]
        clean = [w.strip("*").upper() for w in words]
        if not any(marked):  # no asterisks: numbers, else the longest word of a multi-word beat
            marked = [any(ch.isdigit() for ch in w) for w in clean]
            if not any(marked) and len(clean) > 1:
                longest = max(range(len(clean)), key=lambda i: len(clean[i]))
                marked[longest] = True
        line = " ".join(clean)
        size = fit_size([line], look.font, W * 0.84, (200 if len(clean) == 1 else 150) * u, 50 * u)
        font = look.font(size, weight=900)
        widths = [font.measureText(w) for w in clean]
        space = font.measureText(" ")
        full = sum(widths) + space * (len(clean) - 1)
        prepared.append((clean, marked, font, widths, space, full))
    shadow = soft_shadow(look, 0.9)

    def draw_words(c: skia.Canvas, i: int, x0: float, base: float, alpha: float):
        clean, marked, font, widths, space, _ = prepared[i]
        x = x0
        for w, m, ww in zip(clean, marked, widths):
            p = P(look.c("primary" if m else "text", alpha))
            p.setImageFilter(shadow)
            c.drawString(w, x, base, font, p)
            x += ww + space

    def draw(c: skia.Canvas, t: float):
        for i, st in enumerate(starts):
            local = t - st
            d = beats[i]
            last = i == len(starts) - 1
            hold = (total - 0.35 - st) if last else d
            if local < 0 or local > hold + 0.03:
                continue
            clean, marked, font, widths, space, full = prepared[i]
            size = font.getSize()
            x0, base = (W - full) / 2, cy + size * 0.35
            # exit: lift and fade just before the next beat lands (beats never overlap)
            ex = in_cubic(progress(local, hold - 0.2, 0.22))
            alpha = 1 - ex
            c.save()
            c.translate(0, -60 * u * ex)
            style = styles[i % len(styles)]
            if style == "punch":
                k = out_back(progress(local, 0, 0.38))
                s = 1.7 - 0.7 * k
                c.translate(W / 2, cy)
                c.scale(s, s)
                c.translate(-W / 2, -cy)
                draw_words(c, i, x0, base, alpha * min(1.0, local / 0.08))
            elif style == "rise":
                rise = tween(local, 0, 0.5, size * 1.1, 0, out_expo)
                c.clipRect(skia.Rect.MakeLTRB(0, base - size * 1.05, W, base + size * 0.3))
                draw_words(c, i, x0, base + rise, alpha)
            elif style == "wipe":
                k = in_out_expo(progress(local, 0, 0.55))
                lead, trail = min(1.0, k * 2), max(0.0, k * 2 - 1)
                left, right = x0 - 24 * u, x0 + full + 24 * u
                bx0, bx1 = left + (right - left) * trail, left + (right - left) * lead
                c.save()
                c.clipRect(skia.Rect.MakeLTRB(0, 0, bx0, H))  # text shows where the bar has passed
                draw_words(c, i, x0, base, alpha)
                c.restore()
                if bx1 > bx0 + 1 and alpha > 0:
                    c.drawRect(skia.Rect.MakeLTRB(bx0, base - size * 0.95, bx1, base + size * 0.22),
                               P(look.c("primary", alpha)))
            else:  # track: letters close in from wide spacing (keywords keep their colour)
                spacing = tween(local, 0, 0.6, 70 * u, 0, out_expo)
                a = alpha * min(1.0, local / 0.15)
                chars = [(ch, m) for wi, (w, m) in enumerate(zip(clean, marked))
                         for ch in (w + (" " if wi < len(clean) - 1 else ""))]
                cw = [font.measureText(ch) for ch, _ in chars]
                x = W / 2 - (sum(cw) + spacing * (len(chars) - 1)) / 2
                for (ch, m), w_ in zip(chars, cw):
                    pp = P(look.c("primary" if m else "text", a))
                    pp.setImageFilter(shadow)
                    c.drawString(ch, x, base, font, pp)
                    x += w_ + spacing
            c.restore()
            # accent: a brand-colour bar grows from the centre under each beat (not on the wipe beat)
            if style != "wipe":
                g = out_expo(progress(local, 0.18, 0.45)) * (1 - ex)
                if g > 0.01:
                    bw = full * 0.5 * g
                    c.drawRRect(rrect(W / 2 - bw / 2, base + size * 0.3, bw, 10 * u, 5 * u), P(look.c("primary", 1 - ex)))
    return total, draw


TEMPLATES = {
    "hook_title": hook_title, "slam": slam, "stat_counter": stat_counter, "phrase_card": phrase_card,
    "lower_third": lower_third, "swipe": swipe, "cta_outro": cta_outro, "kinetic_type": kinetic_type,
}
OPAQUE = {"cta_outro"}


# Where each template sits by default (fraction of frame height), so "position" can move it.
POSITIONS = {"top": 0.14, "upper": 0.28, "center": 0.50, "lower": 0.68, "bottom": 0.84}


def anchor(template: str, look: Look) -> float | None:
    v = look.vertical
    low_caps = look.client.brand["captions"]["position"] == "lower"
    return {"hook_title": 0.24 if v else 0.30, "slam": 0.40 if v else 0.45,
            "stat_counter": 0.60 if v else 0.62, "phrase_card": 0.60 if v else 0.62,
            "lower_third": (0.56 if low_caps else 0.74) if v else (0.62 if low_caps else 0.80),
            "kinetic_type": 0.50}.get(template)


def make(template: str, look: Look, fps: float, out: Path, samples: int = 4, position: str | None = None,
         background: str | None = None, speed: float = 1.0, **params) -> Path:
    """position: top/upper/center/lower/bottom moves the graphic. background: a hex colour
    (e.g. "#00b140" for green screen) renders it opaque on that colour instead of transparent."""
    look.fps = fps
    dur, inner = TEMPLATES[template](look, **params)
    speed = max(0.5, min(2.0, float(speed or 1.0)))  # >1 snappier, <1 calmer (matched to a reference)
    dur = dur / speed

    def draw(c, t):
        inner(c, t * speed)
    opaque = template in OPAQUE
    base = anchor(template, look)
    dy = 0.0
    if position in POSITIONS and base is not None:
        # how far each graphic reaches above / below its anchor (px at 1080 on the short side)
        up, down = {"hook_title": (230, 160), "slam": (160, 90), "stat_counter": (185, 185),
                    "phrase_card": (75, 90), "lower_third": (10, 170),
                    "kinetic_type": (230, 120)}.get(template, (150, 150))
        margin = 30 * look.u
        target = POSITIONS[position] * look.H
        target = min(max(target, up * look.u + margin), look.H - down * look.u - margin)  # stay in frame
        dy = target - base * look.H
    bg = color(background) if background else None

    def placed(c: skia.Canvas, t: float):
        if bg is not None:
            c.drawColor(bg)
        if dy:
            c.translate(0, dy)
        draw(c, t)
    return render(placed, look.size, fps, dur, out, samples=samples, opaque=opaque or bg is not None)
