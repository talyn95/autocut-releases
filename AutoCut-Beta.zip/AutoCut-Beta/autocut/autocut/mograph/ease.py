"""Easing curves (the same family After Effects' "Easy Ease" and Flow presets use)."""
from __future__ import annotations

import math


def linear(x: float) -> float:
    return x


def out_cubic(x: float) -> float:
    return 1 - (1 - x) ** 3


def in_cubic(x: float) -> float:
    return x ** 3


def in_out_cubic(x: float) -> float:
    return 4 * x ** 3 if x < 0.5 else 1 - (-2 * x + 2) ** 3 / 2


def out_expo(x: float) -> float:
    return 1.0 if x >= 1 else 1 - 2 ** (-10 * x)


def in_expo(x: float) -> float:
    return 0.0 if x <= 0 else 2 ** (10 * x - 10)


def in_out_expo(x: float) -> float:
    if x <= 0 or x >= 1:
        return min(max(x, 0.0), 1.0)
    return 2 ** (20 * x - 10) / 2 if x < 0.5 else (2 - 2 ** (-20 * x + 10)) / 2


def out_back(x: float, s: float = 1.70158) -> float:
    return 1 + (s + 1) * (x - 1) ** 3 + s * (x - 1) ** 2


def out_elastic(x: float) -> float:
    if x <= 0 or x >= 1:
        return min(max(x, 0.0), 1.0)
    return 2 ** (-10 * x) * math.sin((x * 10 - 0.75) * (2 * math.pi) / 3) + 1


def progress(t: float, start: float, dur: float) -> float:
    """0→1 over [start, start+dur], clamped."""
    if dur <= 0:
        return 1.0 if t >= start else 0.0
    return min(1.0, max(0.0, (t - start) / dur))


def tween(t: float, start: float, dur: float, a: float, b: float, ease=out_cubic) -> float:
    return a + (b - a) * ease(progress(t, start, dur))


def inout(t: float, total: float, t_in: float, t_out: float, ease_in=out_expo, ease_out=in_cubic) -> float:
    """1 while on screen: eases up over the first t_in seconds, down over the last t_out."""
    if t < t_in:
        return ease_in(progress(t, 0, t_in))
    if t > total - t_out:
        return 1 - ease_out(progress(t, total - t_out, t_out))
    return 1.0
