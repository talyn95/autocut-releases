"""Frame loop with motion blur, plus brand fonts/colours as Skia objects."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import numpy as np
import skia

from ..config import Client, hex_to_rgb
from ..effects.render import write_rgba


def color(hex_color: str, alpha: float = 1.0) -> int:
    r, g, b = hex_to_rgb(hex_color)
    return skia.ColorSetARGB(int(255 * max(0.0, min(1.0, alpha))), r, g, b)


def shade(hex_color: str, k: float) -> str:
    """k < 1 darkens, k > 1 lightens (towards white)."""
    r, g, b = hex_to_rgb(hex_color)
    if k <= 1:
        r, g, b = (int(c * k) for c in (r, g, b))
    else:
        f = min(1.0, k - 1)
        r, g, b = (int(c + (255 - c) * f) for c in (r, g, b))
    return f"#{r:02x}{g:02x}{b:02x}"


def _font_files(client: Client) -> list[tuple[Path, str, int]]:
    """(file, family, weight) for every font in the client's fonts folder."""
    folder = client.path(client.brand["fonts"]["folder"])
    out = []
    if not folder or not folder.is_dir():
        return out
    from fontTools.ttLib import TTFont
    for f in sorted(folder.iterdir()):
        if f.suffix.lower() not in (".ttf", ".otf", ".woff", ".woff2"):
            continue
        try:
            tt = TTFont(f, lazy=True)
            names = {r.nameID: r.toUnicode() for r in tt["name"].names if r.nameID in (1, 16)}
            weight = tt["OS/2"].usWeightClass if "OS/2" in tt else 400
            out.append((f, names.get(16) or names.get(1, ""), weight))
        except Exception:  # e.g. WOFF2 without the brotli package: name it from the file
            if f.suffix.lower() in (".woff", ".woff2"):
                out.append((f, *family_from_filename(f)))
    return out


def family_from_filename(f: Path) -> tuple[str, int]:
    """"Gotham-Bold.woff2" → ("Gotham", 700): a font's family and weight guessed from its file name."""
    import re
    stem = re.sub(r"[-_ ]?(webfont|variable|vf)$", "", f.stem, flags=re.I)
    weights = [("thin", 100), ("extralight", 200), ("ultralight", 200), ("light", 300), ("regular", 400), ("book", 400),
               ("medium", 500), ("semibold", 600), ("demibold", 600), ("extrabold", 800), ("ultrabold", 800),
               ("bold", 700), ("black", 900), ("heavy", 900)]
    low = re.sub(r"(italic|oblique|it)$", "", stem.lower().replace("-", "").replace("_", ""))
    weight = next((w for k, w in weights if low.endswith(k)), 400)
    family = re.split(r"[-_ ](?:thin|extralight|ultralight|light|regular|book|medium|semibold|demibold|extrabold|"
                      r"ultrabold|bold|black|heavy|italic)", stem, flags=re.I)[0]
    return re.sub(r"(?<=[a-z])(?=[A-Z])", " ", family).strip() or stem, weight


_tf_cache: dict[tuple, skia.Typeface] = {}


def typeface(client: Client, role: str = "headline", weight: int = 800) -> skia.Typeface:
    """The client's font for `role`, the file closest to `weight` (800 = extra bold)."""
    family = client.brand["fonts"][role]
    key = (str(client.folder), family, weight)
    if key in _tf_cache:
        return _tf_cache[key]
    files = [x for x in _font_files(client) if x[1].lower() == family.lower()] or _font_files(client)
    tf = None
    if files:
        best = min(files, key=lambda x: abs(x[2] - weight))
        tf = skia.Typeface.MakeFromFile(str(best[0]))
    if tf is None:  # installed system font, then any bold sans
        style = skia.FontStyle(weight, skia.FontStyle.kNormal_Width, skia.FontStyle.kUpright_Slant)
        tf = skia.Typeface.MakeFromName(family, style) or skia.Typeface.MakeFromName("Helvetica", style) \
            or skia.Typeface.MakeDefault()
    _tf_cache[key] = tf
    return tf


@dataclass
class Look:
    """Everything a template needs to look on-brand."""
    client: Client
    size: tuple[int, int]
    fps: float = 30.0

    @property
    def W(self) -> int:
        return self.size[0]

    @property
    def H(self) -> int:
        return self.size[1]

    @property
    def u(self) -> float:  # 1 unit = 1px at 1080 on the short side
        return min(self.size) / 1080

    @property
    def vertical(self) -> bool:
        return self.H > self.W

    def c(self, name: str, alpha: float = 1.0) -> int:
        return color(self.client.brand["colors"][name], alpha)

    def hex(self, name: str) -> str:
        return self.client.brand["colors"][name]

    def font(self, px: float, role: str = "headline", weight: int = 800) -> skia.Font:
        f = skia.Font(typeface(self.client, role, weight), px)
        f.setSubpixel(True)
        f.setEdging(skia.Font.Edging.kAntiAlias)
        return f


def render(draw: Callable[[skia.Canvas, float], None], size: tuple[int, int], fps: float, dur: float,
           out: Path, samples: int = 4, shutter: float = 0.5, opaque: bool = False) -> Path:
    """Render draw(canvas, t) for t in [0, dur) to ProRes. Motion blur: each frame averages
    `samples` sub-frames spread over `shutter` of a frame (After Effects' default is 180° = 0.5)."""
    W, H = size
    info = skia.ImageInfo.Make(W, H, skia.kRGBA_8888_ColorType, skia.kPremul_AlphaType)
    surface = skia.Surface.MakeRaster(info)
    n = max(1, round(dur * fps))
    samples = max(1, samples)

    def snap(t: float) -> np.ndarray:
        canvas = surface.getCanvas()
        canvas.clear(skia.ColorTRANSPARENT)
        canvas.save()
        draw(canvas, min(max(t, 0.0), dur))
        canvas.restore()
        return surface.makeImageSnapshot().toarray(colorType=skia.kRGBA_8888_ColorType,
                                                   alphaType=skia.kPremul_AlphaType)

    offsets = [shutter * ((k + 0.5) / samples - 0.5) for k in range(samples)] if samples > 1 else [0.0]

    def frames():
        acc = np.zeros((H, W, 4), np.uint16)
        for i in range(n):
            first = snap((i + offsets[0]) / fps)
            if samples == 1:
                yield first.tobytes()
                continue
            last = snap((i + offsets[-1]) / fps)
            if np.array_equal(first, last):  # nothing moving this frame: no blur needed
                yield first.tobytes()
                continue
            np.add(first, last, out=acc, dtype=np.uint16)
            for off in offsets[1:-1]:
                acc += snap((i + off) / fps)
            yield (acc // samples).astype(np.uint8).tobytes()

    # frames are premultiplied (as Skia draws them); ffmpeg un-premultiplies natively
    return write_rgba(frames(), size, fps, out, opaque=opaque, premultiplied=True)
