"""Brand-styled captions: an editable SRT plus an animated (kinetic) ASS file.

The ASS file is rendered to a transparent ProRes 4444 overlay in overlays.py. `STYLES` lists every style
(id → label, description) for brand.yaml `captions.style` and the dashboard's style gallery:
  pop / highlight / karaoke / punch / clean   the originals
  glow, marker, spring, typewriter, hollow, ribbon, slide, focus, impact, stack, sticker, subtle, icons
Emphasis words (emphasis.py: the number, the promise, the payoff) get the keyword colour in every style;
`layout()` keeps captions inside the platform safe zones (9:16: clear of the buttons and the caption text).
"""
from __future__ import annotations

import re

from .config import hex_to_rgb
from .edit import norm

STYLES = {
    "pop": ("Pop", "Words build on screen one at a time; the newest pops in the brand colour"),
    "highlight": ("Highlight box", "Pop, with a brand-colour box behind the word being said"),
    "karaoke": ("Karaoke", "The whole line shows; the spoken word lights up"),
    "punch": ("Punch", "One big word at a time, centre screen"),
    "clean": ("Clean", "Plain lines with a soft fade (corporate, long form)"),
    "glow": ("Neon glow", "The whole line shows; the spoken word glows in the brand colour"),
    "marker": ("Marker", "A tilted highlighter stroke behind the spoken word; key words keep theirs"),
    "spring": ("Spring up", "Each word springs up from the baseline as it's said"),
    "typewriter": ("Typewriter", "Letters type on as they're said; the line never shifts"),
    "hollow": ("Hollow", "Outlined words; the spoken one fills with colour"),
    "ribbon": ("Ribbon", "The line sits on a solid band; the spoken word in the brand colour"),
    "slide": ("Slide up", "Each line glides up and fades in; the spoken word lights up"),
    "focus": ("Focus in", "Words sharpen out of a blur as they're said"),
    "impact": ("Impact", "Two words at a time; key words slam in alone, big and tilted"),
    "stack": ("Stack", "A small lead-in above, the key word big below"),
    "sticker": ("Sticker", "Heavy words with a hard brand-colour block shadow"),
    "subtle": ("Subtle", "Small sentence-case lines; words brighten as they're said"),
    "icons": ("Icon pops", "Pop captions plus an icon above the key words"),
}
NEW = {"glow", "marker", "spring", "typewriter", "hollow", "ribbon", "slide", "focus", "impact", "stack", "sticker",
       "subtle", "icons"}
SIZE = {"punch": 1.7, "impact": 1.15, "subtle": 0.85, "stack": 0.8, "sticker": 1.05}


def _lum(hex_color: str) -> float:
    def ch(v):
        v /= 255
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = hex_to_rgb(hex_color)
    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b)


def contrast(a: str, b: str) -> float:
    la, lb = sorted((_lum(a), _lum(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def on(hex_color: str) -> str:
    """Dark or white text, whichever reads better on this colour."""
    return "#111111" if contrast(hex_color, "#111111") >= contrast(hex_color, "#FFFFFF") else "#FFFFFF"


def layout(brand: dict, size: tuple[int, int]) -> dict:
    """Font size, alignment and margins. Vertical video keeps captions above the bottom ~quarter (the platform's
    caption, handle and buttons) and inside wider side margins (the like/comment/share column)."""
    cfg = brand["captions"]
    W, H = size
    style = cfg["style"]
    vertical = H > W * 1.3
    fontsize = cfg["size"] * SIZE.get(style, 1.0) * (W / 1080 if W < H else H / 1080)
    side = int(W * (0.12 if vertical else 0.08))
    if style == "punch":
        align, margin_v = 5, 0
    else:
        align, margin_v = {"lower": (2, int(H * (0.25 if vertical else 0.12))), "middle": (5, 0),
                           "upper": (8, int(H * (0.14 if vertical else 0.10)))}[cfg["position"]]
    y = {2: H - margin_v, 5: H / 2, 8: margin_v}[align]
    return {"fontsize": fontsize, "align": align, "margin_v": margin_v, "side": side, "x": W / 2, "y": y,
            "vertical": vertical}


def icon_moments(words: list[dict], emphasis, brand: dict, every: float = 2.0) -> list[dict]:
    """Icon pops for the "icons" style: emphasis words that have an icon (effects/iconlib.py)."""
    from .broll import stem
    from .effects.iconlib import index
    lib = index()
    out, last = [], -1e9
    for i in sorted(emphasis or []):
        w = words[i]
        name = lib.get(stem(w["word"]))
        if name and w["start"] - last >= every:
            out.append({"start": w["start"], "icon": name, "word": w["word"].strip(",.!?")})
            last = w["start"]
    return out

SENTENCE_END = re.compile(r"[.?!]$")


def ass_color(hex_color: str, alpha: int = 0) -> str:
    r, g, b = hex_to_rgb(hex_color)
    return f"&H{alpha:02X}{b:02X}{g:02X}{r:02X}"


def display_text(word: str, upper: bool) -> str:
    w = word.strip().strip(",.;:")
    w = w.replace("\\", "").replace("{", "(").replace("}", ")")
    return w.upper() if upper else w


def group_lines(words: list[dict], per_line: int, max_secs: float) -> list[list[dict]]:
    lines: list[list[dict]] = []
    cur: list[dict] = []
    for w in words:
        if cur and (len(cur) >= per_line
                    or w["start"] - cur[-1]["end"] > 0.6
                    or w["end"] - cur[0]["start"] > max_secs
                    or SENTENCE_END.search(cur[-1]["word"])
                    or cur[-1]["word"].endswith(",") and len(cur) > 1):
            lines.append(cur)
            cur = []
        cur.append(w)
    if cur:
        lines.append(cur)
    return lines


def line_windows(lines: list[list[dict]], total: float) -> list[tuple[float, float]]:
    out = []
    for i, line in enumerate(lines):
        start = line[0]["start"]
        nxt = lines[i + 1][0]["start"] if i + 1 < len(lines) else total
        out.append((start, max(start + 0.2, min(nxt, line[-1]["end"] + 0.5))))
    return out


def ts_srt(t: float) -> str:
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"


def ts_ass(t: float) -> str:
    cs = int(round(t * 100))
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02}:{s:02}.{cs:02}"


def write_srt(words: list[dict], total: float, cfg: dict, path) -> None:
    lines = group_lines(words, max(cfg["words_per_line"], 5), 3.0)
    rows = []
    for i, (line, (s, e)) in enumerate(zip(lines, line_windows(lines, total)), 1):
        text = " ".join(display_text(w["word"], False) for w in line)
        rows.append(f"{i}\n{ts_srt(s)} --> {ts_srt(e)}\n{text}\n")
    path.write_text("\n".join(rows))


def _impact_groups(words: list[dict], keyset: set, cfg: dict) -> list[list[dict]]:
    """Two words at a time, but a key word always stands alone."""
    out = []
    for line in group_lines(words, 2, cfg["max_line_seconds"]):
        cur = []
        for w in line:
            if id(w) in keyset:
                if cur:
                    out.append(cur)
                out.append([w])
                cur = []
            else:
                cur.append(w)
        if cur:
            out.append(cur)
    return out


def write_ass(words: list[dict], total: float, brand: dict, size: tuple[int, int], path, emphasis=None) -> None:
    """emphasis: indices into `words` that get the keyword colour (emphasis.pick); None = none beyond
    highlight_words and numbers."""
    cfg, colors = brand["captions"], brand["colors"]
    W, H = size
    style = cfg["style"] if cfg["style"] in STYLES else "pop"
    lay = layout({**brand, "captions": {**cfg, "style": style}}, size)
    fontsize, align, margin_v, side = lay["fontsize"], lay["align"], lay["margin_v"], lay["side"]
    upper = cfg["uppercase"] and style != "subtle"

    text_c, hi_c = ass_color(colors["text"]), ass_color(colors["primary"])
    key_c = ass_color(cfg.get("keyword_color") or colors["primary"])
    out_c = ass_color(colors["outline"])
    band = colors.get("secondary") or "#111111"
    if contrast(band, colors["text"]) < 4.5:
        band = "#111111" if contrast("#111111", colors["text"]) >= 4.5 else "#FFFFFF"
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Main,{brand['fonts']['caption']},{fontsize:.0f},{text_c},{text_c},{out_c},{ass_color(colors['outline'], 0x60)},{-1 if cfg['bold'] else 0},0,0,0,100,100,0,0,1,{cfg['outline_width']},{cfg['shadow']},{align},{side},{side},{margin_v},1
Style: Ribbon,{brand['fonts']['caption']},{fontsize:.0f},{text_c},{text_c},{ass_color(band)},{ass_color(band)},{-1 if cfg['bold'] else 0},0,0,0,100,100,0,0,3,{max(8, int(fontsize * 0.22))},0,{align},{side},{side},{margin_v},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    keywords = {norm(k) for k in cfg["highlight_words"]}
    emph = {id(words[i]) for i in (emphasis or []) if 0 <= i < len(words)}

    def is_key(w: dict) -> bool:
        n = norm(w["word"])
        return (id(w) in emph or n in keywords
                or (cfg["highlight_numbers"] and bool(re.search(r"\d", w["word"]))))

    def scale_tags(w: dict, pop: bool) -> str:
        base = 112 if is_key(w) else 100
        if pop:
            return (rf"\fscx{base * 0.7:.0f}\fscy{base * 0.7:.0f}\t(0,90,\fscx{base * 1.15:.0f}\fscy{base * 1.15:.0f})"
                    rf"\t(90,170,\fscx{base}\fscy{base})")
        return rf"\fscx{base}\fscy{base}"

    box = max(10, int(fontsize * 0.42))

    def box_run(w: dict, active: bool, pop: bool) -> str:
        """The highlight layer: identical text and scaling (so it lines up exactly), but only the active
        word shows, as a thick brand-colour outline with an invisible fill: a rounded box behind it."""
        txt = display_text(w["word"], upper)
        vis = rf"\1a&HFF&\3c{hi_c}\3a&H00&\bord{box}\shad0" if active else r"\alpha&HFF&\bord0\shad0"
        return "{" + vis + scale_tags(w, pop) + "}" + txt

    def word_run(w: dict, active: bool, pop: bool = False) -> str:
        txt = display_text(w["word"], upper)
        tags = [r"\c" + (hi_c if active else key_c if is_key(w) else text_c)]
        base = 112 if is_key(w) else 100
        if pop:
            tags.append(rf"\fscx{base * 0.7:.0f}\fscy{base * 0.7:.0f}"
                        rf"\t(0,90,\fscx{base * 1.15:.0f}\fscy{base * 1.15:.0f})"
                        rf"\t(90,170,\fscx{base}\fscy{base})")
        else:
            tags.append(rf"\fscx{base}\fscy{base}")
        return "{" + "".join(tags) + "}" + txt

    def run(w: dict, tags: str) -> str:
        """A run that starts from the style's defaults (\r), so no tag leaks into the next word."""
        return "{\\r" + tags + "}" + display_text(w["word"], upper)

    events = []  # (start, end, text, layer, style)
    if style == "impact":
        lines = _impact_groups(words, {id(w) for w in words if is_key(w)}, cfg)
    else:
        per = {"punch": 1, "subtle": max(cfg["words_per_line"], 6), "stack": max(cfg["words_per_line"], 3)}
        lines = group_lines(words, per.get(style, cfg["words_per_line"]), cfg["max_line_seconds"])
    pos = rf"\an{align}\pos({lay['x']:.0f},{lay['y']:.0f})"
    def _new_style(style, line, i, s, w):
        said = line[:i + 1]
        if style in ("pop", "icons"):
            return [(1, " ".join(word_run(x, active=(j == i), pop=(j == i)) for j, x in enumerate(said)), "Main")]
        if style == "glow":
            g = max(8, int(fontsize * 0.22))
            glow = " ".join(run(x, (rf"\c{hi_c}\1a&H40&\3c{hi_c}\3a&H00&\bord{g}\blur{g * 1.4:.0f}\shad0" if j == i
                                    else r"\alpha&HFF&\bord0\shad0") + scale_tags(x, False))
                            for j, x in enumerate(line))
            text = " ".join(run(x, rf"\c{key_c if is_key(x) and j != i else text_c}" + scale_tags(x, False))
                            for j, x in enumerate(line))
            return [(0, glow, "Main"), (1, text, "Main")]
        if style == "marker":
            tilt = r"\frz2"
            mk = lambda x, j: j == i or (j < i and is_key(x))  # noqa: E731
            boxes = " ".join(run(x, tilt + (rf"\1a&HFF&\3c{hi_c}\3a&H30&\bord{box}\shad0" if mk(x, j)
                                             else r"\alpha&HFF&\bord0\shad0") + scale_tags(x, False))
                             for j, x in enumerate(line))
            ink = ass_color(on(colors["primary"]))
            text = " ".join(run(x, tilt + (rf"\c{ink}\bord0\shad0" if mk(x, j) else rf"\c{text_c}") + scale_tags(x, False))
                            for j, x in enumerate(line))
            return [(0, boxes, "Main"), (1, text, "Main")]
        if style == "spring":
            def sp(x, j):
                base = 112 if is_key(x) else 100
                if j < i:
                    return run(x, rf"\c{key_c if is_key(x) else text_c}\fscx{base}\fscy{base}")
                return run(x, rf"\c{hi_c}\fscx{base}\fscy0\t(0,110,\fscy{base * 1.25:.0f})\t(110,200,\fscy{base})")
            return [(1, " ".join(sp(x, j) for j, x in enumerate(said)), "Main")]
        if style == "typewriter":
            parts = []
            for j, x in enumerate(line):
                if j < i:
                    parts.append(run(x, rf"\c{key_c if is_key(x) else text_c}"))
                elif j > i:
                    parts.append(run(x, r"\alpha&HFF&"))
                else:
                    txt = display_text(x["word"], upper)
                    off = max(0, int((x["start"] - s) * 1000))
                    step = max(18, int(min(0.35, max(0.1, x["end"] - x["start"])) * 1000 / max(1, len(txt))))
                    parts.append(rf"{{\r\c{hi_c}}}" + "".join(
                        rf"{{\alpha&HFF&\t({off + k * step},{off + k * step + 1},\alpha&H00&)}}{ch}"
                        for k, ch in enumerate(txt)))
            return [(1, " ".join(parts), "Main")]
        if style == "hollow":
            ob = max(3, int(cfg["outline_width"] * 0.7))
            text = " ".join(run(x, (rf"\c{hi_c}\3c{out_c}\bord{cfg['outline_width']}" if j == i
                                    else rf"\1a&HFF&\3c{key_c if is_key(x) else text_c}\bord{ob}\shad0")
                                + scale_tags(x, False)) for j, x in enumerate(line))
            return [(1, text, "Main")]
        if style == "ribbon":
            text = " ".join(run(x, rf"\c{hi_c if j == i else key_c if is_key(x) else text_c}")
                            for j, x in enumerate(line))
            return [(1, (r"{\fad(90,0)}" if i == 0 else "") + text, "Ribbon")]
        if style == "slide":
            d = int(fontsize * 0.45)
            move = (rf"\an{align}\move({lay['x']:.0f},{lay['y'] + d:.0f},{lay['x']:.0f},{lay['y']:.0f},0,200)\fad(160,0)"
                    if i == 0 else pos)
            text = " ".join(run(x, rf"\c{hi_c if j == i else key_c if is_key(x) else text_c}" + scale_tags(x, False))
                            for j, x in enumerate(line))
            return [(1, "{" + move + "}" + text, "Main")]
        if style == "focus":
            def fo(x, j):
                c = hi_c if j == i else key_c if is_key(x) else text_c
                return run(x, rf"\c{c}" + (r"\blur14\alpha&H90&\t(0,220,\blur0\alpha&H00&)" if j == i else ""))
            return [(1, " ".join(fo(x, j) for j, x in enumerate(said)), "Main")]
        if style == "impact":
            if len(line) == 1 and is_key(line[0]):
                return [(1, run(w, rf"\c{hi_c}\frz-12\fscx190\fscy190\t(0,120,\frz-4\fscx140\fscy140)"), "Main")]
            return [(1, " ".join(word_run(x, active=(j == i), pop=(j == i)) for j, x in enumerate(said)), "Main")]
        if style == "sticker":
            d = max(5, int(fontsize * 0.12))
            hard = rf"\4c{hi_c}\4a&H00&\xshad{d}\yshad{d}\3c{out_c}\bord{max(3, cfg['outline_width'])}"
            return [(1, " ".join(run(x, hard + rf"\c{key_c if is_key(x) and j != i else text_c}" + scale_tags(x, j == i))
                                 for j, x in enumerate(said)), "Main")]
        if style == "subtle":
            soft = r"\bord2\3c&H000000&\3a&H90&\blur3\shad0"
            text = " ".join(run(x, soft + (r"\alpha&H00&" if j <= i else r"\alpha&H88&")
                                + rf"\c{key_c if is_key(x) and j <= i else text_c}") for j, x in enumerate(line))
            return [(1, text, "Main")]
        raise ValueError(style)

    for line, (ls, le) in zip(lines, line_windows(lines, total)):
        if style == "clean":
            text = " ".join(display_text(w["word"], upper) for w in line)
            events.append((ls, le, r"{\fad(120,120)}" + text))
            continue
        if style == "stack":  # the whole line at once: lead-in small on top, the key word big below
            key = next((w for w in line if is_key(w)), None) or max(line, key=lambda w: len(norm(w["word"])))
            k = line.index(key)
            for i, w in enumerate(line):
                s = ls if i == 0 else w["start"]
                e = line[i + 1]["start"] if i + 1 < len(line) else le
                if e - s < 0.02:
                    continue
                small = lambda x, j: run(x, rf"\fscx85\fscy85\c{hi_c if j == i else text_c}")  # noqa: E731
                big = (rf"\fscx170\fscy170\c{hi_c}" + (r"\t(0,80,\fscx190\fscy190)\t(80,160,\fscx170\fscy170)"
                                                         if i == k else ""))
                top = " ".join(small(x, j) for j, x in enumerate(line[:k]))
                rest = " ".join(small(x, j) for j, x in enumerate(line[k + 1:], k + 1))
                text = (top + r"\N" if top else "") + run(key, big) + (" " + rest if rest else "")
                events.append((s, e, (r"{\fad(100,0)}" if i == 0 else "") + text))
            continue
        for i, w in enumerate(line):
            s = ls if i == 0 else w["start"]
            e = line[i + 1]["start"] if i + 1 < len(line) else le
            if e - s < 0.02:
                continue
            said = line[:i + 1]
            if style == "punch":
                runs = [word_run(w, active=False, pop=True)]
            elif style == "karaoke":
                runs = [word_run(x, active=(j == i)) for j, x in enumerate(line)]
            elif style == "highlight":  # pop, with a box behind the word being said (on its own layer below)
                events.append((s, e, " ".join(box_run(x, active=(j == i), pop=(j == i)) for j, x in enumerate(said)), 0))
                runs = [word_run(x, active=False, pop=(j == i)) for j, x in enumerate(said)]
                events.append((s, e, " ".join(runs), 1))
                continue
            elif style in NEW:
                for layer, text, st in _new_style(style, line, i, s, w):
                    events.append((s, e, text, layer, st))
                continue
            else:  # pop: only the words said so far, so the line stays centred as it grows (no stagger)
                runs = [word_run(x, active=(j == i), pop=(j == i)) for j, x in enumerate(said)]
            events.append((s, e, " ".join(runs)))

    body = "".join(f"Dialogue: {ev[3] if len(ev) > 3 else 1},{ts_ass(ev[0])},{ts_ass(ev[1])},"
                   f"{ev[4] if len(ev) > 4 else 'Main'},,0,0,0,,{ev[2]}\n" for ev in events)
    path.write_text(header + body)
