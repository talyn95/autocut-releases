"""Texture overlays: vignette + film grain (one looping clip) and light leaks on cuts.

A client's own overlay clips (alpha .mov, e.g. licensed light leaks) in
assets/overlays/ are used for the leaks instead of the generated one.
"""
from __future__ import annotations

import math
import random
from pathlib import Path

import numpy as np
from PIL import Image

from ..config import Client
from .render import write_rgba

LOOP_SECONDS = 2.0


def _vignette(W: int, H: int, strength: float = 0.55) -> np.ndarray:
    y, x = np.ogrid[0:H, 0:W]
    d = np.sqrt(((x - W / 2) / (W / 2)) ** 2 + ((y - H / 2) / (H / 2)) ** 2) / math.sqrt(2)
    return (np.clip((d - 0.45) / 0.55, 0, 1) ** 1.6 * strength * 255).astype(np.uint8)


def texture_loop(client: Client, size: tuple[int, int], fps: float, out: Path) -> Path | None:
    cfg = client.brand["overlays"]
    if not (cfg["vignette"] or cfg["grain"]):
        return None
    W, H = size
    vig = _vignette(W, H) if cfg["vignette"] else np.zeros((H, W), np.uint8)
    rng = np.random.default_rng(7)
    n = round(LOOP_SECONDS * fps)

    def frames():
        for _ in range(n):
            rgba = np.zeros((H, W, 4), np.uint8)
            alpha = vig.astype(np.int16)
            if cfg["grain"]:
                small = rng.integers(0, 255, (H // 2, W // 2), dtype=np.uint8)
                g = np.asarray(Image.fromarray(small).resize((W, H), Image.NEAREST))
                # grain fades smoothly into the dark vignette (no hard edge where they meet)
                fade = 1 - np.clip(vig.astype(np.float32) / 90, 0, 1)
                rgba[..., :3] = (g * fade)[..., None].astype(np.uint8)
                alpha = np.maximum(alpha, 14)
            rgba[..., 3] = np.clip(alpha, 0, 255).astype(np.uint8)
            yield rgba.tobytes()

    return write_rgba(frames(), size, fps, out)


def leak_clip(client: Client, size: tuple[int, int], fps: float, out: Path, seed: int) -> Path:
    """A warm light leak sweeping across the frame (~0.9s), or the client's own."""
    folder = client.path(client.brand["overlays"]["folder"])
    own = sorted(folder.glob("*.mov")) if folder and folder.is_dir() else []
    if own:
        return own[seed % len(own)]
    W, H = size
    w2, h2 = W // 4, H // 4
    rng = random.Random(seed)
    dur, n = 0.9, round(0.9 * fps)
    hue = rng.choice([(255, 140, 60), (255, 90, 120), (255, 190, 90)])
    y, x = np.ogrid[0:h2, 0:w2]

    def frames():
        for i in range(n):
            t = i / max(1, n - 1)
            env = math.sin(math.pi * t) ** 1.5
            cx = (-0.2 + 1.4 * t) * w2
            cy = (0.3 + 0.3 * math.sin(t * 3 + seed)) * h2
            d = np.sqrt(((x - cx) / (w2 * 0.6)) ** 2 + ((y - cy) / (h2 * 0.45)) ** 2)
            a = np.clip(1 - d, 0, 1) ** 2 * 0.75 * env
            small = np.zeros((h2, w2, 4), np.uint8)
            small[..., 0], small[..., 1], small[..., 2] = hue
            small[..., 3] = (a * 255).astype(np.uint8)
            yield Image.fromarray(small, "RGBA").resize((W, H), Image.BILINEAR).tobytes()

    return write_rgba(frames(), size, fps, out)


def leak_moments(segments, fps: float, every: float) -> list[float]:
    """Timeline seconds of cuts to dress with a leak, at most one per `every` seconds."""
    out, last = [], -1e9
    for seg in segments[1:]:
        t = seg.rec_in / fps
        if t - last >= every:
            out.append(max(0.0, t - 0.45))  # leak peaks on the cut
            last = t
    return out
