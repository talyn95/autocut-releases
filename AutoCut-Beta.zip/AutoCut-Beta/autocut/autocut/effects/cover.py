"""Cover image (thumbnail): the speaker cut out over the brand colour, the hook text
huge behind them, the logo in the corner. Falls back to the frame itself, darkened,
when no person-segmentation engine is available."""
from __future__ import annotations

import subprocess
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

from ..config import Client, hex_to_rgb
from ..media import MediaInfo


def _font(client: Client, size: int) -> ImageFont.FreeTypeFont:
    """The client's headline font from assets/fonts, else a bold system font."""
    folder = client.path(client.brand["fonts"]["folder"])
    want = client.brand["fonts"]["headline"]
    candidates = sorted(folder.glob("*.[ot]tf")) if folder and folder.is_dir() else []
    # prefer the boldest file of the right family
    ranked = sorted(candidates, key=lambda p: (want.lower() not in p.stem.lower(),
                                               not any(w in p.stem.lower() for w in ("black", "extrabold", "heavy", "bold"))))
    for p in ranked + [Path("/System/Library/Fonts/Supplemental/Arial Black.ttf"),
                       Path("/System/Library/Fonts/Helvetica.ttc"),
                       Path(r"C:\Windows\Fonts\ariblk.ttf"), Path(r"C:\Windows\Fonts\arialbd.ttf"),
                       Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")]:
        try:
            return ImageFont.truetype(str(p), size)
        except OSError:
            continue
    return ImageFont.load_default()


def _frame(info: MediaInfo, seconds: float) -> Image.Image:
    raw = subprocess.run(["ffmpeg", "-loglevel", "error", "-ss", f"{seconds:.3f}", "-i", str(info.path),
                          "-frames:v", "1", "-vf", f"scale={info.width}:{info.height}", "-f", "rawvideo",
                          "-pix_fmt", "rgb24", "-"], capture_output=True).stdout
    return Image.frombytes("RGB", (info.width, info.height), raw)


def _fit_cover(img: Image.Image, W: int, H: int, zoom: float = 1.0) -> Image.Image:
    k = max(W / img.width, H / img.height) * zoom
    r = img.resize((int(img.width * k), int(img.height * k)), Image.LANCZOS)
    x, y = (r.width - W) // 2, (r.height - H) // 2
    return r.crop((x, y, x + W, y + H))


def make_cover(client: Client, info: MediaInfo, plan, zooms: list[float], hook: str, out: Path) -> Path:
    b = client.brand
    W, H = client.size
    seg = plan.segments[0]
    t = (seg.src_in + (seg.src_out - seg.src_in) * 0.3) / plan.fps  # a settled moment in the first shot
    frame = _fit_cover(_frame(info, t), W, H, zooms[0] if zooms else 1.0)

    subject = None
    try:
        from .cutout import get_segmenter
        seg_engine = get_segmenter(b["cutout"]["engine"])
        mask = seg_engine(np.asarray(frame.resize((W // 2, H // 2))))
        mask = np.clip((mask - 0.25) / 0.5, 0, 1)
        alpha = Image.fromarray((mask * 255).astype(np.uint8)).resize((W, H), Image.BILINEAR).filter(ImageFilter.GaussianBlur(1.5))
        if np.asarray(alpha).mean() > 8:  # found a person
            subject = frame.convert("RGBA")
            subject.putalpha(alpha)
    except Exception:
        subject = None

    primary = hex_to_rgb(b["colors"]["primary"])
    if subject is not None:
        # brand-colour background with a soft darker edge
        bg = Image.new("RGB", (W, H), primary)
        y, x = np.ogrid[0:H, 0:W]
        d = np.sqrt(((x - W / 2) / W) ** 2 + ((y - H * 0.4) / H) ** 2)
        shade = np.clip(1 - d * 0.9, 0.45, 1)[..., None]
        canvas = Image.fromarray((np.asarray(bg) * shade).astype(np.uint8)).convert("RGBA")
    else:
        canvas = Image.blend(frame, Image.new("RGB", (W, H), (0, 0, 0)), 0.35).convert("RGBA")

    # hook text: up to 3 lines, as big as fits, upper part of the frame
    words = (hook or b["client"]).upper().split()
    lines = [" ".join(words[i:i + 2]) for i in range(0, len(words), 2)][:3]
    size = int(H * 0.16)
    font = _font(client, size)
    while size > 40 and max(font.getlength(l) for l in lines) > W * 0.92:
        size = int(size * 0.92)
        font = _font(client, size)
    text_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw = ImageDraw.Draw(text_layer)
    text_fill = hex_to_rgb(b["colors"]["text"]) if subject is not None else primary
    y0 = H * (0.10 if H > W else 0.12)
    for i, line in enumerate(lines):
        draw.text((W / 2, y0 + i * size * 1.02), line, font=font, fill=text_fill, anchor="mt",
                  stroke_width=max(2, size // 22), stroke_fill=hex_to_rgb(b["colors"]["outline"]))
    canvas.alpha_composite(text_layer)
    if subject is not None:
        canvas.alpha_composite(subject)  # the speaker stands in front of the words

    logo = client.path(b["logo"]["file"])
    if logo and logo.exists():
        lg = Image.open(logo).convert("RGBA")
        lg.thumbnail((int(W * 0.28), int(H * 0.08)))
        canvas.alpha_composite(lg, (int(W * 0.05), int(H - lg.height - H * 0.05)))
    canvas.convert("RGB").save(out, quality=92)
    return out
