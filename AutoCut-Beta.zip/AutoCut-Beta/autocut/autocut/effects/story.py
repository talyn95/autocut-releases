"""Story cutaways: when the speaker describes something (a process, a before/after, a list of
things), cut away to an animated storyboard that tells it with pictures, timed to the words.

Each beat is the best picture AutoCut has for a word that was said, in this order:
  video   a clip from the client's B-roll / media library → a picture-in-picture video window
  image   a photo / graphic / screenshot from the client's media library (tags or file name)
  icon    one of the 2,100 Lucide icons → a flat illustrated icon on a 3D brand-colour tile
Beats swing in in 3D as their word is said, joined by an arrow that draws on. The speaker stays
on screen in a framed picture-in-picture, so it still feels like they're telling the story.

The whole cutaway is one alpha ProRes clip on its own track, under the captions.
"""
from __future__ import annotations

import math
import subprocess
from pathlib import Path

import numpy as np
import skia

from ..broll import STOP, stem
from ..config import Client
from ..edit import norm

VIDEO_EXT = {".mp4", ".mov", ".m4v"}
WEAK = set("""really actually basically literally maybe probably just like stuff thing things kind sort lot lots
going gonna want need make made know think said says say tell told come came take took give gave""".split())


# ---- 1. find the moments -----------------------------------------------------------------
def visuals(client: Client, broll_clips: list | None = None) -> dict[str, dict]:
    """word stem → the best visual for it: client media (video, image) beats icons."""
    from .iconlib import index
    out: dict[str, dict] = {s: {"kind": "icon", "icon": name} for s, name in index().items()}
    try:
        from .media import library
        items = library(client)
    except Exception:
        items = []
    for it in items:
        if it["category"] not in ("graphics", "photos", "screenshots", "broll") or it.get("main_logo"):
            continue
        words = (it["tags"].replace(",", " ") + " " + Path(it["name"]).stem.replace("-", " ").replace("_", " ")).split()
        kind = "video" if Path(it["path"]).suffix.lower() in VIDEO_EXT else "image"
        for w in words:
            s = stem(w)
            if len(s) < 3 or w.lower() in STOP or w.isdigit():
                continue
            if out.get(s, {}).get("kind") != "video":  # a video beats an image beats an icon
                out[s] = {"kind": kind, "path": it["path"]}
    for c in broll_clips or []:
        for s in c.tags:
            if out.get(s, {}).get("kind") in (None, "icon"):
                out[s] = {"kind": "video", "path": str(c.path)}
    return out


def _sentences(words: list[dict]) -> list[tuple[int, int]]:
    out, start = [], 0
    for i, w in enumerate(words):
        nxt = words[i + 1] if i + 1 < len(words) else None
        if w["word"].rstrip().endswith((".", "?", "!")) or nxt is None or nxt["start"] - w["end"] > 1.0:
            out.append((start, i))
            start = i + 1
    return out


def find_moments(words: list[dict], client: Client, occupied, total: float,
                 broll_clips: list | None = None) -> list[dict]:
    cfg = client.brand["story"]
    lib = visuals(client, broll_clips)
    max_beats = int(cfg["max_beats"])
    longest = float(cfg["max_seconds"])
    sents = _sentences(words)
    cands = []
    for i in range(len(sents)):
        for j in range(i, min(i + 3, len(sents))):  # a sentence, or two or three short ones
            a, b = sents[i][0], sents[j][1]
            if words[b]["end"] - words[a]["start"] > longest + 2:
                break
            beats, seen = [], set()
            for w in words[a:b + 1]:
                n = norm(w["word"])
                s = stem(n)
                if len(n) < 3 or n in STOP or n in WEAK or s not in lib:
                    continue
                v = lib[s]
                key = v.get("path") or v.get("icon")
                if key in seen or (beats and w["start"] - beats[-1]["t"] < 0.5):
                    continue
                seen.add(key)
                beats.append({"t": w["start"], "word": w["word"].strip(",.!?;:\"'").lower(), **v})
                if len(beats) >= max_beats:
                    break
            if len(beats) < 2:
                continue
            start = max(0.0, beats[0]["t"] - 0.45)
            end = min(total - 0.3, max(beats[-1]["t"] + 1.7, start + 3.2), start + longest)
            beats = [x for x in beats if x["t"] < end - 0.9]
            if len(beats) < 2 or end - start < 3.0 or start < 2.5:
                continue
            score = len(beats) + 0.6 * sum(x["kind"] != "icon" for x in beats)
            cands.append({"start": round(start, 3), "end": round(end, 3), "beats": beats, "score": score})
    cands.sort(key=lambda c: (-c["score"], c["start"]))
    gap = max(float(cfg["min_gap_seconds"]), 60.0 / max(0.1, float(cfg["max_per_minute"])))
    picked: list[dict] = []
    for c in cands:
        if any(abs(c["start"] - p["start"]) < gap for p in picked):
            continue
        if occupied is not None and not occupied.free(c["start"], c["end"]):
            continue
        picked.append(c)
        if occupied is not None:
            occupied.take(c["start"], c["end"], "story cutaway")
    picked.sort(key=lambda c: c["start"])
    for c in picked:
        for x in c["beats"]:
            x["t"] = round(x["t"] - c["start"], 3)  # relative to the cutaway
    return picked


# ---- 2. pictures --------------------------------------------------------------------------
def _sk(rgba: np.ndarray) -> skia.Image:
    return skia.Image.fromarray(np.ascontiguousarray(rgba), colorType=skia.kRGBA_8888_ColorType)


def icon_image(name: str, px: int, hex_color: str = "#ffffff") -> skia.Image:
    from .iconlib import ICON_DIR
    svg = (ICON_DIR / "svg" / f"{name}.svg").read_text().replace("currentColor", hex_color)
    surface = skia.Surface.MakeRaster(skia.ImageInfo.Make(px, px, skia.kRGBA_8888_ColorType, skia.kPremul_AlphaType))
    c = surface.getCanvas()
    c.clear(skia.ColorTRANSPARENT)
    dom = skia.SVGDOM.MakeFromStream(skia.MemoryStream(svg.encode()))
    dom.setContainerSize(skia.Size(24, 24))
    c.scale(px / 24, px / 24)
    dom.render(c)
    return surface.makeImageSnapshot()


def still_image(path: str, px: int) -> skia.Image:
    from .media import _open
    img = _open(Path(path)).convert("RGBA")
    s = min(img.width, img.height)
    img = img.crop(((img.width - s) // 2, (img.height - s) // 2, (img.width + s) // 2, (img.height + s) // 2))
    return _sk(np.asarray(img.resize((px, px))))


def video_frames(path: str, start: float, dur: float, fps: float, w: int, h: int) -> list[np.ndarray]:
    """Frames of a clip, centre-cropped to w×h (RGBA)."""
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-ss", f"{max(0.0, start):.3f}", "-i", path,
                        "-t", f"{dur:.3f}", "-an", "-vf", f"fps={fps},scale={w}:{h}:force_original_aspect_ratio=increase,"
                        f"crop={w}:{h},format=rgba", "-f", "rawvideo", "-"], capture_output=True)
    n = len(r.stdout) // (w * h * 4)
    return [np.frombuffer(r.stdout, np.uint8, w * h * 4, i * w * h * 4).reshape(h, w, 4) for i in range(n)]


def speaker_frames(video: Path, segments, fps_tl: float, start: float, dur: float, w: int, h: int,
                   fps: float) -> list[np.ndarray]:
    """What V1 shows during [start, start+dur] on the timeline (following the cuts), as w×h frames."""
    out: list[np.ndarray] = []
    t, end = start, start + dur
    for seg in segments:
        a, b = seg.rec_in / fps_tl, seg.rec_out / fps_tl
        if b <= t or a >= end:
            continue
        s, e = max(a, t), min(b, end)
        src = seg.src_in / fps_tl + (s - a)
        out += video_frames(str(video), src, e - s, fps, w, h)
    return out


# ---- 3. drawing ---------------------------------------------------------------------------
def perspective(cx: float, cy: float, rot_y: float, rot_x: float = 0.0, dist: float = 1400.0) -> skia.M44:
    """A 3D rotation about (cx, cy) seen through a camera `dist` px away."""
    persp = skia.M44()
    persp.setRC(3, 2, -1.0 / dist)
    m = skia.M44.Translate(cx, cy)
    m = m.preConcat(persp)
    m = m.preConcat(skia.M44.Rotate(skia.V3(0, 1, 0), rot_y))
    if rot_x:
        m = m.preConcat(skia.M44.Rotate(skia.V3(1, 0, 0), rot_x))
    return m.preConcat(skia.M44.Translate(-cx, -cy))


def layout(n: int, W: int, H: int, vertical: bool) -> tuple[list[tuple[float, float]], float, skia.Rect]:
    """Beat centres, tile size, and where the speaker picture-in-picture sits."""
    u = min(W, H) / 1080
    if vertical:
        pip_w = W * 0.40
        pip = skia.Rect.MakeXYWH((W - pip_w) / 2, H * 0.06, pip_w, pip_w * 1.25)
        tile = min(W * (0.25 if n <= 3 else 0.23), 290 * u)
        if n <= 3:
            ys = [H * 0.56] * n
            xs = [W * (k + 1) / (n + 1) for k in range(n)]
        else:  # a loop: across, down, back
            xs = [W * 0.3, W * 0.7, W * 0.7, W * 0.3][:n]
            ys = [H * 0.43, H * 0.43, H * 0.62, H * 0.62][:n]
    else:
        pip_h = H * 0.34
        pip = skia.Rect.MakeXYWH(W - pip_h * 16 / 9 - W * 0.04, H * 0.06, pip_h * 16 / 9, pip_h)
        tile = min(H * 0.30, W * 0.8 / max(n, 1) * 0.62)
        xs = [W * (k + 1) / (n + 1) for k in range(n)]
        ys = [H * (0.58 if k % 2 == 0 else 0.62) for k in range(n)]
    return list(zip(xs, ys)), tile, pip


def make_draw(moment: dict, client: Client, size: tuple[int, int], fps: float,
              speaker: list[np.ndarray] | None):
    from ..mograph.ease import in_cubic, out_back, out_cubic, out_expo, progress
    from ..mograph.engine import Look, color, shade
    from ..mograph.templates import P, rrect
    look = Look(client, size, fps)
    W, H, u = look.W, look.H, look.u
    dur = moment["end"] - moment["start"]
    beats = moment["beats"]
    pos, tile, pip = layout(len(beats), W, H, look.vertical)
    primary = look.hex("primary")
    # a light "paper" tinted with the brand colour: the flat-illustration look, and white captions
    # (which have an outline) plus the brand-colour highlight both stay readable on it
    paper0, paper1 = shade(primary, 1.92), shade(primary, 1.84)
    ink = shade(primary, 0.42)
    label_font = look.font(max(26 * u, tile * 0.13), weight=800)
    px = int(tile)

    # pictures, made once
    for b in beats:
        if b["kind"] == "icon":
            b["img"] = icon_image(b["icon"], int(px * 0.52))
        elif b["kind"] == "image":
            try:
                b["img"] = still_image(b["path"], px)
            except Exception:
                b["kind"], b["img"] = "icon", icon_image("image", int(px * 0.52))
        else:
            from ..media import probe
            try:
                d = probe(Path(b["path"])).duration
                b["frames"] = video_frames(b["path"], max(0.0, d / 2 - dur / 2), dur, fps, px, px)
            except Exception:
                b["frames"] = []
            if not b["frames"]:
                b["kind"], b["img"] = "icon", icon_image("play", int(px * 0.52))
    spk = [_sk(f) for f in speaker] if speaker else []
    reveal_r = math.hypot(W, H) / 2 + 20

    def draw(c: skia.Canvas, t: float):
        # background: a circle wipe in brand colour, out again at the end
        k_in, k_out = out_expo(progress(t, 0.0, 0.42)), in_cubic(progress(t, dur - 0.38, 0.38))
        r = reveal_r * (k_in - k_out)
        if r <= 0:
            return
        c.save()
        clip = skia.Path()
        clip.addCircle(W / 2, H / 2, r)
        c.clipPath(clip, doAntiAlias=True)
        shader = skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(W * 0.4, H)],
                                                [color(paper0), color(paper1)], [0.0, 1.0])
        c.drawPaint(skia.Paint(Shader=shader))
        # flat-illustration background: soft brand blobs drifting + a dot grid
        for i, (bx, by, br) in enumerate(((0.15, 0.2, 0.35), (0.9, 0.75, 0.42), (0.75, 0.1, 0.22))):
            dx = math.sin(t * 0.6 + i * 2) * 30 * u
            c.drawCircle(W * bx + dx, H * by - dx, min(W, H) * br, P(color(primary, 0.13)))
        dot = P(color(ink, 0.12))
        step = 54 * u
        drift = (t * 12 * u) % step
        y = -step + drift
        while y < H:
            x = -step + drift
            while x < W:
                c.drawCircle(x, y, 2.4 * u, dot)
                x += step
            y += step

        # camera: slow push-in with a little 3D tilt
        push = 1.0 + 0.05 * out_cubic(progress(t, 0, dur))
        c.translate(W / 2, H / 2)
        c.scale(push, push)
        c.translate(-W / 2, -H / 2)
        c.concat(perspective(W / 2, H / 2, math.radians(4 * math.sin(t * 0.7)), math.radians(2 * math.sin(t * 0.5))))

        # the speaker, framed
        if spk:
            kp = out_back(progress(t, 0.15, 0.5))
            if kp > 0:
                fi = min(len(spk) - 1, int(t * fps))
                c.save()
                cx, cy = pip.centerX(), pip.centerY()
                c.concat(perspective(cx, cy, math.radians(35 * (1 - kp))))
                c.translate(cx, cy)
                c.scale(0.6 + 0.4 * kp, 0.6 + 0.4 * kp)
                c.translate(-cx, -cy)
                frame = skia.RRect.MakeRectXY(pip.makeOutset(8 * u, 8 * u), 26 * u, 26 * u)
                c.drawRRect(frame.makeOffset(0, 14 * u) if hasattr(frame, "makeOffset") else frame,
                            P(skia.ColorSetARGB(90, 0, 0, 0), blur=22 * u))
                c.drawRRect(frame, P(skia.ColorWHITE))
                c.save()
                c.clipRRect(skia.RRect.MakeRectXY(pip, 20 * u, 20 * u), doAntiAlias=True)
                c.drawImageRect(spk[fi], pip, skia.SamplingOptions(skia.FilterMode.kLinear))
                c.restore()
                c.restore()

        # arrows between beats, drawing on as the next beat arrives
        for k in range(1, len(beats)):
            ka = out_cubic(progress(t, beats[k]["t"] - 0.35, 0.45))
            if ka <= 0:
                continue
            (x0, y0), (x1, y1) = pos[k - 1], pos[k]
            path = skia.Path()
            if abs(x1 - x0) > tile:  # side by side: edge to edge, arcing over
                d = 1 if x1 > x0 else -1
                sx, sy, ex, ey = x0 + d * tile * 0.62, y0, x1 - d * tile * 0.62, y1
                mx, my = (sx + ex) / 2, min(sy, ey) - tile * 0.35
            else:  # one above the other: round the outside edge, clear of the labels
                d = 1 if x0 >= W / 2 else -1
                sx, sy = x0 + d * tile * 0.6, y0 - tile * 0.1
                ex, ey = x1 + d * tile * 0.6, y1 + tile * 0.1
                mx, my = x0 + d * tile * 1.0, (sy + ey) / 2
            path.moveTo(sx, sy)
            path.quadTo(mx, my, ex, ey)
            meas = skia.PathMeasure(path, False)
            seg = skia.Path()
            meas.getSegment(0, meas.getLength() * ka, seg, True)
            pen = P(color(ink, 0.85), stroke=8 * u)
            pen.setPathEffect(skia.DashPathEffect.Make([18 * u, 14 * u], -t * 60 * u))
            c.drawPath(seg, pen)
            if ka > 0.98:  # arrow head
                ang = math.atan2(ey - my, ex - mx)
                head = skia.Path()
                for da in (2.6, -2.6):
                    head.moveTo(ex, ey)
                    head.lineTo(ex + 26 * u * math.cos(ang + da), ey + 26 * u * math.sin(ang + da))
                c.drawPath(head, P(color(ink, 0.85), stroke=8 * u))

        # beats: swing in in 3D on their word, float, then bow out together
        for k, b in enumerate(beats):
            ki = progress(t, b["t"] - 0.12, 0.55)
            if ki <= 0:
                continue
            kb = out_back(ki)
            ko = in_cubic(progress(t, dur - 0.55 + 0.04 * k, 0.3))
            s = max(0.0, kb * (1 - ko))
            if s <= 0.01:
                continue
            cx, cy = pos[k]
            cy += math.sin(t * 2.2 + k) * 7 * u  # idle float
            c.save()
            c.concat(perspective(cx, cy, math.radians(70 * (1 - out_expo(ki)) + 8 * math.sin(t * 1.3 + k)),
                                 math.radians(-10 * (1 - out_expo(ki)))))
            c.translate(cx, cy)
            c.scale(s, s)
            half = tile / 2
            rad = tile * 0.2
            depth = tile * 0.09
            # 3D slab: shadow, extruded side, face
            c.drawRRect(rrect(-half, -half + depth + 18 * u, tile, tile, rad), P(skia.ColorSetARGB(80, 0, 0, 0), blur=24 * u))
            if b["kind"] == "icon":
                c.drawRRect(rrect(-half, -half + depth, tile, tile, rad), P(color(shade(primary, 0.62))))
                face = rrect(-half, -half, tile, tile, rad)
                hl = skia.GradientShader.MakeLinear([skia.Point(0, -half), skia.Point(0, half)],
                                                    [color(shade(primary, 1.18)), color(primary)], [0.0, 1.0])
                c.drawRRect(face, skia.Paint(AntiAlias=True, Shader=hl))
                c.drawCircle(-half * 0.42, -half * 0.42, tile * 0.13, P(skia.ColorSetARGB(40, 255, 255, 255)))
                ic = b["img"]
                isz = ic.width()
                c.drawImage(ic, -isz / 2, -isz / 2 + 4 * u * math.sin(t * 3 + k),
                            skia.SamplingOptions(skia.FilterMode.kLinear))
            else:
                c.drawRRect(rrect(-half - 7 * u, -half - 7 * u + depth * 0.6, tile + 14 * u, tile + 14 * u, rad),
                            P(color(shade(primary, 0.62))))
                c.drawRRect(rrect(-half - 7 * u, -half - 7 * u, tile + 14 * u, tile + 14 * u, rad), P(skia.ColorWHITE))
                c.save()
                c.clipRRect(rrect(-half, -half, tile, tile, rad * 0.8), doAntiAlias=True)
                img = b.get("img")
                if b["kind"] == "video":
                    fr = b["frames"]
                    img = _sk(fr[min(len(fr) - 1, int(t * fps))])
                c.drawImageRect(img, skia.Rect.MakeXYWH(-half, -half, tile, tile),
                                skia.SamplingOptions(skia.FilterMode.kLinear))
                c.restore()
                if b["kind"] == "video":  # a small "playing" badge
                    c.drawCircle(half - 30 * u, -half + 30 * u, 20 * u, P(color(primary)))
                    tri = skia.Path()
                    tri.moveTo(half - 37 * u, -half + 19 * u)
                    tri.lineTo(half - 37 * u, -half + 41 * u)
                    tri.lineTo(half - 19 * u, -half + 30 * u)
                    tri.close()
                    c.drawPath(tri, P(skia.ColorWHITE))
            # label pill under the beat
            word = b["word"].upper()
            tw = label_font.measureText(word)
            ph = label_font.getSize() * 1.5
            py = half + depth + 22 * u
            c.drawRRect(rrect(-tw / 2 - 18 * u, py, tw + 36 * u, ph, ph / 2), P(color(ink)))
            c.drawString(word, -tw / 2, py + ph * 0.69, label_font, P(skia.ColorWHITE))
            c.restore()
        c.restore()
    return dur, draw


def render_moment(moment: dict, client: Client, size: tuple[int, int], fps: float, out: Path,
                  samples: int = 2, speaker: list[np.ndarray] | None = None) -> Path:
    from ..mograph.engine import render
    dur, draw = make_draw(moment, client, size, fps, speaker)
    return render(draw, size, fps, dur, out, samples=samples)


def speaker_box(size: tuple[int, int], n_beats: int) -> tuple[int, int]:
    """Pixel size of the speaker picture-in-picture for this frame size."""
    W, H = size
    _, _, pip = layout(n_beats, W, H, H > W)
    return int(pip.width()) // 2 * 2, int(pip.height()) // 2 * 2
