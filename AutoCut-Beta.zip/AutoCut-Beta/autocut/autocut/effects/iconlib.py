"""The Lucide icon library (2,100+ open-source icons, ISC licence — see icons/LICENSE),
turned into brand-coloured sticker badges on demand for pop-ups."""
from __future__ import annotations

import functools
import json
import re
from pathlib import Path

from ..broll import STOP, stem
from ..config import LOCAL_SETTINGS

ICON_DIR = Path(__file__).parent / "icons"
CACHE = LOCAL_SETTINGS.parent / "cache" / "icon-stickers"
# tags so broad they'd fire on nearly every sentence
GENERIC = set("""thing things good great time make look right left start stop line text type user people person
way part new old big small high low open close set get go up down back front add remove view show see move
turn change edit check case point place full empty more less one two three first last next previous day""".split())


# Hand-picked icons for words that come up constantly in business / creator videos.
CURATED = {
    "money": "banknote", "cash": "banknote", "dollar": "dollar-sign", "price": "tag", "cost": "tag", "sale": "tag",
    "save": "piggy-bank", "saving": "piggy-bank", "budget": "wallet", "pay": "credit-card", "card": "credit-card",
    "roof": "house", "home": "house", "house": "house", "property": "house", "building": "building-2",
    "storm": "cloud-lightning", "hail": "cloud-hail", "rain": "cloud-rain", "wind": "wind", "sun": "sun",
    "water": "droplet", "leak": "droplets", "fire": "flame", "hot": "flame", "cold": "snowflake",
    "inspection": "clipboard-check", "inspect": "search-check", "check": "circle-check", "checklist": "list-checks",
    "warranty": "shield-check", "guarantee": "shield-check", "safe": "shield", "safety": "shield", "insurance": "shield",
    "team": "users", "family": "users", "customer": "user-round", "client": "handshake", "deal": "handshake",
    "partner": "handshake", "contract": "file-signature", "sign": "pen-line", "kid": "baby", "baby": "baby",
    "call": "phone", "phone": "phone", "text": "message-square", "message": "message-circle", "email": "mail",
    "calendar": "calendar", "schedule": "calendar-clock", "appointment": "calendar-check", "today": "calendar",
    "time": "clock", "minute": "timer", "hour": "clock", "fast": "zap", "quick": "zap", "speed": "gauge",
    "location": "map-pin", "local": "map-pin", "city": "map-pin", "drive": "car", "car": "car", "truck": "truck",
    "review": "star", "rating": "star", "best": "trophy", "win": "trophy", "award": "award",
    "growth": "trending-up", "grow": "trending-up", "increase": "trending-up", "decrease": "trending-down",
    "result": "chart-column-increasing", "data": "chart-column", "idea": "lightbulb", "tip": "lightbulb",
    "secret": "key-round", "question": "circle-help", "warning": "triangle-alert", "danger": "triangle-alert",
    "mistake": "circle-x", "wrong": "circle-x", "love": "heart", "health": "heart-pulse", "doctor": "stethoscope",
    "food": "utensils", "coffee": "coffee", "music": "music", "podcast": "mic", "mic": "mic", "video": "video",
    "camera": "camera", "photo": "image", "game": "gamepad-2", "gaming": "gamepad-2", "stream": "radio",
    "computer": "laptop", "website": "globe", "online": "globe", "internet": "wifi", "app": "smartphone",
    "tool": "wrench", "repair": "wrench", "fix": "wrench", "build": "hammer", "hammer": "hammer", "paint": "paintbrush",
    "school": "graduation-cap", "learn": "book-open", "book": "book-open", "gift": "gift", "free": "gift",
    "goal": "target", "plan": "map", "rocket": "rocket", "launch": "rocket", "power": "zap", "energy": "battery-charging",
    "solar": "sun", "light": "lightbulb", "window": "app-window", "door": "door-open", "key": "key-round",
    "lock": "lock", "fitness": "dumbbell", "gym": "dumbbell", "run": "footprints", "dog": "dog", "cat": "cat",
}


@functools.lru_cache(maxsize=2)
def index(with_tags: bool = False) -> dict[str, str]:
    """word stem → icon name. Curated picks win, then an icon's own name, then its tags
    (among icons sharing a tag, the simplest name and earliest-listed tag wins)."""
    tags = json.loads((ICON_DIR / "tags.json").read_text())
    available = set(tags) | {p.stem for p in (ICON_DIR / "svg").glob("*.svg")}
    by_name: dict[str, str] = {}
    by_tag: dict[str, tuple] = {}
    for name in sorted(available):
        parts = [p for p in name.split("-") if not p.isdigit()]
        if len(parts) == 1 or (len(parts) == 2 and parts[1] in ("sign", "check", "plus")):
            word = parts[0]
            if len(word) >= 3 and word not in GENERIC and word not in STOP:
                by_name.setdefault(stem(word), name)
        for pos, t in enumerate(tags.get(name, [])):
            if " " in t or len(t) < 4 or t in GENERIC or t in STOP:
                continue
            rank = (pos, len(parts), len(name))  # lower is better
            key = stem(t)
            if key not in by_tag or rank < by_tag[key][0]:
                by_tag[key] = (rank, name)
    # Tag-only matches are too loose for a sticker that appears on screen ("estimate" → a scale),
    # so they're used only when explicitly asked for.
    out = {k: v[1] for k, v in by_tag.items()} if with_tags else {}
    out.update(by_name)
    out.update({stem(w): n for w, n in CURATED.items() if n in available})
    return out


def sticker(name: str, color_hex: str, size: int = 512) -> Path:
    """PNG badge: brand-colour disc, white ring, white icon. Cached per icon + colour."""
    import skia
    from ..config import hex_to_rgb
    CACHE.mkdir(parents=True, exist_ok=True)
    out = CACHE / f"{name}-{color_hex.strip('#').lower()}-{size}.png"
    if out.exists():
        return out
    svg = (ICON_DIR / "svg" / f"{name}.svg").read_text()
    svg = svg.replace("currentColor", "#ffffff")
    svg = re.sub(r'stroke-width="[\d.]+"', 'stroke-width="2.25"', svg)
    surface = skia.Surface.MakeRaster(skia.ImageInfo.Make(size, size, skia.kRGBA_8888_ColorType, skia.kPremul_AlphaType))
    c = surface.getCanvas()
    c.clear(skia.ColorTRANSPARENT)
    r, g, b = hex_to_rgb(color_hex)
    cx = cy = size / 2
    shadow = skia.Paint(AntiAlias=True, Color=skia.ColorSetARGB(110, 0, 0, 0))
    shadow.setMaskFilter(skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, size * 0.03))
    c.drawCircle(cx, cy + size * 0.025, size * 0.44, shadow)
    c.drawCircle(cx, cy, size * 0.44, skia.Paint(AntiAlias=True, Color=skia.ColorWHITE))
    c.drawCircle(cx, cy, size * 0.40, skia.Paint(AntiAlias=True, Color=skia.ColorSetARGB(255, r, g, b)))
    dom = skia.SVGDOM.MakeFromStream(skia.MemoryStream(svg.encode()))
    icon = size * 0.46
    dom.setContainerSize(skia.Size(24, 24))  # Lucide icons are drawn on a 24×24 grid
    c.save()
    c.translate(cx - icon / 2, cy - icon / 2)
    c.scale(icon / 24, icon / 24)
    dom.render(c)
    c.restore()
    surface.makeImageSnapshot().save(str(out), skia.kPNG)
    return out
