"""Subject cutout: separate the speaker from the background for a few seconds.

Two looks:
  hook  — big hook text sits BEHIND the speaker for the opening seconds
  pop   — on a key word the background swaps to a brand-colour panel with the
          word huge behind them, and the speaker "pops" in front

Layers on the timeline: footage (V1) → behind layer (text or panel) → cut-out
speaker (same framing as V1) → captions. Segmentation runs locally:
  vision  Apple Vision person segmentation (macOS, built in, fastest)
  onnx    U²-Net human segmentation via onnxruntime (any OS; model downloads once)
"""
from __future__ import annotations

import os
import subprocess
import urllib.request
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

from ..captions import ass_color
from ..config import LOCAL_SETTINGS, Client
from ..edit import norm
from ..media import MediaInfo
from .render import ass_header, clean, dialogue, render_ass_clip, style, write_rgba

MODEL_URL = "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2net_human_seg.onnx"
MODEL_DIR = Path(os.environ.get("AUTOCUT_MODELS", LOCAL_SETTINGS.parent / "models"))


# ---- segmentation engines ---------------------------------------------------
class OnnxSegmenter:
    name = "onnx"

    def __init__(self):
        import onnxruntime as ort
        model = MODEL_DIR / "u2net_human_seg.onnx"
        if not model.exists():
            MODEL_DIR.mkdir(parents=True, exist_ok=True)
            print("  downloading person-segmentation model (one time, 170 MB) …")
            tmp = model.with_suffix(".part")
            urllib.request.urlretrieve(MODEL_URL, tmp)
            tmp.replace(model)
        providers = [p for p in ("CoreMLExecutionProvider", "CPUExecutionProvider")
                     if p in ort.get_available_providers()]
        self.session = ort.InferenceSession(str(model), providers=providers)
        self.input = self.session.get_inputs()[0].name

    def __call__(self, rgb: np.ndarray) -> np.ndarray:
        h, w = rgb.shape[:2]
        x = np.asarray(Image.fromarray(rgb).resize((320, 320), Image.BILINEAR), np.float32) / 255.0
        x = ((x - (0.485, 0.456, 0.406)) / (0.229, 0.224, 0.225)).transpose(2, 0, 1)[None].astype(np.float32)
        m = self.session.run(None, {self.input: x})[0][0, 0]
        m = (m - m.min()) / (m.max() - m.min() + 1e-6)
        return np.asarray(Image.fromarray((m * 255).astype(np.uint8)).resize((w, h), Image.BILINEAR),
                          np.float32) / 255.0


class VisionSegmenter:
    """Apple Vision VNGeneratePersonSegmentationRequest (macOS 12+)."""
    name = "vision"

    def __init__(self):
        import Quartz
        import Vision
        self.Q, self.V = Quartz, Vision
        self.req = Vision.VNGeneratePersonSegmentationRequest.alloc().init()
        self.req.setQualityLevel_(Vision.VNGeneratePersonSegmentationRequestQualityLevelAccurate)
        self.req.setOutputPixelFormat_(1278226488)  # kCVPixelFormatType_OneComponent8

    def __call__(self, rgb: np.ndarray) -> np.ndarray:
        Q = self.Q
        h, w = rgb.shape[:2]
        data = np.ascontiguousarray(rgb).tobytes()
        provider = Q.CGDataProviderCreateWithData(None, data, len(data), None)
        img = Q.CGImageCreate(w, h, 8, 24, w * 3, Q.CGColorSpaceCreateDeviceRGB(), Q.kCGImageAlphaNone,
                              provider, None, False, Q.kCGRenderingIntentDefault)
        handler = self.V.VNImageRequestHandler.alloc().initWithCGImage_options_(img, None)
        ok, err = handler.performRequests_error_([self.req], None)
        if not ok or not self.req.results():
            raise RuntimeError(f"Vision segmentation failed: {err}")
        pb = self.req.results()[0].pixelBuffer()
        Q.CVPixelBufferLockBaseAddress(pb, 1)
        try:
            mw, mh = Q.CVPixelBufferGetWidth(pb), Q.CVPixelBufferGetHeight(pb)
            bpr = Q.CVPixelBufferGetBytesPerRow(pb)
            buf = Q.CVPixelBufferGetBaseAddress(pb).as_buffer(bpr * mh)
            mask = np.frombuffer(buf, np.uint8).reshape(mh, bpr)[:, :mw].copy()
        finally:
            Q.CVPixelBufferUnlockBaseAddress(pb, 1)
        return np.asarray(Image.fromarray(mask).resize((w, h), Image.BILINEAR), np.float32) / 255.0


_cache: dict[str, object] = {}


def get_segmenter(engine: str = "auto"):
    order = {"auto": ["vision", "onnx"], "vision": ["vision"], "onnx": ["onnx"]}[engine]
    errors = []
    for name in order:
        if name in _cache:
            return _cache[name]
        try:
            seg = VisionSegmenter() if name == "vision" else OnnxSegmenter()
            seg(np.zeros((64, 64, 3), np.uint8))  # smoke test
            _cache[name] = seg
            return seg
        except Exception as e:  # missing framework/package — try the next engine
            errors.append(f"{name}: {e}")
    raise RuntimeError("No person-segmentation engine available (" + "; ".join(errors) + ")")


# ---- rendering ----------------------------------------------------------------
def render_subject(info: MediaInfo, src_in: int, frames: int, fps: float, seg, out: Path) -> Path:
    """The speaker alone (alpha) for source frames [src_in, src_in+frames), at source size."""
    W, H = info.width, info.height
    dec = subprocess.Popen(["ffmpeg", "-loglevel", "error", "-ss", f"{src_in / fps:.4f}", "-i", str(info.path),
                            "-frames:v", str(frames), "-vf", f"scale={W}:{H}", "-f", "rawvideo",
                            "-pix_fmt", "rgb24", "-"], stdout=subprocess.PIPE)
    small = (max(1, W // 2), max(1, H // 2))

    def gen():
        prev = None
        for _ in range(frames):
            raw = dec.stdout.read(W * H * 3)
            if len(raw) < W * H * 3:
                break
            rgb = np.frombuffer(raw, np.uint8).reshape(H, W, 3)
            m = seg(np.asarray(Image.fromarray(rgb).resize(small, Image.BILINEAR)))
            m = np.clip((m - 0.25) / 0.5, 0, 1)                      # firm up soft edges
            prev = m if prev is None else 0.6 * m + 0.4 * prev      # calm frame-to-frame flicker
            alpha = Image.fromarray((prev * 255).astype(np.uint8)).resize((W, H), Image.BILINEAR)
            alpha = alpha.filter(ImageFilter.GaussianBlur(1.2))
            rgba = np.dstack([rgb, np.asarray(alpha)])
            yield rgba.tobytes()
        dec.stdout.close()
        dec.wait()

    return write_rgba(gen(), (W, H), fps, out)


def render_hook_text(client: Client, text: str, size: tuple[int, int], fps: float, dur: float, out: Path) -> Path:
    """Huge words slammed in behind the speaker's head."""
    b = client.brand
    W, H = size
    words = clean(text.upper()).split()
    lines = [" ".join(words[i:i + 2]) for i in range(0, len(words), 2)][:3]
    longest = max(len(l) for l in lines)
    fs = min(W / (longest * 0.62), H * 0.16)
    y0 = H * (0.30 if H > W else 0.36) - (len(lines) - 1) * fs * 0.5
    ev = ""
    for i, line in enumerate(lines):
        t0 = 80 * i
        anim = rf"\fscx140\fscy140\alpha&HFF&\t({t0},{t0 + 160},\fscx100\fscy100\alpha&H00&)"
        anim += rf"\t({int(dur * 1000) - 220},{int(dur * 1000)},\alpha&HFF&)"
        ev += dialogue(0, dur, "Hook", "{" + rf"\pos({W / 2:.0f},{y0 + i * fs * 0.98:.0f}){anim}" + "}" + line)
    ass = ass_header(size, [style("Hook", b["fonts"]["headline"], fs, b["colors"]["primary"],
                                  outline=max(2, fs * 0.03), outline_color=b["colors"]["outline"])]) + ev
    return render_ass_clip(client, ass, size, fps, dur, out)


def render_pop_panel(client: Client, word: str, size: tuple[int, int], fps: float, dur: float, out: Path) -> Path:
    """Opaque brand-colour background with the key word huge and faint behind the speaker."""
    b = client.brand
    W, H = size
    word = clean(word.strip(",.!?").upper())
    fs = min(W / (max(3, len(word)) * 0.6), H * 0.3)
    ms = int(dur * 1000)
    ass = ass_header(size, [style("Panel", b["fonts"]["headline"], fs, b["colors"]["text"])])
    ass += dialogue(0, dur, "Panel", "{" + rf"\pos({W / 2:.0f},{H * 0.36:.0f})\alpha&HB0&\fscx120\fscy120"
                    rf"\t(0,{ms},\fscx100\fscy100)" + "}" + word)
    ass_file = out.with_suffix(".ass")
    ass_file.write_text(ass)
    r, g, bl = (int(b["colors"]["primary"].lstrip("#")[i:i + 2], 16) for i in (0, 2, 4))
    from ..overlays import _filter_path, _fonts_dir
    vf = f"ass='{_filter_path(ass_file.name)}'"
    fonts = _fonts_dir(client)
    if fonts:
        vf += f":fontsdir='{_filter_path(fonts.resolve())}'"
    vf += ",vignette=PI/4"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i",
                    f"color=c=0x{r:02x}{g:02x}{bl:02x}:s={W}x{H}:r={fps:.3f}:d={dur:.3f}", "-vf", vf,
                    "-c:v", "prores_ks", "-profile:v", "3", "-pix_fmt", "yuv422p10le", "-vendor", "apl0",
                    out.name], cwd=out.parent, check=True, capture_output=True)
    return out


# ---- choosing moments -----------------------------------------------------------
def segment_at(plan, t: float, length: float):
    """The V1 segment that fully contains [t, t+length] on the timeline, if any."""
    a, b = round(t * plan.fps), round((t + length) * plan.fps)
    return next((s for s in plan.segments if s.rec_in <= a and b <= s.rec_out), None)


def auto_hook_text(words: list[dict], keywords: set[str]) -> str:
    early = [w for w in words if w["start"] < 8]
    for w in early:
        if norm(w["word"]) in keywords:
            return w["word"].strip(",.!?")
    content = [w["word"].strip(",.!?") for w in early if len(norm(w["word"])) > 3][:3]
    return " ".join(content)


def plan_moments(plan, client: Client, hook: str, occupied) -> list[dict]:
    cfg = client.brand["cutout"]
    moments = []
    if cfg["hook"] and plan.segments:
        first = plan.segments[0]
        length = min(cfg["hook_seconds"], (first.rec_out - first.rec_in) / plan.fps)
        keys = {norm(k) for k in client.brand["captions"]["highlight_words"]}
        text = hook or auto_hook_text(plan.words, keys)
        if length >= 1.2 and text:
            moments.append({"kind": "hook", "start": 0.0, "length": length, "text": text, "seg": first})
            occupied.take(0.0, length, "hook")
    keys = {norm(k) for k in client.brand["captions"]["highlight_words"]}
    last = -1e9
    for w in plan.words:
        if len([m for m in moments if m["kind"] == "pop"]) >= cfg["pops"]:
            break
        n = norm(w["word"])
        if not (n in keys or any(ch.isdigit() for ch in w["word"])):
            continue
        seg = segment_at(plan, w["start"], 0)
        if seg is None:
            continue
        # start just before the word, but never before this shot begins; shorten to fit the shot
        start = max(seg.rec_in / plan.fps, w["start"] - 0.15)
        length = min(float(cfg["pop_seconds"]), seg.rec_out / plan.fps - start)
        if length < 0.9 or start - last < 6 or not occupied.free(start, start + length):
            continue
        moments.append({"kind": "pop", "start": start, "length": length, "text": w["word"], "seg": seg})
        occupied.take(start, start + length, "pop")
        last = start
    return moments
