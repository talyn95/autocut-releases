"""Your media: screenshots, photos, logos, graphics and clips the team drags in.

Two sources:
  - the client's media library (Clients tab). Items show up when one of their
    keywords is said (untagged library items are never placed automatically)
  - media added for a specific upload (Queue tab). Placed on its keyword if it
    has one, otherwise spread evenly through the video

Two looks:
  full   fills the frame with a slow push-in (photos, video clips) — on the B-roll track
  float  framed card that pops in over the speaker (screenshots, graphics, logos)
"""
from __future__ import annotations

import json
import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageOps

from ..broll import stem
from ..config import Client
from ..edit import norm
from .render import write_rgba

try:  # iPhone photos
    import pillow_heif
    pillow_heif.register_heif_opener()
except ImportError:
    pass

IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".heic", ".heif", ".gif", ".bmp", ".tif", ".tiff"}
VIDEO_EXT = {".mp4", ".mov", ".m4v"}

# Library categories → folder in the client's assets/ and how they show on screen
CATEGORIES = {
    "screenshots": {"folder": "assets/screenshots", "style": "float", "label": "Screenshots"},
    "photos": {"folder": "assets/photos", "style": "full", "label": "Photos"},
    "graphics": {"folder": "assets/graphics", "style": "float", "label": "Graphics"},
    "logos": {"folder": "assets/logo", "style": "float", "label": "Logos"},
    "broll": {"folder": "assets/broll", "style": "full", "label": "B-roll clips"},
    "stickers": {"folder": "assets/stickers", "style": None, "label": "Stickers"},
    "overlays": {"folder": "assets/overlays", "style": None, "label": "Overlays"},
    "music": {"folder": "assets/music", "style": None, "label": "Music"},
    "fonts": {"folder": "assets/fonts", "style": None, "label": "Fonts"},
    "endcard": {"folder": "assets/endcard", "style": None, "label": "End card"},
}
ALLOWED = {
    "screenshots": IMAGE_EXT, "photos": IMAGE_EXT, "graphics": IMAGE_EXT | VIDEO_EXT, "logos": IMAGE_EXT | {".svg"},
    "broll": VIDEO_EXT | {".mxf"}, "stickers": {".png"}, "overlays": {".mov", ".png"},
    "music": {".mp3", ".wav", ".m4a", ".aac", ".aif", ".aiff"}, "fonts": {".ttf", ".otf"},
    "endcard": VIDEO_EXT | IMAGE_EXT,
}
PLACEABLE = ("screenshots", "photos", "graphics", "logos")  # categories AutoCut can put in a video


def tags_file(client: Client) -> Path:
    return client.folder / "assets" / "tags.json"


def load_tags(client: Client) -> dict[str, str]:
    p = tags_file(client)
    try:
        return json.loads(p.read_text()) if p.exists() else {}
    except json.JSONDecodeError:
        return {}


def save_tags(client: Client, tags: dict[str, str]) -> None:
    p = tags_file(client)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(tags, indent=2, sort_keys=True))
    tmp.replace(p)


def library(client: Client) -> list[dict]:
    """Everything in the client's asset folders, with category and tags."""
    tags = load_tags(client)
    main_logo = client.path(client.brand["logo"]["file"])
    items = []
    for cat, meta in CATEGORIES.items():
        folder = client.folder / meta["folder"]
        if not folder.is_dir():
            continue
        files = folder.rglob("*") if cat == "broll" else folder.iterdir()  # b-roll includes stock/ downloads
        for p in sorted(files):
            if any(part.startswith(".") for part in p.relative_to(folder).parts) or p.suffix.lower() not in ALLOWED[cat]:
                continue
            rel = p.relative_to(client.folder).as_posix()
            items.append({"rel": rel, "path": str(p), "name": p.name, "category": cat,
                          "kind": "video" if p.suffix.lower() in VIDEO_EXT else "image",
                          "tags": tags.get(rel, ""), "main_logo": bool(main_logo and p == main_logo)})
    return items


def _phrases(tags: str) -> list[list[str]]:
    return [[norm(w) for w in ph.split()] for ph in tags.split(",") if ph.strip()]


def _matches(words: list[dict], phrase: list[str]) -> list[float]:
    """Timeline seconds where a tag phrase is said (single words also match plurals etc.)."""
    hits = []
    normed = [norm(w["word"]) for w in words]
    for i in range(len(words) - len(phrase) + 1):
        if len(phrase) == 1:
            if normed[i] == phrase[0] or stem(normed[i]) == stem(phrase[0]):
                hits.append(words[i]["start"])
        elif normed[i:i + len(phrase)] == phrase:
            hits.append(words[i]["start"])
    return hits


def plan_media(words: list[dict], client: Client, job_assets: list[dict], total: float, occupied) -> list[dict]:
    """Placements on the timeline: {path, start, length, style, reason}. Job assets first, then library."""
    cfg = client.brand["media"]
    dur = float(cfg["seconds"])
    placed: list[dict] = []
    gap = 60.0 / max(1, cfg["max_per_minute"])

    def style_for(path: Path, category: str | None, chosen: str = "auto") -> str:
        if chosen in ("full", "float"):
            return chosen
        if path.suffix.lower() in VIDEO_EXT:
            return "full"
        if category in CATEGORIES and CATEGORIES[category]["style"]:
            return CATEGORIES[category]["style"]
        # dropped straight onto a video: camera photos fill the frame, PNG screenshots/graphics float
        return "full" if path.suffix.lower() in (".jpg", ".jpeg", ".heic", ".heif") else "float"

    def try_place(path: Path, style: str, times: list[float], reason: str, spacing: float) -> bool:
        for t in times:
            start = max(0.3, t - 0.1)
            length = min(dur, total - 0.3 - start)  # shorten near the end rather than skip
            if length < 1.5:
                continue
            near = any(abs(start - p["start"]) < spacing for p in placed)
            if not near and occupied.free(start, start + length, gap=0.15):
                placed.append({"path": path, "start": start, "length": length, "style": style, "reason": reason})
                occupied.take(start, start + length, "media")
                return True
        return False

    # 1. media added for this video
    free_items = []
    for a in job_assets:
        path = client.folder / a["file"]
        if not path.exists():
            print(f"  - media {a['file']} is missing, skipped")
            continue
        style = style_for(path, a.get("category"), a.get("style", "auto"))
        times = [t for ph in _phrases(a.get("keywords", "")) for t in _matches(words, ph)]
        if times:
            if not try_place(path, style, sorted(times), f"said: {a['keywords']}", 0):
                print(f"  - media {path.name}: no free moment near its keyword, skipped")
        else:
            free_items.append((path, style))
    # spread the rest evenly, snapped to the start of a word; shorten them if the video is busy
    if free_items:
        dur = max(1.5, min(dur, (total - 1.0) / (len(free_items) + len([p for p in placed]) + 0.5)))
    for i, (path, style) in enumerate(free_items):
        target = total * (i + 1) / (len(free_items) + 1)
        starts = sorted((w["start"] for w in words if w["start"] > 1.5), key=lambda s: abs(s - target))
        if not try_place(path, style, starts, "added for this video", 0):
            print(f"  - media {path.name}: no free moment, skipped")

    # 2. tagged library items, when their keyword is said
    dur = float(cfg["seconds"])
    for item in library(client):
        if item["category"] not in PLACEABLE or item["main_logo"] or not item["tags"]:
            continue
        times = sorted(t for ph in _phrases(item["tags"]) for t in _matches(words, ph))
        if times:
            try_place(Path(item["path"]), style_for(Path(item["path"]), item["category"]), times,
                      f"library, said: {item['tags']}", gap)  # library items are rationed; this video's media isn't
    return sorted(placed, key=lambda p: p["start"])


# ---- rendering -----------------------------------------------------------------
def _open(path: Path) -> Image.Image:
    img = Image.open(path)
    img = ImageOps.exif_transpose(img)  # phone photos store rotation in EXIF
    return img.convert("RGBA")


def render_full(path: Path, size: tuple[int, int], fps: float, dur: float, out: Path) -> Path:
    """Photo fills the frame with a slow push-in (Ken Burns)."""
    W, H = size
    img = _open(path)
    bg = Image.new("RGBA", img.size, (0, 0, 0, 255))
    bg.alpha_composite(img)
    img = bg.convert("RGB")
    base = max(W / img.width, H / img.height)
    big = img.resize((math.ceil(img.width * base * 1.1), math.ceil(img.height * base * 1.1)), Image.LANCZOS)
    n = max(1, round(dur * fps))

    def frames():
        # `big` is the frame-filling image at 110 %; zoom 1.00 → 1.08 pushes in slowly.
        for i in range(n):
            zoom = 1.0 + 0.08 * (i / max(1, n - 1))
            cw, ch = min(big.width, W * 1.1 / zoom), min(big.height, H * 1.1 / zoom)
            x0, y0 = (big.width - cw) / 2, (big.height - ch) / 2
            frame = big.resize((W, H), Image.BILINEAR, box=(x0, y0, x0 + cw, y0 + ch)).convert("RGBA")
            yield frame.tobytes()

    return write_rgba(frames(), size, fps, out, opaque=True)


def _framed(img: Image.Image, max_w: int, max_h: int, unit: float, plain: bool) -> Image.Image:
    """Image in a rounded white frame with a soft shadow (logos/graphics with transparency: no frame)."""
    img = img.copy()
    img.thumbnail((max_w, max_h), Image.LANCZOS)
    has_alpha = img.getextrema()[3][0] < 250
    pad, radius, sh = (0 if plain or has_alpha else int(12 * unit)), int(28 * unit), int(30 * unit)
    w, h = img.width + pad * 2, img.height + pad * 2
    card = Image.new("RGBA", (w + sh * 2, h + sh * 2), (0, 0, 0, 0))
    if not (plain or has_alpha):
        shadow = Image.new("RGBA", card.size, (0, 0, 0, 0))
        ImageDraw.Draw(shadow).rounded_rectangle([sh, sh + sh // 3, sh + w, sh + h + sh // 3], radius, fill=(0, 0, 0, 120))
        card.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(sh / 2.5)))
        ImageDraw.Draw(card).rounded_rectangle([sh, sh, sh + w, sh + h], radius, fill=(255, 255, 255, 255))
        mask = Image.new("L", img.size, 0)
        ImageDraw.Draw(mask).rounded_rectangle([0, 0, img.width, img.height], max(1, radius - pad), fill=255)
        img.putalpha(Image.composite(img.getchannel("A"), mask, mask))
    card.alpha_composite(img, (sh + pad, sh + pad))
    return card


def render_float(path: Path, category: str | None, size: tuple[int, int], fps: float, dur: float, out: Path) -> Path:
    """Framed card that pops in over the speaker, floats gently, then pops out."""
    W, H = size
    unit = min(W, H) / 1080
    logo = category == "logos"
    max_w, max_h = (int(W * 0.5), int(H * 0.22)) if logo else (int(W * 0.82), int(H * (0.42 if H > W else 0.62)))
    card = _framed(_open(path), max_w, max_h, unit, plain=logo)
    cx, cy = W / 2, H * (0.40 if H > W else 0.45)
    n = max(1, round(dur * fps))

    def k_at(t: float) -> float:
        if t < 0.18:
            return 0.8 + 0.26 * (t / 0.18)
        if t < 0.3:
            return 1.06 - 0.06 * ((t - 0.18) / 0.12)
        if t > dur - 0.18:
            return max(0.0, (dur - t) / 0.18)
        return 1.0

    def frames():
        for i in range(n):
            t = i / fps
            k = k_at(t)
            canvas = Image.new("RGBA", (W, H), (0, 0, 0, 0))
            if k > 0.02:
                c = card.resize((max(1, int(card.width * k)), max(1, int(card.height * k))), Image.BILINEAR)
                if t < 0.12:
                    c.putalpha(c.getchannel("A").point(lambda a, f=t / 0.12: int(a * f)))
                y = cy + 6 * unit * math.sin(t * 2.4)
                canvas.alpha_composite(c, (int(cx - c.width / 2), int(y - c.height / 2)))
            yield canvas.tobytes()

    return write_rgba(frames(), size, fps, out)
