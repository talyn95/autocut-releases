"""Graphic cards (numbers, prices, key phrases) and the lower third, drawn as
animated ASS vector shapes in the brand colours and rendered to alpha clips."""
from __future__ import annotations

import re
from pathlib import Path

from ..captions import ass_color
from ..config import Client
from ..edit import norm
from .render import ass_header, clean, dialogue, render_ass_clip, style

UNITS = {"minute", "minutes", "hour", "hours", "day", "days", "week", "weeks", "month", "months", "year",
         "years", "percent", "%", "star", "stars", "dollars", "bucks", "homes", "roofs", "customers",
         "clients", "families", "jobs", "projects", "reviews", "times", "x", "people", "miles", "points"}


def _fmt_number(w: str) -> str:
    raw = re.sub(r"[^\d.$%]", "", w)
    digits = raw.strip("$%")
    try:
        n = float(digits)
        txt = f"{int(n):,}" if n == int(n) else f"{n:,.1f}"
    except ValueError:
        txt = digits
    return ("$" if "$" in raw else "") + txt + ("%" if raw.endswith("%") else "")


def find_cards(words: list[dict], brand: dict) -> list[dict]:
    """Card moments on the output timeline: {start, value, label}."""
    cfg = brand["cards"]
    found = []
    if cfg["numbers"]:
        for i, w in enumerate(words):
            if not re.search(r"\d", w["word"]):
                continue
            value, label = _fmt_number(w["word"]), ""
            nxt = norm(words[i + 1]["word"]) if i + 1 < len(words) else ""
            if nxt in UNITS:
                if nxt in ("dollars", "bucks"):
                    value = value if value.startswith("$") else "$" + value
                elif nxt in ("percent", "%"):
                    value += "%"
                else:
                    label = nxt.upper()
            if value.strip("$%"):
                found.append({"start": w["start"], "value": value, "label": label})
    phrases = [[norm(p) for p in ph.split()] for ph in cfg["phrases"]]
    normed = [norm(w["word"]) for w in words]
    for ph, text in zip(phrases, cfg["phrases"]):
        for i in range(len(words) - len(ph) + 1):
            if normed[i:i + len(ph)] == ph:
                found.append({"start": words[i]["start"], "value": text.upper(), "label": ""})
                break
    return sorted(found, key=lambda c: c["start"])


def _box(x: float, y: float, w: float, h: float) -> str:
    return f"m {x:.0f} {y:.0f} l {x + w:.0f} {y:.0f} {x + w:.0f} {y + h:.0f} {x:.0f} {y + h:.0f}"


def render_card(client: Client, card: dict, size: tuple[int, int], fps: float, out: Path) -> Path:
    b = client.brand
    W, H = size
    dur = float(b["cards"]["seconds"])
    unit = min(W, H) / 1080
    value, label = clean(card["value"]), clean(card["label"])
    # long phrases shrink to fit the frame instead of running off the edges
    big = min(150 * unit, (W * 0.86 - 120 * unit) / (max(1, len(value)) * 0.62))
    small = min(54 * unit, (W * 0.86 - 120 * unit) / (max(1, len(label)) * 0.62))
    text_w = max(len(value) * big * 0.62, len(label) * small * 0.62)
    bw = min(W * 0.86, text_w + 120 * unit)
    bh = big * 1.15 + (small * 1.3 if label else 0) + 50 * unit
    cx = W / 2
    # talking heads keep the face around 25–45% height, so cards sit above or below it
    top = b["cards"]["position"] == "top"
    cy = H * ((0.11 if top else 0.60) if H > W else (0.16 if top else 0.62))
    x0, y0 = cx - bw / 2, cy - bh / 2
    font = b["fonts"]["headline"]
    ms = int(dur * 1000)
    pop = r"\fscx0\t(0,170,\fscx106)\t(170,240,\fscx100)" + rf"\t({ms - 180},{ms},\fscx0)"
    shadow_c, box_c = ass_color(b["colors"]["outline"]), ass_color(b["colors"]["primary"])
    ev = dialogue(0, dur, "Box", "{" + rf"\an7\pos(0,0)\org({cx:.0f},{cy:.0f})\p1\bord0\shad0\c{shadow_c}\alpha&H70&" + pop
                  + "}" + _box(x0 + 14 * unit, y0 + 16 * unit, bw, bh), 0)
    ev += dialogue(0, dur, "Box", "{" + rf"\an7\pos(0,0)\org({cx:.0f},{cy:.0f})\p1\bord0\shad0\c{box_c}" + pop
                   + "}" + _box(x0, y0, bw, bh), 1)
    accent = ass_color(b["colors"]["secondary"])
    ev += dialogue(0, dur, "Box", "{" + rf"\an7\pos(0,0)\org({cx:.0f},{cy:.0f})\p1\bord0\shad0\c{accent}" + pop
                   + "}" + _box(x0, y0 + bh - 14 * unit, bw, 14 * unit), 2)
    fade = r"\alpha&HFF&\t(140,230,\alpha&H00&)" + rf"\t({ms - 200},{ms - 60},\alpha&HFF&)"
    vy = cy - (small * 0.6 if label else 0)
    ev += dialogue(0, dur, "Big", "{" + rf"\pos({cx:.0f},{vy:.0f})\fscx70\fscy70\t(140,280,\fscx100\fscy100)" + fade
                   + "}" + value, 3)
    if label:
        ev += dialogue(0, dur, "Small", "{" + rf"\pos({cx:.0f},{vy + big * 0.62 + small * 0.55:.0f})" + fade
                       + "}" + label, 3)
    ass = ass_header(size, [style("Box", font, 20, b["colors"]["primary"]),
                            style("Big", font, big, b["colors"]["text"]),
                            style("Small", b["fonts"]["caption"], small, b["colors"]["text"])]) + ev
    return render_ass_clip(client, ass, size, fps, dur, out)


def render_lower_third(client: Client, size: tuple[int, int], fps: float, out: Path) -> Path | None:
    cfg = client.brand["lower_third"]
    if not cfg["name"]:
        return None
    b = client.brand
    W, H = size
    dur = float(cfg["seconds"])
    ms = int(dur * 1000)
    unit = min(W, H) / 1080
    name_s, title_s = 64 * unit, 40 * unit
    # sit clear of the captions: above them when captions are low, low when they aren't
    low_caps = b["captions"]["position"] == "lower"
    x, y = W * 0.07, H * ((0.56 if low_caps else 0.74) if H > W else (0.62 if low_caps else 0.80))
    bar_w = max(len(cfg["name"]) * name_s * 0.6, len(cfg["title"]) * title_s * 0.58) + 70 * unit
    bar_h = name_s * 1.3 + (title_s * 1.4 if cfg["title"] else 0) + 20 * unit
    slide = rf"\move({-bar_w - x:.0f},0,0,0,0,260)"
    out_anim = rf"\t({ms - 260},{ms},\alpha&HFF&)"
    ev = dialogue(0, dur, "Box", "{" + rf"\an7{slide}\p1\bord0\shad0\c{ass_color(b['colors']['primary'])}{out_anim}"
                  + "}" + _box(x, y, 16 * unit, bar_h), 1)
    ev += dialogue(0, dur, "Box", "{" + rf"\an7{slide}\p1\bord0\shad0\c{ass_color(b['colors']['secondary'])}\alpha&H20&{out_anim}"
                   + "}" + _box(x + 16 * unit, y, bar_w, bar_h), 0)
    txt_in = r"\alpha&HFF&\t(200,320,\alpha&H00&)" + out_anim
    ev += dialogue(0, dur, "Name", "{" + rf"\an4\pos({x + 46 * unit:.0f},{y + name_s * 0.75 + 10 * unit:.0f}){txt_in}"
                   + "}" + clean(cfg["name"]), 2)
    if cfg["title"]:
        ev += dialogue(0, dur, "Title", "{" + rf"\an4\pos({x + 46 * unit:.0f},{y + name_s * 1.3 + title_s * 0.75 + 10 * unit:.0f}){txt_in}"
                       + "}" + clean(cfg["title"]), 2)
    ass = ass_header(size, [style("Box", b["fonts"]["headline"], 20, b["colors"]["primary"]),
                            style("Name", b["fonts"]["headline"], name_s, b["colors"]["text"]),
                            style("Title", b["fonts"]["caption"], title_s, b["colors"]["primary"], bold=False)]) + ev
    return render_ass_clip(client, ass, size, fps, dur, out)
