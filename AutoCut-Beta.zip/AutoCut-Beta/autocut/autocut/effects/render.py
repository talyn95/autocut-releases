"""Shared helpers for effect renders: RGBA frame piping and ASS→alpha clips."""
from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Iterable

from ..captions import ass_color, ts_ass
from ..config import Client
from ..overlays import render_ass


def write_rgba(frames: Iterable[bytes], size: tuple[int, int], fps: float, out: Path,
               opaque: bool = False, premultiplied: bool = False) -> Path:
    """Encode raw RGBA frames (bytes, W*H*4 each) to ProRes (4444 with alpha unless opaque).
    premultiplied=True: frames come straight from a GPU-style renderer; ffmpeg converts them."""
    W, H = size
    codec = (["-c:v", "prores_ks", "-profile:v", "3", "-pix_fmt", "yuv422p10le"] if opaque else
             ["-c:v", "prores_ks", "-profile:v", "4444", "-pix_fmt", "yuva444p10le"])
    p = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgba",
                          "-s", f"{W}x{H}", "-r", f"{fps:.3f}", "-i", "-",
                          *(["-vf", "unpremultiply=inplace=1"] if premultiplied else []), *codec, "-vendor", "apl0",
                          str(out)], stdin=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        for f in frames:
            p.stdin.write(f)
        p.stdin.close()
    except BrokenPipeError:
        pass
    err = p.stderr.read().decode()
    if p.wait() != 0:
        raise RuntimeError(f"ffmpeg encode failed: {err[-1200:]}")
    return out


def ass_header(size: tuple[int, int], styles: list[str]) -> str:
    W, H = size
    return (f"[Script Info]\nScriptType: v4.00+\nPlayResX: {W}\nPlayResY: {H}\nWrapStyle: 2\n"
            "ScaledBorderAndShadow: yes\n\n[V4+ Styles]\n"
            "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, "
            "Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, "
            "Alignment, MarginL, MarginR, MarginV, Encoding\n" + "\n".join(styles) +
            "\n\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n")


def style(name: str, font: str, size: float, color: str, bold: bool = True, outline: float = 0,
          outline_color: str = "#000000", shadow: float = 0) -> str:
    c = ass_color(color)
    return (f"Style: {name},{font},{size:.0f},{c},{c},{ass_color(outline_color)},{ass_color(outline_color, 0x80)},"
            f"{-1 if bold else 0},0,0,0,100,100,0,0,1,{outline},{shadow},5,0,0,0,1")


def dialogue(start: float, end: float, style_name: str, text: str, layer: int = 0) -> str:
    return f"Dialogue: {layer},{ts_ass(start)},{ts_ass(end)},{style_name},,0,0,0,,{text}\n"


def render_ass_clip(client: Client, ass_text: str, size: tuple[int, int], fps: float,
                    duration: float, out: Path) -> Path:
    ass = out.with_suffix(".ass")
    ass.write_text(ass_text)
    return render_ass(ass, client, size, fps, duration, out)


def clean(text: str) -> str:
    return text.replace("{", "(").replace("}", ")").replace("\\", "/")
