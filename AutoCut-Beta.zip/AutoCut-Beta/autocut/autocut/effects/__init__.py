"""Creative effects, each with an on/off switch.

Switches live in brand.yaml under `effects:` (the client's defaults) and can be
overridden per upload or re-run from the dashboard.
"""
from __future__ import annotations

EFFECTS = [
    # key, label, what it does
    ("captions", "Kinetic captions", "Brand-styled animated captions"),
    ("media", "Your media", "Screenshots, photos, logos and graphics you added, shown when their keywords are said"),
    ("broll", "B-roll cutaways", "Cutaways from the client's library, matched to what's said"),
    ("motion_graphics", "Motion graphics", "AutoCut Motion: animated hook title, keyword slams, swipe transitions, CTA outro (+ Motion Studio pieces)"),
    ("punch_ins", "Punch-in zooms", "Tight/wide reframing at cuts to hide jump cuts"),
    ("graphic_cards", "Graphic cards", "Branded cards for numbers, prices and key phrases"),
    ("lower_third", "Lower third", "Speaker name and title near the start"),
    ("story", "Story cutaways", "Animated storyboards that tell what's being said: 3D icon tiles, your images and picture-in-picture videos, with the speaker framed in the corner"),
    ("popups", "Pop-up stickers", "Icons that pop in on matching words"),
    ("overlays", "Texture overlays", "Vignette, film grain and light leaks on cuts"),
    ("subject_cutout", "Subject cutout", "Hook text behind the speaker; speaker pops out over brand colour"),
    ("studio_sound", "Studio Sound", "Cleans up the voice: less background noise and hum, softer harsh S sounds, more presence, an even level"),
    ("sound_design", "Sound design", "Whooshes, pops, risers and impacts on transitions, graphics and stickers, in the client's sound, on their own audio track (A2)"),
    ("music", "Music bed", "Music under the dialogue on its own track (A3): the client's own track, or original music AutoCut composes in the client's sound"),
    ("cover", "Cover image", "A thumbnail: the speaker over brand colour with the hook text"),
    ("credit", "Agency credit", "Small \"Made by Triumphant Media\" in the bottom-right corner of the video"),
]
KEYS = [k for k, _, _ in EFFECTS]


def resolve(brand: dict, overrides: dict | None = None) -> dict[str, bool]:
    """Which effects run for this video: client defaults, then per-video overrides."""
    on = {k: bool(brand["effects"].get(k, False)) for k in KEYS}
    for k, v in (overrides or {}).items():
        if k in on and v is not None:
            on[k] = bool(v)
    # Older brand files switch some layers off in their own sections.
    on["captions"] &= bool(brand["captions"].get("enabled", True))
    on["broll"] &= bool(brand["broll"].get("enabled", True))
    return on


class Occupancy:
    """Timeline moments already used by a big visual, so effects don't pile up."""

    def __init__(self):
        self.spans: list[tuple[float, float, str]] = []

    def free(self, start: float, end: float, gap: float = 0.3) -> bool:
        return all(end + gap <= s or start >= e + gap for s, e, _ in self.spans)

    def take(self, start: float, end: float, what: str) -> None:
        self.spans.append((start, end, what))

    def blocked(self) -> list[tuple[float, float]]:
        return [(s, e) for s, e, _ in self.spans]
