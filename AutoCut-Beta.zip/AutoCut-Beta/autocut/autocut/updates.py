"""Signed one-click updates: check the agency's feed, install, restart, roll back.

The feed is a folder of files on any HTTPS host (GitHub releases, a website, S3) or a shared office folder:

  feed.json        what's current per channel, the content packs on offer, the installers (tools/release.py writes it)
  feed.json.sig    an Ed25519 signature of feed.json, made with the agency's private release key
  AutoCut-update-<version>.zip, <pack>-<version>.zip   the files the feed points at (relative to the feed)

AutoCut trusts nothing it downloads until the signature checks out against `release_key.pub` (shipped inside the
app, one hex key per line, so a key can be rotated by an update signed with the old one); the feed then pins each
download by SHA-256. An update is never older than what's installed, so an old signed feed can't roll anyone back.

Installing a version:
  1. download + verify, unpack into <AutoCut folder>/.autocut-updates/staging
  2. install new Python packages if requirements.txt changed
  3. run the new version's own self-test (`autocut selftest`) before touching anything
  4. move the current code into .autocut-updates/versions/<version> (the roll-back copy) and the new code in
  5. restart (the dashboard asks); one-time steps run on start (migrations.py) and What's new shows the changelog

Everything the agency owns stays where it is: clients, footage, settings, packs and the models live outside the
AutoCut folder, and .venv / .git inside it are never touched. A git checkout with a remote still updates with
`git pull` (mac/update.sh, windows/update.ps1) when no feed is set.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

from . import __version__, ed25519
from .config import ROOT
from .content import version_tuple

KEY_FILE = Path(__file__).parent / "release_key.pub"
WORK = ROOT / ".autocut-updates"          # same disk as the code, so the swap is a rename
MANIFEST = ROOT / ".autocut-manifest.json"  # the top-level files and folders the installed version shipped
KEEP = {".venv", "venv", ".git", ".autocut-updates", ".autocut-manifest.json", "__pycache__", ".DS_Store"}
_lock = threading.Lock()
_progress: dict = {"state": "idle"}


# ---- settings + keys ---------------------------------------------------------------------------------

def extract(z: zipfile.ZipFile, dest: Path) -> None:
    """extractall, keeping the Unix permissions stored in the zip (zipfile drops them), so double-click launchers
    like "Install AutoCut.command" stay executable."""
    z.extractall(dest)
    for info in z.infolist():
        mode = (info.external_attr >> 16) & 0o777
        if mode and not info.is_dir():
            try:
                os.chmod(Path(dest) / info.filename, mode)
            except OSError:
                pass

def cfg(settings: dict) -> dict:
    u = dict(settings.get("updates") or {})
    u.setdefault("feed_url", "")
    u.setdefault("mirrors", [])  # copies of the feed (e.g. the office Synology); tried in order after feed_url
    u.setdefault("channel", "stable")
    u.setdefault("check", True)
    u.setdefault("keep_versions", 3)
    if os.environ.get("AUTOCUT_UPDATE_FEED"):
        u["feed_url"] = os.environ["AUTOCUT_UPDATE_FEED"]
    return u


def keys() -> list[bytes]:
    try:
        lines = KEY_FILE.read_text().split()
    except OSError:
        return []
    return [bytes.fromhex(x) for x in lines if re.fullmatch(r"[0-9a-fA-F]{64}", x)]


def sources(settings: dict) -> list[str]:
    """Where to look for the feed, in order: the main address, then any mirrors. Every copy is checked against the
    same signature, so a mirror (a NAS, a USB stick, a second host) can never slip anything in."""
    c = cfg(settings)
    mirrors = c["mirrors"] if isinstance(c["mirrors"], list) else [c["mirrors"]]
    out = []
    for u in [c["feed_url"], *mirrors]:
        u = str(u or "").strip()
        if u and u not in out:
            out.append(u)
    return out


def mode(settings: dict) -> str:
    """feed | git | manual: how this computer gets new versions."""
    if sources(settings) and keys():
        return "feed"
    if (ROOT / ".git").exists():
        r = subprocess.run(["git", "remote"], cwd=ROOT, capture_output=True, text=True)
        if r.returncode == 0 and r.stdout.strip():
            return "git"
    return "manual"


# ---- fetching -------------------------------------------------------------------------------------
def _resolve(base: str, ref: str) -> str:
    if re.match(r"^[a-z]+://", ref) or Path(ref).is_absolute():
        return ref
    if re.match(r"^[a-z]+://", base):
        return urllib.parse.urljoin(base, ref)
    return str(Path(base).parent / ref)


def _fetch(url: str, dest: Path | None = None, timeout: float = 30) -> bytes | Path:
    """https://, http:// (fine for an office NAS: what's downloaded is checked against the signature, not trusted
    for where it came from), file://, or a plain path to a shared folder."""
    if re.match(r"^(https?|file)://", url):
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": f"AutoCut/{__version__}"}),
                                    timeout=timeout) as r:
            if dest is None:
                return r.read(20 * 2**20)
            dest.parent.mkdir(parents=True, exist_ok=True)
            with open(dest, "wb") as f:
                shutil.copyfileobj(r, f, 2**20)
            return dest
    src = Path(url).expanduser()
    if dest is None:
        return src.read_bytes()
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dest)
    return dest


def _read_one(url: str, ks: list[bytes]) -> dict:
    try:
        body = _fetch(url)
        sig = _fetch(url + ".sig").strip()
    except (OSError, ValueError) as e:
        raise ValueError(f"couldn't reach it ({e})") from e
    try:
        sig = bytes.fromhex(sig.decode())
    except ValueError:
        raise ValueError("its signature file is damaged")
    if not any(ed25519.verify(k, body, sig) for k in ks):
        raise ValueError("it isn't signed by Triumphant Media's release key; ignoring it")
    feed = json.loads(body)
    if feed.get("app") != "autocut":
        raise ValueError("that isn't an AutoCut feed")
    feed["_source"] = url
    return feed


def read_feed(settings: dict) -> dict:
    """The first copy of the feed that can be reached and whose signature checks out. ValueError with plain reasons."""
    urls = sources(settings)
    if not urls:
        raise ValueError("no update feed is set (This Mac → Updates)")
    ks = keys()
    if not ks:
        raise ValueError("this version of AutoCut has no release key, so it can't check signed updates")
    why = []
    for url in urls:
        try:
            return _read_one(url, ks)
        except ValueError as e:
            why.append(f"{url}: {e}" if len(urls) > 1 else str(e))
    raise ValueError("the update feed " + ("; ".join(why) if len(urls) > 1 else why[0]))


def _download(settings: dict, feed: dict, entry: dict, dest: Path, timeout: float) -> Path:
    """A file the feed lists, from the copy that answered first, else from the mirrors; checked against its SHA-256."""
    order = [feed.get("_source")] + [u for u in sources(settings) if u != feed.get("_source")]
    why = []
    for base in [u for u in order if u]:
        try:
            got = _fetch(_resolve(base, entry["url"]), dest, timeout=timeout)
        except (OSError, ValueError) as e:
            why.append(str(e))
            continue
        if _sha(Path(got)) == str(entry.get("sha256", "")).lower():
            return Path(got)
        why.append(f"{base}: the file doesn't match the signed feed")
    raise ValueError("download failed (" + "; ".join(why) + ")")


def check(settings: dict, force: bool = False) -> dict:
    """What's on offer: {mode, current, latest, available, notes, packs, error}. Cached for an hour."""
    c = cfg(settings)
    out = {"mode": mode(settings), "current": __version__, "channel": c["channel"], "feed_url": c["feed_url"],
           "sources": sources(settings),
           "keys": len(keys()), "available": False, "latest": None, "packs": [], "error": "",
           "versions": rollback_versions()}
    if out["mode"] != "feed":
        if sources(settings) and not keys():
            out["error"] = "this version has no release key yet; install the next AutoCut zip once to turn on updates"
        return out
    cache = WORK / "check.json"
    if not force and cache.exists() and time.time() - cache.stat().st_mtime < 3600:
        try:
            cached = json.loads(cache.read_text())
            if cached.get("current") == __version__ and cached.get("sources") == sources(settings) \
                    and cached.get("channel") == c["channel"]:
                return {**cached, "versions": rollback_versions()}
        except ValueError:
            pass
    try:
        feed = read_feed(settings)
    except ValueError as e:
        return {**out, "error": str(e)}
    rel = (feed.get("channels") or {}).get(c["channel"]) or (feed.get("channels") or {}).get("stable") or {}
    if rel.get("version"):
        out["latest"] = rel["version"]
        out["notes"] = rel.get("notes") or []
        out["date"] = rel.get("date", "")
        out["installed"] = installed_version()
        out["restart_needed"] = out["installed"] != __version__
        out["available"] = version_tuple(rel["version"]) > version_tuple(out["installed"])
        if rel.get("min_version") and version_tuple(__version__) < version_tuple(rel["min_version"]):
            out["available"] = False
            out["error"] = (f"{rel['version']} can't update from {__version__} directly; install the new AutoCut "
                            "zip once (your clients and settings are kept)")
    from . import content
    have = {p["id"]: p.get("version") for p in content.packs()}
    for p in feed.get("packs") or []:
        if not isinstance(p, dict) or not p.get("id"):
            continue
        p = dict(p, installed=have.get(p["id"]))
        p["too_new"] = bool(p.get("min_app")) and version_tuple(p["min_app"]) > version_tuple(__version__)
        p["update"] = bool(p["installed"]) and version_tuple(p.get("version", "0")) > version_tuple(p["installed"])
        out["packs"].append(p)
    out["installers"] = feed.get("installers") or {}
    out["checked_at"] = time.strftime("%Y-%m-%d %H:%M")
    WORK.mkdir(exist_ok=True)
    cache.write_text(json.dumps(out))
    return out


# ---- installing ------------------------------------------------------------------------------------
def progress() -> dict:
    return dict(_progress)


def _step(state: str, msg: str, log) -> None:
    _progress.update(state=state, message=msg, at=time.time())
    log(msg)


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(2**20), b""):
            h.update(chunk)
    return h.hexdigest()


def _code_root(folder: Path) -> Path:
    found = sorted(folder.rglob("autocut/__init__.py"), key=lambda f: len(f.parts))
    if not found:
        raise ValueError("that package doesn't contain AutoCut")
    return found[0].parent.parent


def code_version(root: Path) -> str:
    m = re.search(r'__version__\s*=\s*"([^"]+)"', (root / "autocut" / "__init__.py").read_text())
    return m.group(1) if m else "0"


def installed_version() -> str:
    """The version on disk (newer than the running one after an install, until AutoCut restarts)."""
    try:
        return code_version(ROOT)
    except OSError:
        return __version__


def selftest(root: Path, timeout: float = 300) -> tuple[bool, str]:
    """Run a version's own self-test with this computer's Python and packages, before it's switched on."""
    env = dict(os.environ, PYTHONPATH=str(root), AUTOCUT_SELFTEST="1", PYTHONDONTWRITEBYTECODE="1")
    r = subprocess.run([sys.executable, "-X", "utf8", "-m", "autocut", "selftest"], cwd=root, env=env,
                       capture_output=True, text=True, timeout=timeout)
    return r.returncode == 0, (r.stdout + r.stderr)[-4000:]


def _pip(root: Path, log) -> None:
    new = root / "requirements.txt"
    old = ROOT / "requirements.txt"
    if new.exists() and (not old.exists() or new.read_bytes() != old.read_bytes()):
        _step("packages", "Installing the new version's Python packages…", log)
        r = subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-r", str(new)], capture_output=True,
                           text=True, timeout=1800)
        if r.returncode:
            raise RuntimeError("couldn't install the new Python packages:\n" + (r.stdout + r.stderr)[-1500:])


def _names(root: Path) -> list[str]:
    return sorted(x.name for x in root.iterdir() if x.name not in KEEP)


def _move(src: Path, dst: Path) -> None:
    try:
        os.replace(src, dst)
    except OSError:  # Windows can refuse to rename a folder something has open: copy instead
        if src.is_dir():
            shutil.copytree(src, dst, dirs_exist_ok=True)
            shutil.rmtree(src, ignore_errors=True)
        else:
            shutil.copy2(src, dst)
            src.unlink(missing_ok=True)


def swap(new_root: Path, log=print) -> Path:
    """Put `new_root`'s code in place of the installed code. Returns the roll-back folder. All or nothing."""
    cur = installed_version()
    backup = WORK / "versions" / f"{cur}-{time.strftime('%Y%m%d-%H%M%S')}-{os.urandom(2).hex()}"
    backup.mkdir(parents=True)
    (backup / ".version").write_text(cur)
    try:
        shipped = json.loads(MANIFEST.read_text())["names"]
    except (OSError, ValueError, KeyError):
        shipped = []
    new = _names(new_root)
    old = sorted(set(new) | {n for n in shipped if (ROOT / n).exists()})
    moved_out, moved_in = [], []
    try:
        for n in old:
            if (ROOT / n).exists():
                _move(ROOT / n, backup / n)
                moved_out.append(n)
        for n in new:
            _move(new_root / n, ROOT / n)
            moved_in.append(n)
    except Exception:
        for n in moved_in:  # put everything back the way it was
            shutil.rmtree(ROOT / n, ignore_errors=True) if (ROOT / n).is_dir() else (ROOT / n).unlink(missing_ok=True)
        for n in moved_out:
            _move(backup / n, ROOT / n)
        shutil.rmtree(backup, ignore_errors=True)
        raise
    (backup / ".names").write_text(json.dumps(moved_out))
    MANIFEST.write_text(json.dumps({"version": code_version(ROOT), "names": new}))
    return backup


def _prune(keep: int) -> None:
    vs = sorted((WORK / "versions").glob("*"), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in vs[max(1, keep):]:
        shutil.rmtree(old, ignore_errors=True)


def install_package(zip_path: Path, settings: dict, log=print, sha256: str | None = None,
                    allow_same: bool = False) -> dict:
    """Install an AutoCut update zip (already verified by the caller via sha256, or a zip the admin chose)."""
    with _lock:
        try:
            if sha256 and _sha(zip_path) != sha256.lower():
                raise ValueError("the download doesn't match the signed feed (damaged or tampered); not installed")
            stage = WORK / "staging"
            shutil.rmtree(stage, ignore_errors=True)
            _step("unpack", "Unpacking…", log)
            with zipfile.ZipFile(zip_path) as z:
                for n in z.namelist():
                    if n.startswith(("/", "\\")) or ".." in Path(n).parts:
                        raise ValueError(f"unsafe path in the package: {n}")
                extract(z, stage)
            root = _code_root(stage)
            ver = code_version(root)
            have = installed_version()
            if not allow_same and version_tuple(ver) <= version_tuple(have):
                raise ValueError(f"that package is AutoCut {ver}; this computer already has {have}")
            _pip(root, log)
            _step("selftest", f"Testing AutoCut {ver} on this computer before switching…", log)
            ok, out = selftest(root)
            if not ok:
                raise RuntimeError(f"AutoCut {ver} failed its self-test here, so nothing was changed:\n{out}")
            _step("swap", f"Switching to AutoCut {ver}…", log)
            backup = swap(root, log)
            shutil.rmtree(stage, ignore_errors=True)
            _prune(int(cfg(settings)["keep_versions"]))
            (WORK / "check.json").unlink(missing_ok=True)
            if sys.platform == "darwin" and (ROOT / "mac" / "build_app.sh").exists():
                subprocess.run(["bash", str(ROOT / "mac" / "build_app.sh")], capture_output=True, timeout=300)
            _step("done", f"AutoCut {ver} is installed. Restart AutoCut to use it.", log)
            return {"ok": True, "version": ver, "backup": str(backup), "restart": True}
        except Exception as e:  # noqa: BLE001 - reported to the dashboard
            _step("failed", str(e), log)
            return {"ok": False, "error": str(e)}


def install_latest(settings: dict, log=print) -> dict:
    st = check(settings, force=True)
    if st["mode"] != "feed":
        return {"ok": False, "error": st["error"] or "no signed update feed is set"}
    if not st["available"]:
        return {"ok": False, "error": st["error"] or f"AutoCut {__version__} is the newest"}
    feed = read_feed(settings)
    rel = feed["channels"].get(cfg(settings)["channel"]) or feed["channels"]["stable"]
    _step("download", f"Downloading AutoCut {rel['version']}…", log)
    try:
        z = _download(settings, feed, rel, WORK / "downloads" / f"AutoCut-{rel['version']}.zip", timeout=600)
    except ValueError as e:
        _step("failed", str(e), log)
        return {"ok": False, "error": str(e)}
    out = install_package(z, settings, log, sha256=rel["sha256"])
    Path(z).unlink(missing_ok=True)
    return out


def install_pack_from_feed(settings: dict, pid: str) -> dict:
    from . import content
    feed = read_feed(settings)
    p = next((x for x in feed.get("packs") or [] if x.get("id") == pid), None)
    if not p:
        raise ValueError("that pack isn't in the update feed")
    z = _download(settings, feed, p, WORK / "downloads" / f"{pid}.zip", timeout=300)
    try:
        return content.install_pack(Path(z), sha256=p["sha256"])
    finally:
        Path(z).unlink(missing_ok=True)


# ---- rolling back ----------------------------------------------------------------------------------
def rollback_versions() -> list[dict]:
    out = []
    for d in sorted((WORK / "versions").glob("*"), key=lambda p: p.stat().st_mtime, reverse=True):
        if (d / ".version").exists() and (d / "autocut" / "__init__.py").exists():
            out.append({"id": d.name, "version": (d / ".version").read_text().strip(),
                        "saved": time.strftime("%Y-%m-%d %H:%M", time.localtime(d.stat().st_mtime))})
    return out


def rollback(settings: dict, vid: str | None = None, log=print) -> dict:
    """Go back to a saved version (the newest by default). The current one is saved too, so it can come back."""
    with _lock:
        vs = rollback_versions()
        v = next((x for x in vs if x["id"] == vid), None) if vid else (vs[0] if vs else None)
        if not v:
            return {"ok": False, "error": "there's no earlier version on this computer to go back to"}
        src = WORK / "versions" / v["id"]
        stage = WORK / "staging"
        shutil.rmtree(stage, ignore_errors=True)
        shutil.copytree(src, stage, ignore=shutil.ignore_patterns(".version", ".names"))
        try:
            swap(stage, log)
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": f"couldn't switch back: {e}"}
        shutil.rmtree(stage, ignore_errors=True)
        shutil.rmtree(src, ignore_errors=True)
        (WORK / "check.json").unlink(missing_ok=True)
        _progress.update(state="done", message=f"Back on AutoCut {v['version']}. Restart AutoCut to use it.")
        return {"ok": True, "version": v["version"], "restart": True}


# ---- restarting ------------------------------------------------------------------------------------
def restart() -> None:
    """Start this AutoCut again (same command, new code). Runs on a thread so the dashboard gets its answer first."""
    def go():
        time.sleep(0.6)  # (no server.shutdown(): that would let the main thread exit before this runs)
        argv = list(getattr(sys, "orig_argv", None) or [sys.executable, *sys.argv])
        env = dict(os.environ, AUTOCUT_RESTARTED="1")
        if sys.platform == "win32":
            subprocess.Popen(argv, env=env, creationflags=getattr(subprocess, "DETACHED_PROCESS", 0)
                             | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0), close_fds=True)
            os._exit(0)
        os.environ["AUTOCUT_RESTARTED"] = "1"
        os.execv(argv[0] if os.path.isabs(argv[0]) else sys.executable, argv)
    threading.Thread(target=go, daemon=True).start()


def background_check(settings: dict) -> None:
    """At start and then daily: refresh the cached check, so the dashboard banner is instant (and send the shared
    monthly totals, stats.py)."""
    def loop():
        while True:
            try:
                if cfg(settings)["check"] and mode(settings) == "feed":
                    check(settings, force=True)
            except Exception:  # noqa: BLE001 - never take the app down over an update check
                pass
            try:
                from . import stats
                stats.maybe_send(settings)  # last month's totals, only if this computer agreed to share them
            except Exception:  # noqa: BLE001
                pass
            time.sleep(24 * 3600)
    threading.Thread(target=loop, daemon=True, name="update-check").start()
