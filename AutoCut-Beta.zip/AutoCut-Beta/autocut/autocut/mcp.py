"""AutoCut as an MCP connector: let an AI app (Claude Desktop, Claude Code, Cursor, LM Studio…) use AutoCut.

    python -m autocut mcp          (the AI app starts this itself; This Mac → Use AutoCut from your AI app sets it up)

It speaks the Model Context Protocol over stdin/stdout (JSON-RPC 2.0, one message per line) and offers tools that
drive the AutoCut already running on this computer: queue footage for a client, check jobs, make motion graphics and
social graphics, compose music, ask the Strategist. The thinking happens in the person's own AI app (their
subscription); the editing and rendering happen here, on their hardware. Nothing goes through a server of ours.

ChatGPT only adds connectors that are reachable over the internet (HTTPS), so it needs OpenAI's own tunnel to reach a
local connector; docs/AI-ACCOUNTS.md has the details.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import sys
import urllib.error
import urllib.request
from pathlib import Path

from . import __version__
from .config import LOCAL_SETTINGS, ROOT, clients_dir, list_clients, load_settings

VERSIONS = ("2025-06-18", "2025-03-26", "2024-11-05")
INSTRUCTIONS = ("AutoCut is a local video-editing studio on this computer. Each client has a brand kit (colours, fonts, "
                "logo, look and sound). Use list_clients first to get client ids. Renders take from a few seconds to a "
                "few minutes: start one, then use check_render or list_jobs to see when it's done. File paths you "
                "return are on this computer; the person opens them from AutoCut's dashboard or Finder/Explorer.")


# ---- talking to the running AutoCut ---------------------------------------------------------------------
def _base(settings: dict) -> str:
    return f"http://127.0.0.1:{settings['port']}"


def _api(settings: dict, path: str, body: dict | None = None, timeout: float = 120) -> dict:
    req = urllib.request.Request(_base(settings) + path, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"X-AutoCut": "1", "Content-Type": "application/json"},
                                 method="POST" if body is not None else "GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read()).get("error", "")
        except Exception:  # noqa: BLE001
            msg = ""
        if e.code == 401:
            raise ToolError("AutoCut asks for a sign-in on this computer (web.require_login), so the connector can't "
                            "use it. Turn sign-in off for local use, or use the dashboard.")
        raise ToolError(msg or f"AutoCut answered {e.code}")
    except (urllib.error.URLError, OSError):
        raise ToolError("AutoCut isn't open on this computer. Open it (the ✂ menu-bar app on a Mac, the AutoCut "
                        "shortcut on Windows) and try again.")


class ToolError(Exception):
    pass


def _client_id(settings: dict, name: str | None) -> str | None:
    """A client id from an id or a name ("Harborline Realty" → harborline-realty)."""
    if not name:
        return None
    ids = {d.name: d for d in list_clients(settings)}
    if name in ids:
        return name
    want = re.sub(r"[^a-z0-9]+", "", name.lower())
    for slug, d in ids.items():
        import yaml
        try:
            shown = (yaml.safe_load((d / "brand.yaml").read_text()) or {}).get("client", slug)
        except Exception:  # noqa: BLE001
            shown = slug
        if want in (re.sub(r"[^a-z0-9]+", "", slug), re.sub(r"[^a-z0-9]+", "", str(shown).lower())):
            return slug
    raise ToolError(f"No client called '{name}'. Clients: {', '.join(ids) or 'none yet'}")


# ---- the tools ------------------------------------------------------------------------------------------
def t_status(settings, a):
    st = _api(settings, "/api/state")
    w = st["worker"]
    return {"version": st["version"], "computer": st["machine"], "clients": len(st["clients"]),
            "working_on": (w.get("current") or {}).get("video"), "paused": w["paused"], "waiting": len(st["waiting"]),
            "recent_jobs": [{"video": j.get("job"), "client": j.get("client_slug"), "state": j.get("state")}
                            for j in st["jobs"][:5]]}


def t_list_clients(settings, a):
    from .config import load_client
    out = []
    for d in list_clients(settings):
        try:
            b = load_client(str(d), settings).brand
        except SystemExit:
            continue
        out.append({"id": d.name, "name": b.get("client"), "industry": (b.get("marketing") or {}).get("industry", ""),
                    "colors": b.get("colors"), "website": b.get("website", "")})
    return out


def t_queue_videos(settings, a):
    """Copy videos into a client's queue (AutoCut on this computer edits them in order)."""
    from . import jobs
    cid = _client_id(settings, a.get("client"))
    if not cid:
        raise ToolError("Which client? (list_clients)")
    inc = clients_dir(settings) / cid / "incoming"
    inc.mkdir(exist_ok=True)
    done = []
    for p in a.get("paths") or []:
        src = Path(os.path.expanduser(str(p)))
        if not src.is_file():
            raise ToolError(f"Can't find {src}")
        if src.suffix.lower() not in settings["video_extensions"]:
            raise ToolError(f"{src.name} isn't a video AutoCut reads ({', '.join(settings['video_extensions'])})")
        dest = inc / src.name
        n = 2
        while dest.exists():
            dest = inc / f"{src.stem}-{n}{src.suffix}"
            n += 1
        if a.get("hook"):
            (inc / (dest.name + jobs.OPTIONS_SUFFIX)).write_text(json.dumps({"hook": str(a["hook"])[:120]}))
        tmp = inc / f".copying-{dest.name}"  # the queue ignores dot-files until the copy is complete
        shutil.copy2(src, tmp)
        tmp.replace(dest)
        done.append(dest.name)
    return {"queued": done, "client": cid, "note": "Each one becomes a Premiere rough cut; use list_jobs to follow them."}


def t_list_jobs(settings, a):
    st = _api(settings, "/api/state")
    cid = _client_id(settings, a.get("client")) if a.get("client") else None
    out = []
    for j in st["jobs"]:
        if cid and j.get("client_slug") != cid:
            continue
        row = {"video": j.get("job"), "client": j.get("client_slug")}
        row.update({k: j.get(k) for k in ("state", "step", "error", "xml", "preview", "final", "dir") if j.get(k)})
        out.append(row)
        if len(out) >= int(a.get("limit") or 10):
            break
    return {"jobs": out, "waiting": [w["file"] for w in st["waiting"] if not cid or w["client"] == cid]}


def t_motion_graphic(settings, a):
    cid = _client_id(settings, a.get("client"))
    spec = _api(settings, "/api/create/parse", {"prompt": str(a.get("prompt") or ""), "client": cid})
    if a.get("sizes"):
        spec["sizes"] = list(a["sizes"])
    out = _api(settings, "/api/create/render", spec)
    return {"started": True, "dir": out.get("dir"), "template": spec.get("template"), "sizes": spec.get("sizes"),
            "note": "Rendering on this computer; call check_render with this dir."}


def t_graphic(settings, a):
    cid = _client_id(settings, a.get("client"))
    spec = _api(settings, "/api/design/magic", {"prompt": str(a.get("prompt") or ""), "client": cid})
    spec["client"] = cid
    spec["sizes"] = list(a.get("sizes") or spec.get("sizes") or ["post"])
    out = _api(settings, "/api/design/render", spec)
    return {"started": True, "dir": out.get("dir"), "design": spec.get("template"), "sizes": spec["sizes"],
            "note": "Rendering on this computer; call check_render with this dir."}


def t_explainer(settings, a):
    cid = _client_id(settings, a.get("client"))
    src = Path(str(a.get("path") or "")).expanduser()
    if not src.is_file():
        raise ToolError(f"No video at {src}")
    params = {"source": str(src.resolve()), "style": "explainer", "ai": True, "pop_out": a.get("pop_out", True) is not False}
    assets = [{"path": str(Path(g).expanduser().resolve()), "role": "graphic"} for g in a.get("graphics") or [] if Path(g).expanduser().is_file()]
    out = _api(settings, "/api/create/render", {"template": "transcript", "params": params, "client": cid, "sizes": ["vertical"],
                                                 "formats": ["mp4"], "fps": 30, "engine": "hyperframes", "assets": assets})
    return {"started": True, "dir": out.get("dir"), "note": "Rough-cutting and rendering on this computer (a few minutes); call check_render with this dir."}


def t_check_render(settings, a):
    from .design.stills import library_dir as design_dir
    from .mograph.prompt import library_dir
    d = Path(str(a.get("dir") or "")).resolve()
    roots = [library_dir(settings).resolve(), design_dir(settings).resolve()]
    if not any(r in d.parents for r in roots) or not (d / "spec.json").exists():
        raise ToolError("That isn't a render folder from make_motion_graphic, make_explainer_video or make_graphic")
    st = json.loads((d / "status.json").read_text()) if (d / "status.json").exists() else {}
    files = [str(d / f) for f in st.get("files", []) if (d / f).exists()]
    return {"state": st.get("state", "waiting"), "step": st.get("step"), "error": st.get("error"), "files": files}


def t_music(settings, a):
    from . import sound
    from .config import load_client
    cid = _client_id(settings, a.get("client"))
    client = load_client(cid, settings) if cid else None
    seconds = max(5.0, min(600.0, float(a.get("seconds") or 30)))
    folder = (client.folder / "assets" / "music") if client else (Path.home() / "Downloads")
    folder.mkdir(parents=True, exist_ok=True)
    out = folder / f"autocut-music-{int(seconds)}s-{os.urandom(2).hex()}.wav"
    meta = sound.score(client, settings, seconds, out, str(a.get("notes") or ""), "short",
                       override={"style": a.get("style"), "energy": a.get("energy")}, use_ai_brain=False)
    return {"file": str(out), "style": meta.get("style_name"), "bpm": meta.get("bpm"), "engine": meta.get("engine")}


def t_strategist(settings, a):
    cid = _client_id(settings, a.get("client"))
    return _api(settings, "/api/strategist", {"question": str(a.get("question") or ""), "client": cid}, timeout=400)


def t_open(settings, a):
    import webbrowser
    webbrowser.open(_base(settings) + "/")
    return {"opened": _base(settings)}


S = lambda props, req=(): {"type": "object", "properties": props, "required": list(req)}  # noqa: E731
STR = {"type": "string"}
TOOLS = {
    "autocut_status": (t_status, "What AutoCut on this computer is doing: version, what it's working on, the queue, recent jobs.", S({})),
    "list_clients": (t_list_clients, "The agency's clients on this computer, with their id, industry and brand colours.", S({})),
    "queue_videos": (t_queue_videos, "Queue raw talking-head videos (files on this computer) for a client. AutoCut cuts fillers and "
                     "pauses, adds captions, B-roll, graphics and music, and makes a Premiere rough cut of each.",
                     S({"client": STR, "paths": {"type": "array", "items": STR}, "hook": {"type": "string", "description": "optional hook text for the opening title"}}, ["client", "paths"])),
    "list_jobs": (t_list_jobs, "Recent rough cuts and their state (and the Premiere XML / preview paths when done).",
                  S({"client": STR, "limit": {"type": "integer"}})),
    "make_motion_graphic": (t_motion_graphic, "Make an animated graphic in a client's brand from a description: lower third, title, "
                            "stat counter, chart, list, quote, call-to-action end card, a whole storyboard. Returns a folder to check.",
                            S({"prompt": STR, "client": STR, "sizes": {"type": "array", "items": {"type": "string", "enum": ["vertical", "square", "landscape", "portrait"]}}}, ["prompt"])),
    "make_graphic": (t_graphic, "Make a still social graphic in a client's brand from a description (quote, stat, offer, testimonial, "
                     "thumbnail, tips, event, carousel). Returns a folder to check.",
                     S({"prompt": STR, "client": STR, "sizes": {"type": "array", "items": {"type": "string", "enum": ["post", "portrait", "story", "thumbnail", "ad"]}}}, ["prompt"])),
    "make_explainer_video": (t_explainer, "Edit a raw talking-head video (a file on this computer) in the Explainer split style: rough-cut, "
                             "speaker in a rounded panel at the bottom, captions in the middle, graphics above that explain what they say "
                             "(cards that build word by word, price stickers, a struck-through number with a FREE badge, a step tracker, "
                             "a name card). Optional graphics (screenshots, photos) appear when they're mentioned. Returns a folder to check.",
                             S({"path": STR, "client": STR, "graphics": {"type": "array", "items": STR},
                                "pop_out": {"type": "boolean", "description": "the speaker's head pops out over the panel edge (default true)"}}, ["path"])),
    "check_render": (t_check_render, "Whether a graphic from make_motion_graphic / make_graphic is finished, and its files.", S({"dir": STR}, ["dir"])),
    "compose_music": (t_music, "Compose an original, royalty-free music bed in a client's sound (or a chosen style), fitted to a length.",
                      S({"seconds": {"type": "number"}, "client": STR, "style": STR, "energy": {"type": "string", "enum": ["low", "medium", "high"]},
                         "notes": {"type": "string", "description": "what the video is about"}}, ["seconds"])),
    "ask_strategist": (t_strategist, "Ask AutoCut's Strategist (the agency's video-marketing playbook) for hooks, scripts, content plans or ad angles.",
                       S({"question": STR, "client": STR}, ["question"])),
    "open_dashboard": (t_open, "Open AutoCut's dashboard on this computer.", S({})),
}


# ---- the protocol ---------------------------------------------------------------------------------------
def handle(msg: dict, settings: dict) -> dict | None:
    mid, method, params = msg.get("id"), msg.get("method"), msg.get("params") or {}
    if mid is None:  # a notification (initialized, cancelled…): nothing to answer
        return None

    def ok(result):
        return {"jsonrpc": "2.0", "id": mid, "result": result}

    if method == "initialize":
        want = params.get("protocolVersion")
        return ok({"protocolVersion": want if want in VERSIONS else VERSIONS[0],
                   "capabilities": {"tools": {"listChanged": False}},
                   "serverInfo": {"name": "autocut", "title": "AutoCut", "version": __version__},
                   "instructions": INSTRUCTIONS})
    if method == "ping":
        return ok({})
    if method == "tools/list":
        return ok({"tools": [{"name": n, "description": d, "inputSchema": s} for n, (_, d, s) in TOOLS.items()]})
    if method == "tools/call":
        name = params.get("name")
        if name not in TOOLS:
            return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32602, "message": f"unknown tool {name}"}}
        try:
            out = TOOLS[name][0](settings, params.get("arguments") or {})
            return ok({"content": [{"type": "text", "text": json.dumps(out, indent=1, default=str)}],
                       "structuredContent": out if isinstance(out, dict) else {"items": out}})
        except ToolError as e:
            return ok({"content": [{"type": "text", "text": str(e)}], "isError": True})
        except Exception as e:  # noqa: BLE001
            return ok({"content": [{"type": "text", "text": f"{type(e).__name__}: {e}"}], "isError": True})
    return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": f"method not found: {method}"}}


def serve(stdin=None, stdout=None) -> None:
    stdin, stdout = stdin or sys.stdin, stdout or sys.stdout
    settings = load_settings()
    for line in stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            stdout.write(json.dumps({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "parse error"}}) + "\n")
            stdout.flush()
            continue
        for m in msg if isinstance(msg, list) else [msg]:
            out = handle(m, settings)
            if out is not None:
                stdout.write(json.dumps(out) + "\n")
                stdout.flush()


# ---- setting it up in an AI app -------------------------------------------------------------------------
def launch() -> dict:
    """How an AI app starts this connector on this computer."""
    env = {"PYTHONPATH": str(ROOT)}
    if os.environ.get("AUTOCUT_SETTINGS"):
        env["AUTOCUT_SETTINGS"] = os.environ["AUTOCUT_SETTINGS"]
    return {"command": sys.executable, "args": ["-X", "utf8", "-m", "autocut", "mcp"], "env": env}


def claude_desktop_config() -> Path:
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
    if sys.platform == "win32":
        return Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming")) / "Claude" / "claude_desktop_config.json"
    return Path.home() / ".config" / "Claude" / "claude_desktop_config.json"


def install_claude_desktop() -> dict:
    """Add AutoCut to Claude Desktop's connectors (the rest of its settings file is kept; a backup is made)."""
    f = claude_desktop_config()
    data = {}
    if f.exists():
        try:
            data = json.loads(f.read_text(encoding="utf-8") or "{}")
        except json.JSONDecodeError:
            raise ValueError(f"Claude Desktop's settings file has a mistake in it ({f}); fix or remove it first")
        shutil.copy2(f, f.with_name(f.name + ".autocut-backup"))
    data.setdefault("mcpServers", {})["autocut"] = launch()
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return {"ok": True, "file": str(f), "note": "Quit Claude Desktop completely and open it again; AutoCut appears under its connectors."}


def info(settings: dict) -> dict:
    f = claude_desktop_config()
    try:
        added = "autocut" in (json.loads(f.read_text(encoding="utf-8")).get("mcpServers") or {}) if f.exists() else False
    except (OSError, json.JSONDecodeError):
        added = False
    return {"launch": launch(), "snippet": json.dumps({"mcpServers": {"autocut": launch()}}, indent=2),
            "claude_desktop": {"file": str(f), "app_found": f.parent.exists(), "added": added},
            "tools": [{"name": n, "about": d} for n, (_, d, _s) in TOOLS.items()]}
