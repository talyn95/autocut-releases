"""Brand-kit and machine checks, shared by the dashboard and the command line.
Each check is {"status": "ok" | "warn" | "fail", "msg": str}."""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

from .config import Client, hex_to_rgb


def _r(ok: bool, msg: str, warn: bool = False) -> dict:
    return {"status": "ok" if ok else ("warn" if warn else "fail"), "msg": msg}


def font_families(folder: Path | None) -> set[str]:
    fams: set[str] = set()
    if not folder or not folder.is_dir():
        return fams
    for f in folder.iterdir():
        if f.suffix.lower() not in (".ttf", ".otf"):
            continue
        try:
            from fontTools.ttLib import TTFont
            for rec in TTFont(f, lazy=True)["name"].names:
                if rec.nameID in (1, 16):
                    fams.add(rec.toUnicode().strip())
        except Exception:
            if shutil.which("fc-scan"):
                out = subprocess.run(["fc-scan", "--format", "%{family}\n", str(f)],
                                     capture_output=True, text=True).stdout
                fams |= {x.strip() for line in out.splitlines() for x in line.split(",")}
    return fams


def check_client(c: Client, settings: dict) -> list[dict]:
    from .broll import index_library
    b = c.brand
    out = []
    for k, v in b["colors"].items():
        try:
            hex_to_rgb(v)
            out.append(_r(True, f"colour {k}: {v}"))
        except ValueError:
            out.append(_r(False, f"colour {k}: {v!r} is not a hex colour like #F2A900"))
    fonts_dir = c.path(b["fonts"]["folder"])
    fams = font_families(fonts_dir)
    for role in ("caption", "headline"):
        name = b["fonts"][role]
        if fams:
            out.append(_r(name in fams, f"{role} font '{name}' " + (
                "found" if name in fams else f"not in fonts folder (has: {', '.join(sorted(fams))})")))
        else:
            out.append(_r(False, f"{role} font '{name}': no .ttf/.otf files in assets/fonts", warn=True))
    logo = c.path(b["logo"]["file"])
    out.append(_r(bool(logo and logo.exists()), f"logo: {b['logo']['file'] or 'not set'}",
                  warn=not b["logo"]["watermark"]))
    if logo and logo.suffix.lower() not in (".png", ".svg"):
        out.append(_r(False, "logo should be a transparent PNG", warn=True))
    out.append(_r(bool(b["cta"]["text"]) or not b["cta"]["enabled"], f"CTA text: {b['cta']['text']!r}"))
    ec = c.path(b["cta"]["end_card"])
    if ec:
        out.append(_r(ec.exists(), f"custom end card: {b['cta']['end_card']}"))
    clips = index_library(c.path(b["broll"]["folder"]))
    out.append(_r(len(clips) >= 10, f"b-roll library: {len(clips)} clips (aim for 20+, named descriptively)",
                  warn=True))
    music = c.path(b["music"]["file"])
    if music:
        out.append(_r(music.exists(), f"music bed: {b['music']['file']}"))
    ms = b["motion_studio"]
    if ms["enabled"]:
        bj = c.path(ms["brand_json"])
        out.append(_r(bool(bj and bj.exists()), f"motion studio brand.json: {ms['brand_json']}"))
        for p in ms["pieces"]:
            out.append(_r(c.path(p["spec"]).exists(), f"motion piece {p['spec']} (place: {p.get('place', 'start')})"))
        studio = Path(settings["motion_studio_path"]).expanduser()
        out.append(_r((studio / "render.mjs").exists(), f"motion studio at {studio}", warn=True))
    return out


def doctor(settings: dict, download: bool = False) -> list[dict]:
    out = []
    has_ffmpeg = bool(shutil.which("ffmpeg"))
    out.append(_r(has_ffmpeg, "ffmpeg installed"))
    if has_ffmpeg:
        filters = subprocess.run(["ffmpeg", "-hide_banner", "-filters"], capture_output=True, text=True).stdout
        encoders = subprocess.run(["ffmpeg", "-hide_banner", "-encoders"], capture_output=True, text=True).stdout
        out.append(_r(" ass " in filters, "ffmpeg has libass (kinetic captions)"))
        out.append(_r("prores_ks" in encoders, "ffmpeg has ProRes encoder (alpha overlays)"))
        if sys.platform == "darwin":
            out.append(_r("h264_videotoolbox" in encoders,
                          "Hardware video encoding (Apple media engine) for fast previews and exports", warn=True))
        elif sys.platform == "win32":
            from .media import _hardware_h264
            hw = _hardware_h264()
            names = {"h264_nvenc": "NVIDIA", "h264_qsv": "Intel", "h264_amf": "AMD"}
            out.append(_r(bool(hw), f"Hardware video encoding ({names[hw]} graphics) for fast previews and exports" if hw
                          else "Hardware video encoding: no NVIDIA, Intel or AMD encoder found, so the CPU encodes (slower)",
                          warn=True))
    from .config import clients_dir
    cd = clients_dir(settings)
    out.append(_r(cd.is_dir(), f"clients folder: {cd}"))
    if settings["motion_studio_path"]:
        studio = Path(settings["motion_studio_path"]).expanduser()
        out.append(_r(bool(shutil.which("node")), "node installed (Motion Studio)", warn=True))
        out.append(_r((studio / "render.mjs").exists(), f"Motion Studio at {studio}", warn=True))
        out.append(_r((studio / "node_modules").exists(), "Motion Studio dependencies installed", warn=True))
    try:
        import skia  # noqa: F401
        out.append(_r(True, "AutoCut Motion graphics engine (Skia) ready"))
    except Exception as e:
        out.append(_r(False, f"AutoCut Motion engine missing ({e}); run Update AutoCut", warn=True))
    from .mograph import hyper
    hf_ok = hyper.available(settings)
    out.append(_r(hf_ok, "HyperFrames motion graphics engine ready" if hf_ok else
                  "HyperFrames motion graphics (optional): not set up. Install Node.js 22+, then run "
                  "`autocut hyperframes-setup`. Until then the classic engine makes the graphics", warn=True))
    from .aiimage import engines as ai_engines
    img = ai_engines(settings)
    out.append(_r(bool(img), "AI image generation (optional)" + (f": {', '.join(img)}" if img else
                  (": install the local one (~/AutoCut/.venv/bin/pip install mflux) or connect a ChatGPT or Grok account"
                   if sys.platform == "darwin" else ": connect a ChatGPT or Grok account (This PC → AI accounts)")), warn=True))
    from .transcribe import _pick_backend
    backend = _pick_backend(settings["whisper"]["backend"])
    from .hardware import whisper_model
    m = settings["whisper"].get("model") or "auto"
    out.append(_r(True, f"speech engine: {backend}, model {whisper_model(settings['whisper'])}"
                  + (" (picked for this computer)" if m == "auto" else "")))
    if download:
        import tempfile
        from .transcribe import transcribe
        with tempfile.TemporaryDirectory() as tmp:
            clip = Path(tmp) / "tone.mp4"
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "color=s=320x240:d=2",
                            "-f", "lavfi", "-i", "sine=d=2", "-shortest", str(clip)], check=True)
            transcribe(clip, Path(tmp), settings)
        out.append(_r(True, "speech model downloaded and working"))
    return out


def all_ok(results: list[dict]) -> bool:
    return not any(r["status"] == "fail" for r in results)
