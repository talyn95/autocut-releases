"""Report a problem: one zip a beta tester can email, with everything needed to see what went wrong.

What's in it: the tester's description, AutoCut's version, the computer (OS, chip, memory), the health check,
this computer's settings with every key and password removed, the app log, and the logs and status of the most
recent jobs and projects. No footage and no finished videos (those are big and may be private).
"""
from __future__ import annotations

import json
import platform
import re
import sys
import zipfile
from datetime import datetime
from pathlib import Path

import yaml

from . import __version__
from .config import LOCAL_SETTINGS, clients_dir

SECRET = re.compile(r"key|secret|password|token|hash", re.I)


def _scrub(obj):
    if isinstance(obj, dict):
        return {k: ("(removed)" if SECRET.search(str(k)) and v else _scrub(v)) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_scrub(v) for v in obj]
    return obj


def log_file() -> Path:
    if sys.platform == "win32":
        import os
        return Path(os.environ.get("LOCALAPPDATA", Path.home())) / "AutoCut" / "AutoCut.log"
    return Path.home() / "Library" / "Logs" / "AutoCut.log"


def _tail(p: Path, max_bytes: int = 400_000) -> bytes:
    with p.open("rb") as f:
        f.seek(max(0, p.stat().st_size - max_bytes))
        return f.read()


def _recent_folders(settings: dict, limit: int = 8) -> list[Path]:
    """The newest job, long-form, multicam and motion-graphic folders (by their status file)."""
    root = clients_dir(settings)
    found = []
    for pattern in ("*/ready/*/status.json", "*/longform/*/status.json", "*/multicam/*/status.json"):
        found += root.glob(pattern)
    found += (root.parent / "motion-library").glob("*/status.json")
    found.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return [p.parent for p in found[:limit]]


def build(settings: dict, description: str, out_dir: Path | None = None, job: Path | None = None) -> Path:
    from . import checks
    from .brain import memory_gb
    out_dir = out_dir or (Path.home() / ("Desktop" if (Path.home() / "Desktop").is_dir() else ""))
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"AutoCut-problem-report-{datetime.now():%Y%m%d-%H%M%S}.zip"
    try:
        doctor = checks.doctor(settings)
    except Exception as e:  # the report must still come out when the health check itself is what's broken
        doctor = [{"status": "fail", "msg": f"health check crashed: {e}"}]
    about = {
        "autocut_version": __version__,
        "made": datetime.now().isoformat(timespec="seconds"),
        "machine_name": settings.get("machine_name"),
        "os": platform.platform(),
        "chip": platform.machine(),
        "python": platform.python_version(),
        "memory_gb": round(memory_gb(), 1),
    }
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("1-what-happened.txt", (description or "(no description)").strip() + "\n")
        z.writestr("2-about-this-computer.json", json.dumps(about, indent=2))
        z.writestr("3-health-check.txt", "\n".join(f"[{c['status']}] {c['msg']}" for c in doctor) + "\n")
        z.writestr("4-settings-without-secrets.yaml", yaml.safe_dump(_scrub(settings), sort_keys=False))
        if LOCAL_SETTINGS.exists():
            try:
                local = yaml.safe_load(LOCAL_SETTINGS.read_text()) or {}
                z.writestr("4-this-computer-settings.yaml", yaml.safe_dump(_scrub(local), sort_keys=False))
            except yaml.YAMLError:
                z.writestr("4-this-computer-settings.yaml", "(unreadable YAML)\n")
        if log_file().exists():
            z.writestr("5-app-log.txt", _tail(log_file()))
        folders = ([job] if job else []) + [f for f in _recent_folders(settings) if f != job]
        for f in folders:
            name = f"6-jobs/{f.parent.parent.name}-{f.parent.name}-{f.name}"[:180]
            for item in ("status.json", "log.txt", "job.json", "options.json", "spec.json", "multicam.json"):
                if (f / item).is_file():
                    z.writestr(f"{name}/{item}", _tail(f / item))
            if (f / "spec.json").is_file():  # a HyperFrames graphic: its composition shows what was rendered
                for page in f.glob("hf-*/index.html"):
                    z.writestr(f"{name}/{page.parent.name}.html", page.read_bytes())
    return out
