import sys

# Windows reads and writes text as cp1252 unless told otherwise; brand kits, captions and transcripts
# are UTF-8 (emoji, curly quotes, accents), so run in Python's UTF-8 mode there.
if sys.platform == "win32" and not sys.flags.utf8_mode:
    import subprocess
    sys.exit(subprocess.call([sys.executable, "-X", "utf8", "-m", "autocut", *sys.argv[1:]]))

from .cli import main  # noqa: E402

main()
