"""Brand kit from a website: paste a client's web address, get a draft brand kit to check and save.

`scan(url)` reads the home page (and the stylesheets it links) and finds:
  logo      structured data (schema.org "logo"), the header's logo image, apple-touch-icon, the share image (og:image)
  colours   the site's theme colour, the colours its CSS uses most (brand colours, not greys), the logo's own colours
  fonts     Google Fonts it loads and the font families its CSS names; Google Fonts are downloaded (open licences)
  details   name, description, phone, address, social links, the wording of its call-to-action buttons
then the AI brain (marketing playbook) writes the marketing brief: industry, audience, offer, voice, location, goals,
call to action, words to spell right, hashtags. Without an AI, simple rules fill what they can.

Nothing is saved until `create(proposal)`: the dashboard shows the draft first so the editor can fix anything.
"""
from __future__ import annotations

import colorsys
import json
import re
import shutil
import time
import urllib.parse
import urllib.request
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path

UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36 AutoCut"
GENERIC_FONTS = {"sans-serif", "serif", "monospace", "system-ui", "inherit", "initial", "cursive", "fantasy", "-apple-system",
                 "blinkmacsystemfont", "segoe ui", "roboto", "helvetica neue", "helvetica", "arial", "ui-sans-serif",
                 "ui-serif", "ui-monospace", "apple color emoji", "segoe ui emoji", "segoe ui symbol", "noto color emoji",
                 "var", "unset", "revert", "emoji", "math", "fangsong", "times new roman", "georgia", "courier new"}
SOCIAL = {"facebook.com": "facebook", "instagram.com": "instagram", "tiktok.com": "tiktok", "youtube.com": "youtube",
          "linkedin.com": "linkedin", "x.com": "x", "twitter.com": "x", "pinterest.com": "pinterest", "yelp.com": "yelp"}
CTA_WORDS = re.compile(r"\b(book|schedule|get (a|your)|request|call|contact|start|free|quote|estimate|consult|"
                       r"appointment|order|shop|buy|join|sign up|try|demo|apply|reserve)\b", re.I)


# ---- fetching ---------------------------------------------------------------------------------------
def _get(url: str, limit: int = 3 * 2**20, timeout: float = 15, ua: str = UA) -> tuple[bytes, str, str]:
    """(body, final url, content type)."""
    req = urllib.request.Request(url, headers={"User-Agent": ua, "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(limit), r.geturl(), r.headers.get("Content-Type", "")


def normalize(url: str) -> str:
    url = url.strip()
    if not url:
        raise ValueError("Paste the client's web address")
    if not re.match(r"^https?://", url, re.I):
        url = "https://" + url
    p = urllib.parse.urlparse(url)
    if not p.netloc or "." not in p.netloc and p.hostname not in ("localhost", "127.0.0.1"):
        raise ValueError("That doesn't look like a web address")
    return url


# ---- reading the page ------------------------------------------------------------------------------
class _Page(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.meta: dict[str, str] = {}
        self.links: list[dict] = []
        self.imgs: list[dict] = []
        self.anchors: list[tuple[str, str]] = []
        self.buttons: list[str] = []
        self.styles: list[str] = []
        self.jsonld: list[str] = []
        self.title = ""
        self.heads: list[str] = []
        self.text: list[str] = []
        self._stack: list[str] = []
        self._href = None
        self._buf: list[str] = []
        self._in_header = 0
        self._ld = False

    def handle_starttag(self, tag, attrs):
        a = {k.lower(): (v or "") for k, v in attrs}
        self._stack.append(tag)
        if tag in ("header", "nav"):
            self._in_header += 1
        if tag == "meta":
            k = (a.get("property") or a.get("name") or a.get("itemprop") or "").lower()
            if k:
                self.meta[k] = a.get("content", "")
        elif tag == "link":
            self.links.append(a)
        elif tag == "img":
            a["_header"] = str(self._in_header > 0)
            self.imgs.append(a)
        elif tag == "a":
            self._href = a.get("href", "")
            self._buf = []
        elif tag in ("button",):
            self._buf = []
        elif tag == "script":
            self._ld = "ld+json" in a.get("type", "")

    def handle_endtag(self, tag):
        if self._stack and self._stack[-1] == tag:
            self._stack.pop()
        if tag in ("header", "nav"):
            self._in_header = max(0, self._in_header - 1)
        if tag == "a" and self._href is not None:
            self.anchors.append((self._href, " ".join("".join(self._buf).split())))
            self._href = None
        elif tag == "button":
            self.buttons.append(" ".join("".join(self._buf).split()))

    def handle_data(self, data):
        top = self._stack[-1] if self._stack else ""
        if top == "style":
            self.styles.append(data)
            return
        if top == "script":
            if self._ld:
                self.jsonld.append(data)
            return
        if top == "title":
            self.title += data
        if top in ("h1", "h2", "h3"):
            self.heads.append(" ".join(data.split()))
        if self._href is not None or top in ("button", "a"):
            self._buf.append(data)
        if data.strip() and top not in ("noscript", "svg", "path"):
            self.text.append(" ".join(data.split()))


def _jsonld(page: _Page) -> dict:
    """The organisation / local business from schema.org JSON-LD, if the site has it."""
    found = {}
    for raw in page.jsonld:
        try:
            data = json.loads(raw)
        except ValueError:
            continue
        items = data if isinstance(data, list) else data.get("@graph", [data]) if isinstance(data, dict) else []
        for it in items:
            if not isinstance(it, dict):
                continue
            t = it.get("@type")
            t = " ".join(t) if isinstance(t, list) else str(t or "")
            if any(x in t for x in ("Organization", "LocalBusiness", "Corporation", "Store", "Restaurant", "Service",
                                   "Dentist", "Physician", "Contractor", "RealEstate", "Business", "Clinic")) or it.get("logo"):
                found.setdefault("type", t)
                for k in ("name", "telephone", "description", "url", "slogan"):
                    if it.get(k) and k not in found:
                        found[k] = it[k]
                logo = it.get("logo")
                if isinstance(logo, dict):
                    logo = logo.get("url") or logo.get("contentUrl")
                if isinstance(logo, str) and "logo" not in found:
                    found["logo"] = logo
                addr = it.get("address")
                if isinstance(addr, dict) and "address" not in found:
                    found["address"] = ", ".join(str(addr.get(k)) for k in ("addressLocality", "addressRegion") if addr.get(k))
    return found


# ---- colours ---------------------------------------------------------------------------------------
def _hex(c: str) -> str | None:
    c = c.strip().lower()
    m = re.fullmatch(r"#([0-9a-f]{3}|[0-9a-f]{6})([0-9a-f]{2})?", c)
    if m:
        h = m.group(1)
        return "#" + ("".join(x * 2 for x in h) if len(h) == 3 else h)
    m = re.fullmatch(r"rgba?\(\s*(\d+)[\s,]+(\d+)[\s,]+(\d+)(?:[\s,/]+([\d.]+%?))?\s*\)", c)
    if m:
        if m.group(4) and m.group(4) not in ("1", "100%") and float(m.group(4).rstrip("%")) < (50 if "%" in m.group(4) else 0.5):
            return None
        return "#%02x%02x%02x" % tuple(min(255, int(m.group(i))) for i in (1, 2, 3))
    return None


def _hsv(h: str) -> tuple[float, float, float]:
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (1, 3, 5))
    return colorsys.rgb_to_hsv(r, g, b)


def _is_brand(h: str) -> bool:
    _, s, v = _hsv(h)
    return s >= 0.28 and 0.22 <= v


def _is_dark(h: str) -> bool:
    _, s, v = _hsv(h)
    return v <= 0.32


def css_colours(css: str) -> Counter:
    """Colours the CSS uses, weighted: brand-ish custom properties and button/link/heading rules count extra."""
    out: Counter = Counter()
    for m in re.finditer(r"(--[\w-]*(?:primary|brand|accent|main|secondary|theme)[\w-]*)\s*:\s*([^;}{]+)", css, re.I):
        h = _hex(m.group(2))
        if h:
            out[h] += 8
    for block in re.finditer(r"([^{}]+)\{([^{}]*)\}", css):
        sel, body = block.group(1).lower(), block.group(2)
        w = 3 if re.search(r"\b(button|btn|\.cta|a:hover|a\b|h1|h2|header|nav|\.primary|\.brand|\.accent)", sel) else 1
        for m in re.finditer(r"(?:^|;|\s)(?:color|background(?:-color)?|border(?:-color)?|fill|stroke)\s*:\s*([^;!]+)", body):
            for c in re.findall(r"#[0-9a-fA-F]{3,8}\b|rgba?\([^)]*\)", m.group(1)):
                h = _hex(c)
                if h:
                    out[h] += w
    return out


def logo_colours(path: Path, k: int = 4) -> list[tuple[str, float]]:
    try:
        import numpy as np
        from PIL import Image
        im = Image.open(path).convert("RGBA")
        im.thumbnail((160, 160))
        px = np.asarray(im).reshape(-1, 4)
        px = px[px[:, 3] > 200][:, :3].astype(float)
        if len(px) < 20:
            return []
        rng = np.random.default_rng(0)
        cen = px[rng.choice(len(px), min(k, len(px)), replace=False)]
        for _ in range(10):
            lab = ((px[:, None] - cen[None]) ** 2).sum(2).argmin(1)
            for j in range(len(cen)):
                if (lab == j).any():
                    cen[j] = px[lab == j].mean(0)
        share = np.bincount(lab, minlength=len(cen)) / len(lab)
        return [("#%02x%02x%02x" % tuple(int(v) for v in cen[j]), float(share[j])) for j in np.argsort(-share)]
    except Exception:  # noqa: BLE001 - an odd image just means no logo colours
        return []


def pick_colours(theme: str | None, css: Counter, logo: list[tuple[str, float]]) -> dict:
    """primary (captions highlight, CTA), secondary (end-card background), text, outline."""
    brand = [h for h, _ in css.most_common() if _is_brand(h)]
    logo_brand = [h for h, s in logo if _is_brand(h) and s > 0.04]
    candidates = ([theme] if theme and _is_brand(theme) else []) + logo_brand[:1] + brand
    primary = candidates[0] if candidates else "#F2A900"
    darks = [h for h, _ in css.most_common() if _is_dark(h) and h not in ("#000000",)] + [h for h, _ in logo if _is_dark(h)]
    if darks:
        secondary = darks[0]
    else:  # a deep shade of the primary
        hh, s, _ = _hsv(primary)
        r, g, b = colorsys.hsv_to_rgb(hh, min(1, s * 0.9), 0.16)
        secondary = "#%02x%02x%02x" % (int(r * 255), int(g * 255), int(b * 255))
    others = [h for h in brand + logo_brand if h != primary and abs(_hsv(h)[0] - _hsv(primary)[0]) > 0.06]
    return {"primary": primary.upper(), "secondary": secondary.upper(), "text": "#FFFFFF", "outline": "#000000",
            "extra": [h.upper() for h in others[:3]]}


# ---- fonts -----------------------------------------------------------------------------------------
def _rule_font(css: str, sel_rx: str) -> str | None:
    """The first named (non-generic) font in a CSS rule whose selector matches."""
    for block in re.finditer(r"([^{}]+)\{([^{}]*)\}", css):
        if re.search(sel_rx, block.group(1), re.I):
            m = re.search(r"font-family\s*:\s*([^;}]+)", block.group(2), re.I)
            if m:
                for f in m.group(1).split(","):
                    f = f.strip().strip("'\"")
                    if f and f.lower() not in GENERIC_FONTS and not f.startswith("var("):
                        return f
    return None


def heading_and_body_fonts(fams: list[str], css: str) -> tuple[str, str]:
    head = _rule_font(css, r"(^|[\s,])h[12]\b|\.(title|heading|headline|display)\b")
    body = _rule_font(css, r"(^|[\s,])(body|html|p)\b")
    head = head or (fams[0] if fams else "Montserrat")
    body = body or next((f for f in fams if f != head), head)
    return head, body


def google_families(page: _Page) -> list[str]:
    out = []
    for link in page.links:
        href = link.get("href", "")
        if "fonts.googleapis.com" in href:
            for fam in re.findall(r"family=([^&:]+)", urllib.parse.unquote(href)):
                for f in fam.split("|"):
                    name = f.split(":")[0].replace("+", " ").strip()
                    if name and name not in out:
                        out.append(name)
    return out


def fonts_from(page: _Page, css: str) -> list[str]:
    fams: list[str] = []
    for link in page.links:
        href = link.get("href", "")
        if "fonts.googleapis.com" in href:
            for fam in re.findall(r"family=([^&:]+)", urllib.parse.unquote(href)):
                for f in fam.split("|"):
                    name = f.split(":")[0].replace("+", " ").strip()
                    if name and name not in fams:
                        fams.append(name)
    counts: Counter = Counter()
    for m in re.finditer(r"font-family\s*:\s*([^;}{]+)", css, re.I):
        for f in m.group(1).split(","):
            f = f.strip().strip("'\"")
            if f and f.lower() not in GENERIC_FONTS and not f.startswith("var("):
                counts[f] += 1
    for f, _ in counts.most_common(6):
        if f not in fams:
            fams.append(f)
    return fams[:4]


def download_google_font(family: str, dest: Path) -> list[Path]:
    """Regular, bold and extra-bold TTFs of a Google Font (open licences) into dest; [] if it isn't one."""
    out = []
    dest.mkdir(parents=True, exist_ok=True)
    names = {400: "Regular", 700: "Bold", 800: "ExtraBold"}
    for w in (400, 700, 800):
        url = "https://fonts.googleapis.com/css2?family=" + urllib.parse.quote(family) + f":wght@{w}"
        try:  # a plain old browser name makes Google serve TTF files, which Premiere and libass read
            css = _get(url, ua="Mozilla/4.0", timeout=12)[0].decode("utf-8", "replace")
        except Exception:  # noqa: BLE001 - that weight doesn't exist, or no internet
            continue
        src = re.search(r"src:\s*url\(([^)]+\.ttf)\)", css)
        if not src:
            continue
        f = dest / f"{family.replace(' ', '')}-{names[w]}.ttf"
        try:
            f.write_bytes(_get(src.group(1), timeout=20)[0])
            out.append(f)
        except Exception:  # noqa: BLE001
            continue
    return out


# ---- the logo --------------------------------------------------------------------------------------
def logo_candidates(page: _Page, ld: dict, base: str) -> list[str]:
    abs_ = lambda u: urllib.parse.urljoin(base, u)  # noqa: E731
    out = []
    if ld.get("logo"):
        out.append(abs_(ld["logo"]))
    for im in page.imgs:
        blob = " ".join(im.get(k, "") for k in ("src", "alt", "class", "id", "data-src")).lower()
        if "logo" in blob and (im.get("src") or im.get("data-src")):
            out.append(abs_(im.get("src") or im.get("data-src")))
    for im in page.imgs:  # the first image in the header/nav is usually the logo
        if im.get("_header") == "True" and im.get("src"):
            out.append(abs_(im["src"]))
            break
    for l in page.links:
        rel = l.get("rel", "").lower()
        if "apple-touch-icon" in rel and l.get("href"):
            out.append(abs_(l["href"]))
    for k in ("og:image", "twitter:image"):
        if page.meta.get(k):
            out.append(abs_(page.meta[k]))
    for l in page.links:
        if "icon" in l.get("rel", "").lower() and l.get("href") and not l["href"].endswith(".ico"):
            out.append(abs_(l["href"]))
    seen, uniq = set(), []
    for u in out:
        if u not in seen and not u.startswith("data:"):
            seen.add(u)
            uniq.append(u)
    return uniq


def fetch_logo(cands: list[str], dest_dir: Path) -> tuple[Path | None, Path | None]:
    """(a raster logo AutoCut can use, the SVG original if there is one)."""
    from PIL import Image
    svg = None
    dest_dir.mkdir(parents=True, exist_ok=True)
    for u in cands[:6]:
        try:
            body, final, ctype = _get(u, limit=8 * 2**20, timeout=12)
        except Exception:  # noqa: BLE001
            continue
        if b"<svg" in body[:2000].lower() or "svg" in ctype:
            if svg is None:
                svg = dest_dir / "logo.svg"
                svg.write_bytes(body)
            continue
        tmp = dest_dir / "logo-download"
        tmp.write_bytes(body)
        try:
            im = Image.open(tmp)
            im.load()
        except Exception:  # noqa: BLE001
            tmp.unlink(missing_ok=True)
            continue
        if min(im.size) < 48:
            tmp.unlink(missing_ok=True)
            continue
        out = dest_dir / "logo.png"
        im.convert("RGBA").save(out)
        tmp.unlink(missing_ok=True)
        return out, svg
    return None, svg


# ---- the marketing brief ---------------------------------------------------------------------------
BRIEF_SCHEMA = {"type": "object", "properties": {
    "name": {"type": "string"}, "industry": {"type": "string"}, "audience": {"type": "string"},
    "offer": {"type": "string"}, "voice": {"type": "string"}, "location": {"type": "string"},
    "goals": {"type": "string"}, "cta_text": {"type": "string"}, "cta_sub": {"type": "string"},
    "vocabulary": {"type": "array", "items": {"type": "string"}}, "hashtags": {"type": "array", "items": {"type": "string"}},
    "tagline": {"type": "string"}},
    "required": ["name", "industry", "audience", "offer", "voice", "cta_text"]}


def rules_brief(name: str, page: _Page, ld: dict, ctas: list[str], domain: str) -> dict:
    desc = page.meta.get("description") or page.meta.get("og:description") or ld.get("description") or ""
    t = (ld.get("type") or "").replace("LocalBusiness", "").replace("Organization", "").strip()
    industry = re.sub(r"(?<!^)([A-Z])", r" \1", t).lower().strip() if t else ""
    words = [w for h in page.heads[:12] for w in re.findall(r"\b[A-Z][a-z0-9&]+(?:\s+[A-Z][a-z0-9&]+)+", h)]
    vocab = []
    for w in [name] + words:
        if w and w not in vocab and len(w) < 40 and w.lower() not in ("the", "our", "your", "home", "about", "contact"):
            vocab.append(w)
    tag = "#" + re.sub(r"[^A-Za-z0-9]", "", name) if name else ""
    return {"name": name, "industry": industry, "audience": "", "offer": desc[:160], "voice": "", "location": ld.get("address", ""),
            "goals": "", "cta_text": (ctas[0] if ctas else "Book now")[:40], "cta_sub": domain, "vocabulary": vocab[:8],
            "hashtags": [tag] if tag else [], "tagline": ld.get("slogan", "")}


def ai_brief(settings: dict, name: str, page: _Page, ld: dict, ctas: list[str], domain: str) -> dict | None:
    from . import brain, marketing
    text = " ".join(page.text)
    prompt = (f"A client's website. Write their marketing brief for short-form video.\n\nWebsite: {domain}\nName: {name}\n"
              f"Title: {page.title.strip()}\nDescription: {page.meta.get('description', '')}\n"
              f"Business data: {json.dumps(ld)[:600]}\nHeadings: {' | '.join(page.heads[:20])}\n"
              f"Buttons: {' | '.join(ctas[:8])}\nPage text: {text[:3500]}\n\n"
              "industry: a few words. audience: who they sell to, with place if local. offer: the main offer in one line. "
              "voice: 3-5 words for their tone. location: town/region or blank. goals: what a video should get people to do. "
              "cta_text: max 5 words for a video end card (use their own button wording if it's good). cta_sub: their "
              "website or phone. vocabulary: names, places and products a speech model might misspell. hashtags: 2-4, "
              "branded first. tagline: their slogan if they have one. Never invent facts that aren't on the page.")
    out = brain.ask(settings, marketing.system_prompt(None, "copy"), prompt, BRIEF_SCHEMA, timeout=180)
    return out if isinstance(out, dict) else None


# ---- the whole scan --------------------------------------------------------------------------------
def scan(url: str, settings: dict, work: Path, use_ai: bool = True) -> dict:
    """A draft brand kit (nothing saved to clients yet). Files (logo, fonts) go into `work`."""
    url = normalize(url)
    try:
        body, final, _ = _get(url)
    except Exception as e:  # noqa: BLE001
        raise ValueError(f"Couldn't open {url} ({e}). Check the address, or fill the brand kit in by hand.")
    html = body.decode("utf-8", "replace")
    page = _Page()
    page.feed(html)
    ld = _jsonld(page)
    domain = urllib.parse.urlparse(final).hostname or ""
    domain = domain[4:] if domain.startswith("www.") else domain
    css = "\n".join(page.styles)
    for l in [l for l in page.links if "stylesheet" in l.get("rel", "").lower() and l.get("href")][:5]:
        href = urllib.parse.urljoin(final, l["href"])
        if "fonts.googleapis.com" in href:
            continue
        try:
            css += "\n" + _get(href, limit=2 * 2**20, timeout=10)[0].decode("utf-8", "replace")
        except Exception:  # noqa: BLE001
            continue
    notes = []
    work.mkdir(parents=True, exist_ok=True)
    logo, svg = fetch_logo(logo_candidates(page, ld, final), work)
    if not logo:
        notes.append("No logo image found" + (" (the site's logo is an SVG; export it as a PNG and add it)" if svg else "")
                     + ": add one in the client's assets/logo folder.")
    theme = _hex(page.meta.get("theme-color", "")) if page.meta.get("theme-color") else None
    colours = pick_colours(theme, css_colours(css), logo_colours(logo) if logo else [])
    fams = fonts_from(page, css)
    name = (ld.get("name") or page.meta.get("og:site_name") or re.split(r"\s[|\-–—:]\s", page.title.strip())[0]
            or domain.split(".")[0].title()).strip()
    ctas = []
    for _href, txt in page.anchors:
        if txt and len(txt) <= 40 and CTA_WORDS.search(txt) and txt not in ctas:
            ctas.append(txt)
    ctas += [b for b in page.buttons if b and len(b) <= 40 and CTA_WORDS.search(b) and b not in ctas]
    socials = {}
    for href, _ in page.anchors:
        host = (urllib.parse.urlparse(href).hostname or "").replace("www.", "")
        for k, v in SOCIAL.items():
            if host.endswith(k) and v not in socials:
                socials[v] = href
    phone = ld.get("telephone") or next((h[4:] for h, _ in page.anchors if h.startswith("tel:")), "")
    brief = (ai_brief(settings, name, page, ld, ctas, domain) if use_ai else None)
    via = "ai" if brief else "rules"
    brief = {**rules_brief(name, page, ld, ctas, domain), **{k: v for k, v in (brief or {}).items() if v}}
    head, body_font = heading_and_body_fonts(fams, css)
    gfams = google_families(page)
    font_files = []
    for fam in dict.fromkeys([head, body_font]):
        got = download_google_font(fam, work / "fonts")
        font_files += [str(f) for f in got]
        if not got:
            notes.append(f"Fonts: couldn't download {fam} just now (no internet?); add its files to the client's "
                         "assets/fonts folder later." if fam in gfams else
                         f"Fonts: {fam} isn't a free Google Font; add its font files to the client's assets/fonts "
                         "folder (and install them for Premiere).")
    if not fams:
        notes.append("No brand fonts found; Montserrat for now.")
    return {"url": final, "domain": domain, "name": brief.get("name") or name, "colors": colours,
            "fonts": {"headline": head, "caption": body_font, "files": font_files},
            "logo": str(logo) if logo else "", "logo_svg": str(svg) if svg else "",
            "marketing": {k: brief.get(k, "") for k in ("industry", "audience", "offer", "voice", "location", "goals")},
            "cta": {"text": brief.get("cta_text", ""), "subtext": brief.get("cta_sub") or domain},
            "vocabulary": brief.get("vocabulary") or [], "hashtags": brief.get("hashtags") or [],
            "tagline": brief.get("tagline", ""), "socials": socials, "phone": phone, "notes": notes, "via": via,
            "scanned": time.strftime("%Y-%m-%d %H:%M")}


def create(proposal: dict, settings: dict) -> Path:
    """Save a (checked) draft as a new client: brand.yaml filled in, logo and fonts copied, comments kept."""
    from ruamel.yaml import YAML
    from .app import create_client
    d = create_client(str(proposal.get("name") or proposal.get("domain") or "New client").strip(), settings)
    y = YAML()
    y.preserve_quotes = True
    f = d / "brand.yaml"
    data = y.load(f.read_text())
    col = proposal.get("colors") or {}
    for k in ("primary", "secondary", "text", "outline"):
        if _hex(str(col.get(k, ""))):
            data["colors"][k] = _hex(col[k]).upper()
    fonts = proposal.get("fonts") or {}
    for k in ("headline", "caption"):
        if fonts.get(k):
            data["fonts"][k] = str(fonts[k])
    for src in fonts.get("files") or []:
        if Path(src).is_file():
            (d / "assets" / "fonts").mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, d / "assets" / "fonts" / Path(src).name)
    if proposal.get("logo") and Path(proposal["logo"]).is_file():
        (d / "assets" / "logo").mkdir(parents=True, exist_ok=True)
        shutil.copy2(proposal["logo"], d / "assets" / "logo" / "logo.png")
        data.setdefault("logo", {})["file"] = "assets/logo/logo.png"
    if proposal.get("logo_svg") and Path(proposal["logo_svg"]).is_file():
        shutil.copy2(proposal["logo_svg"], d / "assets" / "logo" / "logo.svg")
    m = proposal.get("marketing") or {}
    for k in ("industry", "audience", "offer", "voice", "location", "goals"):
        if m.get(k):
            data["marketing"][k] = str(m[k])
    if proposal.get("hashtags"):
        data["marketing"]["hashtags"] = [str(h) for h in proposal["hashtags"]][:6]
    cta = proposal.get("cta") or {}
    if cta.get("text"):
        data["cta"]["text"] = str(cta["text"])
    if cta.get("subtext"):
        data["cta"]["subtext"] = str(cta["subtext"])
    if proposal.get("vocabulary"):
        data["vocabulary"] = [str(v) for v in proposal["vocabulary"]][:20]
    data["website"] = proposal.get("url", "")
    with f.open("w") as fh:
        y.dump(data, fh)
    return d
