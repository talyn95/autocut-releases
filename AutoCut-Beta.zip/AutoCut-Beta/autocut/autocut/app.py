"""AutoCut dashboard: a small local web server + the background worker.

Started by AutoCut.app (see macapp.py) or `autocut app`. Serves web/index.html
and a JSON API at http://127.0.0.1:<port>/api/… No external dependencies.
"""
from __future__ import annotations

import dataclasses
import json
import mimetypes
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import yaml

from . import __version__, checks, jobs
from .auth import COOKIE
from .config import (EXAMPLES_DIR, LOCAL_SETTINGS, ROOT, TEMPLATE_DIR, clients_dir, deep_merge,
                     DEFAULT_BRAND, list_clients, load_client, load_settings, slugify)

WEB = Path(__file__).parent / "web"


def git_info() -> dict:
    def g(*args):
        r = subprocess.run(["git", *args], cwd=ROOT, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 else ""
    return {"commit": g("rev-parse", "--short", "HEAD"), "branch": g("rev-parse", "--abbrev-ref", "HEAD"),
            "date": g("log", "-1", "--format=%cd", "--date=short"), "remote": g("remote", "get-url", "origin"),
            "dirty": bool(g("status", "--porcelain"))}


def create_client(name: str, settings: dict) -> Path:
    slug = slugify(name)
    if not slug:
        raise ValueError("Client name is empty")
    dest = clients_dir(settings) / slug
    if dest.exists():
        raise ValueError(f"A client folder '{slug}' already exists")
    shutil.copytree(TEMPLATE_DIR, dest)
    brand = dest / "brand.yaml"
    brand.write_text(brand.read_text().replace('client: "Client Name"', f'client: {json.dumps(name)}'))
    return dest


def mount_share(settings: dict) -> None:
    """On a joined Mac, reconnect the main Mac's shared folder (uses saved Keychain login)."""
    if settings["share_url"] and sys.platform == "darwin" and not clients_dir(settings).is_dir():
        subprocess.run(["osascript", "-e", f'mount volume "{settings["share_url"]}"'],
                       capture_output=True, timeout=60)


def safe_name(name: str) -> str:
    """A file name that is safe on every Mac and in Premiere (keeps letters, numbers, - _ . and spaces)."""
    name = Path(name).name
    stem = re.sub(r"[^\w\- .]+", "", Path(name).stem).strip(" .") or "file"
    return stem[:80] + Path(name).suffix.lower()


def unique_path(folder: Path, name: str) -> Path:
    p = folder / name
    n = 2
    while p.exists() or (folder / f".upload-{p.name}").exists():
        p = folder / f"{Path(name).stem}-{n}{Path(name).suffix}"
        n += 1
    return p


def thumbnail(path: Path) -> Path:
    """Small JPEG preview for the media library (cached next to the file)."""
    thumbs = path.parent / ".thumbs"
    out = thumbs / (path.name + ".jpg")
    if out.exists() and out.stat().st_mtime >= path.stat().st_mtime:
        return out
    thumbs.mkdir(exist_ok=True)
    from .effects.media import VIDEO_EXT, _open
    if path.suffix.lower() in VIDEO_EXT:
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", "1", "-i", str(path), "-frames:v", "1",
                        "-vf", "scale=360:-2", str(out)], capture_output=True)
        if not out.exists():  # clip shorter than 1s
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(path), "-frames:v", "1",
                            "-vf", "scale=360:-2", str(out)], capture_output=True)
    else:
        from PIL import Image
        img = _open(path)
        img.thumbnail((360, 360))
        bg = Image.new("RGB", img.size, (238, 238, 236))  # light checker-free backdrop for transparent art
        bg.paste(img, mask=img.getchannel("A"))
        bg.save(out, "JPEG", quality=82)
    return out


def install_fonts(folder: Path) -> list[str]:
    """Install a client's fonts for this user so Premiere and Motion Studio see them:
    ~/Library/Fonts on a Mac; the per-user Fonts folder (registered, no admin needed) on Windows."""
    if sys.platform == "darwin":
        dest = Path.home() / "Library" / "Fonts"
    elif sys.platform == "win32":
        dest = Path(os.environ["LOCALAPPDATA"]) / "Microsoft" / "Windows" / "Fonts"
    else:
        raise ValueError("Installing fonts works on a Mac or a Windows PC")
    dest.mkdir(parents=True, exist_ok=True)
    done = []
    for f in sorted(folder.glob("*")):
        if f.suffix.lower() in (".ttf", ".otf"):
            shutil.copy2(f, dest / f.name)
            if sys.platform == "win32":
                import winreg
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows NT\CurrentVersion\Fonts",
                                    0, winreg.KEY_SET_VALUE) as key:
                    kind = "OpenType" if f.suffix.lower() == ".otf" else "TrueType"
                    winreg.SetValueEx(key, f"{f.stem} ({kind})", 0, winreg.REG_SZ, str(dest / f.name))
            done.append(f.name)
    return done


def reveal(target: Path) -> None:
    """Show a file (selected) or open a folder in Finder / File Explorer."""
    if sys.platform == "darwin":
        subprocess.run(["open", "-R", str(target)] if target.is_file() else ["open", str(target)])
    elif sys.platform == "win32":
        subprocess.run(["explorer", f"/select,{target}"] if target.is_file() else ["explorer", str(target)])


def longform_list(settings: dict) -> list[dict]:
    out = []
    for client in list_clients(settings):
        for folder in sorted((client / "longform").glob("*/options.json")):
            f = folder.parent
            st = {}
            try:
                st = json.loads((f / jobs.STATUS).read_text()) if (f / jobs.STATUS).exists() else {}
            except json.JSONDecodeError:
                pass
            a = f / "analysis.json"
            summary = {}
            if a.exists():
                try:
                    data = json.loads(a.read_text())
                    summary = {"clips": len(data.get("candidates", [])), "duration": data.get("duration"),
                               "layout": (data.get("layout") or {}).get("layout"),
                               "note": (data.get("layout") or {}).get("note")}
                except json.JSONDecodeError:
                    pass
            mtime = (f / jobs.STATUS).stat().st_mtime if (f / jobs.STATUS).exists() else f.stat().st_mtime
            out.append({"dir": str(f), "name": f.name, "client": client.name, "state": st.get("state"),
                        "step": st.get("step"), "error": st.get("error"), "machine": st.get("machine"),
                        "stalled": st.get("state") == "processing" and time.time() - mtime > 300,
                        "mtime": mtime, **summary})
    out.sort(key=lambda x: x["mtime"], reverse=True)
    return out


def read_json_file(path: Path):
    try:
        return json.loads(path.read_text()) if path.exists() else None
    except json.JSONDecodeError:
        return None


def multicam_list(settings: dict) -> list[dict]:
    out = []
    for client in list_clients(settings):
        for opts in sorted((client / "multicam").glob("*/options.json")):
            f = opts.parent
            st = read_json_file(f / jobs.STATUS) or {}
            res = read_json_file(f / "result.json") or {}
            mtime = (f / jobs.STATUS).stat().st_mtime if (f / jobs.STATUS).exists() else f.stat().st_mtime
            from .multicam.project import media_files
            files = [x.name for x in media_files(f)]
            out.append({"dir": str(f), "name": f.name, "client": client.name, "state": st.get("state"),
                        "step": st.get("step"), "error": st.get("error"), "machine": st.get("machine"),
                        "stalled": st.get("state") == "processing" and time.time() - mtime > 300,
                        "mtime": mtime, "files": files,
                        "switches": res.get("switches"), "length": res.get("length"), "pip": res.get("pip")})
    out.sort(key=lambda x: x["mtime"], reverse=True)
    return out


def transcript_view(job: Path, settings: dict) -> dict:
    """Every transcript word with what AutoCut did to it, for the transcript editor."""
    from .edit import plan_edit
    words = json.loads((job / "transcript.json").read_text())["words"]
    client = load_client(str(job.parent.parent), settings)
    edits = jobs.read_options(job).get("edits") or {}
    duration = (words[-1]["end"] + 1.0) if words else 1.0
    cfg = client.brand["edit"]
    try:
        auto = {r["i"]: r["reason"] for r in plan_edit(words, duration, 30, cfg).removed}
        final = {r["i"]: r["reason"] for r in plan_edit(
            words, duration, 30, cfg, force_remove=set(edits.get("remove", [])),
            force_keep=set(edits.get("keep", [])), fixes=edits.get("fixes")).removed}
    except SystemExit:  # everything cut — show it all as removed
        auto, final = {}, {i: "manual" for i in range(len(words))}
    fixes = edits.get("fixes") or {}
    return {"words": [{"i": i, "word": fixes.get(str(i), w["word"]), "original": w["word"],
                       "start": w["start"], "end": w["end"], "auto": auto.get(i), "cut": final.get(i)}
                      for i, w in enumerate(words)],
            "edits": {"remove": edits.get("remove", []), "keep": edits.get("keep", []), "fixes": fixes}}


def set_effects(brand_file: Path, updates: dict) -> None:
    """Flip effect switches in brand.yaml, keeping the file's comments and layout."""
    from ruamel.yaml import YAML
    from ruamel.yaml.comments import CommentedMap
    from .effects import KEYS
    y = YAML()
    y.preserve_quotes = True
    data = y.load(brand_file.read_text()) or CommentedMap()
    if not isinstance(data.get("effects"), dict):
        data["effects"] = CommentedMap()
    for k, v in updates.items():
        if k not in KEYS:
            raise ValueError(f"unknown effect '{k}'")
        data["effects"][k] = bool(v)
    with brand_file.open("w") as f:
        y.dump(data, f)


def set_caption_style(brand_file: Path, style: str) -> None:
    """Pick the client's caption style in brand.yaml, keeping the file's comments and layout."""
    from ruamel.yaml import YAML
    from ruamel.yaml.comments import CommentedMap
    from .captions import STYLES
    if style not in STYLES:
        raise ValueError(f"unknown caption style '{style}'")
    y = YAML()
    y.preserve_quotes = True
    data = y.load(brand_file.read_text()) or CommentedMap()
    if not isinstance(data.get("captions"), dict):
        data["captions"] = CommentedMap()
    data["captions"]["style"] = style
    with brand_file.open("w") as f:
        y.dump(data, f)


def ensure_data_dir(settings: dict) -> None:
    """First run: create the clients folder and copy in the demo client."""
    mount_share(settings)
    root = clients_dir(settings)
    root.mkdir(parents=True, exist_ok=True)
    demo = root / "demo-roofing-co"
    if not any(root.iterdir()) and (EXAMPLES_DIR / "demo-roofing-co").exists():
        shutil.copytree(EXAMPLES_DIR / "demo-roofing-co", demo)


class App:
    def __init__(self):
        self.settings = load_settings()
        ensure_data_dir(self.settings)
        self.worker = jobs.Worker(self.settings)
        self.lock = threading.Lock()
        self.reels: dict[str, str] = {}  # client slug → "running" | "done" | error text
        from .auth import Auth
        self.auth = Auth(self.settings, clients_dir(self.settings).parent)

    def reload_settings(self):
        self.settings.clear()
        self.settings.update(load_settings())

    def safe_path(self, p: str) -> Path:
        """Only files inside the clients folder (or the Create tab's motion library) may be served."""
        from .mograph.prompt import library_dir
        path = Path(p).resolve()
        from .design.stills import library_dir as design_dir
        for root in (clients_dir(self.settings).resolve(), library_dir(self.settings).resolve(),
                     design_dir(self.settings).resolve()):
            if root == path or root in path.parents:
                return path
        raise PermissionError("outside the AutoCut folders")

    def client_dir(self, slug: str) -> Path:
        if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", slug or ""):
            raise ValueError("bad client id")
        d = clients_dir(self.settings) / slug
        if not (d / "brand.yaml").exists():
            raise FileNotFoundError(f"no client '{slug}'")
        return d

    # ---- API ------------------------------------------------------------
    def state(self) -> dict:
        w = self.worker
        clients = []
        for d in list_clients(self.settings):
            try:
                name = (yaml.safe_load((d / "brand.yaml").read_text()) or {}).get("client", d.name)
            except yaml.YAMLError:
                name = d.name + " (brand.yaml has an error)"
            clients.append({"slug": d.name, "name": name})
        waiting = [{"client": f.parent.parent.name, "file": f.name}
                   for f in jobs.waiting_files(self.settings)]
        return {"version": __version__, "machine": self.settings["machine_name"],
                "worker": {"paused": w.paused, "current": w.current, "queued": w.requests.qsize()},
                "clients": clients, "waiting": waiting, "jobs": jobs.list_jobs(self.settings)}

    def save_brand(self, slug: str, text: str) -> dict:
        d = self.client_dir(slug)
        data = yaml.safe_load(text) or {}  # raises on a syntax error
        if not isinstance(data, dict):
            raise ValueError("brand.yaml must be a set of key: value settings")
        deep_merge(DEFAULT_BRAND, data)
        backup = d / "brand.yaml.bak"
        shutil.copy2(d / "brand.yaml", backup)
        (d / "brand.yaml").write_text(text)
        try:
            client = load_client(str(d), self.settings)
        except SystemExit as e:  # restore the last good version
            shutil.copy2(backup, d / "brand.yaml")
            raise ValueError(str(e))
        return {"checks": checks.check_client(client, self.settings)}

    def machine(self) -> dict:
        import socket
        lan = socket.gethostname().split(".")[0]
        if sys.platform == "darwin":
            r = subprocess.run(["scutil", "--get", "LocalHostName"], capture_output=True, text=True)
            lan = r.stdout.strip() or lan
        return {"checks": checks.doctor(self.settings), "git": git_info(), "root": str(ROOT),
                "os": {"darwin": "mac", "win32": "windows"}.get(sys.platform, "linux"),
                "lan_name": lan if sys.platform == "win32" else f"{lan}.local", "port": self.settings["port"],
                "listen_on_network": self.settings["listen_on_network"],
                "process_jobs": self.settings["process_jobs"],
                "local_settings_path": str(LOCAL_SETTINGS),
                "local_settings": LOCAL_SETTINGS.read_text() if LOCAL_SETTINGS.exists() else "",
                "clients_dir": str(clients_dir(self.settings))}

    def update(self) -> dict:
        from . import updates
        if updates.mode(self.settings) == "feed":
            r = updates.install_latest(self.settings)
            return {"ok": r["ok"], "output": r.get("error") or f"AutoCut {r['version']} is installed. Restart AutoCut.",
                    "restart": r.get("restart", False)}
        if sys.platform == "win32":
            cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(ROOT / "windows" / "update.ps1")]
        else:
            cmd = ["bash", str(ROOT / "mac" / "update.sh")]
        r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=900)
        return {"ok": r.returncode == 0, "output": (r.stdout + r.stderr)[-6000:]}


    def updates_state(self) -> dict:
        from . import content, migrations, updates
        st = updates.check(self.settings)
        cat = content.catalog()
        return {**st, "progress": updates.progress(), "whats_new": migrations.whats_new(),
                "settings": updates.cfg(self.settings), "content": content.summary(),
                "features": [{"name": k, "label": v.get("label", k), "about": v.get("about", ""),
                              "on": content.feature(self.settings, k)} for k, v in (cat.get("features") or {}).items()],
                "engines": cat.get("engines", {}),
                "models": {"local_tiers": cat["ai"]["local"]["tiers"], "claude": list(cat["ai"]["claude"]["models"]),
                           "claude_default": cat["ai"]["claude"]["default"],
                           "compatible_presets": cat["ai"].get("openai_compatible", {}).get("presets", {})}}

    def set_local(self, section: str, values: dict) -> None:
        """Change keys in one section of this computer's settings.yaml (the rest of the file is kept)."""
        data = yaml.safe_load(LOCAL_SETTINGS.read_text()) if LOCAL_SETTINGS.exists() else {}
        data = data if isinstance(data, dict) else {}
        data[section] = {**(data.get(section) or {}), **values}
        LOCAL_SETTINGS.parent.mkdir(parents=True, exist_ok=True)
        LOCAL_SETTINGS.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True))
        self.reload_settings()


ADMIN_ONLY = {"/api/update", "/api/local-settings", "/api/users", "/api/users/add", "/api/users/role",
              "/api/users/remove", "/api/updates/install", "/api/updates/rollback", "/api/updates/settings",
              "/api/restart", "/api/packs/enable", "/api/packs/remove", "/api/packs/install", "/api/packs/upload",
              "/api/features", "/api/accounts/save", "/api/accounts/test", "/api/accounts/remove", "/api/accounts/order",
              "/api/mcp/claude-desktop", "/api/share-stats", "/api/voice/setup"}


def _chunk_file(app: App, q: dict) -> Path:
    uid = q.get("upload_id", "")
    if not re.fullmatch(r"[A-Za-z0-9-]{8,64}", uid):
        raise ValueError("bad upload id")
    d = clients_dir(app.settings).parent / ".uploads"
    d.mkdir(parents=True, exist_ok=True)
    return d / f"{uid}.part"


def _store_chunk(handler, app: App, q: dict) -> dict:
    """One chunk of a big upload (any request through a proxy stays small). Chunks come in order;
    `offset` must match what has arrived so far, so a retried chunk can't be written twice."""
    part = _chunk_file(app, q)
    offset = int(q.get("offset", 0))
    have = part.stat().st_size if part.exists() else 0
    if offset == 0:
        have = 0
        part.unlink(missing_ok=True)
    if offset != have:
        raise ValueError(f"upload out of step (server has {have} bytes, chunk starts at {offset})")
    left = int(handler.headers.get("Content-Length") or 0)
    limit = float((app.settings.get("web") or {}).get("max_upload_gb", 60)) * 2**30
    if offset + left > limit:
        part.unlink(missing_ok=True)
        raise ValueError("That file is bigger than this AutoCut accepts (web.max_upload_gb)")
    with part.open("ab") as f:
        while left > 0:
            chunk = handler.rfile.read(min(1 << 20, left))
            if not chunk:
                raise ValueError("upload interrupted: try again")
            f.write(chunk)
            left -= len(chunk)
    return {"partial": True, "received": part.stat().st_size}


def make_handler(app: App):
    class Handler(BaseHTTPRequestHandler):
        server_version = "AutoCut"

        def log_message(self, fmt, *args):  # keep the console quiet
            pass

        user: dict | None = None
        query: dict = {}

        def end_headers(self):
            # browser security for every response (the dashboard has no third-party content)
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Referrer-Policy", "same-origin")
            self.send_header("Content-Security-Policy",
                             "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; "
                             "style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; "
                             "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
            if self._https():
                self.send_header("Strict-Transport-Security", "max-age=31536000")
            super().end_headers()

        def _https(self) -> bool:
            web = app.settings.get("web") or {}
            return (str(web.get("public_url", "")).startswith("https://") or
                    (web.get("trust_proxy") and self.headers.get("X-Forwarded-Proto") == "https"))

        def _ip(self) -> str:
            if (app.settings.get("web") or {}).get("trust_proxy") and self.headers.get("X-Forwarded-For"):
                return self.headers["X-Forwarded-For"].split(",")[0].strip()
            return self.client_address[0]

        def _local(self) -> bool:
            return self._ip() in ("127.0.0.1", "::1") and not self.headers.get("X-Forwarded-For")

        def _token(self) -> str | None:
            for part in (self.headers.get("Cookie") or "").split(";"):
                k, _, v = part.strip().partition("=")
                if k == COOKIE:
                    return v
            return None

        def _set_cookie(self, token: str, max_age: int):
            flags = "; Secure" if self._https() else ""
            self.send_header("Set-Cookie", f"{COOKIE}={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age={max_age}{flags}")

        def _redirect(self, where: str):
            self.send_response(302)
            self.send_header("Location", where)
            self.send_header("Content-Length", "0")
            self.end_headers()

        def _json(self, data, status=200, cookie: tuple[str, int] | None = None):
            body = json.dumps(data, default=str).encode()
            self.send_response(status)
            if cookie:
                self._set_cookie(*cookie)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _body(self) -> bytes:
            return self.rfile.read(int(self.headers.get("Content-Length") or 0))

        def _receive(self, dest: Path) -> None:
            """Stream the request body to dest via a hidden temp file (watchers never see a partial file).
            A big file arrives in chunks (see _chunk); this is the last one, appended to the earlier ones."""
            part = dest.parent / f".upload-{dest.name}"
            left = int(self.headers.get("Content-Length") or 0)
            earlier = _chunk_file(app, self.query) if "upload_id" in self.query else None
            if left <= 0 and not earlier:
                raise ValueError("empty upload")
            if earlier:
                if not earlier.exists():
                    raise ValueError("upload interrupted: start it again")
                shutil.move(str(earlier), part)
            with part.open("ab" if earlier else "wb") as f:
                while left > 0:
                    chunk = self.rfile.read(min(1 << 20, left))
                    if not chunk:
                        break
                    f.write(chunk)
                    left -= len(chunk)
            if left:
                part.unlink(missing_ok=True)
                raise ValueError("upload interrupted — try again")
            part.replace(dest)

        def _send_file(self, path: Path):
            size = path.stat().st_size
            ctype = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
            start, end = 0, size - 1
            rng = self.headers.get("Range")
            m = re.match(r"bytes=(\d*)-(\d*)", rng or "")
            if m:  # Safari needs byte ranges to play video
                if m.group(1):
                    start = int(m.group(1))
                    end = int(m.group(2)) if m.group(2) else size - 1
                else:
                    start = max(0, size - int(m.group(2)))
                self.send_response(HTTPStatus.PARTIAL_CONTENT)
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            else:
                self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", ctype)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(end - start + 1))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            with path.open("rb") as f:
                f.seek(start)
                left = end - start + 1
                while left > 0:
                    chunk = f.read(min(1 << 20, left))
                    if not chunk:
                        break
                    try:
                        self.wfile.write(chunk)
                    except (BrokenPipeError, ConnectionResetError):
                        return
                    left -= len(chunk)

        def _route(self, method: str):
            u = urlparse(self.path)
            q = {k: v[0] for k, v in parse_qs(u.query).items()}
            p = u.path
            self.query, self.user = q, None
            authn = app.auth
            try:
                # ---- sign-in gate (hosted / require_login) ------------------------------
                if authn.enabled:
                    if method in ("POST", "PUT", "DELETE") and self.headers.get("X-AutoCut") != "1":
                        # every dashboard request sends this header; a form or script on another site can't
                        return self._json({"error": "Blocked: request didn't come from the AutoCut dashboard"}, 403)
                    if method == "GET" and p in ("/login", "/login.html"):
                        return self._send_file(WEB / "login.html")
                    if method == "GET" and p == "/api/setup":
                        return self._json({"needed": bool(authn.setup_code)})
                    if method == "POST" and p in ("/api/login", "/api/setup"):
                        data = json.loads(self._body())
                        if p == "/api/setup":
                            authn.setup_first_admin(data.get("code", ""), data.get("name", ""), data.get("password", ""))
                        try:
                            token = authn.login(data.get("name", ""), data.get("password", ""), self._ip())
                        except Exception as e:
                            return self._json({"error": str(e)}, 401)
                        hours = float((app.settings.get("web") or {}).get("session_hours", 12))
                        return self._json({"ok": True}, cookie=(token, int(hours * 3600)))
                    if not (method == "GET" and p in ("/icon.png", "/api/ping")):
                        self.user = authn.session(self._token())
                        if not self.user:
                            if method == "GET" and p in ("/", "/index.html"):
                                return self._redirect("/login")
                            return self._json({"error": "Please sign in again", "login": True}, 401)
                        if p in ADMIN_ONLY and self.user["role"] != "admin":
                            return self._json({"error": "Only an admin can do that"}, 403)
                        if method != "GET":
                            authn.audit(self.user["name"], self._ip(), f"{method} {p}")
                if method == "GET" and p == "/api/me":
                    return self._json({"auth": authn.enabled, "user": (self.user or {}).get("name"),
                                       "role": (self.user or {}).get("role", "admin"), "local": self._local(),
                                       "os": {"darwin": "mac", "win32": "windows"}.get(sys.platform, "linux")})
                if method == "POST" and p == "/api/logout":
                    authn.logout(self._token())
                    return self._json({"ok": True}, cookie=("", 0))
                # ---- big uploads arrive in chunks; all but the last are stored here --------
                if method == "PUT" and "upload_id" in q and int(q.get("chunk", 0)) < int(q.get("chunks", 1)) - 1:
                    return self._json(_store_chunk(self, app, q))
                # ---- team (admin) ---------------------------------------------------------------
                if method == "GET" and p == "/api/users":
                    return self._json(authn.list_users())
                if method == "POST" and p == "/api/users/add":
                    d = json.loads(self._body())
                    return self._json(authn.add_user(d.get("name", ""), d.get("password", ""), d.get("role", "editor")))
                if method == "POST" and p == "/api/users/role":
                    d = json.loads(self._body())
                    authn.set_role(d["name"], d["role"])
                    return self._json({"ok": True})
                if method == "POST" and p == "/api/users/remove":
                    d = json.loads(self._body())
                    if self.user and d["name"] == self.user["name"]:
                        raise ValueError("You can't remove yourself")
                    authn.remove_user(d["name"])
                    return self._json({"ok": True})
                if method == "POST" and p == "/api/users/password":  # admins: anyone; everyone: themselves
                    d = json.loads(self._body())
                    if self.user and self.user["role"] != "admin" and d.get("name") != self.user["name"]:
                        raise PermissionError("You can only change your own password")
                    authn.set_password(d.get("name") or (self.user or {}).get("name", ""), d.get("password", ""))
                    return self._json({"ok": True})
                if method == "GET" and p in ("/", "/index.html"):
                    return self._send_file(WEB / "index.html")
                if method == "GET" and p == "/icon.png":
                    return self._send_file(ROOT / "mac" / "icon.png")
                if method == "GET" and p == "/api/ping":
                    return self._json({"ok": True})
                if method == "GET" and p == "/api/state":
                    return self._json(app.state())
                if method == "GET" and p == "/files":
                    return self._send_file(app.safe_path(q["path"]))
                if method == "GET" and p == "/api/thumb":
                    return self._send_file(thumbnail(app.safe_path(q["path"])))
                if method == "GET" and p == "/api/log":
                    log = app.safe_path(q["dir"]) / "log.txt"
                    return self._json({"log": log.read_text()[-20000:] if log.exists() else ""})
                if method == "GET" and p == "/api/caption-styles":
                    from .captions import STYLES
                    return self._json([{"id": k, "label": l, "help": h} for k, (l, h) in STYLES.items()])
                if method == "GET" and p == "/api/effects":
                    from .effects import EFFECTS
                    return self._json([{"key": k, "label": l, "help": h} for k, l, h in EFFECTS])
                if method == "GET" and p == "/api/machine":
                    m = app.machine()
                    if self.user and self.user["role"] != "admin":
                        m["local_settings"] = ""  # may hold API keys
                    m["auth"] = authn.enabled
                    return self._json(m)
                m = re.fullmatch(r"/api/client/([a-z0-9-]+)(/[a-z-]+)?", p)
                if m:
                    slug, action = m.group(1), m.group(2) or ""
                    d = app.client_dir(slug)
                    if method == "GET" and action == "":
                        from .effects import resolve
                        client = load_client(str(d), app.settings)
                        proof = d / "ready" / "_style-proof" / f"{slug}-caption-style.mp4"
                        return self._json({"slug": slug, "dir": str(d), "brand": (d / "brand.yaml").read_text(),
                                           "checks": checks.check_client(client, app.settings),
                                           "effects": resolve(client.brand),
                                           "caption_style": client.brand["captions"]["style"],
                                           "motion_pieces": sum(1 for x in client.brand["motion_studio"]["pieces"]
                                                                if client.path(x["spec"]).exists()),
                                           "motion_studio": bool(app.settings.get("motion_studio_path")
                                                                 and Path(app.settings["motion_studio_path"]).expanduser().exists()),
                                           "proof": str(proof) if proof.exists() else None})
                    if method == "PUT" and action == "/effects":
                        set_effects(d / "brand.yaml", json.loads(self._body()))
                        from .effects import resolve
                        return self._json({"effects": resolve(load_client(str(d), app.settings).brand)})
                    if method == "PUT" and action == "/caption-style":
                        set_caption_style(d / "brand.yaml", str(json.loads(self._body()).get("style", "")))
                        return self._json({"caption_style": load_client(str(d), app.settings).brand["captions"]["style"]})
                    if method == "PUT" and action == "/brand":
                        return self._json(app.save_brand(slug, self._body().decode()))
                    if method == "POST" and action == "/style-proof":
                        from .captions import STYLES
                        from .overlays import style_proof
                        client = load_client(str(d), app.settings)
                        work = d / "ready" / "_style-proof"
                        work.mkdir(parents=True, exist_ok=True)
                        try_style = (json.loads(self._body() or b"{}") or {}).get("style")
                        if try_style:  # a sample of another style, without changing the brand kit
                            if try_style not in STYLES:
                                raise ValueError(f"unknown caption style '{try_style}'")
                            client = dataclasses.replace(client, brand={**client.brand, "captions": {
                                **client.brand["captions"], "style": try_style}})
                            out = style_proof(client, work / f"{slug}-caption-{try_style}.mp4", work)
                            return self._json({"proof": str(out)})
                        out = style_proof(client, work / f"{slug}-caption-style.mp4", work)
                        return self._json({"proof": str(out)})
                    if method == "PUT" and action == "/upload":
                        name = safe_name(q.get("name", ""))
                        if Path(name).suffix.lower() not in app.settings["video_extensions"]:
                            raise ValueError(f"{name} isn't a video AutoCut reads (use .mp4, .mov, .m4v, .mkv, .mxf or .webm)")
                        inc = d / "incoming"
                        inc.mkdir(exist_ok=True)
                        dest = unique_path(inc, name)
                        if q.get("options"):  # this upload's effect switches, hook text and media
                            opts = json.loads(q["options"])
                            (inc / (dest.name + jobs.OPTIONS_SUFFIX)).write_text(json.dumps(opts))
                        try:
                            self._receive(dest)  # only once complete does the watcher see it
                        except ValueError:
                            (inc / (dest.name + jobs.OPTIONS_SUFFIX)).unlink(missing_ok=True)
                            raise
                        return self._json({"ok": True, "name": dest.name})
                    if method == "PUT" and action == "/longform":
                        name = safe_name(q.get("name", ""))
                        if Path(name).suffix.lower() not in app.settings["video_extensions"]:
                            raise ValueError(f"{name} isn't a video AutoCut reads")
                        lf = d / "longform"
                        lf.mkdir(exist_ok=True)
                        folder = unique_path(lf, Path(name).stem)
                        folder.mkdir()
                        opts = json.loads(q.get("options") or "{}")
                        (folder / "options.json").write_text(json.dumps(opts, indent=2))
                        self._receive(folder / name)
                        jobs.write_status(folder, state="queued", step="waiting for a free Mac")
                        (folder / ".pending").touch()  # any Mac's worker can now claim it
                        return self._json({"dir": str(folder)})
                    if method == "GET" and action == "/media":
                        from .effects.media import CATEGORIES, library
                        client = load_client(str(d), app.settings)
                        return self._json({"categories": [{"key": k, "label": v["label"], "placeable": v["style"] is not None}
                                                          for k, v in CATEGORIES.items()],
                                           "items": library(client)})
                    if method == "PUT" and action == "/media":
                        from .effects.media import ALLOWED, CATEGORIES
                        cat = q.get("category", "")
                        if cat not in CATEGORIES:
                            raise ValueError("pick a category")
                        name = safe_name(q.get("name", ""))
                        if Path(name).suffix.lower() not in ALLOWED[cat]:
                            raise ValueError(f"{name} can't go in {CATEGORIES[cat]['label']} "
                                             f"(accepts {', '.join(sorted(ALLOWED[cat]))})")
                        folder = d / CATEGORIES[cat]["folder"]
                        folder.mkdir(parents=True, exist_ok=True)
                        dest = unique_path(folder, name)
                        self._receive(dest)
                        return self._json({"ok": True, "rel": dest.relative_to(d).as_posix()})
                    if method == "POST" and action == "/media-tags":
                        from .effects.media import load_tags, save_tags
                        data = json.loads(self._body())
                        client = load_client(str(d), app.settings)
                        if not (d / data["rel"]).resolve().is_relative_to(d.resolve()):
                            raise PermissionError("outside the client folder")
                        tags = load_tags(client)
                        tags[data["rel"]] = data.get("tags", "").strip()
                        if not tags[data["rel"]]:
                            tags.pop(data["rel"])
                        save_tags(client, tags)
                        return self._json({"ok": True})
                    if method == "POST" and action == "/media-delete":
                        rel = json.loads(self._body())["rel"]
                        src = (d / rel).resolve()
                        if not src.is_relative_to((d / "assets").resolve()) or not src.is_file():
                            raise PermissionError("not a media file")
                        trash = d / "assets" / ".trash"
                        trash.mkdir(exist_ok=True)
                        shutil.move(str(src), unique_path(trash, src.name))  # recoverable
                        return self._json({"ok": True})
                    if method == "PUT" and action == "/job-asset":
                        from .effects.media import IMAGE_EXT, VIDEO_EXT
                        name = safe_name(q.get("name", ""))
                        if Path(name).suffix.lower() not in IMAGE_EXT | VIDEO_EXT:
                            raise ValueError(f"{name} isn't an image or video clip")
                        batch = re.sub(r"[^a-z0-9-]", "", q.get("batch", "")) or "misc"
                        folder = d / "assets" / "uploads" / batch
                        folder.mkdir(parents=True, exist_ok=True)
                        dest = unique_path(folder, name)
                        self._receive(dest)
                        return self._json({"file": dest.relative_to(d).as_posix(), "name": dest.name, "path": str(dest)})
                    if method == "POST" and action == "/motion-pack":
                        if app.reels.get(slug) == "running":
                            return self._json({"state": "running"})
                        client = load_client(str(d), app.settings)
                        out = d / "ready" / "_style-proof" / f"{slug}-motion-pack.mp4"
                        out.parent.mkdir(parents=True, exist_ok=True)

                        def build():
                            try:
                                from .mograph.gallery import motion_reel
                                motion_reel(client, out, samples=int(app.settings["motion_blur_samples"]))
                                app.reels[slug] = "done"
                            except Exception as e:
                                app.reels[slug] = f"error: {e}"
                        app.reels[slug] = "running"
                        threading.Thread(target=build, daemon=True).start()
                        return self._json({"state": "running"})
                    if method == "GET" and action == "/motion-pack":
                        out = d / "ready" / "_style-proof" / f"{slug}-motion-pack.mp4"
                        state = app.reels.get(slug) or ("done" if out.exists() else "none")
                        return self._json({"state": state, "path": str(out) if out.exists() else None})
                    if method == "POST" and action == "/ai-image":
                        data = json.loads(self._body())
                        if not data.get("prompt", "").strip():
                            raise ValueError("Describe the image first")
                        from .aiimage import engines as ai_engines
                        if not ai_engines(app.settings):
                            raise ValueError("No AI image engine here: install the local one (This Mac → health check) "
                                             "or connect a ChatGPT or Grok account (This Mac → AI accounts)")
                        client = load_client(str(d), app.settings)
                        key = f"ai:{slug}"

                        def gen():
                            try:
                                from .aiimage import generate
                                p = generate(client, data["prompt"], data.get("style", "illustration"), data.get("shape", "square"),
                                             settings=app.settings, use=data.get("engine", "auto"))
                                app.reels[key] = "done:" + p.name
                            except Exception as e:
                                app.reels[key] = f"error: {e}"
                        app.reels[key] = "running"
                        threading.Thread(target=gen, daemon=True).start()
                        return self._json({"state": "running"})
                    if method == "GET" and action == "/ai-image":
                        return self._json({"state": app.reels.get(f"ai:{slug}", "none")})
                    if method == "POST" and action == "/install-fonts":
                        fonts = install_fonts(d / "assets" / "fonts")
                        return self._json({"installed": fonts})
                if method == "POST" and p == "/api/clients":
                    d = create_client(json.loads(self._body())["name"], app.settings)
                    return self._json({"slug": d.name})
                if method == "POST" and p == "/api/rerun":
                    data = json.loads(self._body())
                    d = app.client_dir(data["client"])
                    video = app.safe_path(data["video"])
                    if not video.exists():
                        raise FileNotFoundError(f"{video.name} is no longer in footage/")
                    job_name = Path(data.get("job") or video.stem).name
                    if data.get("fresh_transcript"):
                        (d / "ready" / job_name / "transcript.json").unlink(missing_ok=True)
                    opts = {k: data[k] for k in ("effects", "hook", "edits", "formats") if k in data}
                    app.worker.request(video, d, job_name=job_name, **opts)
                    jobs.write_status(d / "ready" / job_name, state="queued", machine=app.settings["machine_name"])
                    return self._json({"ok": True})
                if method == "GET" and p == "/api/job/transcript":
                    job = app.safe_path(q["dir"])
                    return self._json(transcript_view(job, app.settings))
                if method == "POST" and p == "/api/job/edits":
                    data = json.loads(self._body())
                    job = app.safe_path(data["dir"])
                    st = json.loads((job / jobs.STATUS).read_text())
                    edits = {"remove": sorted({int(i) for i in data.get("remove", [])}),
                             "keep": sorted({int(i) for i in data.get("keep", [])}),
                             "fixes": {str(k): str(v) for k, v in (data.get("fixes") or {}).items()}}
                    # save now, so reopening the editor shows the changes even before the re-cut runs
                    (job / "options.json").write_text(json.dumps({**jobs.read_options(job), "edits": edits}, indent=2))
                    app.worker.request(Path(st["video"]), job.parent.parent, job_name=job.name, edits=edits)
                    jobs.write_status(job, state="queued")
                    return self._json({"ok": True})
                if method == "POST" and p == "/api/job/export":
                    job = app.safe_path(json.loads(self._body())["dir"])
                    if not (job / "timeline.json").exists():
                        raise ValueError("Re-run this video once first (it was cut by an older AutoCut)")
                    app.worker.request_export(job)
                    jobs.write_status(job, export="queued")
                    return self._json({"ok": True})
                if method == "GET" and p == "/api/dub/languages":
                    from .dub import languages
                    from .sound import voice
                    return self._json({"languages": languages(), "voice": voice.available(app.settings)})
                if method == "POST" and p == "/api/voice/setup":
                    from .sound import voice
                    if not voice.available(app.settings):
                        def fetch():
                            try:
                                voice.setup(app.settings)
                            except Exception as e:  # noqa: BLE001
                                print(f"  ! voice setup: {e}")
                        threading.Thread(target=fetch, daemon=True).start()
                    return self._json({"started": True})
                if method == "POST" and p == "/api/job/dub":
                    from .dub import LANGS
                    data = json.loads(self._body())
                    job = app.safe_path(data["dir"])
                    if not (job / "timeline.json").exists():
                        raise ValueError("Re-run this video once first (it was cut by an older AutoCut)")
                    if data.get("lang") not in LANGS:
                        raise ValueError("Pick a language AutoCut can speak")
                    opts = {"lang": data["lang"], "gender": "female" if data.get("gender") == "female" else "male",
                            "translation": (data.get("translation") or "").strip() or None}
                    app.worker.request_dub(job, opts)
                    jobs.write_status(job, dub="queued", dub_lang=data["lang"])
                    return self._json({"ok": True})
                if method == "POST" and p == "/api/job/remove":
                    job = app.safe_path(json.loads(self._body())["dir"])
                    if job.parent.name != "ready" or not (job / jobs.STATUS).exists():
                        raise PermissionError("not a job folder")
                    trash = job.parent / ".trash"
                    trash.mkdir(exist_ok=True)
                    shutil.move(str(job), unique_path(trash, job.name))  # recoverable
                    return self._json({"ok": True})
                if method == "POST" and p == "/api/waiting/remove":
                    data = json.loads(self._body())
                    d = app.client_dir(data["client"])
                    f = d / "incoming" / Path(data["file"]).name
                    if not f.is_file():
                        raise FileNotFoundError("already picked up by a Mac")
                    trash = d / "incoming" / ".trash"
                    trash.mkdir(exist_ok=True)
                    shutil.move(str(f), unique_path(trash, f.name))
                    (d / "incoming" / (f.name + jobs.OPTIONS_SUFFIX)).unlink(missing_ok=True)
                    return self._json({"ok": True})
                # ---- Create tab -------------------------------------------------------
                if method == "PUT" and p == "/api/create/asset":  # logo, font, graphic, or a transcript/recording
                    from .mograph import customize
                    from .mograph.prompt import library_dir
                    name = safe_name(q.get("name", ""))
                    if Path(name).suffix.lower() not in customize.ALL_EXT:
                        raise ValueError(f"{name}: use a photo or graphic (PNG, JPG, SVG, GIF), a video clip (MP4, MOV), "
                                         "a font (TTF, OTF, WOFF), a transcript (TXT, SRT, VTT) or a recording (MP3, WAV)")
                    up = library_dir(app.settings) / "_uploads"
                    up.mkdir(parents=True, exist_ok=True)
                    dest = unique_path(up, time.strftime("%Y%m%d-%H%M%S-") + name)
                    self._receive(dest)
                    out = customize.describe(dest)
                    if out.get("media"):  # measured now; the AI's read comes from /api/create/media-read
                        from .mograph.media_read import poster, read
                        out["read"] = read(dest, app.settings, use_ai=False)
                        if out["kind"] == "video":
                            out["poster"] = str(poster(dest) or "")
                    return self._json(out)
                if method == "POST" and p == "/api/create/import":  # a graphic or photo from the Graphics tab → Create
                    from .mograph import customize
                    from .mograph.media_read import read
                    from .mograph.prompt import library_dir
                    src = app.safe_path(json.loads(self._body()).get("path", ""))
                    if not src.is_file() or customize.kind_of(src) not in ("image", "video"):
                        raise ValueError("Pick a picture or a video clip")
                    up = library_dir(app.settings) / "_uploads"
                    up.mkdir(parents=True, exist_ok=True)
                    dest = unique_path(up, time.strftime("%Y%m%d-%H%M%S-") + safe_name(src.name))
                    shutil.copy2(src, dest)
                    out = customize.describe(dest)
                    out["role"] = "graphic" if out["kind"] == "image" else out["role"]
                    out["read"] = read(dest, app.settings, use_ai=False)
                    if out["kind"] == "video":
                        from .mograph.media_read import poster
                        out["poster"] = str(poster(dest) or "")
                    return self._json(out)
                if method == "POST" and p == "/api/create/media-read":  # the AI looks at one dropped-in photo or clip
                    from .mograph.media_read import read
                    from .mograph.prompt import library_dir
                    data = json.loads(self._body())
                    path = app.safe_path(data.get("path", ""))
                    if library_dir(app.settings).resolve() not in path.resolve().parents:
                        raise ValueError("That isn't one of the Create tab's uploads")
                    return self._json(read(path, app.settings, use_ai=True,
                                           prefer="cloud" if data.get("use_claude") else "local"))
                if method == "PUT" and p == "/api/create/reference":
                    from .mograph import reference
                    from .mograph.prompt import library_dir
                    name = safe_name(q.get("name", ""))
                    if Path(name).suffix.lower() not in reference.IMAGE_EXT | reference.VIDEO_EXT:
                        raise ValueError(f"{name}: use an image (PNG, JPG) or a video (MP4, MOV) as the reference")
                    refs = library_dir(app.settings) / "_references"
                    refs.mkdir(parents=True, exist_ok=True)
                    folder = unique_path(refs, time.strftime("%Y%m%d-%H%M%S-") + Path(name).stem[:40])
                    folder.mkdir()
                    self._receive(folder / name)
                    result = reference.analyze([folder / name], app.settings,
                                               "cloud" if q.get("use_claude") == "1" else "local")
                    result.update(id=folder.name, file=str(folder / name))
                    reference.save(folder, result)
                    return self._json(result)
                if method == "POST" and p == "/api/create/parse":
                    from .mograph.prompt import library_dir, parse
                    data = json.loads(self._body())
                    ref = None
                    if data.get("reference"):
                        rid = safe_name(data["reference"])
                        ref = read_json_file(library_dir(app.settings) / "_references" / rid / "reference.json")
                    from .mograph import customize
                    assets = [{**a, "path": str(app.safe_path(a["path"]))} for a in data.get("assets") or []
                              if isinstance(a, dict) and a.get("path")]
                    spec = parse(data.get("prompt", ""), app.settings, ref, customize.media(assets, app.settings))
                    spec["client"] = data.get("client") or None
                    return self._json(spec)
                if method == "POST" and p == "/api/create/render":
                    from .mograph.prompt import SIZES, new_item
                    from .mograph.templates import TEMPLATES
                    from .mograph import hyper
                    spec = json.loads(self._body())
                    hf = hyper.available(app.settings)
                    from .mograph.library import LIB_TEMPLATES
                    if spec.get("template") not in TEMPLATES and spec.get("template") != "music" and \
                            not (spec.get("template") in {"custom", "transcript"} | LIB_TEMPLATES and hf):
                        raise ValueError("pick a graphic type")
                    if spec.get("template") == "custom" and not (spec.get("params") or {}).get("brief"):
                        raise ValueError("describe the custom graphic")
                    spec["assets"] = [{**a, "path": str(app.safe_path(a["path"]))} for a in spec.get("assets") or []
                                      if isinstance(a, dict) and a.get("path")]
                    if spec.get("template") == "transcript":
                        from .mograph import customize
                        from .mograph.prompt import library_dir
                        params = spec["params"] = dict(spec.get("params") or {})
                        if params.get("text") and not params.get("source"):  # a pasted script
                            up = library_dir(app.settings) / "_uploads"
                            up.mkdir(parents=True, exist_ok=True)
                            src = unique_path(up, time.strftime("%Y%m%d-%H%M%S-") + "script.txt")
                            src.write_text(str(params.pop("text"))[:60000], encoding="utf-8")
                            params["source"] = str(src)
                        if not params.get("source"):
                            raise ValueError("add a transcript, a script, or the recording")
                        params["source"] = str(app.safe_path(params["source"]))
                        if customize.kind_of(Path(params["source"])) not in ("transcript", "audio", "video"):
                            raise ValueError("the source must be a transcript, script or recording")
                        params["style"] = params.get("style") if params.get("style") in ("explainer", "effects") else "kinetic"
                        if params["style"] in ("explainer", "effects") and customize.kind_of(Path(params["source"])) != "video":
                            raise ValueError(f"the {'explainer' if params['style'] == 'explainer' else 'effects edit'} style needs the speaker's video (MP4 or MOV)")
                        params.pop("text", None)
                        spec["formats"] = ["mp4"]
                    if spec.get("template") == "music":
                        params = spec["params"] = dict(spec.get("params") or {})
                        params["seconds"] = max(5.0, min(600.0, float(params.get("seconds") or 30)))
                        spec["sizes"], spec["formats"] = ["landscape"], ["wav"]
                    if spec.get("template") in ("storyboard", "lookbook"):
                        from .mograph.library.elements import LAYOUTS
                        params = spec["params"] = dict(spec.get("params") or {})
                        scenes = []
                        for sc in params.get("scenes") or []:
                            if isinstance(sc, dict) and sc.get("kind") in LAYOUTS:
                                scenes.append({"kind": sc["kind"], "layout": str(sc.get("layout") or ""),
                                               "params": {str(k): v for k, v in (sc.get("params") or {}).items()},
                                               "dur": max(0.8, min(15.0, float(sc.get("dur") or 3)))})
                        params["scenes"] = scenes[:30]
                        if spec["template"] == "storyboard" and not scenes:
                            raise ValueError("plan the storyboard first")
                        spec["formats"] = ["mp4"]
                    spec["engine"] = spec.get("engine") if spec.get("engine") in ("hyperframes", "classic") and hf \
                        else ("hyperframes" if hf else "classic")
                    spec["sizes"] = [s for s in spec.get("sizes", []) if s in SIZES] or ["vertical"]
                    spec["formats"] = [f for f in spec.get("formats", []) if f in ("mov", "webm", "mp4", "gif")] or ["mov"]
                    spec["speed"] = max(0.5, min(2.0, float(spec.get("speed") or 1.0)))
                    if spec.get("client"):
                        app.client_dir(spec["client"])  # validates
                    item = new_item(spec, app.settings)
                    app.worker.request_motion(item)
                    return self._json({"dir": str(item)})
                if method == "POST" and p in ("/api/create/studio", "/api/create/rerender"):
                    from .mograph import hyper
                    data = json.loads(self._body())
                    item = app.safe_path(data["dir"])
                    if not (item / "spec.json").exists():
                        raise PermissionError("not a motion graphic")
                    if p == "/api/create/rerender":
                        (item / ".rerender").touch()
                        app.worker.request_motion(item)
                        return self._json({"ok": True})
                    if not self._local():
                        raise PermissionError("HyperFrames Studio opens on the computer running AutoCut")
                    size = safe_name(data.get("project") or "")
                    project = item / f"hf-{size}" if size else next(iter(sorted(item.glob("hf-*"))), None)
                    if not project or not (project / "index.html").exists():
                        raise ValueError("This graphic has no HyperFrames project (made with the classic engine)")
                    return self._json({"url": hyper.studio(project, app.settings)})
                if method == "POST" and p == "/api/report":
                    from . import report
                    from .mograph.prompt import library_dir
                    data = json.loads(self._body())
                    job = app.safe_path(data["job"]) if data.get("job") else None
                    who = (self.user or {}).get("name")
                    text = (f"Reported by: {who}\n\n" if who else "") + str(data.get("text", ""))[:20000]
                    if self._local():  # on this computer: straight to the Desktop, shown in Finder / File Explorer
                        out = report.build(app.settings, text, job=job)
                        reveal(out)
                        return self._json({"path": str(out), "local": True})
                    out = report.build(app.settings, text, library_dir(app.settings) / "_reports", job=job)
                    return self._json({"path": str(out), "local": False})
                if method == "POST" and p == "/api/strategist":
                    from . import marketing
                    data = json.loads(self._body())
                    brand = load_client(str(app.client_dir(data["client"])), app.settings).brand if data.get("client") else None
                    return self._json(marketing.strategist(str(data.get("question", ""))[:4000], app.settings, brand,
                                                           data.get("action") or None,
                                                           "cloud" if data.get("use_claude") else "local"))
                # ---- Graphics tab (still designs) -----------------------------------------------
                if p.startswith("/api/design/"):
                    from .design import stills
                    from .mograph import hyper
                    if method == "GET" and p == "/api/design/info":
                        return self._json({"ready": hyper.available(app.settings),
                                           "templates": {k: {"label": v[0], "fields": [list(f) for f in v[1]]}
                                                         for k, v in stills.TEMPLATES.items()},
                                           "sizes": {k: v[1] for k, v in stills.SIZES.items()}, "styles": stills.STYLES})
                    if method == "GET" and p == "/api/design/list":
                        return self._json(stills.list_items(app.settings))
                    if method == "POST" and p == "/api/design/magic":
                        data = json.loads(self._body())
                        brand = load_client(str(app.client_dir(data["client"])), app.settings).brand if data.get("client") else None
                        assets = [{"path": str(app.safe_path(a["path"])), "role": a.get("role", "photo")}
                                  for a in data.get("assets") or [] if a.get("path")]
                        return self._json(stills.magic_design(data.get("prompt", ""), app.settings, brand, assets))
                    if method == "POST" and p == "/api/design/ai-image":  # an AI photo / illustration to design with
                        data = json.loads(self._body())
                        if not str(data.get("prompt", "")).strip():
                            raise ValueError("Describe the image first")
                        from .aiimage import engines as ai_engines
                        if not ai_engines(app.settings):
                            raise ValueError("No AI image engine here: install the local one (This Mac → health check) "
                                             "or connect a ChatGPT or Grok account (This Mac → AI accounts)")
                        from .mograph.prompt import brand_client
                        client = brand_client({"client": data.get("client") or None}, app.settings)
                        up = stills.library_dir(app.settings) / "_uploads"
                        job = os.urandom(4).hex()

                        def gen():
                            try:
                                from .aiimage import generate
                                from .design import assets as uploads
                                p_ = generate(client, data["prompt"], data.get("style", "photo"), data.get("shape", "square"),
                                              settings=app.settings, use=data.get("engine", "auto"), folder=up)
                                app.reels[f"dai:{job}"] = {"state": "done", "asset": uploads.describe(p_)}
                            except Exception as e:  # noqa: BLE001
                                app.reels[f"dai:{job}"] = {"state": "error", "error": str(e)[:300]}
                        app.reels[f"dai:{job}"] = {"state": "running"}
                        threading.Thread(target=gen, daemon=True).start()
                        return self._json({"job": job, "state": "running"})
                    if method == "GET" and p == "/api/design/ai-image":
                        return self._json(app.reels.get(f"dai:{safe_name(q.get('job', ''))}") or {"state": "none"})
                    if method == "PUT" and p == "/api/design/upload":  # a photo (or a video to take a frame from)
                        name = safe_name(q.get("name", ""))
                        ext = Path(name).suffix.lower()
                        if ext not in (".jpg", ".jpeg", ".png", ".webp", ".heic", ".mp4", ".mov", ".m4v"):
                            raise ValueError("Use a photo (JPG, PNG) or a video (MP4, MOV)")
                        up = stills.library_dir(app.settings) / "_uploads"
                        up.mkdir(parents=True, exist_ok=True)
                        dest = unique_path(up, time.strftime("%Y%m%d-%H%M%S-") + name)
                        self._receive(dest)
                        if ext in (".mp4", ".mov", ".m4v"):
                            dest = stills.thumbnail_from_video(dest, dest.with_suffix(".jpg"))
                        from .design import assets as uploads
                        try:
                            return self._json(uploads.describe(dest))
                        except Exception:  # an image PIL can't read (e.g. HEIC without the plugin)
                            return self._json({"path": str(dest), "role": "photo", "colors": []})
                    if method == "POST" and p == "/api/design/csv":
                        data = json.loads(self._body())
                        return self._json({"rows": stills.rows_from_csv(data.get("csv", ""), data["template"])})
                    if method == "POST" and p == "/api/design/render":
                        spec = json.loads(self._body())
                        if spec.get("template") not in stills.TEMPLATES and spec.get("template") != "custom":
                            raise ValueError("pick a design")
                        spec["sizes"] = [x for x in spec.get("sizes", []) if x in stills.SIZES] or ["post"]
                        spec["styles"] = [x for x in spec.get("styles", []) if x in stills.STYLES] or ["bold"]
                        from .design.assets import ROLES as ASSET_ROLES
                        spec["assets"] = [{"path": str(app.safe_path(a["path"])),
                                           "role": a.get("role") if a.get("role") in ASSET_ROLES else "photo"}
                                          for a in spec.get("assets") or [] if a.get("path")][:12]
                        for row in [spec.get("fields") or {}] + list(spec.get("rows") or []):
                            if row.get("photo"):
                                row["photo"] = str(app.safe_path(row["photo"]))
                        if spec.get("client"):
                            app.client_dir(spec["client"])  # validates
                        item = stills.new_item(spec, app.settings)
                        app.worker.request_design(item)
                        return self._json({"dir": str(item)})
                    if method == "POST" and p in ("/api/design/remove", "/api/design/rerender", "/api/design/studio"):
                        data = json.loads(self._body())
                        item = app.safe_path(data["dir"])
                        if not (item / "spec.json").exists() or stills.library_dir(app.settings).resolve() not in item.parents:
                            raise PermissionError("not a graphic")
                        if p.endswith("remove"):
                            shutil.rmtree(item)
                            return self._json({"ok": True})
                        if p.endswith("rerender"):
                            (item / ".rerender").touch()
                            app.worker.request_design(item)
                            return self._json({"ok": True})
                        if not self._local():
                            raise PermissionError("HyperFrames Studio opens on the computer running AutoCut")
                        project = item / f"hf-{safe_name(data.get('project') or '')}"
                        if not (project / "index.html").exists():
                            raise ValueError("no HyperFrames project for that size")
                        return self._json({"url": hyper.studio(project, app.settings)})
                if method == "GET" and p == "/api/create/info":
                    from .mograph import hyper
                    return self._json({"hyperframes": hyper.available(app.settings)})
                # ---- motion library: looks, layouts, storyboards, each client's style DNA -------------------
                if method == "GET" and p == "/api/library/info":
                    from .mograph import library
                    client = load_client(str(app.client_dir(q["client"])), app.settings) if q.get("client") else None
                    return self._json(library.info(client, app.settings))
                # ---- music and sound ---------------------------------------------------------------------
                if method == "GET" and p == "/api/sound/info":
                    from .sound import aimusic, composer, director, sfx
                    client = load_client(str(app.client_dir(q["client"])), app.settings) if q.get("client") else None
                    return self._json({"styles": [{"key": k, "name": v["name"], "mood": v["mood"]} for k, v in composer.STYLES.items()],
                                       "flavours": list(sfx.FLAVOURS), "keys": director.KEY_LIST,
                                       "identity": director.identity(client, app.settings) if client else None,
                                       "ai": aimusic.status(app.settings)})
                if method == "POST" and p == "/api/sound/identity":
                    from .sound import composer, director, sfx
                    data = json.loads(self._body())
                    client = load_client(str(app.client_dir(data["client"])), app.settings)
                    d = director.identity(client, app.settings)
                    if data.get("shuffle"):
                        d = director.assign(client, app.settings, shuffle=int(d.get("shuffle", 0)) + 1)
                    if data.get("style") in composer.STYLES:
                        d["style"] = data["style"]
                    if data.get("key") in director.KEY_LIST:
                        d["key"] = data["key"]
                    if data.get("flavour") in sfx.FLAVOURS:
                        d["flavour"] = data["flavour"]
                    return self._json(director.save(client, d))
                if method == "GET" and p == "/api/library/registry":
                    from .mograph.library import registry
                    return self._json(registry.search(q.get("q", ""), 12) if q.get("q") else [])
                if method == "GET" and p == "/api/library/overview":
                    from .mograph.library import dna
                    return self._json(dna.overview(app.settings))
                if method == "POST" and p == "/api/library/dna":
                    from .mograph.library import dna, looks
                    from .mograph.library.elements import LAYOUTS
                    data = json.loads(self._body())
                    client = load_client(str(app.client_dir(data["client"])), app.settings)
                    d = dna.get(client, app.settings)
                    if data.get("shuffle"):
                        d = dna.assign(client, app.settings, shuffle=int(d.get("shuffle", 0)) + 1)
                    if data.get("look") in looks.LOOKS:
                        d["look"] = data["look"]
                    for kind, order in (data.get("layouts") or {}).items():
                        if kind in LAYOUTS and isinstance(order, list):
                            first = [x for x in order if x in LAYOUTS[kind]]
                            d["layouts"][kind] = first + [x for x in d["layouts"].get(kind, LAYOUTS[kind]) if x not in first]
                    if data.get("transition") in LAYOUTS["transition"]:
                        d["transition"] = data["transition"]
                    from .mograph.feel import FEELS
                    if "feel" in data:
                        if data["feel"] in FEELS:
                            d["feel"] = data["feel"]
                        else:
                            d.pop("feel", None)  # back to the look's own
                    if "brand_fonts" in data:
                        d["brand_fonts"] = bool(data["brand_fonts"])
                    return self._json(dna.save(client, d))
                if method == "POST" and p == "/api/library/plan":
                    from .mograph.library import dna, storyboards
                    from .mograph.prompt import brand_client
                    data = json.loads(self._body())
                    if data.get("recipe") not in storyboards.RECIPES:
                        raise ValueError("pick a storyboard")
                    if data.get("client"):
                        app.client_dir(data["client"])
                    client = brand_client({"client": data.get("client") or None}, app.settings)
                    use_ai = data.get("use_ai", True) is not False
                    from .mograph import customize
                    assets = [{**a, "path": str(app.safe_path(a["path"]))} for a in data.get("assets") or []
                              if isinstance(a, dict) and a.get("path")]
                    return self._json(storyboards.plan(data["recipe"], str(data.get("brief", ""))[:4000], client,
                                                       app.settings if use_ai else None, dna.get(client, app.settings),
                                                       customize.media(assets, app.settings)))
                if method == "GET" and p == "/api/create/list":
                    from .mograph.prompt import list_items
                    return self._json(list_items(app.settings))
                if method == "POST" and p == "/api/create/remove":
                    item = app.safe_path(json.loads(self._body())["dir"])
                    if not (item / "spec.json").exists():
                        raise PermissionError("not a motion graphic")
                    shutil.rmtree(item)
                    return self._json({"ok": True})
                # ---- post copy (titles, captions, hashtags, chapters) -------------------
                if method == "GET" and p == "/api/job/package":  # "Download for Premiere"
                    from .package import package
                    job = app.safe_path(q["dir"])
                    if not (job / "timeline.json").exists():
                        raise FileNotFoundError("This job isn't finished yet")
                    self.send_response(200)
                    self.send_header("Content-Type", "application/zip")
                    self.send_header("Content-Disposition", f'attachment; filename="{safe_name(job.name)}.zip"')
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    self.close_connection = True  # streamed without a length; the end of the connection ends it
                    try:
                        package(job, self.wfile)
                    except (BrokenPipeError, ConnectionResetError):
                        pass
                    return
                if method == "GET" and p == "/api/job/copy":
                    job = app.safe_path(q["dir"])
                    return self._json(read_json_file(job / "copy.json") or {})
                if method == "POST" and p == "/api/job/copy":
                    from . import marketing
                    data = json.loads(self._body())
                    job = app.safe_path(data["dir"])
                    src = read_json_file(job / "copy-source.json")
                    if not src:
                        raise ValueError("This video was cut before post copy existed. Re-run it to get post copy.")
                    client_dir = job.parent.parent
                    brand = load_client(str(client_dir), app.settings).brand
                    pack = marketing.post_copy(src["words"], brand, app.settings, src.get("kind", "short"),
                                               src.get("title", ""), "cloud" if data.get("use_claude") else "local")
                    marketing.write_copy(job, pack)
                    return self._json(pack)
                # ---- the AI brain -----------------------------------------------------
                if method == "GET" and p == "/api/ai":
                    from . import brain
                    return self._json(brain.status(app.settings))
                # ---- projects: several files (or a dropped folder) = one project -------
                if method == "POST" and p == "/api/project/new":
                    data = json.loads(self._body())
                    kind = data.get("kind")
                    if kind not in ("longform", "multicam"):
                        raise ValueError("kind must be longform or multicam")
                    d = app.client_dir(data.get("client", ""))
                    base = d / kind
                    base.mkdir(exist_ok=True)
                    folder = unique_path(base, safe_name(data.get("name") or "project").rsplit(".", 1)[0] or "project")
                    folder.mkdir()
                    (folder / "options.json").write_text(json.dumps(data.get("options") or {}, indent=2))
                    jobs.write_status(folder, state="uploading", step="uploading")
                    return self._json({"dir": str(folder)})
                if method == "PUT" and p == "/api/project/upload":
                    folder = app.safe_path(q["dir"])
                    if folder.parent.name not in ("longform", "multicam"):
                        raise PermissionError("not a project")
                    name = safe_name(q.get("name", ""))
                    from .multicam.project import AUDIO_EXT
                    allowed = set(app.settings["video_extensions"]) | (AUDIO_EXT if folder.parent.name == "multicam" else set())
                    if Path(name).suffix.lower() not in allowed:
                        raise ValueError(f"{name} isn't a file AutoCut reads here")
                    self._receive(unique_path(folder, name))
                    return self._json({"ok": True})
                if method == "POST" and p == "/api/project/start":
                    folder = app.safe_path(json.loads(self._body())["dir"])
                    if folder.parent.name not in ("longform", "multicam"):
                        raise PermissionError("not a project")
                    if not any(f.is_file() and not f.name.startswith(".") and f.name not in ("options.json", jobs.STATUS)
                               for f in folder.iterdir()):
                        raise ValueError("nothing was uploaded to this project")
                    jobs.write_status(folder, state="queued", step="waiting for a free Mac", error=None)
                    (folder / ".pending").touch()  # any Mac's worker can now claim it
                    return self._json({"ok": True})
                # ---- Multicam tab -----------------------------------------------------
                if method == "GET" and p == "/api/multicam":
                    return self._json(multicam_list(app.settings))
                if method == "GET" and p == "/api/multicam/detail":
                    from .multicam.project import ROLES, options
                    folder = app.safe_path(q["dir"])
                    res = read_json_file(folder / "result.json")
                    job = Path(res["job"]) if res and res.get("job") else None
                    preview = next(job.glob("*preview.mp4"), None) if job and job.exists() else None
                    xml = next(job.glob("*AutoCut.xml"), None) if job and job.exists() else None
                    return self._json({"dir": str(folder), "options": options(folder), "roles": ROLES,
                                       "analysis": read_json_file(folder / "analysis.json"), "result": res,
                                       "preview": str(preview) if preview else None, "xml": str(xml) if xml else None,
                                       "job": str(job) if job else None})
                if method == "POST" and p == "/api/multicam/edit":
                    data = json.loads(self._body())
                    folder = app.safe_path(data["dir"])
                    if folder.parent.name != "multicam":
                        raise PermissionError("not a multicam project")
                    from .multicam.project import options
                    opts = {**options(folder), **(data.get("options") or {})}
                    (folder / "options.json").write_text(json.dumps(opts, indent=2))
                    for old in folder.glob(".claimed-*"):
                        old.unlink(missing_ok=True)
                    jobs.write_status(folder, state="queued", step="waiting for a free Mac", error=None)
                    (folder / ".pending").touch()
                    return self._json({"ok": True})
                # ---- Clips tab --------------------------------------------------------
                if method == "GET" and p == "/api/longform":
                    return self._json(longform_list(app.settings))
                if method == "GET" and p == "/api/longform/detail":
                    folder = app.safe_path(q["dir"])
                    a = folder / "analysis.json"
                    return self._json(json.loads(a.read_text()) if a.exists() else {})
                if method == "POST" and p == "/api/longform/make":
                    data = json.loads(self._body())
                    folder = app.safe_path(data["dir"])
                    analysis = json.loads((folder / "analysis.json").read_text())
                    client_dir = folder.parent.parent
                    inc = client_dir / "incoming"
                    inc.mkdir(exist_ok=True)
                    made = []
                    for c in data.get("clips", []):
                        start, end = float(c["start"]), float(c["end"])
                        # which video of the project (a folder can hold several)
                        cand = next((x for x in analysis["candidates"] if x.get("id") == c.get("id")), {})
                        source = cand.get("source") or c.get("source") or analysis["source"]
                        part = next((x for x in analysis.get("parts", []) if x["source"] == source), None)
                        if not 0 <= start < end <= (part or analysis)["duration"] + 1:
                            raise ValueError(f"clip {c.get('title', '')}: start/end out of range")
                        name = f"{folder.name}-clip{int(c.get('id', len(made) + 1)):02d}"
                        spec = {"name": name, "source": source,
                                "transcript": cand.get("transcript") or str(folder / "transcript.json"),
                                "start": start, "end": end, "layout": c.get("layout", "auto"),
                                "detect": cand.get("detect") or analysis.get("layout") or {}, "hook": c.get("title", ""),
                                "formats": [f for f in data.get("formats", ["vertical"]) if f in ("vertical", "square", "portrait", "landscape")] or ["vertical"],
                                "effects": data.get("effects")}
                        dest = unique_path(inc, name + ".clip.json")
                        tmp = inc / f".upload-{dest.name}"
                        tmp.write_text(json.dumps(spec, indent=2))
                        tmp.replace(dest)
                        made.append(name)
                    return self._json({"queued": made})
                if method == "POST" and p in ("/api/longform/retry", "/api/multicam/retry"):
                    folder = app.safe_path(json.loads(self._body())["dir"])
                    if folder.parent.name not in ("longform", "multicam"):
                        raise PermissionError("not a project")
                    for old in folder.glob(".claimed-*"):
                        old.unlink(missing_ok=True)
                    jobs.write_status(folder, state="queued", step="waiting for a free Mac", error=None)
                    (folder / ".pending").touch()
                    return self._json({"ok": True})
                if method == "POST" and p in ("/api/longform/remove", "/api/multicam/remove"):
                    folder = app.safe_path(json.loads(self._body())["dir"])
                    if folder.parent.name not in ("longform", "multicam"):
                        raise PermissionError("not a long video or multicam project")
                    trash = folder.parent / ".trash"
                    trash.mkdir(exist_ok=True)
                    shutil.move(str(folder), unique_path(trash, folder.name))
                    return self._json({"ok": True})
                if method == "GET" and p == "/api/stats":
                    return self._json(jobs.stats(app.settings))
                if method == "POST" and p == "/api/reveal":
                    if not self._local():
                        raise PermissionError("Opening folders only works on the computer running AutoCut")
                    target = app.safe_path(json.loads(self._body())["path"])
                    reveal(target)
                    return self._json({"ok": True})
                if method == "POST" and p == "/api/pause":
                    app.worker.paused = bool(json.loads(self._body())["paused"])
                    return self._json({"paused": app.worker.paused})
                if method == "PUT" and p == "/api/local-settings":
                    text = self._body().decode()
                    yaml.safe_load(text)
                    LOCAL_SETTINGS.parent.mkdir(parents=True, exist_ok=True)
                    LOCAL_SETTINGS.write_text(text)
                    app.reload_settings()
                    return self._json({"ok": True})
                if method == "POST" and p == "/api/update":
                    return self._json(app.update())
                # ---- people's own AI accounts (accounts.py) and the MCP connector (mcp.py) ------------------
                if method == "POST" and p in ("/api/accounts/save", "/api/accounts/test", "/api/accounts/remove"):
                    from . import accounts, brain
                    d = json.loads(self._body())
                    pid = d.get("id")
                    if pid not in ("claude", *accounts.IDS):
                        raise ValueError("unknown account")
                    if p.endswith("save"):
                        vals = {}
                        if str(d.get("key") or "").strip():
                            vals[f"{pid}_api_key"] = str(d["key"]).strip()
                        if d.get("model") is not None:
                            vals[f"{pid}_model"] = str(d["model"]).strip() or "auto"
                        if d.get("limit") is not None:
                            vals[f"{pid}_monthly_limit_usd"] = max(0.0, float(d["limit"]))
                        app.set_local("ai", vals)
                        return self._json(brain.status(app.settings))
                    if p.endswith("remove"):
                        app.set_local("ai", {f"{pid}_api_key": ""})
                        return self._json(brain.status(app.settings))
                    if pid == "claude":
                        ok, why = brain.claude_available(app.settings)
                        out = brain._ask_claude(app.settings, "Reply with the single word: ready", "Are you ready?", None, None) if ok else None
                        return self._json({"ok": bool(out), "model": brain.cfg(app.settings)["claude_model"],
                                           "error": "" if out else (why or "Claude didn't answer (check the key and credit)")})
                    return self._json(accounts.test(app.settings, pid))
                if method == "POST" and p == "/api/accounts/order":
                    order = [x for x in json.loads(self._body()).get("order", []) if x in ("claude", "chatgpt", "grok")]
                    app.set_local("ai", {"cloud_order": order or ["claude", "chatgpt", "grok"]})
                    from . import brain
                    return self._json(brain.status(app.settings))
                if method == "GET" and p == "/api/mcp":
                    from . import mcp
                    return self._json(mcp.info(app.settings))
                if method == "POST" and p == "/api/mcp/claude-desktop":
                    from . import mcp
                    return self._json(mcp.install_claude_desktop())
                # ---- brand kit from a website (brandscan.py) -----------------------------------------------
                if method == "POST" and p == "/api/clients/scan":
                    from . import brandscan
                    data = json.loads(self._body())
                    sid = time.strftime("%Y%m%d-%H%M%S-") + os.urandom(3).hex()
                    work = clients_dir(app.settings) / "_scans" / sid
                    out = brandscan.scan(str(data.get("url", "")), app.settings, work, use_ai=data.get("ai", True) is not False)
                    (work / "proposal.json").write_text(json.dumps(out, indent=1))
                    return self._json({**out, "id": sid})
                if method == "POST" and p == "/api/clients/from-scan":
                    from . import brandscan
                    data = json.loads(self._body())
                    sid = str(data.get("id", ""))
                    if not re.fullmatch(r"[0-9]{8}-[0-9]{6}-[0-9a-f]{6}", sid):
                        raise ValueError("unknown scan")
                    work = clients_dir(app.settings) / "_scans" / sid
                    saved = json.loads((work / "proposal.json").read_text())
                    edits = data.get("proposal") or {}
                    prop = {**saved, **{k: v for k, v in edits.items() if k in ("name", "colors", "fonts", "marketing", "cta",
                                                                                 "vocabulary", "hashtags")}}
                    prop["fonts"] = {**(saved.get("fonts") or {}), **(edits.get("fonts") or {}), "files": (saved.get("fonts") or {}).get("files", [])}
                    prop["logo"], prop["logo_svg"] = saved.get("logo", ""), saved.get("logo_svg", "")  # only files the scan made
                    d = brandscan.create(prop, app.settings)
                    shutil.rmtree(work, ignore_errors=True)
                    return self._json({"slug": d.name})
                # ---- results and first run (results.py, onboarding.py) -------------------------------------
                if method == "GET" and p == "/api/results":
                    from . import results
                    return self._json(results.month(app.settings, q.get("month") or None))
                if method == "GET" and p == "/api/results/popup":
                    from . import results
                    return self._json({"summary": results.popup(app.settings)})
                if method == "POST" and p == "/api/results/seen":
                    from . import results
                    results.seen(str(json.loads(self._body()).get("month", "")))
                    return self._json({"ok": True})
                if method == "GET" and p == "/api/share-stats":
                    from . import results, stats
                    return self._json({**stats.info(app.settings), "preview": stats.row(app.settings, results._prev(time.strftime("%Y-%m")))})
                if method == "POST" and p == "/api/share-stats":
                    from . import stats
                    d = json.loads(self._body())
                    stats.consent(bool(d.get("share")), bool(d.get("include_name")), str(d.get("agency") or ""))
                    return self._json(stats.info(app.settings))
                if method == "GET" and p == "/api/onboarding":
                    from . import onboarding
                    return self._json(onboarding.info(app.settings))
                if method == "POST" and p == "/api/onboarding":
                    from . import onboarding
                    d = json.loads(self._body())
                    onboarding.update(d.get("welcomed"), d.get("hidden"))
                    return self._json(onboarding.info(app.settings))
                # ---- this computer (hardware.py) ----------------------------------------------------------
                if method == "GET" and p == "/api/hardware":
                    from . import hardware
                    return self._json(hardware.summary(app.settings))
                if method == "POST" and p == "/api/hardware/benchmark":
                    from . import hardware
                    hardware.benchmark(app.settings)
                    return self._json(hardware.summary(app.settings))
                # ---- updates, content packs, experiments (updates.py, content.py) ---------------------------
                if method == "GET" and p == "/api/updates":
                    return self._json(app.updates_state())
                if method == "GET" and p == "/api/updates/progress":
                    from . import updates
                    return self._json(updates.progress())
                if method == "POST" and p == "/api/updates/check":
                    from . import updates
                    updates.check(app.settings, force=True)
                    return self._json(app.updates_state())
                if method == "POST" and p == "/api/updates/install":
                    from . import updates
                    if updates.progress().get("state") in ("download", "unpack", "packages", "selftest", "swap"):
                        raise ValueError("an update is already being installed")
                    updates._progress.update(state="download", message="Starting…")
                    threading.Thread(target=updates.install_latest, args=(app.settings,), daemon=True).start()
                    return self._json({"ok": True, "started": True})
                if method == "POST" and p == "/api/updates/rollback":
                    from . import updates
                    return self._json(updates.rollback(app.settings, json.loads(self._body() or b"{}").get("id")))
                if method == "POST" and p == "/api/updates/settings":
                    d = json.loads(self._body())
                    vals = {k: d[k] for k in ("feed_url", "mirrors", "channel", "check") if k in d}
                    if "mirrors" in vals and not (isinstance(vals["mirrors"], list) and all(isinstance(x, str) for x in vals["mirrors"])):
                        raise ValueError("mirrors is a list of addresses")
                    if "channel" in vals and vals["channel"] not in ("stable", "beta"):
                        raise ValueError("channel is stable or beta")
                    app.set_local("updates", vals)
                    return self._json(app.updates_state())
                if method == "POST" and p == "/api/restart":
                    from . import updates
                    if app.worker.current and not json.loads(self._body() or b"{}").get("force"):
                        raise ValueError(f"AutoCut is working on {app.worker.current.get('video', 'a job')}. Restart when it's done "
                                         "(the queue carries on after the restart).")
                    updates.restart()
                    return self._json({"ok": True})
                if method == "POST" and p == "/api/whats-new/dismiss":
                    from . import migrations
                    migrations.dismiss_whats_new()
                    return self._json({"ok": True})
                if method == "POST" and p == "/api/packs/enable":
                    from . import content
                    d = json.loads(self._body())
                    content.set_enabled(d["id"], bool(d.get("on")))
                    return self._json(content.summary())
                if method == "POST" and p == "/api/packs/remove":
                    from . import content
                    content.remove_pack(json.loads(self._body())["id"])
                    return self._json(content.summary())
                if method == "POST" and p == "/api/packs/install":
                    from . import content, updates
                    updates.install_pack_from_feed(app.settings, json.loads(self._body())["id"])
                    return self._json(content.summary())
                if method == "PUT" and p == "/api/packs/upload":
                    import tempfile
                    from . import content
                    n = int(self.headers.get("Content-Length") or 0)
                    if n > 20 * 2**20:
                        raise ValueError("a content pack is data only and should be well under 20 MB")
                    with tempfile.TemporaryDirectory() as tmp:
                        z = Path(tmp) / "pack.zip"
                        z.write_bytes(self._body())
                        out = content.install_pack(z)
                    return self._json({**content.summary(), "installed": out["id"]})
                if method == "POST" and p == "/api/features":
                    d = json.loads(self._body())
                    app.set_local("features", {str(d["name"]): bool(d.get("on"))})
                    return self._json(app.updates_state())
                self._json({"error": "not found"}, 404)
            except (ValueError, KeyError, yaml.YAMLError, FileNotFoundError, PermissionError) as e:
                self._json({"error": str(e)}, 400)
            except Exception as e:  # surface anything else to the dashboard
                self._json({"error": f"{type(e).__name__}: {e}"}, 500)

        def do_GET(self):
            self._route("GET")

        def do_POST(self):
            self._route("POST")

        def do_PUT(self):
            self._route("PUT")

    return Handler


def serve(open_browser: bool = False, block: bool = True) -> tuple[ThreadingHTTPServer, App]:
    app = App()
    from . import migrations, updates
    migrations.run(app.settings)
    hosted = os.environ.get("AUTOCUT_HOSTED") == "1"
    host = "0.0.0.0" if app.settings["listen_on_network"] or hosted else "127.0.0.1"
    for attempt in range(40 if os.environ.get("AUTOCUT_RESTARTED") else 1):  # after a restart the old one may
        try:                                                                # still be letting go of the port
            server = ThreadingHTTPServer((host, app.settings["port"]), make_handler(app))
            break
        except OSError:
            if attempt == 39 or not os.environ.get("AUTOCUT_RESTARTED"):
                raise
            time.sleep(0.25)
    app.server = server
    app.worker.start()
    updates.background_check(app.settings)
    url = f"http://127.0.0.1:{app.settings['port']}/"
    print(f"AutoCut dashboard on {url} (machine: {app.settings['machine_name']}, "
          f"clients: {clients_dir(app.settings)})")
    if app.auth.setup_code:
        print(f"  First run: open /login and create the first admin with setup code {app.auth.setup_code}")
    if host == "0.0.0.0" and not app.auth.enabled:
        print("  ! Listening on the network without logins. Anyone on this network can use AutoCut. "
              "For anything reachable from the internet set web.require_login: true.")
    if open_browser:
        open_dashboard(url)
    if block:
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
    else:
        threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, app


def _windows_app_browser() -> str | None:
    """Chrome or Edge (always on Windows 10/11), for an app-style dashboard window."""
    for base in (os.environ.get("PROGRAMFILES", ""), os.environ.get("PROGRAMFILES(X86)", ""), os.environ.get("LOCALAPPDATA", "")):
        for rel in (r"Google\Chrome\Application\chrome.exe", r"Microsoft\Edge\Application\msedge.exe"):
            if base and Path(base, rel).exists():
                return str(Path(base, rel))
    return None


def open_dashboard(url: str) -> None:
    """Open in an app-style window (Chrome --app) when available, else the default browser."""
    chrome = Path("/Applications/Google Chrome.app")
    if sys.platform == "darwin" and chrome.exists():
        # Calling the binary passes --app to an already-running Chrome too.
        subprocess.Popen([str(chrome / "Contents/MacOS/Google Chrome"), f"--app={url}",
                          "--window-size=1280,860"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    elif sys.platform == "win32" and (app := _windows_app_browser()):
        subprocess.Popen([app, f"--app={url}", "--window-size=1280,860"],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        webbrowser.open(url)
