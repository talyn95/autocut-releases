"""AutoCut — local rough-cut editor for Triumphant Media."""
__version__ = "0.29.0"


def load_tests(loader, tests, pattern):
    """`python -m unittest` discovery: the tests live in tests/, not here. Without this, discovery imports every
    autocut module before tests/test_autocut.py points AUTOCUT_SETTINGS at a scratch folder, and the tests would read
    and write this computer's real settings, state and AI usage."""
    return tests
