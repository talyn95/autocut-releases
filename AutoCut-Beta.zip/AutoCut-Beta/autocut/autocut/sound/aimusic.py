"""Optional AI music: ACE-Step 1.5 (MIT licence; its makers state generated music may be used commercially),
running on this computer through its own local REST API. AutoCut's composer is used whenever it isn't set up.

Setup (`autocut music-setup`): clones ACE-Step into the AutoCut folder and installs it with uv; the model downloads on
first use (several GB). Needs a Mac with Apple Silicon (16 GB+ memory recommended) or an NVIDIA GPU with 6 GB+.
AutoCut starts its API server (`uv run acestep-api`, port 8001) when a score is requested and leaves it running.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import time
import urllib.parse
import urllib.request
from pathlib import Path

from .. import content

REPO = content.catalog()["music"]["acestep_repo"]  # content/catalog.json


def cfg(settings: dict) -> dict:
    m = settings.get("music_ai") or {}
    return {"engine": m.get("engine", "auto"), "url": m.get("url", "http://127.0.0.1:8001"),
            "dir": m.get("dir") or str(Path(settings.get("clients_dir", "~/AutoCut/clients")).expanduser().parent / "ace-step"),
            "steps": int(m.get("steps", 8)), "start_timeout": int(m.get("start_timeout", 900))}


def installed(settings: dict) -> bool:
    d = Path(cfg(settings)["dir"])
    return (d / "pyproject.toml").exists() and (d / ".venv").exists()


def _get(url: str, timeout: float = 5) -> dict | None:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return json.loads(r.read().decode() or "{}")
    except Exception:
        return None


def _post(url: str, body: dict, timeout: float = 30) -> dict:
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def running(settings: dict) -> bool:
    return _get(cfg(settings)["url"] + "/health", 3) is not None


def status(settings: dict) -> dict:
    c = cfg(settings)
    return {"engine": c["engine"], "installed": installed(settings), "running": running(settings), "dir": c["dir"],
            "uv": bool(shutil.which("uv"))}


def start(settings: dict, log=print) -> bool:
    """Start the ACE-Step API server if it isn't running; wait for it (the first start downloads the model)."""
    if running(settings):
        return True
    if not installed(settings):
        return False
    c = cfg(settings)
    d = Path(c["dir"])
    logf = open(d / "autocut-acestep.log", "ab")
    kw = {"cwd": d, "stdout": logf, "stderr": subprocess.STDOUT}
    if os.name == "nt":
        kw["creationflags"] = 0x00000008 | 0x00000200  # detached, new process group
    else:
        kw["start_new_session"] = True
    subprocess.Popen([shutil.which("uv") or "uv", "run", "acestep-api"], **kw)
    log("  starting ACE-Step (the first start downloads its model; this can take a while)")
    t0 = time.time()
    while time.time() - t0 < c["start_timeout"]:
        if running(settings):
            return True
        time.sleep(3)
    return False


def setup(settings: dict, log=print) -> bool:
    c = cfg(settings)
    d = Path(c["dir"])
    uv = shutil.which("uv")
    if not uv:
        log("uv is needed: macOS/Linux `curl -LsSf https://astral.sh/uv/install.sh | sh`, Windows "
            "`powershell -ExecutionPolicy ByPass -c \"irm https://astral.sh/uv/install.ps1 | iex\"`, then run this again.")
        return False
    if not (d / "pyproject.toml").exists():
        log(f"Downloading ACE-Step into {d} …")
        subprocess.run(["git", "clone", "--depth", "1", REPO, str(d)], check=True)
    log("Installing ACE-Step (uv sync) …")
    subprocess.run([uv, "sync"], cwd=d, check=True)
    log("ACE-Step is installed. Its model downloads the first time AutoCut asks it for music.")
    return True


def generate(brief: dict, seconds: float, out: Path, settings: dict, log=print, timeout: float = 900) -> Path | None:
    """One instrumental track from the brief's prompt, fitted to `seconds`. None if ACE-Step isn't available."""
    c = cfg(settings)
    if c["engine"] == "composer" or not start(settings, log):
        return None
    body = {"prompt": brief.get("prompt", ""), "lyrics": "[Instrumental]", "audio_duration": max(10.0, min(600.0, seconds + 2)),
            "bpm": int(round(float(brief.get("bpm", 100)))), "key_scale": f"{brief.get('key', 'C')} {'Minor' if brief.get('mode') in ('minor', 'dorian') else 'Major'}",
            "time_signature": "4", "use_random_seed": False, "seed": int(brief.get("seed", 7)), "batch_size": 1,
            "audio_format": "wav", "inference_steps": c["steps"]}
    try:
        task = _post(c["url"] + "/release_task", body)["data"]["task_id"]
        t0 = time.time()
        while time.time() - t0 < timeout:
            res = _post(c["url"] + "/query_result", {"task_id_list": [task]})["data"][0]
            if res.get("status") == 2:
                log(f"  ! ACE-Step failed: {str(res)[:200]}")
                return None
            if res.get("status") == 1:
                items = json.loads(res["result"]) if isinstance(res.get("result"), str) else res.get("result")
                item = items[0] if isinstance(items, list) else items
                f = item["file"]
                url = c["url"] + (f if f.startswith("/") else "/v1/audio?path=" + urllib.parse.quote(f, safe=""))
                raw = out.with_name(out.stem + "-ace.wav")
                with urllib.request.urlopen(url, timeout=120) as r:
                    raw.write_bytes(r.read())
                fade = min(2.0, seconds * 0.1)
                subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(raw), "-t", f"{seconds:.3f}",
                                "-af", f"afade=t=out:st={max(0, seconds - fade):.3f}:d={fade:.3f},loudnorm=I=-14:TP=-1.5",
                                "-ar", "44100", "-ac", "2", str(out)], check=True)
                return out
            time.sleep(2)
    except Exception as e:
        log(f"  ! ACE-Step unavailable ({e}); using AutoCut's composer")
    return None
