"""Music and sound design, made on this computer: the composer (composer.py, synth.py), the sound effects (sfx.py), the
sound designer (design.py), the music director and each client's sound identity (director.py), and the optional AI
music model (aimusic.py, ACE-Step). score() is the one call the rest of AutoCut makes for a music bed.
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

from . import aimusic, composer, director


def score(client, settings: dict, seconds: float, out: Path, text: str = "", kind: str = "short",
          stems_dir: Path | None = None, override: dict | None = None, use_ai_brain: bool = True, log=print) -> dict:
    """Write a music bed of exactly `seconds` to `out` (WAV, -14 LUFS). Returns what was made and how."""
    b = director.brief(client, settings, text, seconds, kind, override, use_ai_brain)
    engine = (settings.get("music_ai") or {}).get("engine", "auto")
    made = None
    if engine in ("auto", "acestep") and aimusic.installed(settings):
        made = aimusic.generate(b, seconds, out, settings, log)
    meta = {"brief": b}
    if made:
        meta.update(engine="acestep", style_name=composer.STYLES[b["style"]]["name"])
    else:
        raw = out.with_name(out.stem + "-raw.wav")
        meta.update(composer.render(b, seconds, raw, stems_dir), engine="composer")
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(raw), "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                        "-ar", "48000", "-ac", "2", "-t", f"{seconds:.3f}", str(out)], check=True)
        raw.unlink(missing_ok=True)
    out.with_suffix(".json").write_text(json.dumps(meta, indent=1, default=str))
    return meta


def mix_video(video: Path, out: Path, client, settings: dict, events: list[dict], text: str = "", kind: str = "motion",
              music: bool = True, effects: bool = True, density: str = "normal", log=print,
              lines: list[dict] | None = None, notes: str = "", plan: bool | None = None) -> Path:
    """Give a rendered video its score: original music (ducked under any voice already in it) and sound effects on
    its events. Writes the music and effects next to it as separate WAVs too (for editors)."""
    from . import design as sd
    from ..media import probe
    info = probe(video)
    total = info.duration
    work = out.parent / (Path(video).stem + "-sound")  # the music and effects as separate WAVs, for editors
    work.mkdir(parents=True, exist_ok=True)
    ident = director.identity(client, settings)
    brand = client.brand if client is not None else {}
    inputs, chains, labels = ["-i", str(video)], [], []
    has_voice = bool(info.audio_channels)
    if has_voice:
        chains.append("[0:a]aformat=channel_layouts=stereo,aresample=48000,asplit=2[voice][key]")
        labels.append("[voice]")
    # the sound designer's cue sheet (AI, rules fallback): music energy curve + breaks, and the moments that get a sound
    cfg = settings.get("sound") or {}
    sp = None
    if (plan if plan is not None else cfg.get("ai_plan", True)) and (music or effects):
        sp = director.sound_plan(client, settings, total, text, lines, events, kind, notes, use_ai=cfg.get("ai_plan_brain", True))
        (work / "cue-sheet.json").write_text(json.dumps(sp, indent=1))
        events = list(events or []) + [{"t": c["t"], "kind": c["kind"], "boost": 1} for c in sp["cues"]]
    if music:
        m = score(client, settings, total, work / "music.wav", text, kind,
                  override={"style": (brand.get("music") or {}).get("style") or None,
                            "energy": (brand.get("music") or {}).get("energy") or None,
                            "energy_curve": director.energy_curve(sp) if sp else None,
                            "breaks": (sp or {}).get("breaks") or None}, log=log)
        inputs += ["-i", str(work / "music.wav")]
        lvl = 10 ** (float((brand.get("music") or {}).get("ai_level_db", -17)) / 20) if has_voice else 10 ** (-3 / 20)
        chains.append(f"[{len(inputs) // 2 - 1}:a]volume={lvl:.4f}[mus0]")
        if has_voice:
            chains.append("[mus0][key]sidechaincompress=threshold=0.02:ratio=6:attack=20:release=450[mus]")
        else:
            chains.append("[mus0]anull[mus]")
        labels.append("[mus]")
    elif has_voice:
        chains.append("[key]anullsink")
    if effects and events:
        cues = sd.materialise(sd.plan(events, total, density), work / "sfx", ident.get("flavour", "clean"), ident.get("seed", 1))
        if cues:
            sd.render(cues, total, work / "effects.wav")
            inputs += ["-i", str(work / "effects.wav")]
            chains.append(f"[{len(inputs) // 2 - 1}:a]anull[fx]")
            labels.append("[fx]")
    if not labels:
        import shutil
        shutil.copy2(video, out)
        return out
    chains.append(f"{''.join(labels)}amix=inputs={len(labels)}:normalize=0,alimiter=limit=0.95,"
                  "loudnorm=I=-14:TP=-1.5:LRA=11[aout]" if len(labels) > 1 else f"{labels[0]}loudnorm=I=-14:TP=-1.5:LRA=11[aout]")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", *inputs, "-filter_complex", ";".join(chains), "-map", "0:v",
                    "-map", "[aout]", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-shortest",
                    "-movflags", "+faststart", str(out)], check=True)
    return out
