"""The music director: each client's sound identity, and the brief for each video's score.

Sound identity (sound-style.json in the client folder, like the motion style DNA): a style that suits the business and
that the agency's other clients use least, a key that differs from theirs, a seed (the client's motif and instrument
colours) and an effects flavour from the client's motion look. Handed out once, kept, editable.

brief(): the identity, adjusted for one video. The AI brain (with the music playbook, knowledge/music.md) reads the
brand and what the video says and picks the energy, tempo and, when the identity allows, a better-suited style; it also
writes the text prompt the optional AI music model (ACE-Step) uses. Rules do it when no AI answers.
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

from ..config import Client, list_clients
from .. import content
from .composer import KEYS, STYLES
from .sfx import LOOK_FLAVOUR

FILE = "sound-style.json"
STYLE_FITS = {
    "corporate": ["finance", "law", "insurance", "dental", "dentist", "orthodont", "clinic", "medical", "b2b", "consulting", "accounting", "healthcare", "roofing",
                  "contractor", "hvac", "plumbing", "real estate", "home services", "construction"],
    "lofi": ["coffee", "cafe", "creator", "podcast", "barber", "tattoo", "studio", "bookstore", "design"],
    "cinematic": ["film", "production", "travel", "documentary", "wedding", "photography", "videography", "automotive", "nonprofit"],
    "pop": ["ecommerce", "beauty", "fashion", "marketing", "agency", "events", "influencer", "salon", "retail"],
    "hiphop": ["streetwear", "barber", "music", "gaming", "esports", "nightlife", "sneakers", "urban"],
    "acoustic": ["restaurant", "food", "bakery", "farm", "organic", "brewery", "winery", "florist", "family", "pet", "church", "kitchen"],
    "tech": ["saas", "software", "app", "fintech", "ai", "startup", "crypto", "devtools", "data", "cloud", "cybersecurity", "it"],
    "luxury": ["luxury", "jewelry", "hotel", "spa", "med spa", "yacht", "watches", "interior", "architecture", "skincare", "estate"],
    "sport": ["fitness", "gym", "sports", "crossfit", "martial arts", "supplements", "racing", "coach", "athletic", "strength"],
    "playful": ["kids", "daycare", "toys", "pet", "cleaning", "ice cream", "candy", "party", "dentist"],
}
content.register("style_fits", STYLE_FITS)  # + industry words from content packs
KEY_LIST = ["C", "D", "E", "F", "G", "A", "Bb", "Eb"]


def _h(*parts) -> int:
    return int(hashlib.sha1("|".join(map(str, parts)).encode()).hexdigest()[:8], 16)


def _owned(client: Client, settings: dict) -> bool:
    from ..config import clients_dir
    try:
        root = clients_dir(settings).resolve()
        return root in client.folder.resolve().parents
    except (KeyError, OSError):
        return False


def load(folder: Path) -> dict | None:
    try:
        d = json.loads((folder / FILE).read_text())
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(d, dict) or not d.get("style"):
        return None
    if d["style"] not in STYLES:  # its content pack is off or gone: the style it was built on stands in (not saved)
        d = {**d, "style": d.get("style_base") if d.get("style_base") in STYLES else "corporate",
             "style_unavailable": d["style"]}
    return d


def save(client: Client, ident: dict) -> dict:
    d = dict(ident)
    gone = d.pop("style_unavailable", None)
    if gone and d["style"] == (d.get("style_base") if d.get("style_base") in STYLES else "corporate"):
        d["style"] = gone
    (client.folder / FILE).write_text(json.dumps(d, indent=2))
    return ident


def fit(style: str, brand: dict) -> int:
    text = " ".join(str(x) for x in (brand.get("client"), (brand.get("marketing") or {}).get("industry"),
                                     (brand.get("marketing") or {}).get("tone"), brand.get("industry"))).lower()
    score = sum(3 for f in STYLE_FITS.get(style, []) if re.search(rf"\b{re.escape(f)}", text))
    score += sum(1 for m in STYLES[style]["mood"].split(", ") if re.search(rf"\b{re.escape(m)}", text))
    return score


def assign(client: Client, settings: dict, shuffle: int = 0, others: list[dict] | None = None) -> dict:
    if others is None:
        others = [d for f in list_clients(settings) if f.resolve() != client.folder.resolve() for d in [load(f)] if d]
    used: dict[str, int] = {}
    keys_used: dict[str, int] = {}
    for d in others:
        used[d["style"]] = used.get(d["style"], 0) + 1
        keys_used[d.get("key", "")] = keys_used.get(d.get("key", ""), 0) + 1
    ranked = sorted(STYLES, key=lambda s: (used.get(s, 0) * 3 - fit(s, client.brand) * 2, _h(client.slug, s)))
    style = ranked[shuffle % len(ranked)]
    key = sorted(KEY_LIST, key=lambda k: (keys_used.get(k, 0), _h(client.slug, "key", k, shuffle)))[0]
    look = None
    try:
        from ..mograph.library import dna
        look = (dna.get(client, settings) or {}).get("look")
    except Exception:
        pass
    out = {"style": style, "key": key, "seed": _h(client.slug, "seed", shuffle) % 100000,
           "flavour": LOOK_FLAVOUR.get(look or "", "clean"), "keep_style": True, "shuffle": shuffle}
    if STYLES[style].get("pack"):
        out["style_base"] = STYLES[style].get("base") or "corporate"
    return out


def identity(client: Client | None, settings: dict, create: bool = True) -> dict:
    if client is None or client.slug.startswith("_") or not (client.folder / "brand.yaml").exists():
        return {"style": "corporate", "key": "C", "seed": 7, "flavour": "clean", "keep_style": True}
    d = load(client.folder)
    if d is None and create:
        d = assign(client, settings)
        if _owned(client, settings):  # only real client folders keep it (not the bundled demo or test brands)
            save(client, d)
    return d or {"style": "corporate", "key": "C", "seed": 7, "flavour": "clean", "keep_style": True}


BRIEF_SCHEMA = {"type": "object", "properties": {
    "style": {"type": "string"}, "energy": {"type": "string"}, "bpm": {"type": "integer"},
    "reason": {"type": "string"}, "prompt": {"type": "string"}}, "required": ["style", "energy"]}


def rules_energy(text: str) -> str:
    t = text.lower()
    if re.search(r"\b(sale|off|limited|today only|launch|new|now|free|book now|hurry|win)\b", t):
        return "high"
    if re.search(r"\b(story|journey|lost|grief|thank|remember|family|heart|care|patient)\b", t):
        return "low"
    return "medium"


def brief(client: Client | None, settings: dict, text: str = "", seconds: float = 30, kind: str = "short",
          override: dict | None = None, use_ai: bool = True) -> dict:
    """The score for one video: identity + energy/tempo for this content (+ an AI music prompt)."""
    ident = identity(client, settings)
    style = ident["style"]
    out = {"style": style, "key": ident["key"], "seed": ident["seed"], "flavour": ident.get("flavour", "clean"),
           "energy": rules_energy(text), "via": "rules"}
    if use_ai and text.strip():
        from .. import brain, marketing
        brand = client.brand if client else None
        names = ", ".join(f"{k} ({v['name']}: {v['mood']})" for k, v in STYLES.items())
        ai = brain.ask(settings, marketing.system_prompt(brand, "music"),
                       f"Score this {kind} video ({seconds:.0f} s). The client's signature style is '{style}'"
                       f"{' (keep it unless it clearly fits badly)' if ident.get('keep_style', True) else ''}. Styles: {names}. "
                       "Pick the style, the energy (low, medium or high), a tempo in BPM suited to the style, and write a "
                       "one-line instrumental music prompt (genre, instruments, mood, tempo; no artist names). "
                       f"What the video says:\n{text[:1500]}", BRIEF_SCHEMA, timeout=60)
        if isinstance(ai, dict):
            if ai.get("style") in STYLES and (not ident.get("keep_style", True) or ai["style"] == style or fit(ai["style"], brand or {}) > fit(style, brand or {})):
                out["style"] = ai["style"]
            if ai.get("energy") in ("low", "medium", "high"):
                out["energy"] = ai["energy"]
            if isinstance(ai.get("bpm"), int) and 50 <= ai["bpm"] <= 180:
                base = STYLES[out["style"]]["bpm"]
                out["bpm"] = max(base * 0.85, min(base * 1.15, ai["bpm"]))
            if ai.get("prompt"):
                out["prompt"] = str(ai["prompt"])[:400]
            out["via"] = "ai"
    out.update({k: v for k, v in (override or {}).items() if v not in (None, "")})
    st = STYLES.get(out["style"], STYLES["corporate"])
    out.setdefault("mode", st["mode"])
    out.setdefault("prompt", f"{st['ace']}, {out['energy']} energy, instrumental, no vocals")
    out.setdefault("bpm", st["bpm"])
    if out.get("key") not in KEYS:
        out["key"] = "C"
    return out


# ---- the sound designer: a cue sheet for one video -----------------------------------------------------------------

CUE_KINDS = ("transition", "swipe", "graphic", "slam", "number", "sticker", "reveal", "hit", "end", "logo", "ui", "glitch", "boom")
PLAN_SCHEMA = {"type": "object", "properties": {
    "sections": {"type": "array", "items": {"type": "object", "properties": {
        "t": {"type": "number"}, "energy": {"type": "integer"}}, "required": ["t", "energy"]}},
    "breaks": {"type": "array", "items": {"type": "number"}},
    "cues": {"type": "array", "items": {"type": "object", "properties": {
        "t": {"type": "number"}, "kind": {"type": "string"}, "why": {"type": "string"}}, "required": ["t", "kind"]}},
    "reason": {"type": "string"}}, "required": ["sections", "cues"]}
KEY_WORDS = re.compile(r"\b(free|new|now|today|never|guaranteed|save|win|instantly|secret|finally|only)\b", re.I)
NUM = re.compile(r"[$€£]\s?\d|\d+(?:[.,]\d+)?\s?(?:%|percent|x\b|k\b|hours?|days?|minutes?)|\b\d{2,}\b", re.I)


def rules_plan(total: float, lines: list[dict] | None = None, kind: str = "short", energy: str = "medium") -> dict:
    """The cue sheet without AI: an energy curve shaped for the video type, a hit on numbers and power words, a break
    and a riser into the last line (usually the offer or the CTA), the end hit."""
    lines = sorted([ln for ln in (lines or []) if ln.get("text")], key=lambda ln: ln["t"])
    start = {"low": 1, "medium": 2, "high": 2}.get(energy, 2)
    sections = [{"t": 0.0, "energy": start if kind != "story" else 1},
                {"t": round(total * 0.25, 2), "energy": 2},
                {"t": round(total * 0.6, 2), "energy": 3 if energy != "low" else 2},
                {"t": round(max(0.0, total - 4.0), 2), "energy": 3}]
    cues, breaks = [], []
    for ln in lines:
        txt, t = ln["text"], float(ln["t"])
        if NUM.search(txt):
            cues.append({"t": t + 0.1, "kind": "number", "why": "a number on screen or in the line"})
        elif KEY_WORDS.search(txt):
            cues.append({"t": t + 0.1, "kind": "hit", "why": "a power word"})
    if len(lines) >= 3 and total >= 12:
        last = float(lines[-1]["t"])
        breaks.append(round(last, 2))
        cues.append({"t": last, "kind": "reveal", "why": "lands the last line (offer / CTA)"})
    cues.append({"t": max(0.0, total - 1.6), "kind": "end", "why": "the end card"})
    return {"sections": sections, "breaks": breaks, "cues": cues, "via": "rules"}


def _clean_plan(p: dict, total: float) -> dict | None:
    if not isinstance(p, dict):
        return None
    sec = [{"t": round(min(max(float(s["t"]), 0.0), total), 2), "energy": int(min(3, max(0, int(s["energy"]))))}
           for s in p.get("sections") or [] if isinstance(s, dict) and "t" in s and "energy" in s]
    cues = [{"t": round(float(c["t"]), 2), "kind": c["kind"], "why": str(c.get("why", ""))[:120]}
            for c in p.get("cues") or [] if isinstance(c, dict) and c.get("kind") in CUE_KINDS
            and 0 <= float(c.get("t", -1)) <= total]
    brk = sorted({round(float(t), 2) for t in p.get("breaks") or [] if 2.0 <= float(t) <= total - 1.0})[:3]
    if not sec and not cues:
        return None
    sec.sort(key=lambda s: s["t"])
    if not sec or sec[0]["t"] > 0:
        sec.insert(0, {"t": 0.0, "energy": 2})
    return {"sections": sec, "breaks": brk, "cues": sorted(cues, key=lambda c: c["t"])[:40],
            "reason": str(p.get("reason", ""))[:300]}


def sound_plan(client: Client | None, settings: dict, total: float, text: str = "", lines: list[dict] | None = None,
               events: list[dict] | None = None, kind: str = "short", notes: str = "", use_ai: bool = True) -> dict:
    """The cue sheet for one video: the music's energy curve, where it breaks for a key line, and which moments get a
    sound. The AI brain spots it like a trailer editor (knowledge/music.md), from what is said (timed lines), what moves on
    screen (events) and the owner's notes ("darker, a riser before the price"); rules do it when no AI answers."""
    base = rules_plan(total, lines, kind, rules_energy(text or " ".join(ln.get("text", "") for ln in lines or [])))
    if not use_ai:
        return base
    from .. import brain, marketing
    brand = client.brand if client else None
    said = "\n".join(f"{float(ln['t']):6.2f}s  {ln['text']}" for ln in (lines or [])[:80])
    moves = ", ".join(f"{float(e['t']):.1f}s {e['kind']}" for e in sorted(events or [], key=lambda e: e["t"])[:80])
    ask = (f"Spot the sound for this {kind} video ({total:.1f} s). Return: sections (time + music energy 0 silent, 1 light, "
           f"2 body, 3 full), up to 2 breaks (times of the lines that must land in space; the drums drop for the bar before), "
           f"and cues (time + kind, one of: {', '.join(CUE_KINDS)}) for the moments that deserve a sound beyond what already "
           "moves on screen. Fewer, well-placed cues; never mid-sentence; at least 1 s apart."
           + (f"\nThe owner's notes: {notes[:400]}" if notes.strip() else "")
           + (f"\nWhat is said (start time, line):\n{said}" if said else f"\nWhat the video says: {text[:1500]}")
           + (f"\nAlready on screen (each gets its own sound): {moves}" if moves else ""))
    ai = brain.ask(settings, marketing.system_prompt(brand, "music"), ask, PLAN_SCHEMA, timeout=90)
    got = _clean_plan(ai, total) if isinstance(ai, dict) else None
    if not got:
        return base
    got["via"] = "ai"
    return got


def energy_curve(plan: dict) -> list[list[float]]:
    return [[s["t"], s["energy"]] for s in plan.get("sections") or []]
