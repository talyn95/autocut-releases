"""Sound effects, synthesized: whooshes, risers, impacts, pops, clicks, glitches, shimmers… in a client's flavour.

A flavour (from the client's motion look: clean, hard, digital, airy, soft, cinematic, paper) shades every effect:
how bright, how hard, how long, how much room. Each effect is a short stereo WAV; the sound designer (design.py)
places them on the edit's events and AutoCut puts them on their own audio track.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from . import synth as S
from .. import content

KINDS = ["whoosh", "swish", "riser", "impact", "hit", "pop", "click", "tick", "glitch", "shimmer", "swipe", "boom", "typing"]

FLAVOURS = {
    "clean": dict(bright=0.6, hard=0.5, room=0.25, length=1.0),
    "hard": dict(bright=0.75, hard=0.95, room=0.15, length=0.8),
    "digital": dict(bright=0.8, hard=0.7, room=0.12, length=0.8, glitchy=True),
    "airy": dict(bright=0.45, hard=0.25, room=0.45, length=1.3),
    "soft": dict(bright=0.5, hard=0.35, room=0.3, length=1.0),
    "cinematic": dict(bright=0.5, hard=0.8, room=0.55, length=1.4),
    "paper": dict(bright=0.55, hard=0.4, room=0.2, length=0.9, grain=True),
    "bubbly": dict(bright=0.7, hard=0.45, room=0.2, length=0.8),
}
content.register("sfx_flavours", FLAVOURS)  # + flavours from content packs (content.py)
# motion look → sound flavour
LOOK_FLAVOUR = {"corporate": "clean", "minimal": "airy", "editorial": "soft", "swiss": "clean", "brutal": "hard",
                "glass": "airy", "neon": "digital", "glitch": "digital", "retro": "bubbly", "handmade": "paper",
                "luxury": "airy", "sport": "hard", "playful": "bubbly", "broadcast": "clean", "organic": "soft",
                "mono": "digital", "gradient": "clean", "cinematic": "cinematic"}
content.register("look_flavour", LOOK_FLAVOUR)


def _stereo_pan(x: np.ndarray, start: float, end: float) -> np.ndarray:
    a = (np.linspace(start, end, len(x)) + 1) * np.pi / 4
    return np.stack([x * np.cos(a), x * np.sin(a)]).astype(np.float32)


def make(kind: str, flavour: str = "clean", seed: int = 1) -> np.ndarray:
    F = FLAVOURS.get(flavour, FLAVOURS["clean"])
    rng = np.random.default_rng(seed)
    b, h, L = F["bright"], F["hard"], F["length"]
    if kind in ("whoosh", "swish", "swipe"):
        dur = {"whoosh": 0.9, "swish": 0.4, "swipe": 0.3}[kind] * L
        n = S.n_of(dur)
        t = S.t_axis(n) / dur
        nz = S.noise(n, rng)
        up = kind == "swipe"
        body = S.sweep(nz, 500 + 1500 * b, 3000 + 7000 * b, 6) if up else S.sweep(nz, 4000 + 6000 * b, 600 + 800 * b, 6)
        lowband = S.filt(nz, lo=120, hi=900) * (0.5 if kind == "whoosh" else 0.2)
        env = np.sin(np.pi * np.clip(t, 0, 1)) ** (1.6 if kind == "whoosh" else 2.4)
        peak = 0.45 if kind == "whoosh" else 0.6
        env = np.where(t < peak, (t / peak) ** 2, ((1 - t) / (1 - peak)) ** 1.5)
        x = (body + lowband) * env
        out = _stereo_pan(x, -0.7, 0.7)
    elif kind == "riser":
        dur = 2.0 * L
        n = S.n_of(dur)
        t = S.t_axis(n) / dur
        tone = S.saw(220 * 2 ** (2.2 * t), n) * 0.25 + S.sine(110 * 2 ** (2.2 * t), n) * 0.3
        nz = S.sweep(S.noise(n, rng), 500, 9000 * b + 2000, 8) * 0.6
        x = (S.filt(tone, hi=3000 + 5000 * b) + nz) * t ** 2.2
        out = _stereo_pan(x, 0, 0) * (1 + 0.3 * np.sin(2 * np.pi * 6 * t * t))
    elif kind in ("impact", "boom", "hit"):
        dur = {"impact": 1.6, "boom": 2.4, "hit": 0.6}[kind] * (0.8 + 0.4 * F["room"])
        n = S.n_of(dur)
        t = S.t_axis(n)
        sub = S.sine(32 + 60 * np.exp(-t / 0.08), n) * np.exp(-t / (0.35 if kind != "hit" else 0.12))
        crack = S.filt(S.noise(n, rng), lo=800, hi=4000 + 6000 * b) * np.exp(-t / (0.03 + 0.05 * (1 - h)))
        thud = S.kick(1.0, rng)
        x = np.zeros(n, dtype=np.float32)
        x[:len(thud)] += thud[:n] * 0.8
        x += sub * (1.0 if kind != "hit" else 0.5) + crack * (0.5 + 0.5 * h)
        x = np.tanh(1.5 * x)
        out = _stereo_pan(x, 0, 0)
        out = S.reverb(out, 1.5 + 2 * F["room"], 0.3 + F["room"] * 0.4, b, seed)
    elif kind == "pop":
        n = S.n_of(0.12)
        t = S.t_axis(n)
        x = S.sine(500 * (1 + 1.2 * (1 - np.exp(-t / 0.02))) * (1.2 if flavour == "bubbly" else 1), n) * np.exp(-t / 0.035)
        x[:S.n_of(0.003)] += 0.3
        out = _stereo_pan(x.astype(np.float32), 0, 0)
    elif kind in ("click", "tick"):
        n = S.n_of(0.03 if kind == "click" else 0.015)
        t = S.t_axis(n)
        x = S.filt(S.noise(n, rng), lo=1500 + 2000 * b, hi=9000) * np.exp(-t / 0.004)
        x += S.sine(2200 if kind == "click" else 3200, n) * np.exp(-t / 0.003) * 0.4
        out = _stereo_pan(x.astype(np.float32), 0, 0)
    elif kind == "glitch":
        dur = 0.35
        n = S.n_of(dur)
        x = np.zeros(n, dtype=np.float32)
        for k in range(7):
            a = int(rng.integers(0, n - 800))
            ln = int(rng.integers(300, 1600))
            seg = np.sign(S.sine(rng.uniform(200, 2000), ln)) * 0.5 + S.noise(ln, rng) * 0.3
            seg = np.round(seg * 4) / 4  # bit-crushed
            x[a:a + ln] += seg[: max(0, min(ln, n - a))]
        out = np.stack([x, np.roll(x, 120)]).astype(np.float32) * 0.6
    elif kind == "shimmer":
        dur = 1.4 * L
        n = S.n_of(dur)
        x = np.zeros(n, dtype=np.float32)
        for k in range(10):
            f = float(rng.choice([1567.98, 1760, 2093, 2349.3, 2637, 3136, 3520]))
            at = rng.uniform(0, dur * 0.6)
            note = S.sine(f, S.n_of(0.5)) * S.expdecay(S.n_of(0.5), 0.15) * rng.uniform(0.15, 0.35)
            i = S.n_of(at)
            x[i:i + len(note)] += note[: n - i]
        out = S.reverb(_stereo_pan(x, -0.5, 0.5), 2.2, 0.45, 0.8, seed)
    elif kind == "typing":
        n = S.n_of(1.0)
        x = np.zeros(n, dtype=np.float32)
        tk = make("tick", flavour, seed)[0]
        t = 0.0
        while t < 0.9:
            i = S.n_of(t)
            x[i:i + len(tk)] += tk[: n - i] * rng.uniform(0.6, 1.0)
            t += rng.uniform(0.06, 0.14)
        out = _stereo_pan(x, -0.1, 0.1)
    else:
        raise ValueError(kind)
    if F.get("grain"):
        out = out + S.filt(S.noise(out.shape[1], rng), lo=2000, hi=7000) * 0.015 * (np.abs(out[0]) > 0.02)
    if F.get("glitchy") and kind in ("whoosh", "swish", "impact", "hit"):
        out[:, ::97] *= 0.2
    peak = np.max(np.abs(out)) + 1e-9
    return (out / peak * 0.9).astype(np.float32)


def pack(folder: Path, flavour: str = "clean", seed: int = 1) -> dict[str, Path]:
    """Every kind of effect in this flavour, as WAVs (cached)."""
    folder.mkdir(parents=True, exist_ok=True)
    out = {}
    for k in KINDS:
        p = folder / f"{k}-{flavour}-{seed}.wav"
        if not p.exists():
            S.write_wav(p, make(k, flavour, seed))
        out[k] = p
    return out
