"""AutoCut Composer: original, royalty-free music beds written and performed on this computer.

A brief (style, key, tempo, energy, seed) becomes a full arrangement fitted to the exact length of the video: the tempo
is nudged so a whole number of bars lands on the final chord, which rings out on the last frame. Ten styles cover what
agencies use most (see STYLES). The same client seed gives the same key, motif and instrument colours every time, so a
brand has a recognisable sound; the motif is a short signature line that only enters at the lifts. Beds are mixed for
voice: a gentle dip where speech sits, nothing busy in the vocal range while the drums carry the energy.

compose(brief, seconds) -> (mix, stems) with stems drums / bass / harmony / top, all (2, n) at synth.SR.
"""
from __future__ import annotations

import math

import numpy as np

from . import synth as S
from .. import content

SCALES = {"major": [0, 2, 4, 5, 7, 9, 11], "minor": [0, 2, 3, 5, 7, 8, 10], "dorian": [0, 2, 3, 5, 7, 9, 10],
          "mixolydian": [0, 2, 4, 5, 7, 9, 10]}
KEYS = {"C": 0, "C#": 1, "Db": 1, "D": 2, "D#": 3, "Eb": 3, "E": 4, "F": 5, "F#": 6, "Gb": 6, "G": 7, "G#": 8, "Ab": 8,
        "A": 9, "A#": 10, "Bb": 10, "B": 11}

# drum grids: 16 steps a bar; x = hit, o = soft. Per energy level 1 (light) … 3 (full)
D = dict
STYLES: dict[str, dict] = {
    "corporate": D(name="Corporate uplift", bpm=112, mode="major", progs=[[1, 5, 6, 4], [4, 1, 5, 6]], swing=0.0,
                   chords="piano", rhythm="pulse8", bass="warm", bass_rhythm="eighths", pad=True, arp=("pluck", "up8"),
                   motif="pluck", reverb=(1.6, 0.22), risers=True, register=60,
                   drums={1: {"hat": "..x...x...x...x."}, 2: {"kick": "x...x...x...x...", "clap": "....x.......x...", "hat": "..x...x...x...x."},
                          3: {"kick": "x...x...x...x...", "clap": "....x.......x...", "hat": "x.x.x.x.x.x.x.x.", "shaker": "xxxxxxxxxxxxxxxx"}},
                   mood="confident, optimistic, clean", ace="uplifting corporate pop instrumental, bright piano, plucked synth arpeggio, light claps, warm bass, motivational"),
    "lofi": D(name="Lo-fi chill", bpm=82, mode="dorian", progs=[[2, 5, 1, 6], [1, 4, 7, 3]], swing=0.6, sevenths=True,
              chords="epiano", rhythm="sustain_stab", bass="warm", bass_rhythm="syncop", pad=False, arp=None, motif="epiano",
              reverb=(1.4, 0.2), risers=False, register=58, vinyl=True, lowpass=5200,
              drums={1: {"kick": "x.........x.....", "hat": "..o...o...o...o."}, 2: {"kick": "x.......x.x.....", "snare": "....x.......x...", "hat": "x.o.x.o.x.o.x.o."},
                     3: {"kick": "x.......x.x...o.", "snare": "....x.......x..o", "hat": "x.oxx.o.x.oxx.o."}},
              mood="relaxed, cozy, authentic", ace="lo-fi hip hop instrumental, dusty drums, warm electric piano chords, vinyl crackle, mellow, relaxed"),
    "cinematic": D(name="Cinematic", bpm=86, mode="minor", progs=[[1, 6, 3, 7], [1, 4, 6, 5]], swing=0.0,
                   chords="strings", rhythm="sustain", bass="sub", bass_rhythm="whole", pad=True, arp=("piano", "broken8"),
                   motif="piano", reverb=(3.2, 0.38), risers=True, register=55,
                   drums={1: {}, 2: {"kick": "x.......x.......", "tom": "......x.......x."}, 3: {"kick": "x.....x.x.......", "snare": "........x.......", "tom": "....x.x.....x.x."}},
                   mood="dramatic, emotional, premium", ace="cinematic orchestral instrumental, emotional strings, piano, deep percussion, epic build, trailer"),
    "pop": D(name="Upbeat pop", bpm=118, mode="major", progs=[[6, 4, 1, 5], [1, 5, 6, 4]], swing=0.0,
             chords="pad", rhythm="stabs", bass="pluck", bass_rhythm="syncop", pad=True, arp=("lead_sq", "up16"),
             motif="lead", reverb=(1.4, 0.2), risers=True, register=62, pump=0.45,
             drums={1: {"kick": "x.......x.......", "hat": "..x...x...x...x."}, 2: {"kick": "x...x...x...x...", "clap": "....x.......x...", "hat": "..x...x...x...x."},
                    3: {"kick": "x...x...x...x...", "clap": "....x.......x...", "hat": "xxxxxxxxxxxxxxxx", "ohat": "..x...x...x...x."}},
             mood="fun, energetic, bright", ace="upbeat feel-good pop instrumental, bright synths, punchy four on the floor drums, catchy, energetic"),
    "hiphop": D(name="Modern hip-hop", bpm=140, mode="minor", progs=[[1, 6, 4, 5], [1, 7, 6, 7]], swing=0.0, halftime=True,
                chords="epiano", rhythm="sustain", bass="808", bass_rhythm="808", pad=True, arp=("pluck", "broken8"), motif="pluck",
                reverb=(1.6, 0.2), risers=False, register=60,
                drums={1: {"hat": "x.x.x.x.x.x.x.x."}, 2: {"kick": "x.........x.....", "clap": "........x.......", "hat": "x.x.x.x.x.xxx.x."},
                       3: {"kick": "x.....x...x..x..", "clap": "........x.......", "hat": "x.xxx.x.x.xxxxx.", "ohat": "..............x."}},
                mood="bold, street, confident", ace="modern trap hip hop instrumental, 808 bass, crisp hi-hat rolls, dark keys, confident"),
    "acoustic": D(name="Warm acoustic", bpm=100, mode="major", progs=[[1, 4, 6, 5], [1, 5, 4, 4]], swing=0.15,
                  chords="pluck", rhythm="strum", bass="warm", bass_rhythm="root_fifth", pad=False, arp=None, motif="marimba",
                  reverb=(1.2, 0.18), risers=False, register=55,
                  drums={1: {"shaker": "x.xxx.xxx.xxx.xx"}, 2: {"kick": "x.......x.......", "rim": "....x.......x...", "shaker": "x.xxx.xxx.xxx.xx"},
                         3: {"kick": "x.....x.x.......", "snare": "....x.......x...", "shaker": "x.xxx.xxx.xxx.xx"}},
                  mood="warm, honest, friendly", ace="warm acoustic folk instrumental, strummed acoustic guitar, shaker, soft kick, friendly, heartfelt"),
    "tech": D(name="Tech / electronic", bpm=124, mode="minor", progs=[[1, 7, 6, 7], [1, 6, 3, 7]], swing=0.0,
              chords="pad", rhythm="sustain", bass="pluck", bass_rhythm="offbeat", pad=True, arp=("lead_saw", "up16"),
              motif="lead", reverb=(1.8, 0.24), risers=True, register=60, pump=0.6,
              drums={1: {"kick": "x...x...x...x...", "hat": "..x...x...x...x."}, 2: {"kick": "x...x...x...x...", "clap": "....x.......x...", "hat": "..x...x...x...x."},
                     3: {"kick": "x...x...x...x...", "clap": "....x.......x...", "hat": "xxxxxxxxxxxxxxxx", "ohat": "..x...x...x...x."}},
              mood="modern, innovative, sleek", ace="modern tech house instrumental, sidechained synth pads, arpeggiated synth, driving beat, sleek, innovative"),
    "luxury": D(name="Luxury minimal", bpm=74, mode="major", progs=[[1, 4, 2, 5], [4, 1, 6, 5]], swing=0.0, sevenths=True,
                chords="piano", rhythm="sustain", bass="sub", bass_rhythm="whole", pad=True, arp=None, motif="piano",
                reverb=(2.8, 0.34), risers=False, register=57,
                drums={1: {}, 2: {"kick": "x...............", "rim": "........x......."}, 3: {"kick": "x.......x.......", "rim": "....x.......x...", "shaker": "..x...x...x...x."}},
                mood="elegant, calm, exclusive", ace="elegant luxury ambient instrumental, soft grand piano, warm strings pad, minimal, sophisticated"),
    "sport": D(name="Sport / hype", bpm=150, mode="minor", progs=[[1, 6, 7, 1], [1, 4, 6, 7]], swing=0.0, halftime=True,
               chords="lead_saw", rhythm="stabs", bass="808", bass_rhythm="808", pad=False, arp=None, motif="lead",
               reverb=(1.2, 0.16), risers=True, register=62,
               drums={1: {"kick": "x.......x.......", "hat": "x.x.x.x.x.x.x.x."}, 2: {"kick": "x.....x...x.....", "snare": "........x.......", "hat": "x.x.x.x.x.x.x.x."},
                      3: {"kick": "x.....x...x..x..", "snare": "....x.......x...", "clap": "........x.......", "hat": "xxxxxxxxxxxxxxxx", "tom": "............xxxx"}},
               mood="aggressive, powerful, fast", ace="aggressive sports hype instrumental, heavy drums, distorted 808, stadium energy, powerful"),
    "playful": D(name="Playful", bpm=108, mode="major", progs=[[1, 6, 2, 5], [4, 5, 3, 6]], swing=0.25,
                 chords="marimba", rhythm="pulse8", bass="pluck", bass_rhythm="root_fifth", pad=False, arp=("pluck", "updown8"),
                 motif="marimba", reverb=(1.0, 0.16), risers=False, register=64,
                 drums={1: {"rim": "....x.......x..."}, 2: {"kick": "x.......x.......", "clap": "....x.......x...", "shaker": "x.x.x.x.x.x.x.x."},
                        3: {"kick": "x.....x.x.......", "clap": "....x.......x...", "shaker": "xxxxxxxxxxxxxxxx", "rim": "...x......x....."}},
                 mood="cheerful, quirky, friendly", ace="playful quirky instrumental, marimba, pizzicato plucks, ukulele, claps, cheerful, whimsical"),
}
content.register("music_styles", STYLES)  # + styles from content packs (content.py)


def chord_pcs(deg: int, mode: str, seventh: bool = False) -> tuple[list[int], int]:
    """Semitones above the tonic of the chord on scale degree `deg` (stacked thirds within the scale)."""
    sc = SCALES[mode]
    ks = (0, 2, 4, 6) if seventh else (0, 2, 4)
    pcs = [sc[(deg - 1 + k) % 7] + 12 * ((deg - 1 + k) // 7) for k in ks]
    return pcs, sc[deg - 1]


def voice(pcs: list[int], tonic: int, center: int, prev: list[int] | None) -> list[int]:
    """Pick the inversion nearest the previous chord (smooth voice leading), around `center`."""
    base = [tonic + p for p in pcs]
    cands = []
    for inv in range(len(base)):
        v = base[inv:] + [b + 12 for b in base[:inv]]
        for shift in (-24, -12, 0, 12):
            w = [x + shift for x in v]
            if center - 9 <= w[0] <= center + 6:
                cands.append(w)
    if not cands:
        cands = [base]
    if prev is None:
        return min(cands, key=lambda w: abs(np.mean(w) - center))
    return min(cands, key=lambda w: sum(min(abs(a - b) for b in prev) for a in w) + 0.3 * abs(np.mean(w) - center))


def _grid(style: dict, bar: float, steps: int = 16) -> list[float]:
    """Step times within a bar, with swing on the off 16ths."""
    st = bar / steps
    sw = style.get("swing", 0) * st * 0.5
    return [i * st + (sw if i % 2 else 0) for i in range(steps)]


def fit_tempo(bpm: float, seconds: float, tail: float = 1.8, halftime: bool = False) -> tuple[float, int]:
    """A tempo near `bpm` that fits a whole number of bars before the final chord."""
    body = max(2.0, seconds - tail)
    bar = 240 / bpm * (2 if halftime else 1)
    nb = max(2, round(body / bar))
    for cand in sorted({nb, nb - 1, nb + 1}, key=lambda x: abs(x - body / bar)):
        if cand < 2:
            continue
        b2 = 240 * cand * (2 if halftime else 1) / body
        if 0.88 * bpm <= b2 <= 1.12 * bpm:
            return b2, cand
    return bpm, nb


def energy_plan(nb: int, base: str) -> list[int]:
    """Energy per bar: a light intro, the body, lifts every 8 bars on longer pieces, a breath before the last lift."""
    intro = 1 if nb <= 6 else 2
    e = [1] * intro + [2] * (nb - intro)
    if nb >= 10:
        for i in range(intro + 8, nb, 16):
            for j in range(i, min(nb, i + 8)):
                e[j] = 3
    if nb >= 6:
        e[-2:] = [3, 3]
    if nb >= 14:
        k = max(intro, nb - 6)
        e[k] = 1
    if base == "cinematic":
        e = [max(0, x - (1 if i < nb // 3 else 0)) for i, x in enumerate(e)]
    return e


def motif_notes(seed: int, mode: str) -> list[tuple[float, int, float]]:
    """A short signature line (beat offset, scale degree, length in beats), the same for a client every time."""
    rng = np.random.default_rng(seed)
    rhythm = [[0, 1, 1.5, 2.5], [0, 0.5, 1, 2], [0, 1.5, 2, 3], [0, 0.75, 1.5, 2.25, 3]][seed % 4]
    deg = [0]
    for _ in rhythm[1:]:
        deg.append(int(np.clip(deg[-1] + rng.choice([-2, -1, 1, 2, 3]), -2, 6)))
    deg[-1] = rng.choice([0, 2, 4])
    lens = [b - a for a, b in zip(rhythm, rhythm[1:] + [4])]
    return [(r, d, min(l, 1.5)) for r, d, l in zip(rhythm, deg, lens)]


def compose(brief: dict, seconds: float) -> tuple[np.ndarray, dict]:
    style = dict(STYLES.get(brief.get("style"), STYLES["corporate"]))
    seed = int(brief.get("seed", 7))
    rng = np.random.default_rng(seed)
    mode = brief.get("mode") or style["mode"]
    tonic = 48 + KEYS.get(str(brief.get("key", "C")).replace("m", "").strip() or "C", 0)
    half = bool(style.get("halftime"))
    bpm, nb = fit_tempo(float(brief.get("bpm") or style["bpm"]), seconds, half)
    beat = 60 / bpm * (2 if half else 1)
    bar = 4 * beat
    total = S.n_of(seconds)
    stems = {k: np.zeros((2, total), dtype=np.float32) for k in ("drums", "bass", "harmony", "top")}
    energy = energy_plan(nb, brief.get("style", ""))
    if brief.get("energy") == "low":
        energy = [max(0, e - 1) for e in energy]
    elif brief.get("energy") == "high":
        energy = [min(3, e + 1) if i else e for i, e in enumerate(energy)]
    prog = style["progs"][seed % len(style["progs"])]
    seventh = style.get("sevenths", False)
    grid = _grid(style, bar)
    kicks = []
    prev = None
    drums_cache = {"kick": S.kick(1.0, rng), "snare": S.snare(0.5, rng), "clap": S.clap(rng), "hat": S.hat(False, rng),
                   "ohat": S.hat(True, rng), "shaker": S.shaker(rng), "rim": S.rim(), "tom": None}
    motif = motif_notes(seed, mode)
    sc = SCALES[mode]
    hum = lambda: float(rng.normal(0, 0.004))  # noqa: E731  (a few ms of human timing)

    def note(inst: str, m: float, dur: float, vel: float = 0.8) -> np.ndarray:
        if inst == "piano":
            return S.piano(m, dur, vel, rng)
        if inst == "epiano":
            return S.epiano(m, dur, vel)
        if inst == "pluck":
            return S.pluck(m, dur, 0.55, rng) * vel
        if inst == "marimba":
            return S.marimba(m, dur) * vel
        if inst == "strings":
            return S.strings(m, dur) * vel * 0.6
        if inst == "pad":
            return S.pad(m, dur, 0.45, 0.12, rng) * vel * 0.5
        if inst == "lead_saw":
            return S.lead(m, dur, 0.55, "saw") * vel * 0.45
        if inst == "lead_sq" or inst == "lead":
            return S.lead(m, dur, 0.5, "square") * vel * 0.35
        return S.piano(m, dur, vel, rng)

    for b in range(nb):
        t0 = b * bar
        e = energy[b]
        deg = prog[b % len(prog)]
        pcs, root = chord_pcs(deg, mode, seventh)
        v = voice(pcs, tonic, style["register"], prev)
        prev = v
        # harmony
        r = style["rhythm"]
        inst = style["chords"]
        if r == "sustain" or (r == "sustain_stab" and e < 3):
            for m in v:
                S.place(stems["harmony"], note(inst, m, bar * 0.98, 0.55), t0 + hum(), 0.5, pan=(m - 60) / 30)
        elif r == "sustain_stab":
            for k, step in enumerate((0, 6, 10)):
                for m in v:
                    S.place(stems["harmony"], note(inst, m, beat * (1.4 if k == 0 else 0.6), 0.5), t0 + grid[step] + hum(), 0.45, (m - 60) / 30)
        elif r == "pulse8":
            for i in range(0, 16, 2):
                acc = 0.62 if i % 4 == 0 else 0.42
                for m in v[:3]:
                    S.place(stems["harmony"], note(inst, m, beat * 0.45, acc), t0 + grid[i] + hum(), 0.4, (m - 60) / 30)
        elif r == "stabs":
            for step in (0, 3, 6, 10, 12):
                for m in v:
                    S.place(stems["harmony"], note(inst, m, beat * 0.35, 0.6), t0 + grid[step] + hum(), 0.38, (m - 60) / 30)
        elif r == "strum":
            for step, down in ((0, 1), (6, 0), (8, 1), (12, 1), (14, 0)):
                order = v if down else v[::-1]
                for k, m in enumerate(order + [order[0] + 12]):
                    S.place(stems["harmony"], note(inst, m, beat * 1.2, 0.55 if down else 0.4), t0 + grid[step] + k * 0.014, 0.4, (m - 60) / 40)
        if style.get("pad") and inst != "pad" and e >= 2:
            for m in v[:3]:
                S.place(stems["harmony"], S.pad(m + 12, bar, 0.3, 0.1, rng) * 0.22, t0, 0.5, (m - 60) / 25)
        # bass
        rm = tonic - 12 + sc[deg - 1]
        while rm > tonic - 2:
            rm -= 12
        br = style["bass_rhythm"]
        hits = {"whole": [(0, 16)], "eighths": [(i, 2) for i in range(0, 16, 2)], "syncop": [(0, 5), (6, 2), (8, 3), (11, 5)],
                "root_fifth": [(0, 6), (8, 6)], "offbeat": [(i, 1.5) for i in range(2, 16, 4)],
                "808": [(0, 6), (10, 6)]}.get(br, [(0, 16)])
        if e >= 1 or br == "whole":
            for k, (step, ln) in enumerate(hits):
                m = rm + (7 if br == "root_fifth" and k % 2 else 0) + (12 if br == "eighths" and k in (3, 7) else 0)
                S.place(stems["bass"], S.bass(m, ln * bar / 16 * 0.95, style["bass"]), t0 + grid[step], 0.55 if style["bass"] != "808" else 0.6)
        # drums
        pat = style["drums"].get(e, {})
        for part, g in pat.items():
            for i, ch in enumerate(g):
                if ch == ".":
                    continue
                gain = 0.55 if ch == "o" else 0.9
                if part == "tom":
                    smp = S.bass(tonic - 5 + (i % 4) * 2, 0.25, "sub") * 0.7
                else:
                    smp = drums_cache[part]
                pan = {"hat": 0.25, "ohat": 0.25, "shaker": -0.3, "rim": -0.15}.get(part, 0)
                S.place(stems["drums"], smp, t0 + grid[i] + hum() * 0.5, gain * {"kick": 0.9, "snare": 0.6, "clap": 0.55}.get(part, 0.5), pan)
                if part == "kick":
                    kicks.append(t0 + grid[i])
        # arpeggio / top line
        if style.get("arp") and e >= 2:
            ainst, apat = style["arp"]
            tones = v + [v[0] + 12, v[1] + 12]
            order = {"up8": tones[:4] * 2, "up16": (tones[:4] * 4), "broken8": [tones[0], tones[2], tones[1], tones[3]] * 2,
                     "updown8": tones[:4] + tones[3:0:-1] + tones[:1]}[apat]
            step_len = 2 if apat.endswith("8") else 1
            for k, m in enumerate(order):
                st = (k * step_len) % 16
                S.place(stems["top"], note(ainst, m + 12, beat * 0.4 * step_len, 0.45), t0 + grid[st] + hum(), 0.32, ((k % 4) - 1.5) / 3)
        if e >= 3 and style.get("motif") and b % 2 == 0:
            for off, d, ln in motif:
                m = tonic + 12 + sc[d % 7] + 12 * (d // 7)
                S.place(stems["top"], note(style["motif"], m, ln * beat, 0.5), t0 + off * beat, 0.3, 0.1)
        # riser into a lift
        if style.get("risers") and b + 1 < nb and energy[b + 1] > e:
            S.place(stems["top"], riser_fx(bar, rng), t0, 0.18)
    # the final chord: tonic, held to the end
    end_t = nb * bar
    pcs, _ = chord_pcs(1, mode, seventh)
    v = voice(pcs, tonic, style["register"], prev)
    ring = max(0.8, seconds - end_t)
    for m in v:
        S.place(stems["harmony"], note(style["chords"] if style["chords"] not in ("lead_saw", "lead_sq") else "pad", m, ring, 0.6), end_t, 0.55, (m - 60) / 30)
    S.place(stems["bass"], S.bass(tonic - 12, ring, style["bass"] if style["bass"] != "808" else "808"), end_t, 0.55)
    if energy[-1] >= 2:
        S.place(stems["drums"], S.kick(1.0, rng), end_t, 0.9)
        S.place(stems["drums"], S.crash(rng), end_t, 0.45)
    # mix
    if style.get("pump"):
        stems["harmony"] = S.duck(stems["harmony"], kicks, style["pump"])
        stems["bass"] = S.duck(stems["bass"], kicks, style["pump"] * 0.6)
    rv, mix = style["reverb"]
    stems["harmony"] = S.reverb(stems["harmony"], rv, mix, 0.5, seed)
    stems["top"] = S.reverb(stems["top"], rv, mix * 1.2, 0.6, seed + 1)
    if style.get("vinyl"):
        stems["drums"] += vinyl(total, rng)
    if style.get("lowpass"):
        for k in stems:
            stems[k] = S.filt(stems[k], hi=style["lowpass"])
    mixd = stems["drums"] * 0.9 + stems["bass"] * 0.85 + stems["harmony"] * 0.8 + stems["top"] * 0.7
    fade = S.n_of(min(1.2, seconds * 0.1))
    mixd[:, -fade:] *= np.linspace(1, 0, fade) ** 2
    out = S.master(mixd)
    scale = float(np.max(np.abs(out)) / (np.max(np.abs(mixd)) + 1e-9))
    for k in stems:
        stems[k] = np.clip(stems[k] * scale, -1, 1)
    meta = {"style": brief.get("style"), "style_name": style["name"], "bpm": round(bpm, 2), "bars": nb, "key": brief.get("key", "C"),
            "mode": mode, "seed": seed, "energy": energy}
    return out, {"stems": stems, "meta": meta}


def riser_fx(dur: float, rng) -> np.ndarray:
    n = S.n_of(dur)
    t = S.t_axis(n)
    nz = S.sweep(S.noise(n, rng), 600, 9000, 6)
    return (nz * (t / dur) ** 2 * 0.6).astype(np.float32)


def vinyl(n: int, rng) -> np.ndarray:
    hiss = S.filt(S.noise(n, rng), lo=1500, hi=8000) * 0.012
    clicks = np.zeros(n, dtype=np.float32)
    for i in rng.integers(0, n, max(1, n // S.SR * 3)):
        clicks[i:i + 30] += rng.uniform(0.05, 0.15) * np.exp(-np.arange(min(30, n - i)) / 5)
    x = hiss + S.filt(clicks, lo=800)
    return np.stack([x, np.roll(x, 37)])


def render(brief: dict, seconds: float, out_wav, stems_dir=None) -> dict:
    mix, extra = compose(brief, seconds)
    S.write_wav(out_wav, mix)
    if stems_dir is not None:
        from pathlib import Path
        Path(stems_dir).mkdir(parents=True, exist_ok=True)
        for k, x in extra["stems"].items():
            S.write_wav(Path(stems_dir) / f"{k}.wav", x)
    return extra["meta"]
