"""A small synthesizer in numpy: the instruments and effects AutoCut's composer and sound designer play.

Everything is computed, nothing sampled, so every note AutoCut makes is its own (royalty-free by construction) and
identical on every computer. Mono buffers are float32 numpy arrays at SR; stereo is (2, n).
"""
from __future__ import annotations

import numpy as np

SR = 44100


def midi_hz(m: float) -> float:
    return 440.0 * 2 ** ((m - 69) / 12)


def t_axis(n: int) -> np.ndarray:
    return np.arange(n, dtype=np.float32) / SR


def n_of(sec: float) -> int:
    return max(1, int(round(sec * SR)))


# ---- envelopes -------------------------------------------------------------------------------------------------

def adsr(n: int, a: float, d: float, s: float, r: float, hold: float | None = None) -> np.ndarray:
    """Attack/decay/sustain/release over n samples; release starts at `hold` seconds (default: n - r)."""
    env = np.zeros(n, dtype=np.float32)
    ia, idd, ir = n_of(a), n_of(d), n_of(r)
    ih = n - ir if hold is None else min(n, n_of(hold))
    k = 0
    seg = min(ia, n)
    env[:seg] = np.linspace(0, 1, seg, endpoint=False)
    k = seg
    seg = max(0, min(idd, ih - k))
    env[k:k + seg] = np.linspace(1, s, seg, endpoint=False)
    k += seg
    if ih > k:
        env[k:ih] = s
        k = ih
    last = env[k - 1] if k else s
    seg = n - k
    if seg > 0:
        env[k:] = last * np.linspace(1, 0, seg) ** 2
    return env


def expdecay(n: int, tau: float) -> np.ndarray:
    return np.exp(-t_axis(n) / max(tau, 1e-4)).astype(np.float32)


# ---- filters (zero-phase, in the frequency domain) ---------------------------------------------------------------

def _resp(n: int, lo: float | None, hi: float | None, order: int = 2) -> np.ndarray:
    f = np.fft.rfftfreq(n, 1 / SR)
    g = np.ones_like(f)
    if hi:
        g /= np.sqrt(1 + (f / hi) ** (2 * order))
    if lo:
        with np.errstate(divide="ignore"):
            g /= np.sqrt(1 + (lo / np.maximum(f, 1e-3)) ** (2 * order))
    return g


def filt(x: np.ndarray, lo: float | None = None, hi: float | None = None, order: int = 2) -> np.ndarray:
    """Low/high/band-pass (Butterworth-shaped magnitude, zero phase)."""
    if x.ndim == 2:
        return np.stack([filt(c, lo, hi, order) for c in x])
    n = len(x)
    X = np.fft.rfft(x, n)
    return np.fft.irfft(X * _resp(n, lo, hi, order), n).astype(np.float32)


def peq(x: np.ndarray, f0: float, gain_db: float, width: float = 1.0) -> np.ndarray:
    """A bell EQ (log-frequency Gaussian), zero phase."""
    if x.ndim == 2:
        return np.stack([peq(c, f0, gain_db, width) for c in x])
    n = len(x)
    f = np.fft.rfftfreq(n, 1 / SR)
    with np.errstate(divide="ignore"):
        oct_ = np.log2(np.maximum(f, 1) / f0)
    g = 10 ** (gain_db / 20 * np.exp(-(oct_ / width) ** 2))
    return np.fft.irfft(np.fft.rfft(x, n) * g, n).astype(np.float32)


def sweep(x: np.ndarray, hi0: float, hi1: float, steps: int = 6) -> np.ndarray:
    """A low-pass that opens (or closes) over the buffer: a crossfade of a few fixed filters."""
    cuts = np.geomspace(hi0, hi1, steps)
    layers = [filt(x, hi=c) for c in cuts]
    pos = np.linspace(0, steps - 1, len(x))
    out = np.zeros_like(x)
    for i in range(steps):
        w = np.clip(1 - np.abs(pos - i), 0, 1)
        out += layers[i] * w
    return out


# ---- oscillators ------------------------------------------------------------------------------------------------

def phase(freq, n: int) -> np.ndarray:
    f = np.broadcast_to(np.asarray(freq, dtype=np.float64), (n,))
    return (np.cumsum(f) / SR) % 1.0


def sine(freq, n: int) -> np.ndarray:
    return np.sin(2 * np.pi * phase(freq, n)).astype(np.float32)


def saw(freq, n: int) -> np.ndarray:
    return (2 * phase(freq, n) - 1).astype(np.float32)


def square(freq, n: int, width: float = 0.5) -> np.ndarray:
    return np.where(phase(freq, n) < width, 1.0, -1.0).astype(np.float32)


def tri(freq, n: int) -> np.ndarray:
    p = phase(freq, n)
    return (4 * np.abs(p - 0.5) - 1).astype(np.float32)


def noise(n: int, rng: np.random.Generator) -> np.ndarray:
    return rng.uniform(-1, 1, n).astype(np.float32)


# ---- instruments (each returns a mono note) ------------------------------------------------------------------------

def pad(m: float, dur: float, bright: float = 0.5, detune: float = 0.12, rng=None) -> np.ndarray:
    """Detuned saws, slow attack, gentle low-pass: warm sustained chords."""
    n = n_of(dur + 0.9)
    f = midi_hz(m)
    x = sum(saw(f * 2 ** (d / 12), n) for d in (-detune, 0.0, detune)) / 3
    x = filt(x, hi=500 + 3500 * bright)
    return x * adsr(n, 0.35, 0.4, 0.75, 0.8, hold=dur)


def epiano(m: float, dur: float, vel: float = 0.8) -> np.ndarray:
    """FM electric piano: bell-ish attack that mellows."""
    n = n_of(dur + 0.6)
    f = midi_hz(m)
    t = t_axis(n)
    idx = (1.6 * vel) * np.exp(-t / 0.35) + 0.25
    mod = np.sin(2 * np.pi * f * t) * idx
    x = np.sin(2 * np.pi * f * t + mod) + 0.12 * np.sin(2 * np.pi * f * 14 * t) * np.exp(-t / 0.05)
    return (x * adsr(n, 0.004, 0.6, 0.45, 0.5, hold=dur) * vel).astype(np.float32)


def piano(m: float, dur: float, vel: float = 0.8, rng=None) -> np.ndarray:
    """Additive piano-ish tone: decaying partials with a little stretch, a soft hammer."""
    n = n_of(min(dur + 1.2, 4.0))
    f = midi_hz(m)
    t = t_axis(n)
    x = np.zeros(n, dtype=np.float32)
    for k in range(1, 9):
        fk = f * k * (1 + 0.0004 * k * k)
        if fk > 16000:
            break
        x += (1 / k ** 1.25) * np.sin(2 * np.pi * fk * t) * np.exp(-t * (0.9 + 0.55 * k) * (1 + (m - 60) / 40))
    rng = rng or np.random.default_rng(int(m))
    x[:n_of(0.01)] += filt(noise(n_of(0.01), rng), lo=800, hi=5000) * 0.15
    rel = adsr(n, 0.002, 0.1, 1.0, 0.25, hold=dur + 0.05)
    return (x * rel * vel * 0.5).astype(np.float32)


def pluck(m: float, dur: float, bright: float = 0.6, rng=None) -> np.ndarray:
    """Karplus-Strong string: guitar/harp/pizzicato-like."""
    rng = rng or np.random.default_rng(int(m * 7))
    f = midi_hz(m)
    period = max(2, int(SR / f))
    n = n_of(min(dur + 0.8, 3.0))
    buf = filt(noise(period * 4, rng), hi=1500 + 7000 * bright)[:period]
    out = np.zeros(n, dtype=np.float32)
    decay = 0.996 - 0.004 * (1 - bright)
    i = 0
    while i < n:
        k = min(period, n - i)
        out[i:i + k] = buf[:k]
        buf = decay * 0.5 * (buf + np.roll(buf, 1))
        i += period
    return out * adsr(n, 0.001, 0.05, 1.0, 0.2, hold=dur + 0.3)


def marimba(m: float, dur: float) -> np.ndarray:
    n = n_of(0.9)
    f = midi_hz(m)
    t = t_axis(n)
    x = np.sin(2 * np.pi * f * t) * np.exp(-t / 0.35) + 0.35 * np.sin(2 * np.pi * f * 3.99 * t) * np.exp(-t / 0.06)
    return x.astype(np.float32) * 0.8


def lead(m: float, dur: float, bright: float = 0.5, shape: str = "saw") -> np.ndarray:
    n = n_of(dur + 0.15)
    f = midi_hz(m)
    vib = 1 + 0.004 * np.sin(2 * np.pi * 5.5 * t_axis(n)) * np.clip(t_axis(n) / 0.3, 0, 1)
    osc = {"saw": saw, "square": square, "tri": tri}[shape](f * vib, n)
    x = sweep(osc, 600 + 4000 * bright, 400 + 1500 * bright, 4)
    return x * adsr(n, 0.01, 0.15, 0.6, 0.12, hold=dur)


def bass(m: float, dur: float, kind: str = "sub") -> np.ndarray:
    n = n_of(dur + 0.08)
    f = midi_hz(m)
    if kind == "808":
        n = n_of(max(dur, 0.6) + 0.2)
        t = t_axis(n)
        fr = f * (1 + 0.6 * np.exp(-t / 0.03))
        x = np.tanh(1.6 * sine(fr, n)) * np.exp(-t / 0.9)
        return (x * adsr(n, 0.002, 0.05, 1, 0.1, hold=max(dur, 0.6))).astype(np.float32)
    if kind == "pluck":
        x = filt(saw(f, n) * 0.6 + sine(f, n) * 0.6, hi=900)
        return x * adsr(n, 0.003, 0.18, 0.35, 0.06, hold=dur)
    if kind == "warm":
        x = filt(saw(f, n), hi=420) * 0.8 + sine(f, n) * 0.5
        return x * adsr(n, 0.008, 0.2, 0.7, 0.08, hold=dur)
    x = sine(f, n) + 0.15 * sine(2 * f, n)
    return x * adsr(n, 0.006, 0.1, 0.85, 0.08, hold=dur)


def strings(m: float, dur: float) -> np.ndarray:
    n = n_of(dur + 1.0)
    f = midi_hz(m)
    vib = 1 + 0.003 * np.sin(2 * np.pi * 5.2 * t_axis(n))
    x = sum(saw(f * vib * 2 ** (d / 12), n) for d in (-0.07, 0.05)) / 2
    x = filt(x, lo=150, hi=2600)
    return x * adsr(n, 0.5, 0.3, 0.85, 0.9, hold=dur)


# ---- drums ------------------------------------------------------------------------------------------------------

def kick(punch: float = 1.0, rng=None) -> np.ndarray:
    n = n_of(0.45)
    t = t_axis(n)
    f = 45 + 95 * np.exp(-t / 0.04)
    x = sine(f, n) * np.exp(-t / (0.18 + 0.1 * punch))
    rng = rng or np.random.default_rng(1)
    x[:n_of(0.004)] += filt(noise(n_of(0.004), rng), lo=1500) * 0.6 * punch
    return np.tanh(1.4 * x).astype(np.float32)


def snare(tone: float = 0.5, rng=None) -> np.ndarray:
    rng = rng or np.random.default_rng(2)
    n = n_of(0.3)
    t = t_axis(n)
    body = sine(185, n) * np.exp(-t / 0.05) * tone
    nz = filt(noise(n, rng), lo=1800, hi=9000) * np.exp(-t / 0.09)
    return (body + nz).astype(np.float32) * 0.7


def clap(rng=None) -> np.ndarray:
    rng = rng or np.random.default_rng(3)
    n = n_of(0.35)
    t = t_axis(n)
    env = np.zeros(n, dtype=np.float32)
    for k, d in enumerate((0.0, 0.011, 0.022)):
        i = n_of(d)
        env[i:] += np.exp(-(t[: n - i]) / (0.012 if k < 2 else 0.12))
    return (filt(noise(n, rng), lo=900, hi=6000) * env * 0.6).astype(np.float32)


def hat(open_: bool = False, rng=None) -> np.ndarray:
    rng = rng or np.random.default_rng(4 + open_)
    n = n_of(0.25 if open_ else 0.06)
    t = t_axis(n)
    return (filt(noise(n, rng), lo=7000) * np.exp(-t / (0.08 if open_ else 0.015)) * 0.45).astype(np.float32)


def shaker(rng=None) -> np.ndarray:
    rng = rng or np.random.default_rng(6)
    n = n_of(0.09)
    return (filt(noise(n, rng), lo=4500, hi=11000) * adsr(n, 0.02, 0.02, 0.6, 0.05) * 0.3).astype(np.float32)


def rim(rng=None) -> np.ndarray:
    n = n_of(0.05)
    t = t_axis(n)
    return (sine(1700, n) * np.exp(-t / 0.006) * 0.5 + sine(820, n) * np.exp(-t / 0.01) * 0.3).astype(np.float32)


def crash(rng=None) -> np.ndarray:
    rng = rng or np.random.default_rng(7)
    n = n_of(2.2)
    t = t_axis(n)
    return (filt(noise(n, rng), lo=3500) * np.exp(-t / 0.7) * 0.35).astype(np.float32)


# ---- mixing helpers -----------------------------------------------------------------------------------------------

def place(buf: np.ndarray, x: np.ndarray, at: float, gain: float = 1.0, pan: float = 0.0) -> None:
    """Add mono x into stereo buf at `at` seconds (equal-power pan, -1 left … 1 right)."""
    i = n_of(at) if at > 0 else 0
    if i >= buf.shape[1]:
        return
    k = min(len(x), buf.shape[1] - i)
    a = (pan + 1) * np.pi / 4
    buf[0, i:i + k] += x[:k] * gain * np.cos(a)
    buf[1, i:i + k] += x[:k] * gain * np.sin(a)


def reverb(x: np.ndarray, seconds: float = 1.8, mix: float = 0.25, bright: float = 0.5, seed: int = 11) -> np.ndarray:
    """Convolution with a decaying noise tail (a different tail per side for width)."""
    if mix <= 0:
        return x
    rng = np.random.default_rng(seed)
    n_ir = n_of(seconds)
    t = t_axis(n_ir)
    out = np.empty_like(x)
    for c in range(2):
        ir = filt(noise(n_ir, rng), hi=2500 + 6000 * bright) * np.exp(-t * 6.9 / seconds)
        ir[: n_of(0.012)] = 0  # pre-delay
        ir /= np.sqrt(np.sum(ir ** 2)) + 1e-9
        n = x.shape[1] + n_ir
        wet = np.fft.irfft(np.fft.rfft(x[c], n) * np.fft.rfft(ir, n), n)[: x.shape[1]]
        out[c] = x[c] * (1 - mix * 0.5) + wet.astype(np.float32) * mix
    return out


def duck(x: np.ndarray, hits: list[float], depth: float = 0.5, release: float = 0.22) -> np.ndarray:
    """Sidechain-style pumping on the given hit times."""
    if not hits or depth <= 0:
        return x
    g = np.ones(x.shape[-1], dtype=np.float32)
    r = n_of(release)
    curve = 1 - depth * (1 - np.linspace(0, 1, r)) ** 2
    for h in hits:
        i = n_of(h)
        if i >= len(g):
            continue
        k = min(r, len(g) - i)
        g[i:i + k] = np.minimum(g[i:i + k], curve[:k])
    return x * g


def master(x: np.ndarray, pocket: bool = True, ceiling: float = 0.89) -> np.ndarray:
    """Clean up the low end, carve room for a voice (a gentle dip where speech lives), soft-limit."""
    x = filt(x, lo=32, order=2)
    if pocket:
        x = peq(x, 2600, -3.0, 1.1)
    peak = np.max(np.abs(x)) + 1e-9
    x = x / peak * 1.25
    x = np.tanh(x) / np.tanh(1.25)
    return (x * ceiling).astype(np.float32)


def write_wav(path, x: np.ndarray, sr: int = SR) -> None:
    import wave
    x = np.atleast_2d(x)
    pcm = (np.clip(x.T, -1, 1) * 32767).astype("<i2")
    with wave.open(str(path), "wb") as w:
        w.setnchannels(x.shape[0])
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())


def read_wav(path) -> np.ndarray:
    import wave
    with wave.open(str(path), "rb") as w:
        n, ch = w.getnframes(), w.getnchannels()
        data = np.frombuffer(w.readframes(n), dtype="<i2").astype(np.float32) / 32767
    return data.reshape(-1, ch).T
