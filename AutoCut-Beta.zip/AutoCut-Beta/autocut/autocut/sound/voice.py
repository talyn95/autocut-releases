"""AutoCut's own voiceover: a local, free text-to-speech voice (Kokoro, Apache-2.0) that runs on this computer.

`speak(text, out)` writes a broadcast-ready WAV (48 kHz mono, de-rumbled, gently compressed, -16 LUFS). Voices are the
Kokoro presets (am_* / bm_* male, af_* / bf_* female) or a blend written "am_michael:60,am_onyx:40". The model files
(kokoro-v1.0.onnx + voices-v1.0.bin) are looked for in settings `voice.model_dir`, AutoCut's data folder and the
HyperFrames cache; nothing is sent anywhere.
"""
from __future__ import annotations

import os
import subprocess
import tempfile
from pathlib import Path

DEFAULT_VOICE = "am_michael:60,am_onyx:40"  # warm, confident, a little depth
MODEL, VOICES = "kokoro-v1.0.onnx", "voices-v1.0.bin"


def _dirs(settings: dict) -> list[Path]:
    out = []
    if (settings.get("voice") or {}).get("model_dir"):
        out.append(Path(settings["voice"]["model_dir"]).expanduser())
    if settings.get("data_dir"):
        out.append(Path(settings["data_dir"]).expanduser() / "models" / "voice")
    home = Path(os.path.expanduser("~"))
    out += [home / ".autocut" / "models" / "voice", home / ".cache" / "hyperframes" / "tts"]
    return out


def setup(settings: dict, say=print) -> Path:
    """Download the voice model once (content/catalog.json `voice`) into AutoCut's models folder."""
    import urllib.request
    from ..content import catalog
    if find_model(settings):
        return find_model(settings)[0].parent
    cat = catalog().get("voice") or {}
    dest = _dirs(settings)[-2]  # ~/.autocut/models/voice (or the data folder's, when set)
    if settings.get("data_dir"):
        dest = Path(settings["data_dir"]).expanduser() / "models" / "voice"
    dest.mkdir(parents=True, exist_ok=True)
    say(f"downloading AutoCut's voice (one time, about {cat.get('megabytes', 340)} MB) …")
    for name, url in (cat.get("files") or {}).items():
        tmp = dest / (name + ".part")
        urllib.request.urlretrieve(url, tmp)
        tmp.replace(dest / name)
    if not find_model(settings):
        raise RuntimeError("The voice model didn't download completely. Try again.")
    return dest


def find_model(settings: dict) -> tuple[Path, Path] | None:
    for d in _dirs(settings):
        m = next(iter(sorted(d.rglob(MODEL))), None) if d.exists() else None
        v = next(iter(sorted(d.rglob(VOICES))), None) if d.exists() else None
        if m and v:
            return m, v
    return None


def available(settings: dict) -> bool:
    try:
        import kokoro_onnx  # noqa: F401
    except ImportError:
        return False
    return find_model(settings) is not None


_engine = None


def _kokoro(settings: dict):
    global _engine
    if _engine is None:
        from kokoro_onnx import Kokoro
        found = find_model(settings)
        if not found:
            raise RuntimeError("AutoCut's voice model isn't on this computer yet (kokoro-v1.0.onnx + voices-v1.0.bin).")
        _engine = Kokoro(str(found[0]), str(found[1]))
    return _engine


def voices(settings: dict) -> list[str]:
    return sorted(_kokoro(settings).get_voices())


def _style(k, voice: str):
    """A preset name, or a weighted blend "a:60,b:40"."""
    if ":" not in voice and "," not in voice:
        return voice
    parts = [p.split(":") for p in voice.split(",")]
    total = sum(float(w) for _, w in parts)
    return sum(k.get_voice_style(n.strip()) * (float(w) / total) for n, w in parts)


def speak(text: str, out: Path, settings: dict | None = None, voice: str = DEFAULT_VOICE, speed: float = 1.0,
          lang: str = "en-us") -> Path:
    """Say `text` into `out` (WAV). Returns `out`."""
    import numpy as np
    import soundfile as sf
    settings = settings or {}
    k = _kokoro(settings)
    samples, rate = k.create(text, voice=_style(k, voice), speed=speed, lang=lang)
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        raw = Path(td) / "raw.wav"
        sf.write(raw, np.asarray(samples, dtype=np.float32), rate)
        # broadcast polish: no rumble, a touch of presence, even level
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(raw), "-af",
                        "highpass=f=70,equalizer=f=3200:t=q:w=1.2:g=2.5,acompressor=threshold=0.12:ratio=3:attack=8:release=120,"
                        "loudnorm=I=-16:TP=-1.5:LRA=7,aresample=48000", "-ac", "1", str(out)], check=True)
    return out
