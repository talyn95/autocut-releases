"""The sound designer: picture events → placed effects, with restraint.

Events come from the edit (a transition, a graphic landing, a slam, a sticker, a number counting, a reveal, the end
card…). Each maps to an effect; its timing is shifted so the effect's peak lands on the event (a whoosh peaks
mid-sweep, a riser ends on it). A density limit keeps it from sounding like a template: effects at least 1.2 s apart,
about one every 3–4 s in talking-head edits, the more important event wins a clash.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from . import sfx as FX
from . import synth as S

# event → (effect, priority, level dB, where the effect's peak sits as a fraction of its length)
MAP = {
    "transition": ("whoosh", 2, -10, 0.45), "swipe": ("swish", 2, -11, 0.45), "graphic": ("swish", 1, -14, 0.45),
    "lower_third": ("swipe", 1, -15, 0.4), "slam": ("impact", 3, -8, 0.0), "number": ("pop", 2, -12, 0.0),
    "sticker": ("pop", 1, -13, 0.0), "reveal": ("riser", 3, -12, 1.0), "hit": ("hit", 2, -10, 0.0),
    "end": ("impact", 3, -9, 0.0), "logo": ("shimmer", 2, -14, 0.1), "ui": ("click", 1, -16, 0.0),
    "typing": ("typing", 1, -18, 0.0), "glitch": ("glitch", 2, -12, 0.0), "boom": ("boom", 3, -8, 0.0),
}
DENSITY = {"light": (2.5, 0.20), "normal": (1.2, 0.30), "rich": (0.6, 0.6)}  # min gap s, max effects per second


def plan(events: list[dict], total: float, density: str = "normal") -> list[dict]:
    """events: [{t, kind}] → cues [{t (start), kind (effect), event, level_db}] in time order, thinned."""
    gap, per_s = DENSITY.get(density, DENSITY["normal"])
    cand = []
    for e in events:
        if e.get("kind") not in MAP:
            continue
        fx, pri, db, peak = MAP[e["kind"]]
        cand.append({"event": e["kind"], "kind": fx, "pri": pri + float(e.get("boost", 0)), "level_db": db, "peak": peak,
                     "at": float(e["t"])})
    # most important first, then keep those with room around them
    kept: list[dict] = []
    for c in sorted(cand, key=lambda c: (-c["pri"], c["at"])):
        if c["at"] < 0 or c["at"] > total:
            continue
        if any(abs(c["at"] - k["at"]) < gap for k in kept):
            continue
        kept.append(c)
    budget = max(2, int(total * per_s) + 1)
    kept = sorted(sorted(kept, key=lambda c: -c["pri"])[:budget], key=lambda c: c["at"])
    return kept


def materialise(cues: list[dict], folder: Path, flavour: str, seed: int) -> list[dict]:
    """Render the effects (cached per flavour), and set each cue's start so its peak lands on the event."""
    files = FX.pack(folder, flavour, seed)
    out = []
    for c in cues:
        f = files[c["kind"]]
        length = S.read_wav(f).shape[1] / S.SR
        start = c["at"] - c["peak"] * length
        head = max(0.0, -start)  # an effect that would start before 0 s loses its head, not its peak
        out.append({**c, "file": f, "start": round(max(0.0, start), 3), "src_in": round(head, 3),
                    "length": round(length - head, 3)})
    # one track: no overlaps (an earlier effect's tail is cut where the next starts)
    for a, b in zip(out, out[1:]):
        if a["start"] + a["length"] > b["start"]:
            a["length"] = round(max(0.05, b["start"] - a["start"]), 3)
    return out


def render(cues: list[dict], total: float, out: Path) -> Path:
    """All cues mixed into one stereo WAV (for MP4s: storyboards, transcript videos, previews)."""
    buf = np.zeros((2, S.n_of(total)), dtype=np.float32)
    cache: dict[Path, np.ndarray] = {}
    for c in cues:
        x = cache.setdefault(c["file"], S.read_wav(c["file"]))
        j = S.n_of(c.get("src_in", 0)) if c.get("src_in") else 0
        n = S.n_of(c["length"])
        i = S.n_of(c["start"])
        k = min(n, x.shape[1] - j, buf.shape[1] - i)
        if k <= 0:
            continue
        buf[:, i:i + k] += x[:, j:j + k] * 10 ** (c["level_db"] / 20)
    S.write_wav(out, np.clip(buf, -1, 1))
    return out
