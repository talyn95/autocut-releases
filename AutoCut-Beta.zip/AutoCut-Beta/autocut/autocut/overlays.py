"""Renders the graphics layers that sit on top of the edit."""
from __future__ import annotations

import subprocess
from pathlib import Path

from .captions import ass_color, ts_ass
from .config import Client, brand_backdrop, hex_to_rgb


def _ffmpeg(args: list[str], cwd: Path | None = None) -> None:
    res = subprocess.run(["ffmpeg", "-y", "-loglevel", "error", *args],
                         capture_output=True, text=True, cwd=cwd)
    if res.returncode != 0:
        raise RuntimeError(f"ffmpeg failed: {res.stderr[-1500:]}")


def _filter_path(p: Path) -> str:
    # ffmpeg filter arguments need ':' , '\' and quotes escaped.
    return str(p).replace("\\", "/").replace(":", r"\:").replace("'", r"\'")


def _fonts_dir(client: Client) -> Path | None:
    d = client.path(client.brand["fonts"]["folder"])
    return d if d and d.is_dir() and any(d.iterdir()) else None


def render_ass(ass: Path, client: Client, size: tuple[int, int], fps: float,
               duration: float, out: Path) -> Path:
    """Render an ASS file onto a transparent canvas → ProRes 4444 with alpha."""
    W, H = size
    vf = f"ass='{_filter_path(ass.name)}':alpha=1"
    fonts = _fonts_dir(client)
    if fonts:
        vf += f":fontsdir='{_filter_path(fonts.resolve())}'"
    _ffmpeg(["-f", "lavfi", "-i", f"color=c=black@0.0:s={W}x{H}:r={fps:.3f}:d={duration:.3f},format=rgba",
             "-vf", vf, "-c:v", "prores_ks", "-profile:v", "4444", "-pix_fmt", "yuva444p10le",
             "-vendor", "apl0", out.name], cwd=ass.parent)
    return out


def watermark(client: Client, size: tuple[int, int], out: Path) -> Path | None:
    """A full-frame transparent PNG with the logo in its corner, so it drops in place."""
    cfg = client.brand["logo"]
    logo = client.path(cfg["file"])
    if not (cfg["watermark"] and logo and logo.exists()):
        return None
    W, H = size
    lw = int(W * cfg["width_pct"] / 100)
    m = int(min(W, H) * 0.05)
    x = {"left": str(m), "right": f"W-w-{m}"}[cfg["position"].split("-")[1]]
    y = {"top": str(int(H * 0.06)), "bottom": f"H-h-{int(H * 0.06)}"}[cfg["position"].split("-")[0]]
    _ffmpeg(["-f", "lavfi", "-i", f"color=c=black@0.0:s={W}x{H},format=rgba", "-i", str(logo),
             "-filter_complex",
             f"[1]scale={lw}:-1,format=rgba,colorchannelmixer=aa={cfg['opacity']}[l];[0][l]overlay={x}:{y}:format=auto",
             "-frames:v", "1", str(out)])
    return out


def add_credit(png: Path | None, size: tuple[int, int], text: str, out: Path) -> Path:
    """Small agency credit ("Made by Triumphant Media") in the bottom-right corner, added to the
    watermark PNG (or a fresh transparent frame when there's no logo watermark)."""
    from PIL import Image, ImageDraw, ImageFont
    W, H = size
    img = Image.open(png).convert("RGBA") if png and png.exists() else Image.new("RGBA", (W, H), (0, 0, 0, 0))
    unit = min(W, H) / 1080
    font = None
    for f in ("/System/Library/Fonts/SFNS.ttf", "/System/Library/Fonts/Helvetica.ttc",
              r"C:\Windows\Fonts\segoeui.ttf", r"C:\Windows\Fonts\arial.ttf",
              "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"):
        try:
            font = ImageFont.truetype(f, int(24 * unit))
            break
        except OSError:
            continue
    font = font or ImageFont.load_default()
    d = ImageDraw.Draw(img)
    m = int(28 * unit)
    d.text((W - m, H - m), text, font=font, anchor="rd", fill=(255, 255, 255, 190),
           stroke_width=max(1, int(2 * unit)), stroke_fill=(0, 0, 0, 120))
    img.save(out)
    return out


def end_card(client: Client, size: tuple[int, int], fps: float, workdir: Path) -> Path | None:
    """The client's own end card if they have one, otherwise a branded CTA card."""
    cta = client.brand["cta"]
    if not cta["enabled"]:
        return None
    own = client.path(cta["end_card"])
    if own and own.exists():
        return own
    if not cta["text"]:
        return None
    W, H = size
    colors, fonts = client.brand["colors"], client.brand["fonts"]
    dur = float(cta["duration"])
    scale = W / 1080 if W < H else H / 1080
    head, sub = int(96 * scale), int(52 * scale)
    text = cta["text"].upper().replace("{", "(").replace("}", ")")
    events = (f"Dialogue: 0,{ts_ass(0.15)},{ts_ass(dur)},CTA,,0,0,0,,"
              r"{\fscx60\fscy60\alpha&HFF&\t(0,120,\alpha&H00&\fscx110\fscy110)\t(120,220,\fscx100\fscy100)}"
              f"{text}\n")
    if cta["subtext"]:
        events += (f"Dialogue: 0,{ts_ass(0.5)},{ts_ass(dur)},Sub,,0,0,0,,"
                   r"{\fad(200,0)}" + cta["subtext"].replace("{", "(") + "\n")
    ass = workdir / "endcard.ass"
    ass.write_text(f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: CTA,{fonts['headline']},{head},{ass_color(colors['primary'])},{ass_color(colors['primary'])},&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,0,0,5,{int(W*0.1)},{int(W*0.1)},0,1
Style: Sub,{fonts['caption']},{sub},{ass_color(colors['text'])},{ass_color(colors['text'])},&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,2,{int(W*0.1)},{int(W*0.1)},{int(H*0.3)},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
{events}""")
    r, g, b = hex_to_rgb(colors["secondary"])
    inputs = ["-f", "lavfi", "-i", f"color=c=0x{r:02x}{g:02x}{b:02x}:s={W}x{H}:r={fps:.3f}:d={dur:.3f}"]
    vf = f"ass='{_filter_path(ass.name)}'"
    fonts_dir = _fonts_dir(client)
    if fonts_dir:
        vf += f":fontsdir='{_filter_path(fonts_dir.resolve())}'"
    logo = client.path(client.brand["logo"]["file"])
    if logo and logo.exists():
        inputs += ["-loop", "1", "-i", str(logo.resolve())]
        graph = (f"[0]{vf}[bg];[1]scale={int(W*0.42)}:-1,format=rgba,fade=in:st=0:d=0.3:alpha=1[l];"
                 f"[bg][l]overlay=(W-w)/2:H*0.18:shortest=1[v]")
        args = [*inputs, "-filter_complex", graph, "-map", "[v]"]
    else:
        args = [*inputs, "-vf", vf]
    out = workdir / "endcard.mov"
    _ffmpeg([*args, "-t", f"{dur:.3f}", "-c:v", "prores_ks", "-profile:v", "3",
             "-pix_fmt", "yuv422p10le", "-vendor", "apl0", out.name], cwd=workdir)
    return out


def style_proof(client: Client, out: Path, workdir: Path) -> Path:
    """A short sample of the client's caption style over a brand-tinted background,
    for sign-off during onboarding."""
    from .captions import write_ass
    sample = ("So here's the thing most people get wrong, and it costs them "
              "about 3000 dollars every single year. The fix is free.").split()
    words, t = [], 0.3
    for w in sample:
        d = 0.18 + 0.03 * len(w)
        words.append({"word": w, "start": round(t, 3), "end": round(t + d, 3)})
        t += d + 0.06
    W, H = client.size
    ass = workdir / "proof.ass"
    from .emphasis import rules
    write_ass(words, t + 0.6, client.brand, (W, H), ass, emphasis=rules(words, client.brand))
    overlay = render_ass(ass, client, (W, H), 30, t + 0.6, workdir / "proof_overlay.mov")
    icons = []
    if client.brand["captions"]["style"] == "icons":  # the icon pops too, so the sample shows the whole style
        from .captions import icon_moments, layout
        from .effects.iconlib import sticker
        from .effects.popups import render_popup
        lay = layout(client.brand, (W, H))
        for i, m in enumerate(icon_moments(words, rules(words, client.brand), client.brand)):
            pop = {**m, "sticker": sticker(m["icon"], client.brand["colors"]["primary"]), "side": 0, "cx": lay["x"],
                   "cy": lay["y"] - lay["fontsize"] * 2.1, "dur": 1.1, "size_pct": 15}
            icons.append((m["start"], render_popup(pop, client, (W, H), 30, workdir / f"proof_icon_{i}.mov")))
    c0, c1 = brand_backdrop(client.brand)
    ins, graph, last = [], "[0][1]overlay=format=auto[v1]", "v1"
    for i, (start, clip) in enumerate(icons):
        ins += ["-itsoffset", f"{start:.3f}", "-i", str(clip)]
        graph += f";[{last}][{i + 2}]overlay=format=auto:eof_action=pass[v{i + 2}]"
        last = f"v{i + 2}"
    _ffmpeg(["-f", "lavfi", "-i", f"gradients=s={W}x{H}:c0={c0}:c1={c1}:d={t + 0.6:.2f}:r=30",
             "-i", str(overlay), *ins, "-filter_complex", graph, "-map", f"[{last}]",
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "20", str(out)])
    return out
