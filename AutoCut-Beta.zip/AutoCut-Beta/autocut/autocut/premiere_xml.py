"""Write the rough cut as Final Cut Pro 7 XML (xmeml), which Premiere Pro imports
with File → Import and rebuilds as an editable sequence.

Track layout (see TRACKS):
  V1  edit + end card              V7   graphic cards + lower third    A1  dialogue (the subject's voice)
  V2  B-roll + full-screen media   V8   your media (floating)          A2  sound effects
                                                                       A3  music
  V3  grain + vignette             V9   pop-up stickers
  V4  light leaks                  V10  story cutaways
  V5  behind-subject layer         V11  kinetic captions
  V6  cut-out subject              V12  logo watermark
                                   V13  Motion Studio graphics
"""
from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import quote

from .media import MediaInfo, timebase


TRACKS = {"edit": 1, "broll": 2, "texture": 3, "leaks": 4, "behind": 5, "cutout": 6,
          "cards": 7, "media": 8, "popups": 9, "story": 10, "captions": 11, "logo": 12, "motion": 13}


def _el(parent, tag, text=None, **attrs):
    e = ET.SubElement(parent, tag, {k: str(v) for k, v in attrs.items()})
    if text is not None:
        e.text = str(text)
    return e


def pathurl(path: Path | str) -> str:
    """Premiere's file link: file://localhost/Users/... on a Mac, file://localhost/C%3a/Users/... on Windows."""
    posix = Path(path).as_posix() if not isinstance(path, str) else path.replace("\\", "/")
    return "file://localhost" + ("" if posix.startswith("/") else "/") + quote(posix)

class Timeline:
    def __init__(self, name: str, fps: float, size: tuple[int, int]):
        self.name, self.fps, self.size = name, fps, size
        self.tb, self.ntsc = timebase(fps)
        self.files: dict[Path, tuple[str, MediaInfo]] = {}
        self.video: list[list[dict]] = [[] for _ in range(len(TRACKS))]
        self.audio: list[list[dict]] = [[] for _ in range(3)]
        # "roles": A1 dialogue, A2 sound effects, A3 music. Timelines saved before 0.20 are "stereo" (A1/A2 = the
        # left/right of the dialogue, A3 music).
        self.audio_layout = "roles"
        self.markers: list[tuple[int, str, str]] = []
        self._ids = 0

    def frames(self, seconds: float) -> int:
        return int(round(seconds * self.fps))

    def _next(self, prefix: str) -> str:
        self._ids += 1
        return f"{prefix}-{self._ids}"

    def file_id(self, info: MediaInfo) -> str:
        key = info.path.resolve()
        if key not in self.files:
            self.files[key] = (f"file-{len(self.files) + 1}", info)
        return self.files[key][0]

    def add_video(self, track: int | str, info: MediaInfo, rec_in: int, src_in: int, length: int,
                  name: str | None = None, zoom: float = 1.0, center: tuple[float, float] | None = None) -> dict:
        """zoom multiplies the fill-the-frame scale (punch-ins; < 1 for picture-in-picture).
        center moves the clip: (x, y) offset as a fraction of the frame, (0, 0) = centred."""
        track = TRACKS[track] if isinstance(track, str) else track
        while len(self.video) < track:
            self.video.append([])
        item = {"id": self._next("clipitem"), "info": info, "file": self.file_id(info),
                "start": rec_in, "end": rec_in + length, "in": src_in, "out": src_in + length,
                "name": name or info.path.name, "links": [], "zoom": zoom}
        if center:
            item["center"] = [round(center[0], 4), round(center[1], 4)]
        self.video[track - 1].append(item)
        return item

    def add_audio(self, track: int, info: MediaInfo, rec_in: int, src_in: int, length: int,
                  source_channel: int = 1, level: float | None = None) -> dict:
        while len(self.audio) < track:
            self.audio.append([])
        item = {"id": self._next("clipitem"), "info": info, "file": self.file_id(info),
                "start": rec_in, "end": rec_in + length, "in": src_in, "out": src_in + length,
                "name": info.path.name, "channel": source_channel, "level": level, "links": []}
        self.audio[track - 1].append(item)
        return item

    @staticmethod
    def link(*items: dict) -> None:
        for it in items:
            it["links"] = list(items)

    # ---- save / load (used by "Export MP4") -------------------------------
    def save(self, path: Path) -> Path:
        import dataclasses
        import json

        def item(it):
            out = {k: it[k] for k in ("start", "end", "in", "out", "name") if k in it}
            out.update(zoom=it.get("zoom", 1.0), level=it.get("level"), channel=it.get("channel"),
                       center=it.get("center"),
                       info={**dataclasses.asdict(it["info"]), "path": str(it["info"].path)})
            return out
        path.write_text(json.dumps({"name": self.name, "fps": self.fps, "size": list(self.size),
                                    "video": [[item(i) for i in t] for t in self.video],
                                    "audio": [[item(i) for i in t] for t in self.audio], "audio_layout": self.audio_layout}, indent=1))
        return path

    @classmethod
    def load(cls, path: Path) -> "Timeline":
        import json
        data = json.loads(Path(path).read_text())
        tl = cls(data["name"], data["fps"], tuple(data["size"]))

        def item(d):
            info = MediaInfo(**{**d["info"], "path": Path(d["info"]["path"])})
            return {**d, "info": info, "file": tl.file_id(info), "id": tl._next("clipitem"), "links": []}
        tl.video = [[item(d) for d in t] for t in data["video"]]
        tl.audio = [[item(d) for d in t] for t in data["audio"]]
        tl.audio_layout = data.get("audio_layout", "stereo")
        return tl

    def marker(self, frame: int, name: str, comment: str = "") -> None:
        self.markers.append((frame, name, comment))

    # ---- XML -------------------------------------------------------------
    def _rate(self, parent):
        r = _el(parent, "rate")
        _el(r, "timebase", self.tb)
        _el(r, "ntsc", "TRUE" if self.ntsc else "FALSE")

    def _file(self, parent, fid: str, info: MediaInfo, written: set):
        f = _el(parent, "file", id=fid)
        if fid in written:
            return
        written.add(fid)
        _el(f, "name", info.path.name)
        _el(f, "pathurl", pathurl(info.path.resolve()))
        self._rate(f)
        _el(f, "duration", self.frames(info.duration) if not info.is_still else self.frames(3600))
        media = _el(f, "media")
        if info.has_video:
            sc = _el(_el(media, "video"), "samplecharacteristics")
            self._rate(sc)
            _el(sc, "width", info.width)
            _el(sc, "height", info.height)
            _el(sc, "anamorphic", "FALSE")
            _el(sc, "pixelaspectratio", "square")
        if info.audio_channels:
            a = _el(media, "audio")
            sc = _el(a, "samplecharacteristics")
            _el(sc, "depth", 16)
            _el(sc, "samplerate", 48000)
            _el(a, "channelcount", info.audio_channels)

    def _clip(self, track_el, item: dict, kind: str, written: set):
        c = _el(track_el, "clipitem", id=item["id"])
        _el(c, "masterclipid", "master-" + item["file"])
        _el(c, "name", item["name"])
        _el(c, "enabled", "TRUE")
        _el(c, "duration", self.frames(item["info"].duration) if not item["info"].is_still else self.frames(3600))
        self._rate(c)
        for k in ("start", "end", "in", "out"):
            _el(c, k, item[k])
        self._file(c, item["file"], item["info"], written)
        if kind == "video":
            W, H = self.size
            info = item["info"]
            if info.width and info.height:
                scale = max(W / info.width, H / info.height) * 100 * item.get("zoom", 1.0)
                center = item.get("center")
                if abs(scale - 100) > 0.5 or center:
                    eff = _el(_el(c, "filter"), "effect")
                    _el(eff, "name", "Basic Motion")
                    _el(eff, "effectid", "basic")
                    _el(eff, "effectcategory", "motion")
                    _el(eff, "effecttype", "motion")
                    _el(eff, "mediatype", "video")
                    p = _el(eff, "parameter", authoringApp="PremierePro")
                    _el(p, "parameterid", "scale")
                    _el(p, "name", "Scale")
                    _el(p, "valuemin", 0)
                    _el(p, "valuemax", 1000)
                    _el(p, "value", f"{scale:.2f}")
                    if center:
                        p = _el(eff, "parameter", authoringApp="PremierePro")
                        _el(p, "parameterid", "center")
                        _el(p, "name", "Center")
                        v = _el(p, "value")
                        _el(v, "horiz", f"{center[0]:.4f}")
                        _el(v, "vert", f"{center[1]:.4f}")
        else:
            st = _el(c, "sourcetrack")
            _el(st, "mediatype", "audio")
            _el(st, "trackindex", item["channel"])
            if item.get("level") is not None:
                eff = _el(_el(c, "filter"), "effect")
                _el(eff, "name", "Audio Levels")
                _el(eff, "effectid", "audiolevels")
                _el(eff, "effectcategory", "audiolevels")
                _el(eff, "effecttype", "audiolevels")
                _el(eff, "mediatype", "audio")
                p = _el(eff, "parameter", authoringApp="PremierePro")
                _el(p, "parameterid", "level")
                _el(p, "name", "Level")
                _el(p, "valuemin", 0)
                _el(p, "valuemax", 3.98109)
                _el(p, "value", f"{item['level']:.5f}")
        for other in item["links"]:
            ln = _el(c, "link")
            _el(ln, "linkclipref", other["id"])
            is_audio = "channel" in other
            _el(ln, "mediatype", "audio" if is_audio else "video")
            tracks = self.audio if is_audio else self.video
            t_idx, c_idx = next((ti, ci) for ti, t in enumerate(tracks)
                                for ci, x in enumerate(t) if x is other)
            _el(ln, "trackindex", t_idx + 1)
            _el(ln, "clipindex", c_idx + 1)
            if is_audio:
                _el(ln, "groupindex", 1)

    def write(self, path: Path) -> Path:
        root = ET.Element("xmeml", version="4")
        seq = _el(root, "sequence", id="sequence-1")
        _el(seq, "name", self.name)
        end = max([i["end"] for t in self.video + self.audio for i in t] or [0])
        _el(seq, "duration", end)
        self._rate(seq)
        tc = _el(seq, "timecode")
        self._rate(tc)
        _el(tc, "string", "00:00:00:00")
        _el(tc, "frame", 0)
        _el(tc, "displayformat", "NDF")
        media = _el(seq, "media")
        written: set = set()

        video = _el(media, "video")
        sc = _el(_el(video, "format"), "samplecharacteristics")
        self._rate(sc)
        _el(sc, "width", self.size[0])
        _el(sc, "height", self.size[1])
        _el(sc, "anamorphic", "FALSE")
        _el(sc, "pixelaspectratio", "square")
        _el(sc, "fielddominance", "none")
        for track in self.video:
            t = _el(video, "track")
            for item in track:
                self._clip(t, item, "video", written)
            _el(t, "enabled", "TRUE")
            _el(t, "locked", "FALSE")

        audio = _el(media, "audio")
        _el(audio, "numOutputChannels", 2)
        asc = _el(_el(audio, "format"), "samplecharacteristics")
        _el(asc, "depth", 16)
        _el(asc, "samplerate", 48000)
        for track in self.audio:
            t = _el(audio, "track")
            for item in track:
                self._clip(t, item, "audio", written)
            _el(t, "enabled", "TRUE")
            _el(t, "locked", "FALSE")

        for frame, name, comment in self.markers:
            m = _el(seq, "marker")
            _el(m, "name", name)
            _el(m, "comment", comment)
            _el(m, "in", frame)
            _el(m, "out", -1)

        ET.indent(root, space="  ")
        body = ET.tostring(root, encoding="unicode")
        path.write_text('<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n' + body + "\n")
        return path
