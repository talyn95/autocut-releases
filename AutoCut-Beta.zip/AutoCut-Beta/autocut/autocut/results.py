"""Your month in AutoCut: what this computer made and the editing time it saved.

Counted from what's on disk (nothing is sent anywhere): finished rough cuts, clips, multicam edits and extra shapes from
the queue; motion graphics, music and social graphics from the Create and Graphics tabs. Time saved is an estimate per
piece of work (ESTIMATES, plus `minutes_saved_per_footage_minute` for rough cuts), the turnaround is measured.

The dashboard shows the previous month once, early in the new month (the pop-up), and any month on request.
"""
from __future__ import annotations

import calendar
import json
import time
from collections import Counter
from datetime import datetime
from pathlib import Path

from . import jobs
from .config import list_clients

# minutes an editor would otherwise spend, per finished piece (rough cuts use minutes per footage minute)
ESTIMATES = {"clip": 15, "multicam_per_footage_min": 3, "extra_shape": 8, "motion_graphic": 25, "graphic": 12, "music": 20}


def _ym(ts: float | str | None) -> str | None:
    if ts is None:
        return None
    try:
        dt = datetime.fromisoformat(ts) if isinstance(ts, str) else datetime.fromtimestamp(float(ts))
    except (ValueError, TypeError, OSError):
        return None
    return dt.strftime("%Y-%m")


def _label(ym: str) -> str:
    y, m = (int(x) for x in ym.split("-"))
    return f"{calendar.month_name[m]} {y}"


def _names(settings: dict) -> dict[str, str]:
    import yaml
    out = {}
    for d in list_clients(settings):
        try:
            out[d.name] = (yaml.safe_load((d / "brand.yaml").read_text()) or {}).get("client", d.name)
        except Exception:  # noqa: BLE001
            out[d.name] = d.name
    return out


def month(settings: dict, ym: str | None = None) -> dict:
    """Totals for one month (default: this month so far)."""
    ym = ym or time.strftime("%Y-%m")
    rate = float(settings.get("minutes_saved_per_footage_minute", 4))
    names = _names(settings)
    c = Counter()
    minutes = 0.0
    footage = 0.0
    turn: list[float] = []
    per_client: Counter = Counter()
    days: Counter = Counter()
    for j in jobs.list_jobs(settings, limit=100000):
        if j.get("state") != "done":
            continue
        when = j.get("finished") or j.get("updated") or j.get("mtime")
        if _ym(when) != ym:
            continue
        job = Path(j["dir"])
        opts = j.get("options") or {}
        src = float(j.get("source_seconds") or 0) / 60
        if (job / "multicam.json").exists() or job.name.endswith("-multicam"):
            c["multicam"] += 1
            minutes += src * ESTIMATES["multicam_per_footage_min"]
            footage += src
        elif opts.get("clip"):
            c["clips"] += 1
            minutes += ESTIMATES["clip"]
        elif j.get("fmt"):
            c["extra_shapes"] += 1
            minutes += ESTIMATES["extra_shape"]
            continue  # another shape of a video already counted
        else:
            c["rough_cuts"] += 1
            minutes += src * rate
            footage += src
            if j.get("processing_seconds"):
                turn.append(float(j["processing_seconds"]))
        per_client[names.get(j.get("client_slug"), j.get("client_slug"))] += 1
        try:
            days[datetime.fromisoformat(when).strftime("%A") if isinstance(when, str) else
                 datetime.fromtimestamp(float(when)).strftime("%A")] += 1
        except (ValueError, TypeError):
            pass
    from .design import stills
    from .mograph import prompt
    for kind, items in (("create", prompt.list_items(settings, limit=100000)), ("design", stills.list_items(settings, limit=100000))):
        for it in items:
            if it.get("state") != "done":
                continue
            try:
                st = json.loads((Path(it["dir"]) / "status.json").read_text())
            except (OSError, ValueError):
                continue
            if _ym(st.get("updated")) != ym:
                continue
            if kind == "design":
                c["graphics"] += 1
                minutes += ESTIMATES["graphic"]
            elif (it.get("spec") or {}).get("template") == "music":
                c["music"] += 1
                minutes += ESTIMATES["music"]
            else:
                c["motion_graphics"] += 1
                minutes += ESTIMATES["motion_graphic"]
            cl = (it.get("spec") or {}).get("client")
            if cl:
                per_client[names.get(cl, cl)] += 1
    videos = c["rough_cuts"] + c["clips"] + c["multicam"]
    return {"month": ym, "label": _label(ym), "videos": videos, "counts": dict(c),
            "pieces": videos + c["graphics"] + c["motion_graphics"] + c["music"],
            "footage_minutes": round(footage), "hours_saved": round(minutes / 60, 1),
            "turnaround_minutes": round(sum(turn) / len(turn) / 60, 1) if turn else None,
            "fastest_minutes": round(min(turn) / 60, 1) if turn else None,
            "top_clients": per_client.most_common(5), "busiest_day": days.most_common(1)[0][0] if days else None,
            "estimates": {"rough_cut_per_footage_minute": rate, **ESTIMATES}}


def _prev(ym: str) -> str:
    y, m = (int(x) for x in ym.split("-"))
    return f"{y - 1}-12" if m == 1 else f"{y}-{m - 1:02d}"


def popup(settings: dict) -> dict | None:
    """Last month's summary, once, in the new month (None if already seen or nothing happened)."""
    from . import migrations
    last = _prev(time.strftime("%Y-%m"))
    if migrations.state().get("results_seen") == last:
        return None
    m = month(settings, last)
    return m if m["pieces"] else None


def seen(ym: str) -> None:
    from . import migrations
    st = migrations.state()
    st["results_seen"] = ym
    migrations._save(st)
