""""Download for Premiere": one job as a zip an editor can open anywhere.

The XML references media by absolute path, which only works on the machine (or shared folder) that made
it. In the zip, every file the timeline uses sits in media/, and the XML points at
/Users/Shared/AutoCut-Downloads/<job>/, so unzipping it there means Premiere finds everything with
no relinking. (Unzipped anywhere else, Premiere asks once; point it at one file in media/ and it finds the rest.)
"""
from __future__ import annotations

import zipfile
from pathlib import Path
from .premiere_xml import Timeline, pathurl

DOWNLOAD_ROOT = "/Users/Shared/AutoCut-Downloads"


def package(job: Path, out) -> None:
    """Write the zip to `out` (a file object; it doesn't need to be seekable, so it can be the HTTP response)."""
    xml = next(job.glob("*AutoCut.xml"), None)
    if not xml:
        raise FileNotFoundError("This job has no Premiere XML yet")
    tl = Timeline.load(job / "timeline.json")
    files = {it["info"].path.resolve() for track in tl.video + tl.audio for it in track}
    base = f"{DOWNLOAD_ROOT}/{job.name}"
    names: dict[Path, str] = {}
    for f in sorted(files):
        name, n = f.name, 1
        while name in names.values():
            name, n = f"{f.stem}-{n}{f.suffix}", n + 1
        names[f] = name
    text = xml.read_text()
    for f, name in names.items():
        text = text.replace(pathurl(f), pathurl(f"{base}/media/{name}"))
    readme = (f"AutoCut: {job.name}\n\nFor Premiere to find every clip by itself, unzip this so the folder is\n"
              f"  {base}\n(in Finder: Go > Go to Folder > /Users/Shared, make a folder AutoCut-Downloads, unzip into it).\n"
              "Then in Premiere: File > Import > the .xml file.\n\n"
              "Unzipped somewhere else? Premiere asks where the media is: point it at any file in media/ "
              "and it finds the rest.\n")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_STORED, allowZip64=True) as z:
        z.writestr(f"{job.name}/README.txt", readme)
        z.writestr(f"{job.name}/{xml.name}", text)
        for extra in ("captions.srt", "post-copy.md", "cover.png"):
            if (job / extra).exists():
                z.write(job / extra, f"{job.name}/{extra}")
        for prev in job.glob("*preview.mp4"):
            z.write(prev, f"{job.name}/{prev.name}")
        for f, name in names.items():
            if f.exists():
                z.write(f, f"{job.name}/media/{name}")
