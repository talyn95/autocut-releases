"""Reframe a wide video into any shape by finding the people in it.

Layouts:
  follow   one speaker: crop to them and follow them as they move (podcast single cam, vlog)
  speakers two or more people in a wide shot → simple jump cuts to whoever is talking
  split    two speakers side by side → stacked top/bottom (two-person podcast wide shot)
  pip      a small, steady person in a corner = a facecam → facecam on top, gameplay/screen below
  fit      no one found, or the target is wider than the source → whole frame over a blurred copy
  center   plain centre crop
People are found with the same local person-segmentation engine used for cutouts.
"""
from __future__ import annotations

import statistics
import subprocess
from pathlib import Path

import numpy as np
from PIL import Image

from ..media import probe, video_encoder

LAYOUTS = {"auto": "Auto (detect)", "follow": "Follow the speaker",
           "speakers": "Jump between speakers", "split": "Two speakers (stacked)",
           "pip": "Facecam + gameplay (picture-in-picture)", "fit": "Whole frame (blurred background)",
           "center": "Centre crop"}


def _frame(source: Path, t: float, width: int = 640) -> np.ndarray | None:
    r = subprocess.run(["ffmpeg", "-loglevel", "error", "-ss", f"{t:.2f}", "-i", str(source), "-frames:v", "1",
                        "-vf", f"scale={width}:-2", "-f", "image2pipe", "-vcodec", "png", "-"], capture_output=True)
    if r.returncode != 0 or not r.stdout:
        return None
    import io
    return np.asarray(Image.open(io.BytesIO(r.stdout)).convert("RGB"))


def _boxes(mask: np.ndarray, min_area: float = 0.004) -> list[tuple[float, float, float, float, float]]:
    """Connected person blobs → normalized (cx, cy, w, h, area) boxes."""
    h, w = mask.shape
    binary = (mask > 0.5).astype(np.uint8)
    try:
        import cv2
        n, _, stats, _ = cv2.connectedComponentsWithStats(binary, 8)
        comps = [(s[0], s[1], s[2], s[3], s[4]) for s in stats[1:n]]
    except ImportError:  # fallback: split by empty columns
        cols = binary.any(axis=0)
        comps, x = [], 0
        while x < w:
            if cols[x]:
                x0 = x
                while x < w and cols[x]:
                    x += 1
                sub = binary[:, x0:x]
                rows = np.where(sub.any(axis=1))[0]
                comps.append((x0, rows[0], x - x0, rows[-1] - rows[0] + 1, int(sub.sum())))
            x += 1
    out = []
    for x, y, bw, bh, area in comps:
        if area / (w * h) >= min_area:
            out.append(((x + bw / 2) / w, (y + bh / 2) / h, bw / w, bh / h, area / (w * h)))
    return out


def detect_layout(source: Path, ranges: list[tuple[float, float]], settings: dict, samples: int = 10) -> dict:
    """Look at a few frames and decide follow / split / pip / fit, with the boxes to crop to."""
    from ..effects.cutout import get_segmenter
    seg = get_segmenter("auto")
    info = probe(source)
    times = []
    for a, b in ranges:
        times += [a + (b - a) * k for k in (0.2, 0.5, 0.8)]
    times = sorted(times)[:samples] or [min(5.0, info.duration / 2)]
    frames = [(t, _frame(source, t)) for t in times]
    per_frame = []
    for t, f in frames:
        if f is None:
            continue
        per_frame.append(_boxes(seg(f)))
    if not per_frame:
        return {"layout": "fit", "note": "couldn't read frames"}

    # group boxes across frames by horizontal position
    clusters: list[list[tuple]] = []
    for boxes in per_frame:
        for b in boxes:
            for c in clusters:
                if abs(statistics.median(x[0] for x in c) - b[0]) < 0.12 and abs(statistics.median(x[1] for x in c) - b[1]) < 0.2:
                    c.append(b)
                    break
            else:
                clusters.append([b])
    n = len(per_frame)
    people = []
    for c in clusters:
        presence = len(c) / n
        if presence < 0.4:
            continue
        med = lambda i: statistics.median(x[i] for x in c)  # noqa: E731
        spread = statistics.pstdev([x[0] for x in c]) + statistics.pstdev([x[1] for x in c])
        people.append({"cx": med(0), "cy": med(1), "w": med(2), "h": med(3), "area": med(4),
                       "presence": round(presence, 2), "steady": spread < 0.03})
    people.sort(key=lambda p: p["area"] * p["presence"], reverse=True)

    facecam = next((p for p in people if p["area"] < 0.08 and p["steady"] and
                    (p["cx"] < 0.33 or p["cx"] > 0.67) and (p["cy"] < 0.4 or p["cy"] > 0.6)), None)
    big = [p for p in people if p is not facecam and p["area"] >= 0.02]
    if facecam and len(big) <= 1 and (not big or big[0]["area"] < 0.12):
        return {"layout": "pip", "facecam": facecam, "people": people,
                "note": "facecam in the corner → facecam on top, gameplay below"}
    if len(big) >= 2 and abs(big[0]["cx"] - big[1]["cx"]) > 0.25 and big[1]["area"] > big[0]["area"] * 0.35:
        lead = big[0]["area"]
        group = [p for p in big[:4] if p["area"] > lead * 0.35]
        group = [p for i, p in enumerate(group) if all(abs(p["cx"] - q["cx"]) > 0.15 for q in group[:i])]
        return {"layout": "speakers", "people": sorted(group, key=lambda p: p["cx"]),
                "note": f"{len(group)} people → jump cuts to whoever is talking"}
    if big or people:
        return {"layout": "follow", "people": [(big or people)[0]], "note": "one main speaker → follow"}
    return {"layout": "fit", "people": [], "note": "no one found → whole frame"}


def _even(v: float) -> int:
    return max(2, int(round(v / 2)) * 2)


def _pos(v: float) -> int:
    return max(0, int(v // 2) * 2)


def _crop(cx: float, cy: float, aspect: float, sw: int, sh: int, max_w: float | None = None) -> str:
    """crop=w:h:x:y with the given aspect, centred on (cx, cy) in pixels, inside the frame."""
    w = min(sw, sh * aspect, max_w or sw)
    h = w / aspect
    if h > sh:
        h, w = sh, sh * aspect
    x = min(max(cx - w / 2, 0), sw - w)
    y = min(max(cy - h / 2, 0), sh - h)
    return f"crop={int(w // 2) * 2}:{int(h // 2) * 2}:{_pos(x)}:{_pos(y)}"


def resolve_layout(det: dict, layout: str, sw: int, sh: int, W: int, H: int) -> str:
    target, source_aspect = W / H, sw / sh
    if layout == "auto":
        layout = det.get("layout", "fit")
    people = det.get("people") or []
    if layout == "speakers" and len(people) < 2:
        layout = "follow" if people else "fit"
    if target >= source_aspect * 0.98 and layout not in ("center", "speakers"):
        layout = "fit" if target > source_aspect * 1.02 else "scale"
    if layout == "split" and len(people) < 2:
        layout = "follow" if people else "fit"
    if layout == "pip" and not det.get("facecam"):
        layout = "fit"
    if layout == "follow" and not people:
        layout = "center"
    return layout


def _person_crop(p: dict, aspect: float, sw: int, sh: int) -> str:
    """A crop on one person; in a wide target (landscape from landscape) a punch-in instead."""
    max_w = sw / 1.6 if aspect >= sw / sh * 0.98 else None
    return _crop(p["cx"] * sw, (p["cy"] - p["h"] * 0.1) * sh, aspect, sw, sh, max_w)


def filter_graph(det: dict, layout: str, sw: int, sh: int, W: int, H: int,
                 cuts: list[tuple[float, float, int]] | None = None, track_file: str | None = None) -> str:
    """ffmpeg filter_complex that turns the source into W×H with the chosen layout → [v].
    `cuts` (start, end, person) drives the "speakers" jump cuts."""
    target = W / H
    layout = resolve_layout(det, layout, sw, sh, W, H)
    people = det.get("people") or []
    if layout == "speakers":
        cuts = cuts or [(0.0, 1e6, 0)]
        n = len(people)
        parts = [f"[0:v]split={n}" + "".join(f"[s{i}]" for i in range(n))]
        for i, p in enumerate(people):
            parts.append(f"[s{i}]{_person_crop(p, target, sw, sh)},scale={W}:{H},setsar=1[p{i}]")
        base = cuts[0][2] if cuts else 0
        cur = f"p{base}"
        k = 0
        for i in range(n):
            if i == base:
                continue
            spans = [(a, b) for a, b, w in cuts if w == i]
            if not spans:
                continue
            expr = "+".join(f"between(t,{a:.3f},{b - 0.001:.3f})" for a, b in spans)
            parts.append(f"[{cur}][p{i}]overlay=enable='{expr}'[o{k}]")
            cur = f"o{k}"
            k += 1
        parts.append(f"[{cur}]null[v]" if cur != "v" else "")
        # unused people streams must still be consumed
        used = {base} | {w for _, _, w in cuts}
        for i in range(n):
            if i not in used:
                parts.append(f"[p{i}]nullsink")
        return ";".join(x for x in parts if x)

    if layout == "scale":
        return f"[0:v]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},setsar=1[v]"
    if layout == "center":
        return f"[0:v]{_crop(sw / 2, sh / 2, target, sw, sh)},scale={W}:{H},setsar=1[v]"
    if layout == "fit":
        return (f"[0:v]split=2[a][b];[a]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},"
                f"boxblur=28:2,eq=saturation=1.25[bg];[b]scale={W}:{H}:force_original_aspect_ratio=decrease[fg];"
                f"[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1[v]")
    if layout == "follow":
        p = people[0]
        # keep the head in the upper part of the frame: aim a little above the body centre
        crop = _crop(p['cx'] * sw, (p['cy'] - p['h'] * 0.1) * sh, target, sw, sh)
        moves = f"sendcmd=f='{track_file}'," if track_file else ""
        return f"[0:v]{moves}{crop},scale={W}:{H},setsar=1[v]"
    if layout == "split":
        Ht = _even(H / 2)
        Hb = H - Ht
        a, b = people[0], people[1]
        crops = []
        for p, ph in ((a, Ht), (b, Hb)):
            aspect = W / ph
            max_w = min(sw * 0.5, p["w"] * sw * 2.4)  # don't let one speaker's panel swallow the other
            crops.append(_crop(p["cx"] * sw, (p["cy"] - p["h"] * 0.12) * sh, aspect, sw, sh, max_w))
        return (f"[0:v]split=2[a][b];[a]{crops[0]},scale={W}:{Ht}[t];[b]{crops[1]},scale={W}:{Hb}[u];"
                f"[t][u]vstack=inputs=2,drawbox=x=0:y={Ht - 3}:w={W}:h=6:color=white@0.85:t=fill,setsar=1[v]")
    # pip: facecam on top (≈38%), gameplay below
    f = det["facecam"]
    Ht = _even(H * 0.38)
    Hb = H - Ht
    # just the facecam (the person fills it), fitted into the top panel over a blurred copy of itself
    cw, ch = min(sw, f["w"] * sw * 1.12), min(sh, f["h"] * sh * 1.12)
    cx = min(max(f["cx"] * sw - cw / 2, 0), sw - cw)
    cy = min(max(f["cy"] * sh - ch / 2, 0), sh - ch)
    cam = f"crop={int(cw // 2) * 2}:{int(ch // 2) * 2}:{_pos(cx)}:{_pos(cy)}"
    # gameplay: centred, but nudged away from the facecam so it isn't shown twice
    gw = min(sw, sh * W / Hb)
    gx = sw / 2
    if f["cx"] > 0.5 and gx + gw / 2 > cx:
        gx = max(gw / 2, cx - gw / 2)
    elif f["cx"] <= 0.5 and gx - gw / 2 < cx + cw:
        gx = min(sw - gw / 2, cx + cw + gw / 2)
    game = _crop(gx, sh / 2, W / Hb, sw, sh)
    return (f"[0:v]split=2[a][b];[a]{cam},split=2[c1][c2];"
            f"[c1]scale={W}:{Ht}:force_original_aspect_ratio=increase,crop={W}:{Ht},boxblur=24:2,eq=saturation=1.25[cb];"
            f"[c2]scale={W}:{Ht}:force_original_aspect_ratio=decrease[cf];[cb][cf]overlay=(W-w)/2:(H-h)/2[t];"
            f"[b]{game},scale={W}:{Hb}[u];"
            f"[t][u]vstack=inputs=2,drawbox=x=0:y={Ht - 3}:w={W}:h=6:color=white@0.85:t=fill,setsar=1[v]")


def track_person(source: Path, start: float, end: float, hint: dict, max_samples: int = 90) -> list[tuple[float, float]] | None:
    """Follow one person through [start, end]: (time, centre x 0..1) every 0.1 s, moved like a camera
    operator would (holds still while they stay near the middle, glides when they move away).
    None if the person can't be found (the static crop is used instead)."""
    from ..effects.cutout import get_segmenter
    try:
        seg = get_segmenter("auto")
    except Exception:
        return None
    dur = end - start
    n = max(3, min(max_samples, int(dur * 2)))
    times = [start + dur * (k + 0.5) / n for k in range(n)]
    xs, last = [], hint["cx"]
    for t in times:
        f = _frame(source, t, 480)
        if f is None:
            xs.append(None)
            continue
        boxes = [b for b in _boxes(seg(f)) if b[4] > 0.01]
        if not boxes:
            xs.append(None)
            continue
        b = min(boxes, key=lambda b: abs(b[0] - last) - 0.5 * b[4])  # the same person: nearest, prefer big
        if abs(b[0] - last) > 0.35:  # someone else walked in: keep the one we were following
            xs.append(None)
            continue
        last = b[0]
        xs.append(b[0])
    found = [x for x in xs if x is not None]
    if len(found) < max(2, n // 3):
        return None
    # fill gaps, resample to 10/s
    filled, prev = [], found[0]
    for x in xs:
        prev = x if x is not None else prev
        filled.append(prev)
    grid = np.arange(0, dur, 0.1)
    raw = np.interp(grid, [t - start for t in times], filled)
    # camera operator: a dead zone, then an eased glide towards the subject
    cam, out = raw[0], []
    for x in raw:
        if abs(x - cam) > 0.06:
            cam += (x - cam) * 0.12
        out.append(cam)
    return [(round(float(t), 2), float(x)) for t, x in zip(grid, out)]


def _track_cmds(track: list[tuple[float, float]], crop_w: float, sw: int) -> str:
    """sendcmd lines moving the crop's x along the track (only when it moves ≥ 2 px)."""
    lines, last = [], None
    for t, cx in track:
        x = int(min(max(cx * sw - crop_w / 2, 0), sw - crop_w) // 2 * 2)
        if last is None or abs(x - last) >= 2:
            lines.append(f"{t:.2f} crop x {x};")
            last = x
    return "\n".join(lines) + "\n"


def speaker_cuts(source: Path, start: float, end: float, people: list[dict], audio_channels: int = 0,
                 words: list[dict] | None = None, min_shot: float = 1.8) -> list[tuple[float, float, int]]:
    """Who's talking in [start, end] → jump cuts (times relative to start)."""
    from .. import speakers as spk
    dur = end - start
    act = spk.motion_activity(source, people, start, dur)
    if audio_channels >= 2 and len(people) == 2:  # one mic per side? then the audio decides
        energy = spk.audio_energy(source, None, start, dur)
        if spk.channels_are_separate(energy):
            mics = spk.normalize(energy[:2])
            T = min(mics.shape[1], act.shape[1])
            if T > 10:
                # which channel belongs to which person: the pairing whose activity agrees best
                same = np.corrcoef(mics[0, :T], act[0, :T])[0, 1] + np.corrcoef(mics[1, :T], act[1, :T])[0, 1]
                swap = np.corrcoef(mics[1, :T], act[0, :T])[0, 1] + np.corrcoef(mics[0, :T], act[1, :T])[0, 1]
                act = mics if not (swap > same) else mics[::-1]
    cuts = spk.shots(act, min_shot=min_shot)
    if words:
        rel = [{**w, "start": w["start"] - start, "end": w["end"] - start} for w in words
               if start <= w["start"] <= end]
        cuts = spk.snap_to_words(cuts, rel)
    return cuts


def render_clip(source: Path, start: float, end: float, det: dict, layout: str, size: tuple[int, int], out: Path,
                words: list[dict] | None = None) -> Path:
    info = probe(source)
    W, H = size
    cuts, track_file = None, None
    resolved = resolve_layout(det, layout, info.width, info.height, W, H)
    if resolved == "speakers":
        cuts = speaker_cuts(source, start, end, det["people"], info.audio_channels, words)
    if resolved == "follow" and det.get("people"):
        try:
            track = track_person(source, start, end, det["people"][0])
        except Exception:
            track = None
        if track:
            import tempfile
            crop_w = int(_crop(0, 0, W / H, info.width, info.height).split("=")[1].split(":")[0])
            fd, track_file = tempfile.mkstemp(prefix="autocut-track-", suffix=".txt")
            with open(fd, "w") as fh:
                fh.write(_track_cmds(track, crop_w, info.width))
    graph = filter_graph(det, layout, info.width, info.height, W, H, cuts, track_file)
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-ss", f"{start:.3f}", "-i", str(source), "-t", f"{end - start:.3f}",
           "-filter_complex", graph, "-map", "[v]"]
    if info.audio_channels:
        cmd += ["-map", "0:a:0", "-c:a", "aac", "-b:a", "192k"]
    cmd += [*video_encoder(), "-pix_fmt", "yuv420p", str(out)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if track_file:
        Path(track_file).unlink(missing_ok=True)
    if r.returncode != 0:
        raise RuntimeError(f"reframe failed: {r.stderr[-800:]}")
    return out
