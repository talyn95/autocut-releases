"""Find the clips worth posting in a long video, and say why.

Every candidate starts and ends on a sentence. The score (0–100) adds up:
  hook        30  the first words: a question, a number, "the secret / nobody / here's why…", "you"
  energy      20  how loud and lively it is compared with the rest of the episode (laughs, shouting)
  emotion     15  strong words: crazy, insane, love, hate, money, never, best…
  length      10  25–60 seconds is the sweet spot for Reels/TikTok/Shorts
  pace        10  2.3–3.6 words a second
  complete    10  starts at the start of a thought, ends at the end of one
  payoff       5  "because", "that's why", "the reason", "here's how"…
The marketing brain (brain.py: the free local model, Claude as backup) then reviews the top candidates
together: its own score, a title, three hook options and why.
"""
from __future__ import annotations

import json
import re
import statistics
import subprocess
import urllib.request
from pathlib import Path

from ..edit import norm

HOOK_PHRASES = [
    "the secret", "nobody", "no one", "never", "biggest mistake", "here's why", "here is why", "how to", "the truth",
    "stop", "you need to", "i can't believe", "the reason", "what if", "did you know", "the problem", "most people",
    "everyone", "the best", "the worst", "this is why", "let me tell you", "the one thing", "real talk", "honestly",
    "wait", "watch this", "listen", "the craziest", "story time", "i quit", "i lost", "i made", "million", "free",
]
EMOTION = set("""crazy insane amazing incredible unbelievable love hate scared afraid angry mad shocked wild
insanely literally obsessed terrible horrible awful perfect best worst never always money million billion rich
broke fired quit died dead kill killed war fight win won lose lost secret truth lie lied crying cried laughing
funny hilarious wow omg dude bro huge massive disaster dream nightmare success failure""".split())
WEAK_OPENERS = {"and", "but", "so", "because", "okay", "ok", "anyway", "um", "uh", "like", "which", "then",
                "also", "plus", "yeah", "right", "alright", "well"}
PAYOFF = ["because", "that's why", "that is why", "the reason", "here's how", "so what", "which means", "turns out",
          "the answer", "the key", "what happened"]


def loudness_per_second(video: Path) -> list[float]:
    """RMS level (dBFS) of every second of audio. Cheap even for multi-hour files."""
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(video), "-vn", "-ac", "1", "-ar", "16000",
                        "-af", "asetnsamples=n=16000,astats=metadata=1:reset=1,"
                               "ametadata=print:key=lavfi.astats.Overall.RMS_level:file=-",
                        "-f", "null", "-"], capture_output=True, text=True)
    vals = []
    for line in r.stdout.splitlines():
        if "RMS_level=" in line:
            v = line.split("=", 1)[1]
            vals.append(-90.0 if v in ("-inf", "inf", "nan") else max(-90.0, float(v)))
    return vals


def sentences(words: list[dict]) -> list[tuple[int, int]]:
    """(first word index, last word index) of each sentence; long pauses also end one."""
    out, start = [], 0
    for i, w in enumerate(words):
        nxt = words[i + 1] if i + 1 < len(words) else None
        end = re.search(r"[.?!]$", w["word"]) or nxt is None or nxt["start"] - w["end"] > 1.2
        if end:
            out.append((start, i))
            start = i + 1
    return out


def score(words: list[dict], a: int, b: int, loud: list[float], median_db: float) -> tuple[float, list[str], dict]:
    seg = words[a:b + 1]
    text = " ".join(w["word"] for w in seg)
    low = text.lower()
    start, end = seg[0]["start"], seg[-1]["end"]
    dur = end - start
    reasons, parts = [], {}

    first_sentence_end = next((i for i, w in enumerate(seg) if re.search(r"[.?!]$", w["word"])), len(seg) - 1)
    first = " ".join(w["word"] for w in seg[:min(first_sentence_end + 1, 18)]).lower()  # the opening sentence only
    hook = 0.0
    if "?" in first:
        hook += 8
        reasons.append("opens with a question")
    hits = [p for p in HOOK_PHRASES if re.search(rf"\b{re.escape(p)}\b", first)]
    if hits:
        hook += min(14, 7 * len(hits))
        reasons.append(f'hook: "{hits[0]}"')
    if re.search(r"\d", first):
        hook += 5
        reasons.append("number in the hook")
    if re.search(r"\byou\b|\byour\b", first):
        hook += 4
    if first_sentence_end <= 12:
        hook += 3
    parts["hook"] = min(30.0, hook)

    if loud:
        secs = loud[int(start):max(int(start) + 1, int(end))]
        mean_db = statistics.fmean(secs) if secs else median_db
        lift = (mean_db - median_db) / 6.0
        peaks = sum(1 for v in secs if v > median_db + 8)
        energy = max(0.0, min(1.0, 0.5 + lift)) * 16 + min(4, peaks)
        if lift > 0.4 or peaks >= 3:
            reasons.append("high energy")
    else:
        energy = 10.0
    parts["energy"] = min(20.0, energy)

    emo = sum(1 for w in seg if norm(w["word"]) in EMOTION)
    parts["emotion"] = min(15.0, emo * 15 / max(4.0, len(seg) / 12))
    if emo >= 2:
        reasons.append("emotional language")

    parts["length"] = 10.0 if 25 <= dur <= 60 else 7.0 if 18 <= dur <= 75 else 3.0
    wps = len(seg) / max(1.0, dur)
    parts["pace"] = 10.0 if 2.3 <= wps <= 3.6 else 6.0 if 1.8 <= wps <= 4.2 else 2.0
    weak_start = norm(seg[0]["word"]) in WEAK_OPENERS
    complete = (6 if re.search(r"[.?!]$", seg[-1]["word"]) else 0) + (4 if seg[0]["word"][:1].isupper() and not weak_start else 0)
    parts["complete"] = float(complete)
    if weak_start:  # starts mid-thought ("And…", "Because…", "Okay so…")
        parts["hook"] = max(0.0, parts["hook"] - 6)
    if any(p in low for p in PAYOFF):
        parts["payoff"] = 5.0
        reasons.append("has a payoff")
    else:
        parts["payoff"] = 0.0
    if parts["pace"] == 10:
        reasons.append("good pace")
    return round(sum(parts.values()), 1), reasons, parts


FILLERS = {"um", "umm", "uh", "uhh", "uhm", "erm", "er", "ah", "ahh", "hmm", "mm", "mhm"}


def title_for(words: list[dict], a: int, b: int) -> str:
    """The clip's first sentence (up to 10 words) without ums, or leading "so"/"and"/"but"."""
    seg = [w for w in words[a:b + 1] if norm(w["word"]) not in FILLERS]
    while seg and norm(seg[0]["word"]) in WEAK_OPENERS:
        seg = seg[1:]
    end = next((i for i, w in enumerate(seg) if re.search(r"[.?!]$", w["word"])), min(len(seg), 10) - 1)
    t = " ".join(w["word"] for w in seg[:min(end + 1, 10)]).strip(" ,.;")
    t = re.sub(r"\s*,\s*,", ",", t)
    return (t[:1].upper() + t[1:]) if t else "Clip"


def _stem(w: str) -> str:
    w = re.sub(r"[^a-z0-9]", "", w.lower())
    for suf in ("ing", "ers", "er", "es", "ed", "s"):
        if len(w) > len(suf) + 3 and w.endswith(suf):
            return w[:-len(suf)]
    return w


def topic_terms(topic: str) -> set[str]:
    """The words that matter in a "find clips about …" request."""
    from ..broll import STOP
    return {_stem(w) for w in re.findall(r"[A-Za-z0-9']+", topic or "") if w.lower() not in STOP and len(w) > 2}


def relevance(text: str, terms: set[str]) -> float:
    """0..1: how much of the request this clip talks about (each term counted once, a little extra for repeats)."""
    if not terms:
        return 0.0
    stems = [_stem(w) for w in re.findall(r"[A-Za-z0-9']+", text)]
    hits = sum(1 for t in terms if t in stems)
    repeats = sum(stems.count(t) for t in terms)
    return min(1.0, hits / len(terms) + 0.04 * max(0, repeats - hits))


def candidates(words: list[dict], loud: list[float], min_len: float = 20, max_len: float = 75,
               count: int = 8, topic: str = "") -> list[dict]:
    sents = sentences(words)
    terms = topic_terms(topic)
    median_db = statistics.median([v for v in loud if v > -80]) if loud else -30.0
    raw = []
    for i, (a, _) in enumerate(sents):
        for j in range(i, min(i + 40, len(sents))):
            b = sents[j][1]
            dur = words[b]["end"] - words[a]["start"]
            if dur < min_len:
                continue
            if dur > max_len:
                break
            s, reasons, parts = score(words, a, b, loud, median_db)
            if terms:  # "find clips about …": on-topic moments rise, off-topic ones sink
                rel = relevance(" ".join(w["word"] for w in words[a:b + 1]), terms)
                s = round(s * (0.55 + 0.45 * rel) + 30 * rel, 1)
                if rel >= 0.34:
                    reasons = [f"about: {topic[:40]}"] + reasons
            raw.append({"a": a, "b": b, "start": round(words[a]["start"], 2), "end": round(words[b]["end"], 2),
                        "score": s, "reasons": reasons, "parts": parts})
    raw.sort(key=lambda c: c["score"], reverse=True)
    picked: list[dict] = []
    for c in raw:  # no two picks that mostly overlap
        if all(min(c["end"], p["end"]) - max(c["start"], p["start"]) < 0.3 * (c["end"] - c["start"]) for p in picked):
            picked.append(c)
        if len(picked) >= count * 2:
            break
    for n, c in enumerate(picked, 1):
        c["id"] = n
        c["title"] = title_for(words, c["a"], c["b"])
        c["text"] = " ".join(w["word"] for w in words[c["a"]:c["b"] + 1])
        c["duration"] = round(c["end"] - c["start"], 1)
    return picked


RANK_SCHEMA = {"type": "object", "properties": {"clips": {"type": "array", "items": {"type": "object", "properties": {
    "id": {"type": "integer"}, "score": {"type": "integer"}, "title": {"type": "string"},
    "hooks": {"type": "array", "items": {"type": "string"}}, "why": {"type": "string"},
    "platform": {"type": "string"}}}}}, "required": ["clips"]}


def llm_rerank(cands: list[dict], settings: dict, brand: dict | None = None, prefer: str = "local",
               topic: str = "") -> bool:
    """The marketing brain reviews the top candidates together (one request): a 0-100 score, a punchy
    title, three hook options and the reason. Blended with the measured score. Returns True if it ran."""
    from .. import brain, marketing
    top = cands[:20]
    if not top:
        return False
    listing = "\n\n".join(f"CLIP {c['id']} ({c['end'] - c['start']:.0f}s):\n{c['text'][:1800]}" for c in top)
    prompt = ("These are candidate short-form clips cut from one long video. For each clip, judge how well it "
              "would perform on its own as a TikTok/Reel/Short (0-100), write a title of 3-8 words for the on-screen "
              "hook, three alternative opening hooks (max 8 words, true to the clip), one sentence on why it would or "
              "wouldn't work, and the best platform. Be a tough judge: most clips should score under 70.\n\n"
              + (f"The editor is looking for clips about: {topic}. A clip that isn't about that scores under 30, "
                 "however good it is otherwise.\n\n" if topic else "") + listing)
    out = brain.ask(settings, marketing.system_prompt(brand, "clips"), prompt, RANK_SCHEMA, prefer=prefer, timeout=600)
    if not isinstance(out, dict):
        return False
    by_id = {c["id"]: c for c in top}
    engine = "AI" if brain.last_engine() == "local" else "Claude"
    for r in out.get("clips", []):
        c = by_id.get(r.get("id"))
        if not c:
            continue
        ai = max(0.0, min(100.0, float(r.get("score", c["score"]))))
        c["measured_score"] = c["score"]
        c["score"] = round(0.4 * c["score"] + 0.6 * ai, 1)
        if r.get("title"):
            c["title"] = str(r["title"])[:70]
        c["hooks"] = [str(h)[:80] for h in (r.get("hooks") or [])][:3]
        if r.get("why"):
            c["why"] = str(r["why"])[:240]
        if r.get("platform"):
            c["platform"] = str(r["platform"])[:30]
        c["reasons"].insert(0, f"{engine} pick" if ai >= 70 else f"{engine} reviewed")
    cands.sort(key=lambda c: c["score"], reverse=True)
    return True


VIDEO_EXT = (".mp4", ".mov", ".m4v", ".mkv", ".mxf")


def analyze(longform: Path, settings: dict, on_step=None) -> dict:
    """longform/<name>/ holds one or more source videos and options.json. Writes analysis.json.
    A folder dropped as one project can hold several videos (e.g. part 1 and part 2 of a stream);
    each is transcribed on its own and the best moments from all of them are ranked together."""
    from ..transcribe import load_or_transcribe
    from .reframe import detect_layout
    step = on_step or (lambda _s: None)
    opts = json.loads((longform / "options.json").read_text()) if (longform / "options.json").exists() else {}
    sources = [p for p in sorted(longform.iterdir())
               if p.is_file() and p.suffix.lower() in VIDEO_EXT and not p.name.startswith(".")]
    if not sources:
        raise ValueError("No video in this project")
    client_dir = longform.parent.parent
    vocab, brand = [], None
    try:
        from ..config import load_client
        brand = load_client(str(client_dir), settings).brand
        vocab = brand["vocabulary"]
    except SystemExit:
        pass
    count = int(opts.get("count", 8))
    all_cands, parts = [], []
    for n, source in enumerate(sources):
        tag = f" ({n + 1}/{len(sources)})" if len(sources) > 1 else ""
        work = longform if len(sources) == 1 else longform / ".parts" / source.stem
        work.mkdir(parents=True, exist_ok=True)
        step("transcribing" + tag)
        data = load_or_transcribe(source, work, settings, None, vocab)
        words = data["words"]
        step("measuring energy" + tag)
        loud = loudness_per_second(source)
        step("scoring moments" + tag)
        cands = candidates(words, loud, float(opts.get("min_len", 20)), float(opts.get("max_len", 75)), count,
                           str(opts.get("topic") or ""))
        step("finding the speakers" + tag)
        if opts.get("layout") and opts["layout"] != "auto":
            layout = {"layout": opts["layout"], "people": [], "note": "set for this project"}
        else:
            try:
                layout = detect_layout(source, [(c["start"], c["end"]) for c in cands[:6]] or [(0, 60)], settings)
            except Exception as e:
                layout = {"layout": "fit", "note": f"couldn't detect people ({e})"}
        for c in cands:
            c.update(source=str(source), transcript=str(work / "transcript.json"), detect=layout)
        all_cands += cands
        parts.append({"source": str(source), "duration": words[-1]["end"] if words else 0, "layout": layout})
    all_cands.sort(key=lambda c: c["score"], reverse=True)
    for n, c in enumerate(all_cands, 1):  # ids unique across every video of the project
        c["id"] = n
    step("AI is reviewing the best moments")
    used_ai = llm_rerank(all_cands, settings, brand, "cloud" if opts.get("use_claude") else "local",
                         str(opts.get("topic") or ""))
    all_cands = all_cands[:count * 2 * max(1, min(3, len(sources)))]
    result = {"source": parts[0]["source"], "duration": max(p["duration"] for p in parts), "candidates": all_cands,
              "layout": parts[0]["layout"], "parts": parts, "ai": used_ai, "options": opts}
    (longform / "analysis.json").write_text(json.dumps(result, indent=1))
    return result
