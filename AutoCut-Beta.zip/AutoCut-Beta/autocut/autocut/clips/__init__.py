"""Clips: long podcasts / streams → short, scored, reframed clips (Opus Clips-style), all local.

  analyze.py   transcript + loudness → candidate clips with a viral-potential score and reasons
  reframe.py   find the people (speaker / two speakers / facecam picture-in-picture) and
               render the clip in any shape: follow, split, pip (facecam over gameplay), fit
"""
