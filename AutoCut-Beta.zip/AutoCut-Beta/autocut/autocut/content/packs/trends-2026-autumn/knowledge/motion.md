## Trend notes (autumn 2026 pack)

- Aurora gradients and soft glass are the app-launch look of the season; keep them slow (blur-ins, 0.8–1 s) so the
  colour fields read as calm, not busy.
- Indie print (risograph) textures signal "made by people" for local and craft brands; pair stamped type with a
  hard cut out, never a soft fade.
- Myth-vs-fact is a reliable educational hook: say the myth on screen first, then flip it within two seconds.
