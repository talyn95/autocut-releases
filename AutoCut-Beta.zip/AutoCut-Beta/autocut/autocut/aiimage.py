"""AI image generation (clip art, illustrations, backgrounds, photos).

Engines, in order:
  local    FLUX.1-schnell (Apache-2.0, fine for client work) through `mflux` on Apple Silicon. Install once with:
           ~/AutoCut/.venv/bin/pip install mflux (the model downloads on first use, several GB). Nothing leaves the
           Mac; no per-image cost.
  chatgpt / grok   the person's own connected AI account (accounts.py), any computer, billed to that account and
           counted against its monthly cap.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

STYLES = {
    "illustration": "flat vector illustration, clean simple shapes, bold outlines, plenty of white space, "
                    "white background, color palette {colors}",
    "icon": "single minimalist icon, flat design, centered, plain white background, colors {colors}",
    "3d": "single 3D rendered object, glossy clay render, soft studio lighting, isometric view, rounded shapes, "
          "centered, plain white background, colors {colors}",
    "photo": "professional photograph, natural light, sharp focus, realistic, high detail",
    "background": "abstract soft background, smooth gradients, subtle shapes, no text, colors {colors}",
}
SIZES = {"square": (1024, 1024), "vertical": (768, 1344), "landscape": (1344, 768)}
CATEGORY = {"illustration": "graphics", "icon": "graphics", "3d": "graphics", "photo": "photos", "background": "graphics"}


def engine() -> str | None:
    """The mflux command if installed (next to this Python first, then on PATH)."""
    local = Path(sys.executable).parent / "mflux-generate"
    if local.exists():
        return str(local)
    return shutil.which("mflux-generate")


def engines(settings: dict | None) -> list[str]:
    """The image engines this computer can use now, best first."""
    out = ["local"] if engine() else []
    if settings:
        from . import accounts
        out += [pid for pid in accounts.IDS if accounts.available(settings, pid)[0]]
    return out


def generate(client, prompt: str, style: str = "illustration", shape: str = "square",
             seed: int | None = None, steps: int = 4, settings: dict | None = None, use: str = "auto") -> Path:
    """Generate one image into the client's media library; returns its path. `use`: auto | local | chatgpt | grok."""
    from .effects.media import CATEGORIES, load_tags, save_tags
    have = engines(settings)
    pick = have if use == "auto" else [x for x in have if x == use]
    if not pick:
        raise RuntimeError("No AI image engine here. On a Mac with Apple Silicon run: "
                           "~/AutoCut/.venv/bin/pip install mflux; or connect a ChatGPT or Grok account "
                           "(This Mac → AI accounts)")
    cmd = engine()
    colors = ", ".join(client.brand["colors"][k] for k in ("primary", "secondary"))
    full = f"{prompt.strip()}. {STYLES.get(style, STYLES['illustration']).format(colors=colors)}"
    w, h = SIZES.get(shape, SIZES["square"])
    folder = client.folder / CATEGORIES[CATEGORY.get(style, "graphics")]["folder"]
    folder.mkdir(parents=True, exist_ok=True)
    slug = re.sub(r"[^a-z0-9]+", "-", prompt.lower()).strip("-")[:40] or "ai-image"
    out = folder / f"ai-{slug}-{int(time.time())}.png"
    if pick[0] != "local":
        from . import accounts
        errors = []
        for pid in pick:
            try:
                data = accounts.image(settings, pid, full, shape)
                break
            except RuntimeError as e:
                errors.append(str(e))
        else:
            raise RuntimeError("; ".join(errors))
        out.write_bytes(data)
        if data[:3] == b"\xff\xd8\xff":  # JPEG from the account: keep the right extension
            out = out.replace(out.with_suffix(".jpg"))
        _tag(client, out, prompt, load_tags, save_tags)
        return out
    args = [cmd, "--model", "schnell", "--prompt", full, "--steps", str(steps), "--width", str(w),
            "--height", str(h), "--quantize", "4", "--seed", str(seed if seed is not None else int(time.time()) % 100000),
            "--output", str(out)]
    r = subprocess.run(args, capture_output=True, text=True, timeout=1800)
    if r.returncode != 0 or not out.exists():
        raise RuntimeError(f"Image generation failed: {(r.stderr or r.stdout)[-600:]}")
    _tag(client, out, prompt, load_tags, save_tags)
    return out


def _tag(client, out: Path, prompt: str, load_tags, save_tags) -> None:
    tags = load_tags(client)
    tags[out.relative_to(client.folder).as_posix()] = ", ".join(
        w for w in re.findall(r"[a-z]{4,}", prompt.lower())[:6])
    save_tags(client, tags)
