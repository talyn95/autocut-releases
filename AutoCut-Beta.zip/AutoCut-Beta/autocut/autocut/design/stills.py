"""Still graphics in the client's brand: social posts, stories, YouTube thumbnails, ads, quote and stat cards,
testimonials, tips, events and multi-slide carousels.

How it works: each design is plain HTML + CSS (this file writes it) in the client's colours, fonts and logo, laid
out for its size from one set of rules (so "resize" is just another size), and rendered by the HyperFrames engine
(mograph/hyper.py) to a PNG. A batch (a carousel's slides, a CSV's rows) is one composition with one design per
frame, so it renders in one pass. Each render keeps its HTML project, so it opens in HyperFrames Studio too.

Three looks per design: bold (brand colour ground), clean (light) and dark.
"""
from __future__ import annotations

import csv
import html
import io
import json
import re
import shutil
import subprocess
import time
from datetime import datetime
from pathlib import Path

from PIL import Image

from ..config import Client, clients_dir
from ..mograph import hyper

SIZES = {
    "post": ((1080, 1080), "Post 1:1"),
    "portrait": ((1080, 1350), "Feed 4:5"),
    "story": ((1080, 1920), "Story / Reel cover 9:16"),
    "thumbnail": ((1280, 720), "YouTube thumbnail 16:9"),
    "ad": ((1200, 628), "Link ad / Facebook 1.91:1"),
}
STYLES = {"bold": "Bold (brand colour)", "clean": "Clean (light)", "dark": "Dark"}
# field key, label, kind (text | long | list | photo)
TEMPLATES = {
    "quote": ("Quote card", [("quote", "Quote", "long"), ("author", "Who said it", "text"), ("role", "Their role", "text")]),
    "stat": ("Stat card", [("number", "Number (e.g. 98% or $3,000)", "text"), ("label", "What it means", "text"),
                           ("context", "Small print / source", "text")]),
    "offer": ("Offer / ad", [("kicker", "Kicker (e.g. LIMITED TIME)", "text"), ("headline", "Headline", "long"),
                             ("offer", "The offer (e.g. $99 inspection)", "text"), ("cta", "Button", "text"),
                             ("fineprint", "Fine print", "text"), ("photo", "Photo (optional)", "photo")]),
    "testimonial": ("Testimonial", [("review", "Review", "long"), ("name", "Name", "text"),
                                    ("detail", "Detail (e.g. Homeowner, Austin)", "text"), ("photo", "Photo (optional)", "photo")]),
    "thumbnail": ("YouTube thumbnail", [("title", "Title, 2-6 words, *word* for colour", "long"),
                                        ("badge", "Badge (optional, e.g. NEW)", "text"), ("photo", "Photo of the person", "photo")]),
    "tips": ("Tips / list", [("title", "Title", "long"), ("items", "One item per line (up to 5)", "list")]),
    "event": ("Event / announcement", [("kicker", "Kicker", "text"), ("title", "Title", "long"), ("date", "Date", "text"),
                                       ("time", "Time", "text"), ("place", "Place", "text"), ("cta", "Button", "text")]),
    "product": ("Product spotlight", [("name", "Product name", "text"), ("benefit", "The benefit, in one line", "long"),
                                      ("price", "Price or offer (optional)", "text"), ("cta", "Button", "text"),
                                      ("badge", "Badge (optional, e.g. NEW / BESTSELLER)", "text"),
                                      ("photo", "Product photo (cut out automatically)", "photo")]),
    "photo": ("Photo + headline", [("headline", "Headline", "long"), ("sub", "Supporting line", "text"),
                                   ("cta", "Button (optional)", "text"), ("photo", "Your photo", "photo")]),
    "carousel": ("Carousel (multi-slide)", [("title", "Cover title", "long"),
                                            ("items", "One slide per line: Heading | text", "list"),
                                            ("cta", "Last slide call to action", "text")]),
}
FPS = 30


def library_dir(settings: dict) -> Path:
    return clients_dir(settings).parent / "design-library"


# ---- colour + type ---------------------------------------------------------------------------------------------

def _palette(client: Client, style: str) -> dict:
    c = client.brand["colors"]
    primary, secondary = c["primary"], c["secondary"]
    dark_secondary = hyper._luma(secondary) < 110
    if style == "bold":
        ground, ink, accent = primary, hyper.on(primary), secondary if hyper._luma(secondary) != hyper._luma(primary) else hyper.on(primary)
        ground2 = hyper._mix(primary, "#000000", 0.18)
    elif style == "dark":
        ground = secondary if dark_secondary else "#0e1116"
        ground2, ink, accent = hyper._mix(ground, primary, 0.22), "#ffffff", primary
    else:  # clean: a warm off-white tinted with the brand colour (never gray)
        ground = hyper._mix("#fffdf9", primary, 0.05)
        ground2, ink, accent = hyper._mix("#fffdf9", primary, 0.14), secondary if dark_secondary else "#121212", primary
    if hyper._luma(accent) - hyper._luma(ground) in range(-40, 40):  # accent too close to the ground to read
        accent = ink
    accent = hyper.readable(accent, ground, 3.0)      # large accent text (headline words, offers, prices)
    soft = hyper.readable(hyper._mix(ground, ink, 0.62), ground, 4.5)
    return {"ground": ground, "ground2": ground2, "ink": ink, "accent": accent, "on_accent": hyper.on(accent),
            "accent_strong": hyper.readable(accent, ground, 4.5),  # small accent text (kickers)
            "stars": hyper.readable("#f5b301", ground, 3.0), "soft": soft}


def _rich(text: str) -> str:
    """Escape, keep line breaks, and give *word* the accent colour."""
    t = html.escape(str(text or "")).replace("\n", "<br>")
    return re.sub(r"\*([^*]+)\*", r'<span class="acc">\1</span>', t)


def _fit(text: str, base: float, chars_per_line: float, max_lines: int = 4) -> float:
    """Shrink long text so it stays inside its box (base = the font size for short text)."""
    n = len(re.sub(r"\*", "", str(text or "")))
    lines_needed = max(1.0, n / chars_per_line)
    return round(base * min(1.0, (max_lines / lines_needed) ** 0.5), 1)


# ---- one design --------------------------------------------------------------------------------------------------

def _photo_html(path: str | None, cls: str, assets: Path, n: int) -> str:
    if not path or not Path(path).is_file():
        return ""
    dest = assets / f"photo-{n}{Path(path).suffix.lower()}"
    shutil.copy2(path, dest)
    return f'<img class="{cls}" src="assets/{dest.name}" alt="">'


def cutout(photo: Path, out: Path) -> Path:
    """The person from a photo on a transparent background (for thumbnails). Falls back to the photo itself."""
    try:
        import numpy as np
        from ..effects.cutout import get_segmenter
        img = Image.open(photo).convert("RGB")
        img.thumbnail((1600, 1600))
        mask = get_segmenter()(np.asarray(img))
        alpha = Image.fromarray((np.clip((mask - 0.35) / 0.3, 0, 1) * 255).astype("uint8"))
        rgba = img.convert("RGBA")
        rgba.putalpha(alpha)
        bbox = alpha.point(lambda v: 255 if v > 40 else 0).getbbox()
        if bbox:
            rgba = rgba.crop(bbox)
        rgba.save(out)
        return out
    except Exception as e:  # no segmentation engine: the photo still works, just not cut out
        print(f"  (no cutout: {e})")
        return photo


def body(template: str, f: dict, client: Client, assets: Path, n: int, slide: tuple[int, int] | None = None) -> str:
    """The inner HTML of one design."""
    logo = ""
    lf = client.brand["logo"].get("file")
    if lf and client.path(lf) and client.path(lf).is_file():
        dest = assets / f"logo{client.path(lf).suffix.lower()}"
        if not dest.exists():
            shutil.copy2(client.path(lf), dest)
        logo = f'<img class="logo" src="assets/{dest.name}" alt="">'
    name = html.escape(client.brand.get("client", ""))
    name = "" if name == "Custom" else name  # no client picked: no footer, rather than the word "Custom"
    foot = f'<div class="foot">{logo or f"<b>{name}</b>"}</div>' if (logo or name) else ""
    if template == "quote":
        q = f.get("quote", "")
        return (f'<div class="mark">&ldquo;</div><div class="quote" style="--fs:{_fit(q, 76, 26, 6)}">{_rich(q)}</div>'
                f'<div class="by"><b>{html.escape(f.get("author", ""))}</b><span>{html.escape(f.get("role", ""))}</span></div>{foot}')
    if template == "stat":
        num = f.get("number", "")
        return (f'<div class="num" style="--fs:{_fit(num, 300, 4.2, 1)}; --nch:{max(2, len(re.sub(r"[*,.]", "", num)) + 0.4 * len(re.findall(r"[,.]", num)))}">{_rich(num)}</div>'
                f'<div class="label">{_rich(f.get("label", ""))}</div>'
                f'<div class="ctx">{html.escape(f.get("context", ""))}</div>{foot}')
    if template == "offer":
        ph = _photo_html(f.get("photo"), "photo cut" if f.get("photo_is_cutout") else "photo", assets, n)
        h = f.get("headline", "")
        return (f'{ph}<div class="copy"><div class="kicker">{html.escape(f.get("kicker", ""))}</div>'
                f'<div class="headline" style="--fs:{_fit(h, 92, 16, 3)}">{_rich(h)}</div>'
                f'<div class="offer">{_rich(f.get("offer", ""))}</div>'
                + (f'<div class="btn">{html.escape(f["cta"])}</div>' if f.get("cta") else "")
                + f'<div class="fine">{html.escape(f.get("fineprint", ""))}</div></div>{foot}')
    if template == "testimonial":
        ph = _photo_html(f.get("photo"), "avatar", assets, n)
        r = f.get("review", "")
        return (f'<div class="stars">★★★★★</div><div class="review" style="--fs:{_fit(r, 64, 30, 6)}">{_rich(r)}</div>'
                f'<div class="who">{ph}<div><b>{html.escape(f.get("name", ""))}</b><span>{html.escape(f.get("detail", ""))}</span></div></div>{foot}')
    if template == "thumbnail":
        photo = f.get("photo")
        ph = ""
        if photo and Path(photo).is_file():
            cut = cutout(Path(photo), assets / f"cutout-{n}.png")
            ph = _photo_html(str(cut), "subject" + (" cut" if cut.suffix == ".png" and cut.name.startswith("cutout") else ""), assets, n)
        t = f.get("title", "")
        badge = f'<div class="badge">{html.escape(f["badge"])}</div>' if f.get("badge") else ""
        return f'<div class="burst"></div>{ph}<div class="ttitle" style="--fs:{_fit(t, 150, 9, 3)}">{_rich(t)}</div>{badge}{logo and f"<div class=foot>{logo}</div>"}'
    if template == "tips":
        items = [i.strip() for i in str(f.get("items", "")).splitlines() if i.strip()][:5]
        t = f.get("title", "")
        li = "".join(f'<li><i>{k + 1}</i><span>{_rich(i)}</span></li>' for k, i in enumerate(items))
        return f'<div class="title" style="--fs:{_fit(t, 84, 18, 3)}">{_rich(t)}</div><ol>{li}</ol>{foot}'
    if template == "event":
        t = f.get("title", "")
        meta = "".join(f"<span>{html.escape(f[k])}</span>" for k in ("date", "time", "place") if f.get(k))
        return (f'<div class="kicker">{html.escape(f.get("kicker", ""))}</div>'
                f'<div class="headline" style="--fs:{_fit(t, 104, 16, 3)}">{_rich(t)}</div><div class="meta">{meta}</div>'
                + (f'<div class="btn">{html.escape(f["cta"])}</div>' if f.get("cta") else "") + foot)
    if template == "product":
        ph = _photo_html(f.get("photo"), "prod", assets, n)
        nm = f.get("name", "")
        badge = f'<div class="badge">{html.escape(f["badge"])}</div>' if f.get("badge") else ""
        return (f'<div class="glow"></div>{ph}{badge}<div class="pcopy"><div class="pname" style="--fs:{_fit(nm, 88, 14, 2)}">{_rich(nm)}</div>'
                f'<div class="pbenefit">{_rich(f.get("benefit", ""))}</div>'
                + (f'<div class="price">{_rich(f["price"])}</div>' if f.get("price") else "")
                + (f'<div class="btn">{html.escape(f["cta"])}</div>' if f.get("cta") else "") + f"</div>{foot}")
    if template == "photo":
        ph = _photo_html(f.get("photo"), "hero", assets, n)
        h = f.get("headline", "")
        return (f'{ph}<div class="scrim"></div><div class="hcopy"><div class="headline" style="--fs:{_fit(h, 100, 16, 3)}">{_rich(h)}</div>'
                + (f'<div class="hsub">{_rich(f["sub"])}</div>' if f.get("sub") else "")
                + (f'<div class="btn">{html.escape(f["cta"])}</div>' if f.get("cta") else "") + f"</div>{foot}")
    if template == "slide":  # one carousel page
        i, total = slide or (1, 1)
        h, b = f.get("heading", ""), f.get("text", "")
        return (f'<div class="count">{i}/{total}</div><div class="shead" style="--fs:{_fit(h, 96, 16, 3)}">{_rich(h)}</div>'
                f'<div class="sbody" style="--fs:{_fit(b, 48, 34, 6)}">{_rich(b)}</div><div class="swipe">→</div>{foot}')
    raise ValueError(f"unknown design {template}")


def expand(template: str, fields: dict) -> list[tuple[str, dict]]:
    """A carousel becomes its slides (cover, one per line, call to action); everything else is one design."""
    if template != "carousel":
        return [(template, fields)]
    rows = [r.strip() for r in str(fields.get("items", "")).splitlines() if r.strip()][:10]
    out = [("event", {"kicker": "SWIPE →", "title": fields.get("title", "")})]
    for r in rows:
        head, _, text = r.partition("|")
        out.append(("slide", {"heading": head.strip(), "text": text.strip()}))
    out.append(("event", {"kicker": "", "title": fields.get("cta") or "Follow for more", "cta": "Save this post"}))
    return out


def _logo_tone(client: Client, ground: str) -> str:
    """"mono-dark" / "mono-light" when the logo's own colours have too little contrast with the ground, else ""."""
    lf = client.brand.get("logo", {}).get("file")
    path = client.path(lf) if lf else None
    if not path or not path.is_file():
        return ""
    try:
        im = Image.open(path).convert("RGBA")
        im.thumbnail((200, 200))
        px = [(r, g, b) for r, g, b, a in im.getdata() if a > 128]
        if not px:
            return ""
        # the logo's ink: its most visible half (the colours furthest from the ground)
        gl = hyper._luma(ground)
        px.sort(key=lambda c: abs(0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2] - gl), reverse=True)
        top = px[:max(1, len(px) // 2)]
        mean = "#%02x%02x%02x" % tuple(int(sum(c[i] for c in top) / len(top)) for i in range(3))
        if hyper.contrast(mean, ground) >= 3.0:  # WCAG 1.4.11: graphics need 3:1
            return ""
        return "mono-dark" if hyper.on(ground) == "#111111" else "mono-light"
    except Exception:  # noqa: BLE001 - an unreadable logo file: leave it as it is
        return ""


CSS = Path(__file__).with_name("design.css")


def build_project(designs: list[tuple[str, dict]], client: Client, size: tuple[int, int], style: str, project: Path,
                  gsap: Path) -> int:
    """One composition, one design per frame. Returns how many frames (designs)."""
    W, H = size
    if project.exists():
        shutil.rmtree(project)
    assets = project / "assets"
    assets.mkdir(parents=True)
    shutil.copy2(gsap, assets / "gsap.min.js")
    faces, head_font, body_font = hyper._fonts(client, project)
    pal = _palette(client, style)
    ratio = H / W
    shape = "tall" if ratio > 1.5 else "portrait" if ratio > 1.1 else "wide" if ratio < 0.8 else "square"
    total_slides = sum(1 for t, _ in designs if t == "slide")
    parts, k = [], 0
    for n, (template, f) in enumerate(designs):
        if template == "slide":
            k += 1
        inner = body(template, f, client, assets, n, slide=(k, total_slides) if template == "slide" else None)
        parts.append(f'<section id="d{n}" class="d t-{template}"><div class="deco a"></div><div class="deco b"></div>'
                     f'<div class="pad">{inner}</div></section>')
    # a logo that would vanish into the ground (lime on cream, gold on white) is shown in one solid colour instead
    tone = _logo_tone(client, pal["ground"]) if style != "bold" else ""
    if tone:
        parts = [x.replace('<img class="logo"', f'<img class="logo {tone}"') for x in parts]
    frames = len(designs)
    dur = round(frames / FPS + 0.001, 4)
    css = CSS.read_text(encoding="utf-8")
    page = f"""<!doctype html>
<!-- AutoCut graphic (HyperFrames composition, {frames} design{'s' if frames > 1 else ''}: one per frame). -->
<html lang="en"><head><meta charset="UTF-8">
<script src="assets/gsap.min.js"></script>
<style>
{faces}
:root {{ --W: {W}px; --H: {H}px; --u: {min(W, H) / 1080 * {"tall": 1.3, "portrait": 1.12}.get(shape, 1):.4f}px; --ground: {pal['ground']}; --ground2: {pal['ground2']};
  --ink: {pal['ink']}; --inv: {1 if hyper._luma(pal['ink']) > 128 else 0}; --accent: {pal['accent']}; --on-accent: {pal['on_accent']}; --soft: {pal['soft']};
  --accent-strong: {pal['accent_strong']}; --stars: {pal['stars']};
  --head: "{head_font}", "Montserrat", sans-serif; --body: "{body_font}", "Montserrat", sans-serif; }}
{css}
</style></head>
<body class="{style} {shape}">
<div id="root" data-composition-id="main" data-start="0" data-duration="{dur}" data-width="{W}" data-height="{H}">
  <div id="g" class="clip" data-start="0" data-duration="{dur}" data-track-index="1" data-layout-allow-overflow data-layout-allow-overlap>
  {''.join(parts)}
  </div>
</div>
<script>
  window.__timelines = window.__timelines || {{}};
  const tl = gsap.timeline({{ paused: true }});
  const ds = gsap.utils.toArray(".d");
  ds.forEach((d, i) => {{ tl.set(d, {{ opacity: i === 0 ? 1 : 0 }}, 0); if (i) tl.set(d, {{ opacity: 1 }}, i / {FPS}); if (i) tl.set(ds[i - 1], {{ opacity: 0 }}, i / {FPS}); }});
  tl.set({{}}, {{}}, {dur});
  window.__timelines["main"] = tl;
</script>
</body></html>"""
    (project / "index.html").write_text(page, encoding="utf-8")
    return frames


def render_project(project: Path, frames: int, settings: dict) -> list[Path]:
    """Render the composition's frames to PNGs (frame i = design i)."""
    seq = project / "_frames"
    if seq.exists():
        shutil.rmtree(seq)
    hyper.render_project(project, seq, settings, "png-sequence", fps=FPS)
    got = sorted(seq.glob("*.png"))
    if len(got) < frames:
        raise RuntimeError(f"expected {frames} frames, got {len(got)}")
    return got[:frames]


# ---- items: what the dashboard creates ------------------------------------------------------------------------------

def new_item(spec: dict, settings: dict) -> Path:
    label = re.sub(r"[^a-z0-9]+", "-", json.dumps(spec.get("fields") or spec.get("rows", [])[:1]).lower())[:40].strip("-")
    item = library_dir(settings) / f"{datetime.now():%Y%m%d-%H%M%S}-{spec['template']}-{label or 'design'}"
    item.mkdir(parents=True, exist_ok=True)
    (item / "spec.json").write_text(json.dumps(spec, indent=2))
    _status(item, state="queued")
    return item


def _status(item: Path, **fields):
    p = item / "status.json"
    data = json.loads(p.read_text()) if p.exists() else {}
    data.update(fields, updated=time.time())
    p.write_text(json.dumps(data, indent=2))


def render_item(item: Path, settings: dict) -> None:
    """Every size × look for one Graphics-tab item (run by the worker). Rows (bulk create) each become a design."""
    from ..mograph.prompt import brand_client
    from . import assets as uploads
    spec = json.loads((item / "spec.json").read_text())
    assets = [a for a in spec.get("assets") or [] if a.get("path") and Path(a["path"]).exists()]
    colors = spec.get("colors") or []
    if not colors and assets:
        colors, _style = uploads.style_colors(assets, settings)  # "match this look": its colours lead
    client = brand_client({"client": spec.get("client"), "colors": colors}, settings)
    logo = next((a["path"] for a in assets if a.get("role") == "logo"), None)
    if logo:  # this design's own logo
        client.brand["logo"] = {**client.brand["logo"], "file": str(Path(logo).resolve())}
    gsap = hyper.runtime_dir(settings) / "node_modules" / "gsap" / "dist" / "gsap.min.js"
    work = item / "_assets"
    work.mkdir(exist_ok=True)
    rows = [uploads.apply(spec["template"], r, assets, work) for r in (spec.get("rows") or [spec.get("fields") or {}])]
    edited = (item / ".rerender").exists()  # re-render the Studio-edited projects as they are
    (item / ".rerender").unlink(missing_ok=True)
    files = []
    try:
        if not hyper.available(settings):
            raise RuntimeError("The Graphics tab needs the HyperFrames engine: run `autocut hyperframes-setup`")
        combos = [(s, st) for s in spec.get("sizes") or ["post"] for st in spec.get("styles") or ["bold"]]
        for n, (size_name, style) in enumerate(combos):
            _status(item, state="rendering", step=f"{SIZES[size_name][1]} · {style} ({n + 1}/{len(combos)})")
            if spec["template"] == "custom":
                png = item / f"custom-{size_name}-{style}.png"
                make_custom(spec.get("brief") or spec.get("prompt", ""), client, SIZES[size_name][0], png, settings, style)
                files.append(png.name)
                continue
            designs = [d for row in rows for d in expand(spec["template"], row)]
            project = item / f"hf-{size_name}-{style}"
            if edited and (project / "index.html").exists():
                frames = len(designs)
            else:
                frames = build_project(designs, client, SIZES[size_name][0], style, project, gsap)
            pngs = render_project(project, frames, settings)
            names = []
            for k, src in enumerate(pngs):
                dest = item / (f"{spec['template']}-{size_name}-{style}" + (f"-{k + 1:02d}" if frames > 1 else "") + ".png")
                Image.open(src).convert("RGB").save(dest, optimize=True)
                names.append(dest.name)
            shutil.rmtree(project / "_frames", ignore_errors=True)
            files += names
            if spec["template"] == "carousel":  # LinkedIn takes a carousel as one PDF
                pdf = item / f"carousel-{size_name}-{style}.pdf"
                imgs = [Image.open(item / nm).convert("RGB") for nm in names]
                imgs[0].save(pdf, save_all=True, append_images=imgs[1:], resolution=144)
                files.append(pdf.name)
        _status(item, state="done", files=files, step=None, edited=edited or None)
    except Exception as e:
        _status(item, state="error", error=str(e)[:400])
        raise


def list_items(settings: dict, limit: int = 60) -> list[dict]:
    out = []
    for d in sorted(library_dir(settings).glob("*/spec.json"), reverse=True)[:limit]:
        item = d.parent
        try:
            spec = json.loads(d.read_text())
            st = json.loads((item / "status.json").read_text()) if (item / "status.json").exists() else {}
        except json.JSONDecodeError:
            continue
        files = [str(item / f) for f in st.get("files", []) if (item / f).exists()]
        out.append({"dir": str(item), "name": item.name, "spec": spec, "state": st.get("state"), "step": st.get("step"),
                    "error": st.get("error"), "files": files, "edited": bool(st.get("edited")),
                    "studio": sorted(p.name[3:] for p in item.glob("hf-*") if (p / "index.html").exists())})
    return out


# ---- bulk create + Magic Design ---------------------------------------------------------------------------------------

def rows_from_csv(text: str, template: str) -> list[dict]:
    """A spreadsheet (CSV) → one design per row. Column names match the field names or their labels."""
    keys = {k: k for k, _, _ in TEMPLATES[template][1]}
    keys.update({lbl.split(" (")[0].lower(): k for k, lbl, _ in TEMPLATES[template][1]})
    rows = []
    for r in csv.DictReader(io.StringIO(text.lstrip("﻿"))):
        row = {keys[c.strip().lower()]: (v or "").strip() for c, v in r.items() if c and c.strip().lower() in keys}
        if any(row.values()):
            rows.append(row)
    if not rows:
        raise ValueError("No rows matched. Use column names like: " + ", ".join(k for k, _, _ in TEMPLATES[template][1]))
    return rows[:100]


DESIGN_WORDS = [
    ("thumbnail", r"thumbnail|youtube"), ("carousel", r"carousel|slides?\b|swipe"), ("testimonial", r"testimonial|review"),
    ("quote", r"\bquote\b"), ("stat", r"\bstat\b|statistic|number|percent|%"), ("tips", r"tips?\b|\blist\b|\bsigns\b|ways\b|steps\b"),
    ("event", r"event|webinar|workshop|open house|grand opening|announce"), ("product", r"product|launch|new arrival|spotlight|shop"),
    ("offer", r"\bad\b|offer|promo|sale|discount|deal"),
]
SIZE_WORDS = [("story", r"story|stories|reel cover|9:16"), ("thumbnail", r"thumbnail|youtube"), ("portrait", r"4:5|portrait|feed"),
              ("ad", r"link ad|facebook ad|1\.91|landscape"), ("post", r"\bpost\b|1:1|square|instagram")]

DESIGN_SCHEMA = {"type": "object", "properties": {
    "template": {"type": "string"}, "fields": {"type": "object", "properties": {
        k: {"type": "string"} for k in sorted({k for _, fs in TEMPLATES.values() for k, _, _ in fs if k != "photo"})}},
    "sizes": {"type": "array", "items": {"type": "string"}}}, "required": ["template", "fields"]}


QUOTE_RX = re.compile(r'"([^"]{2,})"|“([^”]{2,})”|(?:^|(?<=[\s:(]))[\'‘]((?:[^\'’]|[\'’](?=\w))+?)[\'’](?=[\s,.!?;:)]|$)')
DAY_RX = re.compile(r"\b(?:this |next )?((?:mon|tues|wednes|thurs|fri|satur|sun)day|tonight|tomorrow|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.? \d{1,2}(?:st|nd|rd|th)?)\b", re.I)
TIME_RX = re.compile(r"\b(\d{1,2}(?::\d\d)?\s?(?:am|pm)?\s?(?:-|–|to)\s?\d{1,2}(?::\d\d)?\s?(?:am|pm)|\d{1,2}(?::\d\d)?\s?(?:am|pm))\b", re.I)
PLACE_RX = re.compile(r"\b(?:at|@)\s+((?:\d+\s+)?[A-Z0-9][\w'&.-]*(?:\s+[A-Z0-9][\w'&.-]*){0,4})")
WHEN_RX = re.compile(r"\b(this (?:month|week|weekend)|today only|today|ends? \w+|until \w+(?: \d+)?|for a limited time)\b", re.I)
NUM_RX = re.compile(r"[+\-−]?[$€£]?\d[\d,.]*\s?(?:%|x\b|k\b|m\b|lbs?\b|kg\b|days?\b|hours?\b|years?\b|weeks?\b)?", re.I)
NAME_RX = re.compile(r"^[A-Z][\w'.-]*(?:\s+[A-Z][\w'.-]*){0,3}\.?$")


def _quotes(prompt: str) -> tuple[list[str], str]:
    """Quoted text (apostrophes inside words don't end a quote), and what follows the last quote."""
    found, tail = [], ""
    for m in QUOTE_RX.finditer(prompt):
        found.append(next(g for g in m.groups() if g))
        tail = prompt[m.end():]
    return found, tail.strip(" ,-–—:;")


def _sentence(t: str) -> str:
    t = re.sub(r"\s+", " ", str(t or "")).strip(" ,.-:;")
    return t[:1].upper() + t[1:] if t else t


def _rules_fields(template: str, prompt: str, quotes: list[str], tail: str) -> dict:
    """The design's text without AI: quoted text kept exactly, the rest sorted into the right fields."""
    fields = {k: "" for k, _, _ in TEMPLATES[template][1]}
    body = re.sub(r"^\s*[\w /&-]{0,40}:\s*", "", prompt)               # "event: …" → "…"
    body = QUOTE_RX.sub(" ", body)
    body = re.sub(r",?\s*\b(all sizes|every size|in (square|vertical|landscape)|(instagram |facebook |youtube )?(post|story|stories|thumbnail)"
                  r"( and (post|story))?|(for|about) (our|my|the|a)\b)", " ", body, flags=re.I)
    body = re.sub(r"\s+", " ", body).strip(" ,.-:")
    who = tail if tail and NAME_RX.match(tail) else ""
    if who:
        body = body.replace(who, "").strip(" ,.-:")
    if template == "quote":
        fields.update(quote=quotes[0] if quotes else _sentence(body), author=who)
    elif template == "testimonial":
        fields.update(review=quotes[0] if quotes else _sentence(body), name=who)
    elif template == "stat":
        m = NUM_RX.search(body if not quotes else quotes[0])
        src = body if not quotes else quotes[0]
        if m:
            fields["number"] = m.group(0).strip().replace("−", "-")
            fields["label"] = (src[:m.start()] + src[m.end():]).strip(" ,.-:")
        else:
            fields["label"] = _sentence(src)
    elif template == "event":
        day, time_, place = DAY_RX.search(body), TIME_RX.search(body), PLACE_RX.search(body)
        fields["date"] = _sentence(day.group(1)) if day else ""
        fields["time"] = time_.group(1).replace(" ", "") if time_ else ""
        fields["place"] = place.group(1) if place else ""
        rest = body
        for m in (place, time_, day):
            if m:
                rest = rest[:m.start()] + "," + rest[m.end():]
        kick = re.search(r"open house|webinar|workshop|grand opening|launch party|launch|wine dinner|tasting|class|meetup|"
                         r"\w+ (?:dinner|night|party|sale|day)", rest, re.I)
        fields["kicker"] = (kick.group(0) if kick else "Save the date").upper()
        if kick:
            rest = rest[:kick.start()] + rest[kick.end():]
        parts = [x.strip(" .-") for x in re.split(r",", re.sub(r"\b(event|this|next|on)\b", " ", rest, flags=re.I)) if x.strip(" .-")]
        fields["title"] = quotes[0] if quotes else _sentence(", ".join(parts))
        if not fields["title"]:  # nothing but the kind of event: it becomes the title, the kicker an invitation
            fields["title"], fields["kicker"] = _sentence(fields["kicker"].lower()), "YOU'RE INVITED"
        fields["cta"] = "Save your spot" if not re.search(r"dinner|tasting|table", prompt, re.I) else "Book a seat"
    elif template == "offer":
        when = WHEN_RX.search(body)
        rest = (body[:when.start()] + body[when.end():]).strip(" ,.-") if when else body
        rest = re.sub(r"^\b(ad|offer|promo|sale|deal)\b\s*", "", rest, flags=re.I)
        if quotes:
            fields["headline"] = quotes[0]
            fields["offer"] = _sentence(rest) + ("." if rest and not rest.endswith((".", "!")) else "")
        else:
            fields["headline"] = _sentence(rest)
            fields["offer"] = _sentence(when.group(1)) + (" only" if when and "only" not in when.group(1).lower() else "") if when else ""
        free = re.search(r"\bfree\b|\d+%\s*off|\bsave\b", prompt, re.I)
        fields["kicker"] = "LIMITED TIME" if when or free else ""
        fields["cta"] = "Claim yours" if free else "Get started"
    elif template == "tips":
        fields["title"] = quotes[0] if quotes else _sentence(body.split(":")[0])
        items = [x.strip(" .") for x in re.split(r"[;\n]|,(?![^(]*\))", body.split(":", 1)[1]) if x.strip(" .")] if ":" in body else []
        fields["items"] = "\n".join(_sentence(x) for x in items[:5]) if len(items) >= 2 else ""
    elif template == "product":
        price = re.search(r"[$€£]\s?\d[\d,.]*", body)
        if price:
            fields["price"] = price.group(0)
            body = (body[:price.start()] + body[price.end():]).strip(" ,.-:")
        named = re.search(r"\bnew\s+([\w'-]+(?:\s+[\w'-]+)?)", body, re.I)
        fields["name"] = quotes[0] if quotes else (named.group(1) if named else body.split(",")[0])[:40].strip().title()
        fields["badge"] = "NEW" if named else ""
        fields["cta"] = "Shop now"
    elif template == "thumbnail":
        fields["title"] = quotes[0] if quotes else _sentence(body)
    else:
        main = next(k for k, _, kind in TEMPLATES[template][1] if kind in ("long", "text"))
        fields[main] = quotes[0] if quotes else _sentence(body)[:140]
    return fields


def magic_design(prompt: str, settings: dict, brand: dict | None = None, assets: list[dict] | None = None) -> dict:
    """A plain-English request (+ your images) → a design spec. The AI looks at the images and writes the copy in the
    brand's voice; rules are the fallback."""
    from .. import brain, marketing
    assets = [a for a in assets or [] if a.get("path") and Path(a["path"]).exists()]
    roles = {a.get("role") for a in assets}
    p = prompt.lower()
    default = "product" if "product" in roles else "photo" if "photo" in roles else "offer"
    template = next((t for t, rx in DESIGN_WORDS if re.search(rx, p)), default)
    sizes = [s for s, rx in SIZE_WORDS if re.search(rx, p)] or (["thumbnail"] if template == "thumbnail" else ["post", "story"])
    if re.search(r"all sizes|every size|resize", p):
        sizes = list(SIZES)
    quotes, tail = _quotes(prompt)
    fields = _rules_fields(template, prompt, quotes, tail)
    guide = ("Design a social graphic from this request. template: one of " + json.dumps(list(TEMPLATES)) +
             ". fields for the chosen template: " + json.dumps({t: [k for k, _, _ in fs if k != "photo"] for t, (_, fs) in TEMPLATES.items()}) +
             ". Write short, punchy, on-brand copy (headlines under 8 words; use *one keyword* for the accent colour). "
             "For tips, items is one per line; for carousel, items is one slide per line as 'Heading | one or two sentences'. "
             "Keep any text the user quoted exactly. sizes: any of " + json.dumps(list(SIZES)) + ". "
             "Examples: 'event: wine dinner Thursday 7pm, five courses five Tuscan wines' → {\"template\": \"event\", \"fields\": "
             "{\"kicker\": \"WINE DINNER\", \"title\": \"Five courses, *five* Tuscan wines\", \"date\": \"Thursday\", \"time\": \"7 PM\", "
             "\"cta\": \"Book a seat\"}}. 'ad: free home valuation this month' → {\"template\": \"offer\", \"fields\": {\"kicker\": "
             "\"LIMITED TIME\", \"headline\": \"What's your home *really* worth?\", \"offer\": \"Free valuation, this month only\", "
             "\"cta\": \"Book yours\"}}. Sentence case; each fact in its own field; never truncate a quote.")
    looks = [Path(a["path"]) for a in assets if a.get("role") in ("photo", "product", "style")][:3]
    if looks:
        guide += (" Images are attached (" + ", ".join(f"{a.get('role')}: {Path(a['path']).name}" for a in assets) +
                  "). Look at them: describe the product/photo truthfully in the copy (what it is, what it's for), "
                  "never invent features you can't see or weren't told. With a product image, prefer the product template; "
                  "with a strong photo, prefer the photo template, unless the request names another design.")
    ai = brain.ask(settings, marketing.system_prompt(brand, "design") + "\n\n" + guide, "Request: " + prompt, DESIGN_SCHEMA,
                   images=looks or None, timeout=180)
    via = None
    if isinstance(ai, dict) and ai.get("template") in TEMPLATES:
        template = ai["template"]
        fields = {k: str((ai.get("fields") or {}).get(k) or "") for k, _, _ in TEMPLATES[template][1] if k != "photo"}
        for k, q in zip([k for k, _, kind in TEMPLATES[template][1] if kind in ("long", "text")], quotes):
            fields[k] = fields[k] or q
        sizes = [s for s in (ai.get("sizes") or []) if s in SIZES] or sizes
        via = brain.last_engine()
    return {"template": template, "fields": fields, "sizes": sizes, "styles": ["bold", "clean", "dark"],
            "prompt": prompt, "via": via}


# ---- fully custom (the AI writes the whole design) --------------------------------------------------------------------

CUSTOM_STILL = """You design one social media graphic as a single standalone index.html that HyperFrames renders to a PNG.
Agency quality: strong hierarchy, generous spacing, one accent colour with meaning, nothing cramped, everything inside a
6% margin. It is a STILL: no animation needed.
Rules: html and body are {W}x{H}px, overflow hidden. Root: <div id="root" data-composition-id="main" data-start="0"
data-duration="0.034" data-width="{W}" data-height="{H}" data-no-timeline>. No scripts, no network, no external images.
Fonts that resolve: {fonts}. Brand: primary {primary}, secondary {secondary}, text {text}; look: {style}.
Assets you may use: {assets}
Return JSON: {{"html": the complete index.html, "summary": one sentence}}."""


def make_custom(brief: str, client: Client, size: tuple[int, int], out: Path, settings: dict, style: str = "bold") -> Path:
    from .. import brain
    W, H = size
    project = out.with_name("hf-" + out.stem)
    if project.exists():
        shutil.rmtree(project)
    (project / "assets").mkdir(parents=True)
    faces, head, body_font = hyper._fonts(client, project)
    assets = []
    lf = client.brand["logo"].get("file")
    if lf and client.path(lf) and client.path(lf).is_file():
        shutil.copy2(client.path(lf), project / "assets" / ("logo" + client.path(lf).suffix.lower()))
        assets.append(f"assets/logo{client.path(lf).suffix.lower()} (logo)")
    c = client.brand["colors"]
    system = CUSTOM_STILL.format(W=W, H=H, fonts=", ".join(sorted({head, body_font, "Inter", "Montserrat", "Poppins",
                                 "Playfair Display", "Oswald", "Archivo Black"})), primary=c["primary"], secondary=c["secondary"],
                                 text=c.get("text", "#fff"), style=STYLES.get(style, style), assets=", ".join(assets) or "none")
    last = ""
    for _ in range(2):
        from .. import marketing
        res = brain.ask(settings, marketing.system_prompt(client.brand, "design") + "\n\n" + system, "Design: " + brief + (f"\n\nThe last version failed: {last}" if last else ""),
                        hyper.CUSTOM_SCHEMA, prefer="cloud", timeout=300)
        page = (res or {}).get("html") if isinstance(res, dict) else None
        if not page:
            raise RuntimeError("The AI didn't write a design (is Claude set up under This Mac → AI brain?)")
        if faces and "@font-face" not in page:
            page = page.replace("<style>", "<style>\n" + faces + "\n", 1)
        (project / "index.html").write_text(page, encoding="utf-8")
        try:
            png = render_project(project, 1, settings)[0]
            Image.open(png).convert("RGB").save(out, optimize=True)
            shutil.rmtree(project / "_frames", ignore_errors=True)
            return out
        except RuntimeError as e:
            last = str(e)[-800:]
    raise RuntimeError("The AI's design didn't render: " + last[-300:])


def thumbnail_from_video(video: Path, out: Path, at: float = 0.3) -> Path:
    """A frame from a video (default 30% in) to use as the thumbnail photo."""
    dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(video)],
                               capture_output=True, text=True).stdout or 10)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", f"{dur * at:.2f}", "-i", str(video), "-frames:v", "1", str(out)],
                   check=True)
    return out
