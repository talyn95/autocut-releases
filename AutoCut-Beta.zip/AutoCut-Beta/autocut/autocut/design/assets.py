"""Your own images in the Graphics tab: photography, product shots, logos and look/colour references.

Each upload gets a role:
  photo    a photo to feature (the team, the work, a customer, a location): shown large, never cut up
  product  a product (or any object): cut out of its background and placed on the brand ground
  logo     a logo for this design (instead of the client's)
  style    "match this look": its colours (and the AI's read of its style) steer the design
AutoCut composes your real images into on-brand designs; it doesn't invent new pixels. (Optional AI image
generation on Macs is separate: aiimage.py.)
"""
from __future__ import annotations

import os
import urllib.request
from pathlib import Path

import numpy as np
from PIL import Image

from ..config import LOCAL_SETTINGS

ROLES = {"photo": "Feature this photo", "product": "Product (cut out)", "logo": "Logo", "style": "Match this look / colours"}
MODEL_DIR = Path(os.environ.get("AUTOCUT_MODELS", LOCAL_SETTINGS.parent / "models"))
# U²-Net-P: a small (4.6 MB) general "salient object" model: products, objects, people. Apache-2.0 (U-2-Net).
OBJECT_MODEL_URL = "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2netp.onnx"
_session = None


def _object_session():
    global _session
    if _session is None:
        import onnxruntime as ort
        model = MODEL_DIR / "u2netp.onnx"
        if not model.exists():
            MODEL_DIR.mkdir(parents=True, exist_ok=True)
            print("  downloading the product cut-out model (one time, 5 MB) …")
            tmp = model.with_suffix(".part")
            urllib.request.urlretrieve(OBJECT_MODEL_URL, tmp)
            tmp.replace(model)
        _session = ort.InferenceSession(str(model), providers=["CPUExecutionProvider"])
    return _session


def has_transparency(img: Image.Image) -> bool:
    if img.mode not in ("RGBA", "LA", "P"):
        return False
    a = np.asarray(img.convert("RGBA"))[..., 3]
    return float((a < 250).mean()) > 0.03


def object_mask(rgb: np.ndarray) -> np.ndarray:
    """0..1 mask of the main object in an RGB image."""
    sess = _object_session()
    h, w = rgb.shape[:2]
    x = np.asarray(Image.fromarray(rgb).resize((320, 320), Image.BILINEAR), np.float32) / 255.0
    x = ((x - (0.485, 0.456, 0.406)) / (0.229, 0.224, 0.225)).transpose(2, 0, 1)[None].astype(np.float32)
    m = sess.run(None, {sess.get_inputs()[0].name: x})[0][0, 0]
    m = (m - m.min()) / (m.max() - m.min() + 1e-6)
    return np.asarray(Image.fromarray((m * 255).astype(np.uint8)).resize((w, h), Image.BILINEAR), np.float32) / 255.0


def cutout_object(src: Path, out: Path) -> Path:
    """The product on a transparent background, trimmed to its edges. A PNG that's already transparent is kept
    as it is; without the model, the photo itself is used."""
    img = Image.open(src)
    img.thumbnail((1800, 1800))
    if has_transparency(img):
        rgba = img.convert("RGBA")
    else:
        try:
            rgb = np.asarray(img.convert("RGB"))
            mask = object_mask(rgb)
            alpha = Image.fromarray((np.clip((mask - 0.3) / 0.35, 0, 1) * 255).astype("uint8"))
            rgba = img.convert("RGBA")
            rgba.putalpha(alpha)
        except Exception as e:
            print(f"  (no product cut-out: {e})")
            return src
    bbox = rgba.getchannel("A").point(lambda v: 255 if v > 24 else 0).getbbox()
    if bbox:
        rgba = rgba.crop(bbox)
    rgba.save(out)
    return out


def guess_role(path: Path, img: Image.Image) -> str:
    name = path.stem.lower()
    if "logo" in name or "wordmark" in name or "brandmark" in name:
        return "logo"
    if any(w in name for w in ("style", "reference", "moodboard", "palette", "inspo", "inspiration")):
        return "style"
    if has_transparency(img):
        w, h = img.size
        return "logo" if w / max(h, 1) > 2.2 and max(w, h) < 1600 else "product"
    if any(w in name for w in ("product", "bottle", "box", "package", "item", "sku")):
        return "product"
    return "photo"


def describe(path: Path) -> dict:
    """What the dashboard shows after an upload: a role guess and the image's main colours."""
    from ..mograph.reference import palette
    img = Image.open(path)
    small = img.convert("RGB")
    small.thumbnail((256, 256))
    return {"path": str(path), "role": guess_role(path, img), "size": list(img.size),
            "colors": [c for c, _ in palette([small], k=4)]}


def apply(template: str, row: dict, assets: list[dict], work: Path) -> dict:
    """Fill a design's photo/product fields from the uploaded assets (the first of each role)."""
    row = dict(row)
    photo = next((a["path"] for a in assets if a.get("role") == "photo"), None)
    product = next((a["path"] for a in assets if a.get("role") == "product"), None)
    if template == "product" and not row.get("photo") and (product or photo):
        src = Path(product or photo)
        row["photo"] = str(cutout_object(src, work / f"product-{src.stem}.png")) if product else str(src)
    elif template in ("photo", "offer", "testimonial", "thumbnail") and not row.get("photo"):
        if photo:
            row["photo"] = photo
        elif product and template == "offer":
            src = Path(product)
            row["photo"] = str(cutout_object(src, work / f"product-{src.stem}.png"))
            row["photo_is_cutout"] = True
    return row


def style_colors(assets: list[dict], settings: dict) -> tuple[list[str], dict | None]:
    """Brand colours from "match this look" references (and the AI's style read, if it ran)."""
    refs = [Path(a["path"]) for a in assets if a.get("role") == "style" and Path(a["path"]).exists()]
    if not refs:
        return [], None
    from ..mograph.reference import analyze
    try:
        r = analyze(refs, settings)
    except Exception as e:
        print(f"  (couldn't read the reference: {e})")
        return [], None
    return list(r.get("colors") or [])[:2], r
