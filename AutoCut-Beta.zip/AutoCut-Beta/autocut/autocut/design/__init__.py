"""Graphics tab: on-brand still graphics (posts, stories, thumbnails, ads, carousels), Canva-style.
See stills.py."""
