# PLATFORMS: what works where (practices, not guarantees; platforms change often)

TikTok
- Vertical 9:16, native-feeling, creator-style. 20-60 s is a common sweet spot; longer works for stories and
  education when retention holds. Search is a major discovery path: say and write the keywords people search.
- Captions: conversational, 1-3 lines, a question invites comments. 3-5 hashtags (broad + niche + branded).
- Trends and sounds help reach but only when they fit the brand. Reply-to-comment videos and stitches build community.
- Ads: Spark Ads (boosting organic/creator posts) usually feel more native than brand ads.

Instagram Reels / feed / stories
- Reels 9:16 for reach; carousels (4:5) for saves and education; stories for warm audiences and offers.
- Keep text and faces out of the bottom ~20% and top ~14% (UI overlays). First frame doubles as the cover in grid.
- Collaborations (collab posts) with partners, staff and customers expand reach. Trial-style posting to
  non-followers is useful for testing hooks.

YouTube
- Shorts: under a minute is safest, vertical, hook in the first second, loopable. Shorts can feed long-form viewers.
- Long-form: title 40-60 characters, main keyword near the front, curiosity without clickbait; the thumbnail and
  title are a single promise (thumbnail 3-5 words max, an emotional face, high contrast). Description: 2-line summary,
  chapters starting 00:00, links, CTA. Search and suggested traffic reward watch time and satisfaction.

Facebook
- Warm, community and local. Older audiences, longer captions are OK. Reels plus groups and local pages.

LinkedIn
- Professional and specific: an insight, a lesson, a result, a behind-the-scenes of the work. Native video and
  document carousels (PDF) perform well. 1-3 hashtags. Founder and employee voices outperform company pages.

Google Business Profile (local)
- Short videos and photos of real work, staff and location build local trust; post regularly; ask for reviews.

Across platforms (current direction)
- Authenticity and real faces are rising as generic/AI content floods feeds; founder-led and employee-generated
  content, behind-the-scenes and customer stories stand out.
- Search inside social apps (TikTok, Instagram, YouTube) behaves like SEO: use clear spoken and written keywords.
- Ad delivery systems (e.g. Meta's Advantage+) reward many genuinely different creatives: different angles, formats,
  people and hooks, not ten copies of one ad.
