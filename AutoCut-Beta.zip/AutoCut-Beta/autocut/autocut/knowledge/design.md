# GRAPHIC DESIGN FOR SOCIAL AND ADS

- One message per graphic. Hierarchy: headline (big) → support line → proof/detail → CTA → logo (small).
- Mobile first: headline readable at thumb size; few words; strong contrast; generous margins; nothing important
  in platform UI zones.
- Brand consistency: client colours, fonts and logo every time; one accent colour for the key word or number.
- Use real photography (the team, the work, the product, the customer) over stock when possible; people's faces and
  eyes draw attention; cut-outs over brand colour feel premium.
- Thumbnails: 3-5 words max (complement the title, don't repeat it), an expressive face, one focal point,
  high contrast, readable at small size, curiosity or a clear outcome.
- Carousels: slide 1 is a hook (promise or question), each slide one point, last slide a CTA (save/share/book);
  consistent layout and numbering; 5-10 slides.
- Static ads: offer or benefit as the headline, social proof (stars, review quote, numbers), a clear button-style
  CTA; test multiple headlines and images.
- Quote/testimonial cards: short, specific quotes with a name and context; stars only if real.

## Checkable rules (AutoCut scores every design against these)
- Contrast: text at least 4.5:1 against what's behind it (3:1 for big headlines and numbers). Brand colours that
  fail get darker/lighter, never dropped. Small coloured text (kickers) needs the full 4.5:1.
- Sentence case for headlines ("Free home valuation", not "free home valuation"); kickers in capitals, 1-3 words.
- Put each fact in its own field: an event's day, time and place go in date/time/place (they become pills), never in
  the title. Title = what it is ("Five courses, five Tuscan wines"); kicker = the kind of event ("WINE DINNER").
- A quote or review is kept word for word, with who said it in author/name ("Maria G."). Never cut it short.
- An offer needs three parts: headline (the benefit, under 8 words), offer line (the terms: "No contract, no
  excuses." / "This month only"), and a button CTA (2-3 words: "Claim yours", "Book a seat"). Kicker "LIMITED TIME"
  only when there is a deadline or a free/discount.
- A stat keeps its sign and unit together ("+60 lb", "$1,250,000", "98%"); the label finishes the sentence in lower
  case ("average deadlift gain in 6 weeks").
- Tips/lists: 3-5 items, each under 6 words, parallel wording; never a list title without the items.
- Story (9:16): nothing important in the top 12% or bottom 18%. Text never touches the edges (4% margin).
