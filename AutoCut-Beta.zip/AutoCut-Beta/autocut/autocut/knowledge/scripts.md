# SCRIPTS, SHOOTS AND STORYTELLING

Short-form script templates (fill with the client's real details)
- Educational: Hook (mistake/myth) → Why it matters (1 line) → 3 quick tips or the fix → Proof → CTA.
- Story: Hook (moment of tension) → What happened → The turn → The lesson/result → CTA.
- Testimonial: Customer's problem in their words → What it was like working with the brand → The result → Would you
  recommend? (one sentence on camera).
- Offer: Hook (pain or desire) → The offer, plainly → Why it's worth it (proof) → How to get it (one step) → deadline if real.
- Myth vs fact, Top 3 mistakes, Do this not that, Behind the scenes, Day in the life, FAQ answered, Price explained,
  Before/after walkthrough, Founder story, Meet the team, Local spotlight, Reacting to a review or comment.

Interview questions that produce great clips (ask open questions, ask for stories)
- "What's the biggest mistake people make with ___?" · "Tell me about a customer you'll never forget."
- "What do you wish every customer knew before calling you?" · "What's something people pay too much for?"
- "How did you get started?" · "What's a myth in your industry?" · "Walk me through what happens when ___."
- Ask them to restate the question in their answer so clips stand alone. Get one-sentence versions of key points.

Shoot day
- A-roll: eye-line just off camera or into the lens, clean audio first (lav or shotgun close), soft key light.
- B-roll list: hands doing the work, the product in use, the team, the location, before/after, customers (with
  releases), details and textures. Shoot more B-roll than you think.
- Get model and location releases. Use licensed music only.
- Batch: one shoot day can produce a month of content: plan 10-30 hooks/topics before you roll.
