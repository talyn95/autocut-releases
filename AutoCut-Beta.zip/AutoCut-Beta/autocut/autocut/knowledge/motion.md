# MOTION GRAPHICS IN MARKETING VIDEOS

- Use motion to clarify and emphasise, not decorate: hook titles, key numbers (counters), names (lower thirds),
  steps and lists, before/after, data stories, CTAs and end cards.
- Kinetic typography for hooks and key lines: 3-7 words per beat, one highlighted keyword in the accent colour.
- Motion craft: arrivals fast with a soft landing (ease-out), exits shorter than entrances, stagger elements slightly,
  land titles and hold them still long enough to read (about 0.5 s + 0.3 s per word).
- Keep graphics inside safe zones on 9:16; never cover the speaker's face; match brand colours and fonts.
- A logo sting or end card with one CTA at the end; avoid long animated intros (they cost viewers).

## Effects edit: one effect per sentence (talking-head shorts)
Pick the effect that shows what the sentence says, never the same one twice in a row, and use as many different ones
as fit (variety is the style). Open strong: magazine cover, frame pop or punch-through for the hook.
- tick_list: a list or steps ("first, then, finally", "3 ways", tips). Each item ticks as it's said.
- graph_rise: a number, growth, savings, results ("save 40%", "doubled our sales").
- interface_world: apps, websites, booking online, software, "click the link".
- phone_frame: texting, calling, social media, DMs, anything on a phone.
- news_wall: news, launches, "just announced", updates, something new.
- dolly_zoom: a realisation or tension beat ("imagine…", "suddenly", "wait").
- punch_through: a turn ("but", "actually", "the truth is", busting a myth, "stop doing this").
- screen_wall: scale and social proof ("thousands of customers", "everyone").
- magazine_cover: the brand, an award, "the best", a feature story, the hook.
- glass_text: one clear statement or price, "simple", "honest", "clear".
- orbit_spin: completeness ("every angle", "the whole process", 360).
- pixel_zoom: hidden details, "look closer", "you'd never notice".
- sketch_boil: plans, ideas, designs, "before we build".
- green_screen: places and areas ("anywhere in the city", "local"), or to lift the speaker out of a messy room.
- pull_out_reveal: the answer or the secret ("here's the thing", "that's why").
- frame_pop: the speaker introducing themselves or the team ("I'm Sam").
- paper_cutout: friendly, crafty or playful lines and the call to action.
