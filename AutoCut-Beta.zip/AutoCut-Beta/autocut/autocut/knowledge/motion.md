# MOTION GRAPHICS IN MARKETING VIDEOS

- Use motion to clarify and emphasise, not decorate: hook titles, key numbers (counters), names (lower thirds),
  steps and lists, before/after, data stories, CTAs and end cards.
- Kinetic typography for hooks and key lines: 3-7 words per beat, one highlighted keyword in the accent colour.
- Motion craft: arrivals fast with a soft landing (ease-out), exits shorter than entrances, stagger elements slightly,
  land titles and hold them still long enough to read (about 0.5 s + 0.3 s per word).
- Keep graphics inside safe zones on 9:16; never cover the speaker's face; match brand colours and fonts.
- A logo sting or end card with one CTA at the end; avoid long animated intros (they cost viewers).
