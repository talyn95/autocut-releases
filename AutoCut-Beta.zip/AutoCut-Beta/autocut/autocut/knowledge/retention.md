# RETENTION: keeping them watching to the end

Structure for short-form (15-60 s): Hook (0-3 s) → Context in one line → The value (steps, story or proof) →
Payoff → One call to action (or a loop back to the start).
- One idea per video. If there are three ideas, make three videos.
- Open loops: promise something later ("the third one surprised me") and pay it off.
- Pace: a visual change every 2-4 s (cut, punch-in, B-roll, graphic, text). Remove ums, pauses and false starts.
- Captions burned in: most people watch muted. Highlight the key word.
- B-roll must show what is being said, not generic stock.
- End on the payoff or a punchline, never a trailing "so yeah, that's it". Loops (the end flows into the start)
  raise rewatches.
- A clip cut from a longer video must stand alone: start at the start of a thought, end at the end of one, no inside
  references.

Long-form (YouTube, podcasts): the first 30 s restate the promise and show what's coming; chapters every few minutes;
re-hooks and pattern interrupts every 30-90 s; deliver the best moment before the midpoint; strong thumbnail + title
pairing; end screen pointing to the next video.

Reading the numbers
- Big drop in the first 3 s = the hook or first frame failed. Drop mid-video = slow section or broken promise.
- Watch time and completion drive organic reach; shares and saves signal real value; comments signal conversation.
