# PROMPTING AND THE LANGUAGE OF THE TRADE

Getting great output from AutoCut (and any AI): give the goal, the audience, the offer, the platform, the tone and
any must-say facts; ask for options ("10 hooks", "3 angles"); then pick and refine.
Good prompt: "10 TikTok hooks for a Dallas roofing company's free inspection offer, for homeowners after hail
season, plain-spoken, no hype, under 8 words each."

Glossary
- A-roll (main talking footage) / B-roll (cutaway footage) · J-cut / L-cut (audio leads/trails the picture) ·
  jump cut · punch-in · pattern interrupt · open loop · hook / re-hook · CTA · safe zone · lower third · end card ·
  kinetic type · UGC (user-generated content) · creator/whitelisted/Spark ads · hook rate · hold rate · ThruPlay ·
  CPM / CPC / CTR / CPL / CPA / ROAS / MER · TOFU/MOFU/BOFU · content pillars · repurposing · swipe file ·
  creative fatigue · retargeting · lead magnet · social proof · risk reversal.
