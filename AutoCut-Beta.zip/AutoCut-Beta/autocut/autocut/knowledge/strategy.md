# CONTENT STRATEGY

Content pillars (3-5 per client): e.g. Educate (how-to, tips, myths), Prove (results, testimonials, case studies),
Behind the scenes (process, team, culture), Promote (offers, launches), Community (local, customers, partners).

Funnel
- Top (discovery): hooks, myths, tips, trends, entertaining or surprising stories; aim for reach and follows.
- Middle (consideration): how it works, comparisons, FAQs, case studies, founder story; aim for trust and saves.
- Bottom (decision): offers, testimonials, guarantees, "what to expect", booking walkthroughs; aim for leads and sales.
- Retarget engaged viewers with middle- and bottom-funnel content.

Repurposing waterfall (one recording, many assets)
- 1 podcast/interview/long video → 8-20 short clips → quote graphics and carousels → YouTube long-form with
  chapters → blog/newsletter summary → paid ad variations from the best-performing organic clips.

Cadence and calendar
- Consistency beats bursts: a realistic weekly rhythm (e.g. 3-5 shorts, 1 carousel, 1 long-form a month).
- Plan by month: pillar mix, key dates (seasons, holidays, local events, launches), one hero piece per month.
- Review monthly: what got watched, saved, shared, and what brought leads; double down on winners.

Local businesses
- Show real faces, real jobs and real places; mention the town/neighbourhood; feature reviews; post on Google
  Business Profile; seasonal problems make great hooks (storms, heat, holidays, back to school).
