# PAID SOCIAL & VIDEO ADS

Structure: Hook (stop the scroll) → Body (problem, proof, how it works) → CTA (one action, low friction).
Make ads that look like content: UGC-style, talking head, street interview, POV, demo, before/after, listicle
("3 reasons why"), us-vs-them, founder story, testimonial, FAQ/objection-busting, green-screen over a review or article.

Angles to test (each a different reason to buy)
- Pain/problem, desire/outcome, objection-busting (price, trust, time), social proof (reviews, numbers, logos),
  comparison, authority/expertise, urgency (real deadlines only), offer-led, curiosity, local pride, guarantee/risk
  reversal, behind-the-scenes/process, founder/mission.

Offers (value = dream outcome × believability ÷ (time delay × effort))
- Make the outcome concrete, raise believability with proof, shorten the time, lower the effort.
- Good local-service offers: free inspection/estimate/audit, limited-slot booking, bonus or bundle, guarantee.
  Lead magnets: checklist, guide, quiz, calculator, mini-training.
- Scarcity and urgency only when true.

Testing and iteration
- Test hooks first (same body, new first 3 s), then angles, then formats. Change one big thing at a time.
- Creative fatigue: rising frequency, falling CTR and rising cost mean refresh the creative, not just the audience.
- Feed the algorithm variety: different people, settings, formats and angles, not near-duplicates.

Metrics (use with judgement; benchmarks vary by industry and platform)
- Hook rate ≈ 3-second views ÷ impressions (is the opening stopping people?).
- Hold rate ≈ ThruPlays (or 15 s views) ÷ 3-second views (is the body keeping them?).
- CTR (link), CPM, CPC; then the business numbers: cost per lead (CPL), lead-to-booking rate, cost per acquisition,
  ROAS and MER (total revenue ÷ total ad spend). Optimise for the business number, diagnose with the funnel numbers.
- Retarget video viewers (e.g. 50%+ viewers) with proof and offer content.
