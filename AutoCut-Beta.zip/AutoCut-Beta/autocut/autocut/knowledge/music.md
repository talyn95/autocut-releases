# MUSIC AND SOUND DESIGN: how an agency scores short-form and ads

## The bed serves the message
- Music sets the emotion in the first second, before a word lands. Choose it for how the viewer should FEEL about
  the brand, not for the topic.
- Under speech the bed sits 14 to 20 dB below the voice (voice around -14 LUFS, bed around -30 LUFS) and keeps
  out of the speech band (1 to 4 kHz): pads, low keys, drums and bass carry it; no busy melodies or vocals under
  talking. Melodic hooks belong in gaps, intros, end cards and B-roll montages.
- Silence is a tool: drop the music for a key line, then bring it back on the payoff.
- Every video ends on the music's final hit, not a fade into nothing. Land the last chord on the end card.

## Genre and tempo by business (starting points, not rules)
- Trust businesses (dental, medical, finance, law, insurance, B2B): corporate uplift or warm acoustic, 90 to 115 BPM,
  major key, steady, never aggressive.
- Food, cafés, bakeries, hospitality: warm acoustic, lo-fi or playful, 85 to 110 BPM.
- Luxury, real estate, weddings, med-spa, jewellery: luxury minimal or cinematic, 65 to 90 BPM, sparse piano and pads.
- Fitness, sports, automotive, supplements: sport/hype or modern hip-hop, 130 to 150 BPM (half-time feel), big drums.
- Tech, SaaS, apps, AI: tech/electronic or upbeat pop, 115 to 128 BPM, sidechained pads, arpeggios.
- Kids, pets, cleaning, e-commerce, creators: playful or upbeat pop, 100 to 120 BPM.
- Film, travel, documentary, premium launches: cinematic, 80 to 95 BPM, builds and swells.
- Creators and agencies with a relaxed voice: lo-fi chill, 75 to 90 BPM.

## Energy by video type
- Hook-first ads and promos: medium-high energy from the first bar, a lift into the offer, a hit on the CTA.
- Testimonials and stories: low energy, emotional, let the person carry it.
- Educational and how-to: medium-low, steady, unobtrusive.
- Launches and events: build (riser) into a reveal, high energy after it.
- Podcasts and long-form: no bed under conversation; music only on intros, outros and transitions.

## Sonic branding
- A brand should sound the same every time: one style, one key, one short motif (3 to 5 notes) used at intros, lifts
  and end cards. Consistency builds recognition the way a logo does.
- Two clients of the same agency should not share a sound.

## Sound design (effects)
- Every effect has a cause on screen: a whoosh on a transition or a fast move, a pop when a badge or sticker lands,
  an impact on a slam or a big number, a riser into a reveal, a soft click on UI, a shimmer on a logo.
- Restraint: about one effect every 3 to 5 seconds in talking-head content; more is a template look. Never put an
  effect on top of a key word.
- Effects sit 3 to 6 dB above the bed and well under the voice. Land them a frame after the picture event.
- Match the brand: clean and airy for premium and trust brands, hard and punchy for sport, digital for tech and
  gaming, soft or paper-textured for human, crafty brands, bubbly for playful brands.

## Rights
- Only use music the agency owns or generated itself. AutoCut's composer writes original music on the computer, so
  it is royalty-free; open models with commercial licences (ACE-Step) can be used too. Never imitate a named artist
  or a recognisable song.

## Spotting a video (the cue sheet)
Plan sound like a trailer editor: decide where the music lifts, where it breathes, and which moments get a sound.
- Energy curve: start where the hook needs it (medium-high for ads, low for stories), lift into the offer or the
  payoff, keep the body steady under talking, land the end card at full energy on the final hit.
- Breaks: drop the drums for the bar before the line that matters most (a price, a result, the offer, the brand
  reveal) so it lands in space; the riser fills that bar and the full beat returns on the line. One or two per
  minute at most.
- Hits and impacts: on the hook word, a big number, the brand name, the end card. A "boom" is for one moment only.
- Risers: end exactly on a reveal; never under a sentence that is still being spoken.
- Whooshes and swishes: on scene changes and things that move across the screen. Pops and clicks: small things
  appearing (icons, stickers, UI). Glitch: tech and digital brands, sparingly, on a transition.
- Leave space: no effect under the middle of a sentence; keep effects at least a second apart; fewer and well
  placed beats more and busy. The voice always wins.
