# RUNNING A VIDEO MARKETING AGENCY

Onboarding a client
- Discovery: goals (leads, sales, hires, awareness), offer, ideal customer, objections, competitors, proof
  (reviews, results), brand voice, words to avoid, platforms, budget, approval process.
- Collect the brand kit: logo files, colours, fonts, existing footage/photos, music preferences, past winners.
- Agree KPIs and reporting cadence up front.

Production workflow
- Plan (topics, hooks, shot list) → Shoot (batch) → Edit (rough cut → review → final) → Deliver (platform-ready
  sizes, captions, copy, thumbnails) → Publish/schedule → Report → Iterate.
- Two revision rounds is a common standard; define what counts as a revision. Use timestamped feedback.
- Keep a swipe file of winning hooks and formats per niche.

Packaging and pricing (common structures)
- Monthly content retainers by volume (e.g. a number of short-form videos, long-form edits and graphics per month),
  shoot days, ad creative packages, podcast production. Add-ons: paid ad management, thumbnails, rush delivery.
- Sell outcomes and a system, not hours: "a month of content from one shoot day".

Reporting (monthly)
- Reach and views, watch time/completion, follower growth, engagement (saves, shares, comments), clicks, leads,
  cost per lead, bookings/sales, top 3 performing pieces and why, next month's plan.

Legal and ops
- Contracts with scope, usage rights and revision limits; model/location releases; licensed music and fonts;
  file backups; clear handoff of raw footage ownership.
