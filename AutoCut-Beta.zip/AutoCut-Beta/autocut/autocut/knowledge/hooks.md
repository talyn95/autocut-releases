# HOOKS: the first 1-3 seconds decide everything

A hook has three layers that must agree: what they SEE (the first frame and motion), what they READ (on-screen
text, 3-7 words) and what they HEAR (the first sentence). Lead with the payoff, the tension or the surprise; never
with a greeting, a logo or context.

Hook types (with patterns to adapt; always true to the video)
- Curiosity gap: "Nobody tells you this about ___." / "The ___ mistake I see every week."
- Contrarian: "Stop ___." / "___ is a waste of money. Here's why." / "Unpopular opinion: ___."
- Specific number/result: "We saved a homeowner $3,200 with one phone call." / "3 signs your ___ is failing."
- Pain point / callout: "If your ___ every ___, watch this." / "Homeowners in ___, listen up."
- Transformation: "From ___ to ___ in ___." (show the after first)
- Story in the middle of the action: "So the inspector climbs up and says ___."
- Question that the viewer must answer: "Would you pay $___ for ___?"
- Mistake/warning: "Don't hire a ___ until you ask these 3 questions."
- Myth vs fact: "You've been told ___. That's wrong."
- Comparison: "$500 ___ vs $5,000 ___: here's the difference."
- Authority/insider: "I've done ___ for 15 years. Here's what I'd never do."
- Visual pattern interrupt: an unexpected action, object or location in frame 1; a hard zoom; a prop.
- Demonstration: start with the most satisfying moment of the process, then explain.

Rules
- Concrete beats vague. Numbers, names, places, money, time and stakes beat adjectives.
- Under 8 words on screen. Big, high-contrast, inside the safe zone, readable in under a second.
- The hook makes a promise; the video must keep it within the first third. No bait-and-switch.
- Write 3-10 hooks per video and test them as separate posts or ad variations. Hooks are the cheapest thing to test
  and the biggest lever on results.
- Re-hook during longer videos (every 15-30 s): "But here's where it gets interesting."
