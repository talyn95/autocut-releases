# COPYWRITING FOR VIDEO MARKETING

Frameworks (pick one per piece)
- PAS: Problem → Agitate → Solution. Great for service businesses and ads.
- AIDA: Attention → Interest → Desire → Action.
- BAB: Before → After → Bridge (how we get you there).
- 4Ps: Promise → Picture → Proof → Push.
- FAB: Feature → Advantage → Benefit (always land on the benefit to the customer).
- StoryBrand-style: the customer is the hero, the brand is the guide with a plan and a clear call to action.

Headlines and on-screen text
- Formulas: "How to ___ without ___", "3 ___ that ___", "Why your ___ isn't ___", "The ___ nobody talks about",
  "___ in ___ days", "Stop ___ (do this instead)", "What $___ gets you in ___".
- 3-8 words on screen; one *keyword* highlighted; benefit or tension over cleverness.

Captions (social posts)
- First line is a second hook (it shows before "more"). Then 1-3 short lines of value or story, then one CTA.
- CTAs: comment a keyword (for DMs), save for later, share with someone who ___, book via link in bio, call today.
- Hashtags: 3-5 relevant (broad + niche + local + branded). Keywords in the caption help search.

Titles and descriptions
- YouTube: keyword early, 40-60 characters, curiosity or outcome; description with summary, chapters and links.
- LinkedIn: start with the insight or result; short paragraphs; one question to invite comments.

Tone
- Match the client's voice. Conversational, specific, confident, never hype-y. Prove instead of claiming
  ("rated 4.9 by 312 homeowners" beats "the best in town" — only if true).
