"""One raw video in → one Premiere-ready rough-cut package out."""
from __future__ import annotations

import copy
import csv
import dataclasses
import json
import re
import shutil
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from . import broll, captions, emphasis, motion, overlays
from .config import Client
from .edit import norm, plan_edit, report
from .effects import Occupancy, resolve
from .effects import cards as fx_cards
from .effects import cutout as fx_cutout
from .effects import media as fx_media
from .effects import overlays as fx_overlays
from .effects import popups as fx_popups
from .effects import story as fx_story
from .media import probe, steady_recording
from .premiere_xml import Timeline
from .transcribe import load_or_transcribe


def sound_events(plan, moments, media_items, placements, graphics, pops, stories, pieces, end_card_at, hook) -> list[dict]:
    """What happens on screen, as events for the sound designer (design.MAP)."""
    ev = []
    for m in moments:
        ev.append({"t": m["start"], "kind": "slam" if m["kind"] == "hook" else "graphic"})
    for m in media_items:
        ev.append({"t": m["start"], "kind": "transition" if m.get("style") == "full" else "graphic"})
    for p in placements:
        ev.append({"t": p["start"], "kind": "transition", "boost": -1.5})
    for s_, _, name in graphics:
        low = str(name).lower()
        ev.append({"t": s_, "kind": "lower_third" if "lower third" in low else "number" if any(ch.isdigit() for ch in low) else "graphic"})
    for p in pops:
        ev.append({"t": p["start"], "kind": "sticker"})
    for mo, _ in stories:
        ev.append({"t": mo["start"], "kind": "transition"})
    for pc in pieces:
        low = pc["name"].lower()
        kind = ("reveal" if low.startswith("hook") else "slam" if low.startswith("slam") else "swipe" if "swipe" in low
                else "number" if any(ch.isdigit() for ch in low) else "end" if "cta" in low or "outro" in low else "graphic")
        t = pc["start"] + (0.35 if kind == "reveal" else 0)
        ev.append({"t": t, "kind": kind})
        if kind == "reveal":
            ev.append({"t": t, "kind": "hit"})
    if end_card_at is not None:
        ev.append({"t": end_card_at, "kind": "end"})
        ev.append({"t": end_card_at + 0.4, "kind": "logo"})
    return ev


def dialogue_gain(video: Path, job: Path, target: float, cache_name: str = "loudness.json") -> float | None:
    """Linear gain that brings the speech to `target` LUFS (social platforms use about -14).
    Measured once per video and cached; Premiere's Audio Levels tops out at +12 dB."""
    cache = job / cache_name
    if cache.exists():
        lufs = json.loads(cache.read_text())["lufs"]
    else:
        r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(video), "-vn",
                            "-af", "ebur128=framelog=quiet", "-f", "null", "-"], capture_output=True, text=True)
        m = re.findall(r"I:\s+(-?[\d.]+) LUFS", r.stderr)
        if not m:
            return None
        lufs = float(m[-1])
        cache.write_text(json.dumps({"lufs": lufs}))
    if lufs < -60:  # silence / no speech: leave it alone
        return None
    gain_db = max(-12.0, min(12.0, target - lufs))
    print(f"  ✓ dialogue {lufs:.1f} LUFS → {target:.0f} LUFS ({gain_db:+.1f} dB)")
    return 10 ** (gain_db / 20)


def punch_zooms(plan, brand: dict) -> list[float]:
    """Per-segment zoom: alternate wide/tight so jump cuts read as deliberate reframes."""
    z = float(brand["punch_ins"]["zoom"])
    if brand["punch_ins"]["pattern"] == "keywords":
        from .edit import norm
        keys = {norm(k) for k in brand["captions"]["highlight_words"]}
        out = []
        for seg in plan.segments:
            a, b = seg.rec_in / plan.fps, seg.rec_out / plan.fps
            hit = any(a <= w["start"] < b and (norm(w["word"]) in keys or any(c.isdigit() for c in w["word"]))
                      for w in plan.words)
            out.append(z if hit else 1.0)
        return out
    return [z if i % 2 else 1.0 for i in range(len(plan.segments))]


def emphasis_punches(plan, brand: dict, zooms: list[float], emph: list[int]) -> list[dict]:
    """Smart punch-ins: on each emphasis word the shot pushes in tighter (a hard punch, like a second camera),
    then cuts back out at the end of the phrase. Each punch stays inside its segment, so it never fights a jump cut.
    Returns [{seg, start, end (timeline frames), zoom}]."""
    cfg = brand["punch_ins"]
    if cfg["pattern"] != "smart" or not emph:
        return []
    fps, z = plan.fps, float(cfg["zoom"])
    lead, hold_max, min_len = round(0.08 * fps), round(float(cfg.get("hold_seconds", 1.6)) * fps), round(0.6 * fps)
    out, last_end = [], -10**9
    for k in sorted(emph):
        w = plan.words[k]
        f = round(w["start"] * fps) - lead
        si = next((i for i, sg in enumerate(plan.segments) if sg.rec_in <= f < sg.rec_out), None)
        if si is None:
            continue
        seg = plan.segments[si]
        start = seg.rec_in if f - seg.rec_in < round(0.5 * fps) else f  # near the cut: the cut itself punches
        if start < last_end + round(1.0 * fps):
            continue
        # out at the end of the phrase (a pause or a sentence end), within the hold limit
        stop = round(w["end"] * fps) + round(0.25 * fps)
        for nw in plan.words[k + 1:]:
            if nw["start"] * fps >= start + hold_max or nw["start"] - w["end"] > 0.35:
                break
            stop = round(nw["end"] * fps) + round(0.15 * fps)
            if re.search(r"[.?!,]$", nw["word"].strip()):
                break
            w = nw
        end = min(seg.rec_out, start + hold_max, max(stop, start + min_len))
        if seg.rec_out - end < round(0.4 * fps):
            end = seg.rec_out  # don't leave a sliver before the next cut
        if end - start < min_len:
            continue
        zoom = round(min(1.32, zooms[si] + (z - 1) * 1.4), 3)
        out.append({"seg": si, "start": start, "end": end, "zoom": zoom, "word": plan.words[k]["word"]})
        last_end = end
    return out


def shots(plan, zooms: list[float], punches: list[dict]) -> list[tuple[int, int, int, float]]:
    """Segments split at the punches: (segment index, timeline in, timeline out, zoom)."""
    out = []
    for si, (seg, zoom) in enumerate(zip(plan.segments, zooms)):
        t = seg.rec_in
        for p in sorted((p for p in punches if p["seg"] == si), key=lambda p: p["start"]):
            if p["start"] > t:
                out.append((si, t, p["start"], zoom))
            out.append((si, p["start"], p["end"], p["zoom"]))
            t = p["end"]
        if t < seg.rec_out:
            out.append((si, t, seg.rec_out, zoom))
    return out


def run_job(video: Path, client: Client, settings: dict, transcript: Path | None = None,
            hook: str = "", preview: bool = False, on_step=None, effects: dict | None = None,
            assets: list[dict] | None = None, edits: dict | None = None, fmt: str | None = None,
            job_name: str | None = None) -> Path:
    """assets: media added for this video — [{file (relative to the client folder), keywords, style}]
    edits:  transcript-editor changes — {remove: [word index], keep: [word index], fixes: {index: text}}
    fmt:    render an extra aspect ratio (square/landscape/…) into its own "<video>-<fmt>" job"""
    t0 = time.time()
    step = on_step or (lambda _s: None)
    video = steady_recording(video.resolve())  # teleprompter recordings: constant frame rate first
    if fmt and fmt != client.brand["format"]:
        client = dataclasses.replace(client, brand={**copy.deepcopy(client.brand), "format": fmt})
    else:
        fmt = None
    brand = client.brand
    fx = resolve(brand, effects)
    info = probe(video)
    if not info.has_video:
        raise SystemExit(f"{video.name} has no video stream")
    fps = float(brand["fps"] or info.fps or 30)
    size = client.size
    job = client.folder / "ready" / (job_name or video.stem + (f"-{fmt}" if fmt else ""))
    job.mkdir(parents=True, exist_ok=True)
    main_transcript = client.folder / "ready" / video.stem / "transcript.json"
    if fmt and main_transcript.exists() and not (job / "transcript.json").exists():
        shutil.copy2(main_transcript, job / "transcript.json")  # same speech, no need to transcribe twice
    fxdir = job / "fx"  # effect renders; rebuilt every run so switched-off effects leave nothing behind
    shutil.rmtree(fxdir, ignore_errors=True)
    fxdir.mkdir()
    print(f"▶ {video.name}  →  {client.brand['client']}  ({brand['format']} {size[0]}x{size[1]} @ {fps:.3f}fps)")
    print("  effects: " + ", ".join(k for k, v in fx.items() if v))
    applied: dict[str, int] = {}
    background = ThreadPoolExecutor(max_workers=3, thread_name_prefix="autocut-render")

    # 1. Transcript + edit decisions
    step("transcribing")
    data = load_or_transcribe(video, job, settings, transcript, brand["vocabulary"])
    edits = edits or {}
    plan = plan_edit(data["words"], info.duration, fps, brand["edit"],
                     force_remove=set(edits.get("remove", [])), force_keep=set(edits.get("keep", [])),
                     fixes=edits.get("fixes"))
    gain = None
    voice = info  # where the dialogue comes from: the camera, or the Studio Sound version of it
    if fx.get("studio_sound") and info.audio_channels:
        step("cleaning up the voice (Studio Sound)")
        from .audio import studio_sound
        try:
            voice = probe(studio_sound(video, job / "studio-sound.wav"))
            applied["studio_sound"] = 1
        except (subprocess.CalledProcessError, OSError) as e:
            print(f"  ! Studio Sound skipped: {e}")
    if voice is info and info.audio_channels >= 2:  # A1 carries the dialogue alone: make it dual-mono
        from .audio import dialogue_mono
        try:
            voice = probe(dialogue_mono(video, job / "dialogue.wav"))
        except (subprocess.CalledProcessError, OSError) as e:
            print(f"  ! dialogue track: {e}")
    if brand["audio"]["normalize"] and info.audio_channels:
        step("measuring loudness")
        gain = dialogue_gain(voice.path, job, float(brand["audio"]["target_lufs"]),
                             "loudness.json" if voice is info else f"loudness-{voice.path.stem}.json")
    (job / "edit_report.txt").write_text(report(plan))
    content_s = plan.seconds
    print(f"  ✓ rough cut {info.duration:.1f}s → {content_s:.1f}s, {len(plan.removed)} words removed")
    # the words a viewer should feel: keyword colour in the captions, punch-ins on them
    emph = emphasis.pick(plan.words, brand, settings) if (fx["captions"] or fx["punch_ins"]) else []
    zooms = punch_zooms(plan, brand) if fx["punch_ins"] else [1.0] * len(plan.segments)
    punches = emphasis_punches(plan, brand, zooms, emph) if fx["punch_ins"] else []
    if fx["punch_ins"]:
        applied["punch_ins"] = sum(1 for z in zooms if z != 1.0) + len(punches)
    occupied = Occupancy()

    # 2. Captions (editable SRT always; kinetic overlay when on)
    step("captions")
    cap_overlay, icon_pops = None, []
    captions.write_srt(plan.words, content_s, brand["captions"], job / "captions.srt")
    if fx["captions"]:
        captions.write_ass(plan.words, content_s, brand, size, job / "captions.ass", emphasis=emph)
        if brand["captions"]["style"] == "icons":  # icon pops above the caption line, on the key words
            lay = captions.layout(brand, size)
            for m in captions.icon_moments(plan.words, emph, brand):
                if m["start"] + 1.1 < content_s and occupied.free(m["start"], m["start"] + 1.1, gap=0.1):
                    occupied.take(m["start"], m["start"] + 1.1, "popup")
                    icon_pops.append({**m, "cx": lay["x"], "cy": lay["y"] - lay["fontsize"] * 2.1, "dur": 1.1,
                                      "size_pct": 15, "side": 0})
        # the longest single render (full-length ProRes): it runs in the background, an ffmpeg
        # process on its own cores, while the graphics below are made
        cap_overlay = background.submit(overlays.render_ass, job / "captions.ass", client, size, fps, content_s,
                                        job / "captions_overlay.mov")
        applied["captions"] = 1
        print(f"  ✓ kinetic captions ({brand['captions']['style']})")

    # 3. The team's own media first (their picks win), then cutout moments, then b-roll fills in
    media_items = []
    if fx["media"]:
        step("placing your media")
        for i, m in enumerate(fx_media.plan_media(plan.words, client, assets or [], content_s, occupied)):
            category = next((c for c, meta in fx_media.CATEGORIES.items()
                             if (client.folder / meta["folder"]) in m["path"].parents), None)
            if m["path"].suffix.lower() in fx_media.VIDEO_EXT:
                m["clip"] = m["path"]
            elif m["style"] == "full":
                m["clip"] = fx_media.render_full(m["path"], size, fps, m["length"], fxdir / f"media_{i}.mov")
            else:
                m["clip"] = fx_media.render_float(m["path"], category, size, fps, m["length"], fxdir / f"media_{i}.mov")
            media_items.append(m)
        applied["media"] = len(media_items)
        if media_items:
            print(f"  ✓ your media: {len(media_items)} placed")

    moments = []
    if fx["subject_cutout"]:
        step("cutting out the speaker")
        try:
            seg = fx_cutout.get_segmenter(brand["cutout"]["engine"])
            for i, m in enumerate(fx_cutout.plan_moments(plan, client, hook, occupied)):
                s0 = m["seg"]
                start_f = round(m["start"] * fps)
                n = round(m["length"] * fps)
                src_in = s0.src_in + (start_f - s0.rec_in)
                m["zoom"] = zooms[plan.segments.index(s0)]
                m["subject"] = fx_cutout.render_subject(info, src_in, n, fps, seg, fxdir / f"subject_{i}.mov")
                m["behind"] = (fx_cutout.render_hook_text(client, m["text"], size, fps, m["length"], fxdir / f"hook_{i}.mov")
                               if m["kind"] == "hook" else
                               fx_cutout.render_pop_panel(client, m["text"], size, fps, m["length"], fxdir / f"panel_{i}.mov"))
                m["frames"] = (start_f, n)
                moments.append(m)
            applied["subject_cutout"] = len(moments)
            # a cut-out moment is rendered at its segment's zoom: no punch-in inside one
            punches[:] = [p for p in punches if all(p["end"] <= m["frames"][0] or p["start"] >= sum(m["frames"])
                                                    for m in moments)]
            if fx["punch_ins"]:
                applied["punch_ins"] = sum(1 for z in zooms if z != 1.0) + len(punches)
            print(f"  ✓ subject cutout: {len(moments)} moments ({seg.name})")
        except RuntimeError as e:
            print(f"  ! subject cutout skipped: {e}")

    # 3b. Story cutaways: storyboards of what's being said (before b-roll, so they get first pick)
    broll_clips = None
    stories = []
    if fx["story"]:
        step("animating story cutaways")
        broll_clips = broll.index_library(client.path(brand["broll"]["folder"]))
        moments_s = fx_story.find_moments(plan.words, client, occupied, content_s, broll_clips)
        for i, mo in enumerate(moments_s):
            speaker = None
            if brand["story"]["speaker_pip"]:
                bw, bh = fx_story.speaker_box(size, len(mo["beats"]))
                speaker = fx_story.speaker_frames(video, plan.segments, fps, mo["start"], mo["end"] - mo["start"],
                                                  bw, bh, fps)
            clip = fx_story.render_moment(mo, client, size, fps, fxdir / f"story_{i}.mov",
                                          int(settings["motion_blur_samples"]), speaker)
            stories.append((mo, clip))
        applied["story"] = len(stories)
        if stories:
            print(f"  ✓ story cutaways: {len(stories)} (" + "; ".join(
                " → ".join(b["word"] for b in mo["beats"]) for mo, _ in stories) + ")")

    # 4. Brand layers + creative effects
    step("graphics & b-roll")
    mark = overlays.watermark(client, size, job / "watermark.png")
    if fx["credit"]:
        mark = overlays.add_credit(mark, size, settings["agency_credit"], job / "watermark.png")
        applied["credit"] = 1
    pro = brand["graphics"]["style"] == "pro"
    samples = int(settings["motion_blur_samples"])
    custom_end = client.path(brand["cta"]["end_card"])
    if (pro and fx["motion_graphics"] and brand["motion"]["cta_outro"] and brand["cta"]["enabled"]
            and not (custom_end and custom_end.exists())):
        step("animating the end card")
        from .mograph import placement as mg
        endcard = mg.cta_outro(client, size, fps, fxdir / "cta_outro.mov", samples) or overlays.end_card(client, size, fps, job)
    else:
        endcard = overlays.end_card(client, size, fps, job)
    placements = []
    if fx["broll"]:
        clips = broll_clips if broll_clips is not None else broll.index_library(client.path(brand["broll"]["folder"]))
        if brand["broll"]["stock"]:
            from . import stock
            if stock.fetch(client, plan.words, settings, stock.library_tags(clips), brand["format"]):
                clips = broll.index_library(client.path(brand["broll"]["folder"]))
        placements = broll.plan_broll(plan.words, clips, brand["broll"], content_s, occupied)
        applied["broll"] = len(placements)
        print(f"  ✓ b-roll: {len(placements)} cutaways from {len(clips)} library clips")

    graphics = []  # (start_seconds, file, name) on the cards track
    lane = Occupancy()  # cards and lower third share one track
    if pro and (fx["lower_third"] or fx["graphic_cards"]):
        step("animating graphics")
        from .mograph import placement as mg
    if fx["lower_third"]:
        lt = (mg.lower_third(client, size, fps, fxdir / "lower_third.mov", samples) if pro
              else fx_cards.render_lower_third(client, size, fps, fxdir / "lower_third.mov"))
        if lt:
            start = float(brand["lower_third"]["start"])
            hook_title_on = (pro and fx["motion_graphics"] and brand["motion"]["hook_title"]
                             and not any(m["kind"] == "hook" for m in moments))
            if hook_title_on:
                start = max(start, 3.3)  # let the opening hook title finish first
            graphics.append((start, lt, "Lower third"))
            lane.take(start, start + probe(lt).duration, "lower third")
            applied["lower_third"] = 1
    if fx["graphic_cards"]:
        dur = 2.6 if pro else float(brand["cards"]["seconds"])
        gap = 60.0 / max(1, brand["cards"]["max_per_minute"])
        last = -1e9
        for i, card in enumerate(fx_cards.find_cards(plan.words, brand)):
            s = card["start"]
            on_cutout = any(m["start"] < s + dur and s < m["start"] + m["length"] for m in moments + media_items)
            if s - last < gap or s + dur > content_s or not lane.free(s, s + dur) or on_cutout:
                continue
            clip = (mg.card(client, card, size, fps, fxdir / f"card_{i}.mov", samples) if pro
                    else fx_cards.render_card(client, card, size, fps, fxdir / f"card_{i}.mov"))
            graphics.append((s, clip, f"Card: {card['value']} {card['label']}".strip()))
            lane.take(s, s + dur, "card")
            last = s
        applied["graphic_cards"] = sum(1 for g in graphics if g[2].startswith("Card"))
    for s, _, name in graphics:
        occupied.take(s, s + 0.01, name)  # keep pop-ups from landing on the exact same beat

    pops = []
    for i, p in enumerate(icon_pops):
        from .effects.iconlib import sticker as icon_sticker
        p["sticker"] = icon_sticker(p["icon"], brand["colors"]["primary"])
        pops.append((p, background.submit(fx_popups.render_popup, p, client, size, fps, fxdir / f"icon_{i}.mov")))
    if fx["popups"]:
        for i, p in enumerate(fx_popups.find_popups(plan.words, client, occupied, content_s)):
            pops.append((p, background.submit(fx_popups.render_popup, p, client, size, fps, fxdir / f"popup_{i}.mov")))
        applied["popups"] = len(pops) - len(icon_pops)

    texture, leaks = None, []
    if fx["overlays"]:
        texture = background.submit(fx_overlays.texture_loop, client, size, fps, fxdir / "texture_loop.mov")
        if brand["overlays"]["light_leaks"]:
            for i, t in enumerate(fx_overlays.leak_moments(plan.segments, fps, brand["overlays"]["leak_every_seconds"])):
                leaks.append((t, background.submit(fx_overlays.leak_clip, client, size, fps, fxdir / f"leak_{i}.mov", i)))
        applied["overlays"] = 1 + len(leaks)

    pieces = []
    if fx["motion_graphics"]:
        pieces = motion.render_pieces(
            client, settings, plan.words, content_s,
            {"CLIENT": brand["client"], "CTA_TEXT": brand["cta"]["text"],
             "CTA_SUBTEXT": brand["cta"]["subtext"], "HOOK": hook}, fxdir)
        if pro:  # the built-in AutoCut Motion pack works around everything placed so far
            step("animating motion graphics")
            from .mograph import placement as mg
            busy = [(m["start"], m["start"] + m["length"]) for m in moments + media_items]
            busy += [(s, s + probe(clip).duration) for s, clip, _ in graphics]
            busy += [(p["start"], p["start"] + float(brand["popups"]["seconds"])) for p, _ in pops]
            pieces += mg.builtin_pieces(plan, client, hook, busy, any(m["kind"] == "hook" for m in moments),
                                        fxdir, size, fps, samples)
        applied["motion_graphics"] = len(pieces) + (1 if endcard and endcard.parent == fxdir else 0)

    # 5. Timeline (first collect the renders that ran in the background)
    step("finishing renders")
    cap_overlay = cap_overlay.result() if cap_overlay else None
    pops = [(p, f.result()) for p, f in pops]
    texture = texture.result() if texture else None
    leaks = [(t, f.result()) for t, f in leaks]
    background.shutdown()
    step("building timeline")
    tl = Timeline(f"{video.stem} — {brand['client']} — AutoCut", fps, size)
    cuts = shots(plan, zooms, punches)
    for si, seg in enumerate(plan.segments):
        length = seg.src_out - seg.src_in
        vs = [tl.add_video("edit", info, a, seg.src_in + (a - seg.rec_in), b - a, zoom=zoom)
              for k, a, b, zoom in cuts if k == si]
        auds = [tl.add_audio(1, voice, seg.rec_in, seg.src_in, length, source_channel=1, level=gain)] if voice.audio_channels else []
        tl.link(vs[0], *auds)
    for p in punches:
        tl.marker(p["start"], "Punch-in", p["word"].strip(",.!?"))
    end = plan.frames
    total_frames = end
    if endcard:
        ec = probe(endcard)
        ec_len = tl.frames(ec.duration)
        v = tl.add_video("edit", ec, end, 0, ec_len, name="End card / CTA")
        auds = [tl.add_audio(2, ec, end, 0, ec_len, source_channel=1)] if ec.audio_channels else []  # its sound: an effect (A2)
        tl.link(v, *auds)
        tl.marker(end, "CTA end card", brand["cta"]["text"])
        total_frames = end + ec_len

    for p in placements:
        c = p["clip"]
        length = tl.frames(p["length"])
        src_in = max(0, tl.frames((c.duration - p["length"]) / 2))  # middle of the shot
        tl.add_video("broll", probe(c.path), tl.frames(p["start"]), src_in, length, name=c.path.name)
        tl.marker(tl.frames(p["start"]), "B-roll", f"{c.path.name} — matched: {p['reason']}")

    if texture:
        tinfo = probe(texture)
        loop = tl.frames(tinfo.duration)
        for f in range(0, end, loop):
            tl.add_video("texture", tinfo, f, 0, min(loop, end - f), name="Grain + vignette")
    for m in media_items:
        minfo = probe(m["clip"])
        start = tl.frames(m["start"])
        length = min(tl.frames(m["length"]), end - start, tl.frames(minfo.duration))
        src_in = max(0, tl.frames((minfo.duration - m["length"]) / 2)) if m["clip"] == m["path"] else 0
        tl.add_video("broll" if m["style"] == "full" else "media", minfo, start, src_in, length,
                     name=f"Your media: {m['path'].name}")
        tl.marker(start, "Your media", f"{m['path'].name} — {m['reason']}")
    for t, clip in leaks:
        linfo = probe(clip)
        start = tl.frames(t)
        tl.add_video("leaks", linfo, start, 0, min(tl.frames(linfo.duration), end - start), name="Light leak")

    for m in moments:
        start, n = m["frames"]
        tl.add_video("behind", probe(m["behind"]), start, 0, n,
                     name="Hook text (behind speaker)" if m["kind"] == "hook" else f"Pop panel: {m['text']}")
        tl.add_video("cutout", probe(m["subject"]), start, 0, n, name="Speaker cutout", zoom=m["zoom"])
        tl.marker(start, "Subject cutout", f"{m['kind']}: {m['text']}")

    prev = None
    for s, clip, name in sorted(graphics, key=lambda g: g[0]):
        ginfo = probe(clip)
        start = tl.frames(s)
        if prev and prev["end"] > start:
            prev["end"], prev["out"] = start, prev["in"] + (start - prev["start"])
        prev = tl.add_video("cards", ginfo, start, 0, tl.frames(ginfo.duration), name=name)
    for p, clip in pops:
        tl.add_video("popups", probe(clip), tl.frames(p["start"]), 0, tl.frames(probe(clip).duration),
                     name=f"{'Icon' if p.get('icon') else 'Pop-up'}: {p['word']}")
    for mo, clip in stories:
        start = tl.frames(mo["start"])
        tl.add_video("story", probe(clip), start, 0, min(tl.frames(mo["end"] - mo["start"]), end - start),
                     name="Story: " + " → ".join(b["word"] for b in mo["beats"]))
        tl.marker(start, "Story cutaway", " → ".join(f"{b['word']} ({b['kind']})" for b in mo["beats"]))
    if cap_overlay:
        tl.add_video("captions", probe(cap_overlay), 0, 0, end, name="Kinetic captions")
    if mark:
        still = probe(mark)
        still.is_still = True
        tl.add_video("logo", still, 0, 0, end, name="Logo watermark")
    prev = None
    for piece in sorted(pieces, key=lambda p: p["start"]):
        pinfo = probe(piece["path"])
        start = tl.frames(piece["start"])
        if prev and prev["end"] > start:  # keep the graphics track overlap-free
            prev["end"], prev["out"] = start, prev["in"] + (start - prev["start"])
        prev = tl.add_video("motion", pinfo, start, 0, tl.frames(piece["duration"]), name=f"Motion: {piece['name']}")
    # Sound: effects on A2, music on A3 (A1 is the dialogue). The sound designer's cue sheet (AI, rules fallback) shapes both.
    cue_sheet = None
    if fx.get("sound_design") or fx["music"]:
        try:
            from .edit import sentences
            from .sound import director as _dir
            lines = [{"t": plan.words[ix[0]]["start"], "text": " ".join(plan.words[i]["word"] for i in ix)}
                     for ix in sentences(plan.words) if ix]
            cue_sheet = _dir.sound_plan(client, settings, total_frames / fps, lines=lines, kind="short",
                                        notes=str(brand.get("sound", {}).get("notes") or ""),
                                        use_ai=(settings.get("sound") or {}).get("ai_plan_brain", True))
            (job / "cue-sheet.json").write_text(json.dumps(cue_sheet, indent=1))
        except Exception as e:  # a bonus layer; never fail the edit over it
            print(f"  ! sound plan skipped: {e}")
    if fx.get("sound_design"):
        step("sound design")
        try:
            events = sound_events(plan, moments, media_items, placements, graphics, [p for p, _ in pops], stories, pieces,
                                  end / fps if endcard else None, hook)
            if cue_sheet:
                events = list(events) + [{"t": c["t"], "kind": c["kind"], "boost": 1} for c in cue_sheet["cues"]]
            from .sound import design as sd, director
            ident = director.identity(client, settings)
            flavour = brand.get("sound", {}).get("flavour") or ident.get("flavour", "clean")
            cues = sd.materialise(sd.plan(events, total_frames / fps, brand.get("sound", {}).get("density", "normal")),
                                  job / "sfx", flavour, ident.get("seed", 1))
            boost = float(brand.get("sound", {}).get("level_db", 0))
            for c in cues:
                tl.add_audio(2, probe(c["file"]), tl.frames(c["start"]), tl.frames(c.get("src_in", 0)), max(1, tl.frames(c["length"])),
                             level=min(3.98, 10 ** ((c["level_db"] + boost) / 20)))
            applied["sound_design"] = len(cues)
            print(f"  ✓ sound design: {len(cues)} effects ({flavour})")
        except Exception as e:  # a bonus layer; never fail the edit over it
            print(f"  ! sound design skipped: {e}")
    msrc = brand["music"].get("source", "auto")
    music = client.path(brand["music"]["file"])
    if fx["music"] and msrc in ("auto", "file") and music and music.exists():
        minfo = probe(music)
        level = 10 ** (brand["music"]["level_db"] / 20)
        tl.add_audio(3, minfo, 0, 0, min(total_frames, tl.frames(minfo.duration)), level=level)
        applied["music"] = 1
    elif fx["music"] and msrc in ("auto", "composed"):
        step("composing the music")
        try:
            from . import sound
            text = " ".join(w["word"] for w in plan.words)[:2000]
            meta = sound.score(client, settings, total_frames / fps + 0.1, job / "music.wav", text, "short",
                               stems_dir=job / "music-stems",
                               override={"style": brand["music"].get("style") or None, "energy": brand["music"].get("energy") or None,
                                         "energy_curve": _dir.energy_curve(cue_sheet) if cue_sheet else None,
                                         "breaks": (cue_sheet or {}).get("breaks") or None})
            minfo = probe(job / "music.wav")
            tl.add_audio(3, minfo, 0, 0, min(total_frames, tl.frames(minfo.duration)),
                         level=10 ** (float(brand["music"].get("ai_level_db", -17)) / 20))
            applied["music"] = 1
            print(f"  ✓ music: {meta.get('style_name', meta['brief']['style'])} ({meta['engine']})")
        except Exception as e:
            print(f"  ! music skipped: {e}")

    xml = tl.write(job / f"{job.name} - AutoCut.xml")
    tl.save(job / "timeline.json")  # lets "Export MP4" rebuild the edit later
    (job / "words.json").write_text(json.dumps(plan.words))  # timeline-timed words: dubbing, re-captioning
    if fx["cover"]:
        step("making the cover")
        try:
            from .effects.cover import make_cover
            hook_text = hook or fx_cutout.auto_hook_text(plan.words, {norm(k) for k in brand["captions"]["highlight_words"]})
            make_cover(client, info, plan, zooms, hook_text, job / "cover.png")
            applied["cover"] = 1
        except Exception as e:  # a cover is a bonus; never fail the rough cut over it
            print(f"  ! cover skipped: {e}")
    if preview:
        step("rendering preview")
        from .preview import render_preview
        render_preview(tl, job / f"{job.name} - preview.mp4")
        print("  ✓ preview MP4")

    with (job / "broll_plan.csv").open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["timeline_seconds", "clip", "length", "matched_words"])
        for p in placements:
            w.writerow([f"{p['start']:.2f}", p["clip"].path.name, f"{p['length']:.2f}", p["reason"]])
    copy_engine = None
    if (settings.get("ai") or {}).get("post_copy", True):
        step("writing post copy")
        from . import marketing
        try:
            pack = marketing.post_copy(plan.words, brand, settings, "short", hook)
            marketing.write_copy(job, pack, plan.words, "short", hook)
            copy_engine = pack.get("engine")
            print(f"  ✓ post copy ({copy_engine})")
        except Exception as e:  # never fail a cut over the copy
            print(f"  ! post copy skipped: {e}")
    (job / "job.json").write_text(json.dumps({
        "copy": copy_engine,
        "source": str(video), "client": brand["client"], "fps": fps, "size": size,
        "source_seconds": info.duration, "cut_seconds": content_s,
        "fillers_removed": len(plan.removed), "broll": len(placements),
        "effects_on": fx, "effects_applied": applied, "hook": hook,
        "motion_pieces": [p["name"] for p in pieces], "xml": xml.name,
        "processing_seconds": round(time.time() - t0, 1)}, indent=2))
    print(f"  ✓ effects: " + ", ".join(f"{k} ×{v}" for k, v in applied.items()))
    print(f"  ✓ Premiere XML: {xml}  ({time.time() - t0:.0f}s)")
    return xml
