"""Pick B-roll from the client's library by matching what's being said.

Phase 1 matching is keyword-based: each clip is tagged by its filename
("roof-shingles-closeup.mp4" → roof, shingles, closeup) plus an optional
tags.csv (filename,tag tag tag). Name clips descriptively and this works well.
Phase 2 swaps in a local vision model (CLIP) to match on what's actually in
the shot, so untagged libraries work too.
"""
from __future__ import annotations

import csv
import json
import re
from dataclasses import dataclass
from pathlib import Path

from .media import probe

STOP = set("""a an and are as at be been but by can could did do does doing for from had has have
having he her here hers him his how i i'm if in into is it it's its just me more most my no not
now of off on once only or other our out over own same she so some such than that that's the their
them then there these they this those through to too under until up very was we were what when where
which while who whom why will with would you your you're yours really like got get gonna going thing
things know yeah okay also want make one two because about lot well actually""".split())


def stem(word: str) -> str:
    """Rough word root so "shingles"/"shingle", "roofing"/"roof", "inspected"/"inspect" match."""
    w = re.sub(r"[^a-z0-9]", "", word.lower())
    if len(w) > 4 and w.endswith("ies"):
        w = w[:-3] + "y"
    elif len(w) > 4 and w.endswith(("ses", "xes", "zes", "ches", "shes")):
        w = w[:-2]
    elif len(w) > 3 and w.endswith("s") and not w.endswith("ss"):
        w = w[:-1]
    for suf in ("ing", "er", "ed"):
        if len(w) > len(suf) + 2 and w.endswith(suf):
            return w[: -len(suf)]
    return w


def content_words(text: str) -> set[str]:
    return {stem(w) for w in re.findall(r"[A-Za-z0-9']+", text)
            if w.lower() not in STOP and len(w) > 2}


@dataclass
class BrollClip:
    path: Path
    tags: set[str]
    duration: float
    width: int
    height: int
    fps: float


def index_library(folder: Path | None) -> list[BrollClip]:
    if not folder or not folder.is_dir():
        return []
    extra: dict[str, str] = {}
    tag_file = folder / "tags.csv"
    if tag_file.exists():
        for row in csv.reader(tag_file.open()):
            if len(row) >= 2:
                extra[row[0].strip()] = " ".join(row[1:])
    tags_json = folder.parent / "tags.json"  # tags typed in the dashboard's media library
    if tags_json.exists():
        try:
            for rel, t in json.loads(tags_json.read_text()).items():
                extra[Path(rel).name] = (extra.get(Path(rel).name, "") + " " + t.replace(",", " ")).strip()
        except json.JSONDecodeError:
            pass
    clips = []
    for p in sorted(folder.rglob("*")):
        if p.suffix.lower() not in (".mp4", ".mov", ".m4v", ".mxf"):
            continue
        try:
            info = probe(p)
        except RuntimeError:
            continue
        words = re.sub(r"[_\-.]+", " ", p.stem) + " " + p.parent.name + " " + extra.get(p.name, "")
        clips.append(BrollClip(p, content_words(words), info.duration, info.width, info.height, info.fps))
    return clips


def plan_broll(words: list[dict], clips: list[BrollClip], cfg: dict, total: float,
               occupied=None) -> list[dict]:
    """Return placements on the output timeline: {clip, start, length, reason}.
    `occupied` (effects.Occupancy) keeps cutaways off moments used by other effects."""
    if not clips:
        return []
    placements, last_end, uses = [], -1e9, {}
    i = 0
    while i < len(words):
        w = words[i]
        if w["start"] < cfg["skip_first_seconds"] or w["start"] - last_end < cfg["every_seconds"]:
            i += 1
            continue
        window = [x for x in words[i:i + 12] if x["start"] - w["start"] < 4]
        said = content_words(" ".join(x["word"] for x in window))
        best, best_score = None, 0.0
        for c in clips:
            hits = said & c.tags
            score = len(hits) - 0.6 * uses.get(c.path, 0)
            if hits and score > best_score:
                best, best_score = c, score
        if best is None:
            i += 1
            continue
        hits = said & best.tags
        # Start the cutaway on the first matching word.
        anchor = next((x for x in window if stem(x["word"]) in hits), w)
        length = min(cfg["clip_seconds"], best.duration, total - anchor["start"] - 0.5)
        if occupied is not None and not occupied.free(anchor["start"], anchor["start"] + length):
            i += 1
            continue
        if length >= 1.0:
            spoken = sorted({x["word"].strip(",.!?").lower() for x in window if stem(x["word"]) in hits})
            placements.append({"clip": best, "start": anchor["start"], "length": length,
                               "reason": ", ".join(spoken)})
            uses[best.path] = uses.get(best.path, 0) + 1
            if occupied is not None:
                occupied.take(anchor["start"], anchor["start"] + length, "broll")
            last_end = anchor["start"] + length
        i += len(window)
    return placements
