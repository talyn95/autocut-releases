"""Studio Sound: one-click voice cleanup (Descript-style), built from ffmpeg's own filters.

The chain, in order: cut rumble below 80 Hz → reduce steady background noise (hiss, fans, hum) while tracking
it as it changes → tame harsh S sounds → pull out a little "boxy" 250 Hz mud → add presence around 3.5 kHz and a
touch of air → even out the level with a gentle compressor → a limiter so nothing clips. The result is a separate
WAV that the timeline uses instead of the camera's audio, so Premiere, the preview and the export all get it.
"""
from __future__ import annotations

import subprocess
from pathlib import Path

CHAIN = ("highpass=f=80,"
         "afftdn=nr=12:nf=-30:tn=1,"
         "deesser=i=0.35,"
         "equalizer=f=250:t=q:w=1.2:g=-2,"
         "equalizer=f=3500:t=q:w=1.4:g=2.5,"
         "equalizer=f=10000:t=h:w=0.7:g=1.5,"
         "acompressor=threshold=-21dB:ratio=3:attack=8:release=120:makeup=2,"
         "alimiter=limit=0.95")


def chain(pick: str = "") -> str:
    """The filter chain, optionally after a channel pick (e.g. "pan=mono|c0=c1,")."""
    return pick + CHAIN


def studio_sound(src: Path, out: Path, channel: int | None = None) -> Path:
    """Write the cleaned voice of `src` (a video or an audio file) as a stereo 48 kHz WAV. Cached by file times."""
    if out.exists() and out.stat().st_mtime >= src.stat().st_mtime:
        return out
    pick = f"pan=mono|c0=c{channel - 1}," if channel else "aformat=channel_layouts=mono,"
    tmp = out.with_name(out.stem + ".part.wav")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(src), "-vn", "-af", chain(pick) + ",aformat=channel_layouts=stereo",
                    "-ar", "48000", "-c:a", "pcm_s16le", str(tmp)], check=True)
    tmp.replace(out)
    return out


def dialogue_mono(src: Path, out: Path) -> Path:
    """The dialogue as dual-mono (both channels the same), so it sits on one timeline track (A1). Cached."""
    if out.exists() and out.stat().st_mtime >= src.stat().st_mtime:
        return out
    tmp = out.with_name(out.stem + ".part.wav")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(src), "-vn", "-af",
                    "aformat=channel_layouts=mono,aformat=channel_layouts=stereo", "-ar", "48000", "-c:a", "pcm_s16le", str(tmp)],
                   check=True)
    tmp.replace(out)
    return out
