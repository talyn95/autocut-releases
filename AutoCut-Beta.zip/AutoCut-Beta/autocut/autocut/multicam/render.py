"""Render a multicam edit to MP4 in a single ffmpeg pass.

Each camera is decoded once, lined up on the programme clock and scaled to the output size;
the cameras are stacked with `overlay=enable=` switched by the shot list, so a two-hour podcast
with a thousand cuts is one linear read of each file (no per-cut seeking). Removed ums/pauses
are dropped at the end with select/aselect. On a Mac, decoding and encoding run on the media
engine (VideoToolbox).
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from ..media import video_encoder


def _between(spans: list[tuple[float, float]]) -> str:
    return "+".join(f"between(t,{s:.3f},{e - 0.0005:.3f})" for s, e in spans) or "0"


def render(recipe: dict, out: Path, height: int | None = None, final: bool = False) -> Path:
    a, L, fps = recipe["range"][0], recipe["length"], recipe["fps"]
    W, H = recipe["size"]
    if height and height < H:
        W, H = int(W * height / H) // 2 * 2, height
    files = recipe["files"]
    shots = [(s, e, cam) for s, e, cam in recipe["shots"]]
    pip = [(s, e, scr) for s, e, scr in recipe.get("pip", [])]
    keep = [(s, e) for s, e in recipe["keep"]]

    inputs: list[str] = []
    index: dict[str, int] = {}

    def add_input(name: str, video: bool) -> int:
        if name in index:
            return index[name]
        f = files[name]
        seek = a - f["offset"]  # file time at the programme start
        if video and sys.platform == "darwin":
            inputs.extend(["-hwaccel", "videotoolbox"])
        elif video and sys.platform == "win32":
            inputs.extend(["-hwaccel", "auto"])  # the PC's GPU decodes if it can, else the CPU does
        if seek > 0:
            inputs.extend(["-ss", f"{seek:.3f}"])
        inputs.extend(["-i", f["path"]])
        index[name] = len(index)
        return index[name]

    def lead(name: str) -> float:  # seconds of black/silence before this file starts
        return max(0.0, files[name]["offset"] - a)

    chains: list[str] = []
    cams = sorted({c for _, _, c in shots}, key=lambda c: -sum(e - s for s, e, x in shots if x == c))
    pip_cams = {c for s, e, c in shots if any(min(e, pe) > max(s, ps) for ps, pe, _ in pip)}
    for c in cams:
        i = add_input(c, True)
        pad = f",tpad=start_duration={lead(c):.3f}:color=black" if lead(c) > 0 else ""
        outs = "[v_" + str(i) + "]" + ("[q_" + str(i) + "]" if c in pip_cams else "")
        chains.append(f"[{i}:v]setpts=PTS-STARTPTS{pad},fps={fps},scale={W}:{H}:force_original_aspect_ratio=increase,"
                      f"crop={W}:{H},setsar=1" + (f",split=2{outs}" if c in pip_cams else f"[v_{i}]"))
    # a black programme-length base, so a camera that stops early can't end the video
    chains.append(f"color=c=black:s={W}x{H}:r={fps}:d={L:.3f}[bg]")
    base = "bg"
    for k, c in enumerate(cams):
        spans = [(s, e) for s, e, x in shots if x == c]
        expr = "1" if len(cams) == 1 else _between(spans)
        chains.append(f"[{base}][v_{index[c]}]overlay=eof_action=pass:enable='{expr}'[b{k}]")
        base = f"b{k}"
    # picture-in-picture: the screen full-frame, the current speaker small in the corner
    zoom = recipe.get("pip_zoom", 0.34)
    cx, cy = recipe.get("pip_corner", (0.30, 0.28))
    pw, ph = int(W * zoom) // 2 * 2, int(H * zoom) // 2 * 2
    px, py = int((W - pw) / 2 + cx * W), int((H - ph) / 2 + cy * H)
    border = max(2, W // 320)
    for k, scr in enumerate(sorted({s for _, _, s in pip})):
        i = add_input(scr, True)
        pad = f",tpad=start_duration={lead(scr):.3f}:color=black" if lead(scr) > 0 else ""
        chains.append(f"[{i}:v]setpts=PTS-STARTPTS{pad},fps={fps},scale={W}:{H}:force_original_aspect_ratio=decrease,"
                      f"pad={W}:{H}:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1[s{k}]")
        spans = [(s, e) for s, e, x in pip if x == scr]
        chains.append(f"[{base}][s{k}]overlay=eof_action=pass:enable='{_between(spans)}'[sb{k}]")
        base = f"sb{k}"
    all_pip = [(s, e) for s, e, _ in pip]
    for k, c in enumerate(sorted(pip_cams)):
        i = index[c]
        spans = []
        for s, e, x in shots:
            if x != c:
                continue
            for ps, pe in all_pip:
                if min(e, pe) > max(s, ps):
                    spans.append((max(s, ps), min(e, pe)))
        chains.append(f"[q_{i}]scale={pw - 2 * border}:{ph - 2 * border},pad={pw}:{ph}:{border}:{border}:color=white[qs{k}]")
        chains.append(f"[{base}][qs{k}]overlay={px}:{py}:eof_action=pass:enable='{_between(spans)}'[pb{k}]")
        base = f"pb{k}"
    cut = len(keep) > 1 or (keep and (keep[0][0] > 0.01 or keep[0][1] < L - 0.01))
    vsel = f",select='{_between(keep)}',setpts=N/FRAME_RATE/TB" if cut else ""
    chains.append(f"[{base}]trim=duration={L:.3f}{vsel},format=yuv420p[vout]")

    # audio: every mic, at its gain, lined up
    mics = []
    for p in recipe["people"]:
        i = add_input(p["file"], False)
        ch = p.get("channel")
        pick = f"pan=mono|c0=c{int(ch)}" if ch is not None else "aformat=channel_layouts=mono"
        delay = f",adelay={int(lead(p['file']) * 1000)}:all=1" if lead(p["file"]) > 0 else ""
        if recipe.get("studio_sound"):
            from ..audio import CHAIN
            pick += "," + CHAIN
        chains.append(f"[{i}:a]asetpts=PTS-STARTPTS,{pick},aresample=48000{delay},volume={p.get('gain') or 1:.4f}[m{len(mics)}]")
        mics.append(f"[m{len(mics)}]")
    asel = f",aselect='{_between(keep)}',asetpts=N/SR/TB" if cut else ""
    chains.append(f"{''.join(mics)}amix=inputs={len(mics)}:normalize=0:duration=longest,atrim=duration={L:.3f}"
                  f"{asel},alimiter=limit=0.95,aformat=channel_layouts=stereo[aout]")

    script = out.with_suffix(".filter.txt")
    script.write_text(";\n".join(chains))
    cmd = ["ffmpeg", "-y", "-loglevel", "error", *inputs, "-filter_complex_script", str(script),
           "-map", "[vout]", "-map", "[aout]", *video_encoder("final" if final else "preview"),
           "-movflags", "+faststart", "-c:a", "aac", "-b:a", "192k" if final else "160k", str(out)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    script.unlink(missing_ok=True)
    if r.returncode != 0:
        raise RuntimeError(f"multicam render failed: {r.stderr[-1500:]}")
    return out
