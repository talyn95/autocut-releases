"""Multicam project: sort the files, sync them, pair mics with cameras, pick the shots, write
the Premiere XML and the render recipe.

Timeline clock = the reference camera's clock (offset 0). Every other file has an `offset`:
where it starts on that clock (file time = timeline time - offset).

options.json (all optional, the dashboard writes it):
  cut_fillers   false  remove ums/ahs, stutters and false starts (needs a transcript)
  cut_pauses    false  close long silences (needs a transcript)
  pip           true   show screen recordings full-frame with the speaker in a corner
  wide          true   cut to the wide camera when nobody / everybody is talking
  min_shot      2.0    shortest shot, seconds
  max_shot      25     a monologue longer than this gets a short cutaway (wide or listener)
  format        landscape | vertical | square | portrait
  roles         {file name: camera | wide | screen | audio | ignore}
  speakers      [{name, file, channel, camera}]   (channel: 0-based, or null = whole file)
  clips         false  also send the finished podcast to the Clips tab
  post_copy     true   transcribe and write the YouTube title, description, chapters and social posts
"""
from __future__ import annotations

import json
import re
import subprocess
import time
from pathlib import Path

import numpy as np

from .. import speakers as spk
from ..media import MediaInfo, probe
from . import sync

VIDEO_EXT = {".mp4", ".mov", ".m4v", ".mkv", ".mxf", ".avi", ".mts"}
AUDIO_EXT = {".wav", ".mp3", ".m4a", ".aif", ".aiff", ".flac", ".aac", ".caf"}
ROLES = {"camera": "Camera (one person)", "wide": "Wide camera (everyone)", "screen": "Screen / clips / articles",
         "audio": "Audio only (mic / recorder)", "ignore": "Don't use"}
SCREEN_WORDS = re.compile(r"screen|display|capture|share|desktop|obs|slides|browser|zoom|riverside|b-?roll", re.I)
WIDE_WORDS = re.compile(r"wide|master|2-?shot|two-?shot|group", re.I)
PIP_CUES = re.compile(r"\b(look at this|check (this|it) out|pull (it|this|that) up|put (it|this) on (the )?screen|"
                      r"on (the|my|your) screen|this article|this clip|this video|this tweet|this post|watch this|"
                      r"let me show you|as you can see|here it is|right here)\b", re.I)

WIDE_FREQUENCY = {"less": (6.0, 0.65), "normal": (4.0, 0.55), "more": (2.5, 0.45)}
DEFAULTS = {"cut_fillers": False, "cut_pauses": False, "pip": True, "wide": True, "studio_sound": True, "wide_frequency": "normal", "min_shot": 2.0,
            "max_shot": 25.0, "format": "landscape", "clips": False, "post_copy": True}


def read_json(path: Path, default=None):
    try:
        return json.loads(path.read_text()) if path.exists() else default
    except json.JSONDecodeError:
        return default


def options(folder: Path) -> dict:
    return {**DEFAULTS, **(read_json(folder / "options.json", {}) or {})}


def media_files(folder: Path) -> list[Path]:
    return [p for p in sorted(folder.iterdir()) if p.is_file() and not p.name.startswith(".")
            and p.suffix.lower() in VIDEO_EXT | AUDIO_EXT]


def guess_role(info: MediaInfo) -> str:
    if not info.has_video or info.is_still:
        return "audio"
    if SCREEN_WORDS.search(info.path.stem):
        return "screen"
    if WIDE_WORDS.search(info.path.stem):
        return "wide"
    return "camera"


def inventory(folder: Path, roles: dict | None = None) -> list[dict]:
    out = []
    for p in media_files(folder):
        try:
            info = probe(p)
        except RuntimeError:
            continue
        role = (roles or {}).get(p.name) or guess_role(info)
        out.append({"name": p.name, "path": str(p), "role": role, "duration": round(info.duration, 2),
                    "video": info.has_video and not info.is_still, "width": info.width, "height": info.height,
                    "fps": round(info.fps, 3), "channels": info.audio_channels})
    return out


def frame_motion(source: Path, start: float, dur: float, region=(0.2, 0.05, 0.8, 0.7), fps: float = 5.0) -> np.ndarray:
    """Movement in the middle/upper part of the picture every speakers.HOP seconds (0..1).
    On a one-person camera this rises when that person talks."""
    w, h = 160, 90
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-ss", f"{max(0.0, start):.3f}", "-i", str(source),
                        "-t", f"{dur:.3f}", "-an", "-vf", f"fps={fps},scale={w}:{h},format=gray", "-f", "rawvideo", "-"],
                       capture_output=True)
    frames = np.frombuffer(r.stdout, dtype=np.uint8)
    n = len(frames) // (w * h)
    T = int(dur / spk.HOP)
    if n < 3:
        return np.zeros(T)
    f = frames[: n * w * h].reshape(n, h, w).astype(np.int16)
    x0, y0, x1, y1 = int(region[0] * w), int(region[1] * h), int(region[2] * w), int(region[3] * h)
    d = np.abs(np.diff(f[:, y0:y1, x0:x1], axis=0)).mean(axis=(1, 2))
    d = np.interp(np.arange(T) * spk.HOP, np.arange(len(d)) / fps, d)
    lo, hi = np.percentile(d, 15), np.percentile(d, 92)
    return np.clip((d - lo) / max(1e-3, hi - lo), 0, 1)


def _corr(a: np.ndarray, b: np.ndarray) -> float:
    n = min(len(a), len(b))
    if n < 20 or a[:n].std() < 1e-6 or b[:n].std() < 1e-6:
        return 0.0
    return float(np.corrcoef(a[:n], b[:n])[0, 1])


# ---- 1. analyse: sync + suggest who is who ----------------------------------------------
def analyze(folder: Path, settings: dict, on_step=None) -> dict:
    step = on_step or (lambda _s: None)
    opts = options(folder)
    step("reading the files")
    files = inventory(folder, opts.get("roles"))
    used = [f for f in files if f["role"] != "ignore"]
    cams = [f for f in used if f["role"] in ("camera", "wide")]
    if not cams:
        raise ValueError("No camera files found. Drop the camera videos (and any audio recordings) together.")
    ref = max(cams, key=lambda f: f["duration"])

    step("syncing the audio")
    ref_env = sync.envelope(Path(ref["path"]))
    manual = opts.get("offsets") or {}
    for f in used:
        if f["name"] in manual:  # set by hand in the dashboard (e.g. a screen recording with no sound)
            f["offset"], f["sync"] = float(manual[f["name"]]), 99.0
        elif f is ref:
            f["offset"], f["sync"] = 0.0, 99.0
        elif not f["channels"]:
            f["offset"], f["sync"] = 0.0, 0.0
        else:
            off, conf = sync.find_offset(ref_env, sync.envelope(Path(f["path"])))
            f["offset"], f["sync"] = float(off), float(conf)
        print(f"  ✓ {f['name']}: starts at {f['offset']:+.2f}s (sync confidence {f['sync']})")

    # program range: where the main audio exists (every mic if there are recorders)
    mic_files = [f for f in used if f["role"] == "audio" and f["channels"]] or [f for f in cams if f["channels"]]
    a = max([f["offset"] for f in mic_files] + [min(c["offset"] for c in cams)])
    b = min([f["offset"] + f["duration"] for f in mic_files] + [max(c["offset"] + c["duration"] for c in cams)])
    if b - a < 5:
        a, b = ref["offset"], ref["offset"] + ref["duration"]

    step("finding the speakers")
    mics = suggest_mics(used)
    singles = [c for c in cams if c["role"] == "camera"]
    # sample a stretch where everyone is talking to see which camera shows which mic's person
    win_start = a + min(120.0, (b - a) * 0.1)
    win = min(480.0, b - win_start)
    mic_act = [spk.normalize(spk.audio_energy(Path(m["path"]), None if m["channel"] is None else [m["channel"]],
                                              win_start, win, m["offset"]).max(axis=0, keepdims=True))[0]
               for m in mics]
    cam_act = [frame_motion(Path(c["path"]), win_start - c["offset"], win) for c in singles]
    taken: set[str] = set()
    pairs = sorted(((_corr(ma, ca), i, c["name"]) for i, ma in enumerate(mic_act)
                    for ca, c in zip(cam_act, singles)), reverse=True)
    for score, i, cname in pairs:
        if mics[i].get("camera") is None and cname not in taken and score > 0.02:
            mics[i]["camera"], mics[i]["match"] = cname, round(score, 2)
            taken.add(cname)
    left = [c["name"] for c in singles if c["name"] not in taken]
    for m in mics:  # unmatched mics take the remaining cameras in order
        if m.get("camera") is None and left:
            m["camera"] = left.pop(0)
    wide = next((c["name"] for c in cams if c["role"] == "wide"), None)
    if not wide and left:
        wide = left[0]  # a spare camera nobody's mic matched is probably the wide
    for m in mics:  # more voices than one-person cameras: the extra people are seen on the wide
        if m.get("camera") is None:
            m["camera"] = wide or (singles[0]["name"] if singles else cams[0]["name"])
    if len(mics) == 1 and len(singles) > 1:
        # one mixed track for everyone: tell people apart by which camera moves (each camera = one person)
        mics = [{"name": f"Speaker {i + 1}", "file": c["name"], "path": c["path"], "channel": None,
                 "offset": c["offset"], "camera": c["name"], "source": "picture"} for i, c in enumerate(singles)]
    result = {"files": files, "reference": ref["name"], "range": [round(a, 3), round(b, 3)],
              "speakers": mics, "wide": wide, "fps": ref["fps"] or 30.0,
              "size": [ref["width"] or 1920, ref["height"] or 1080], "analysed": time.time()}
    (folder / "analysis.json").write_text(json.dumps(result, indent=1))
    return result


def suggest_mics(files: list[dict]) -> list[dict]:
    """One entry per voice: separate audio files / separate channels first, else camera audio."""
    out = []

    def add(f, ch, label):
        out.append({"name": f"Speaker {len(out) + 1}", "file": f["name"], "path": f["path"], "channel": ch,
                    "offset": f["offset"], "camera": None, "source": "mic", "label": label})

    def split_channels(f) -> bool:
        if f["channels"] >= 2:
            e = spk.audio_energy(Path(f["path"]), None, 0, min(f["duration"], 600))
            if spk.channels_are_separate(e):
                for ch in range(f["channels"]):
                    if e[ch].max() > -60:  # skip dead channels
                        add(f, ch, f"{f['name']} · channel {ch + 1}")
                return True
        return False

    for f in [f for f in files if f["role"] == "audio" and f["channels"]]:
        if not split_channels(f):
            add(f, None, f["name"])
    if out:
        return out
    for f in [f for f in files if f["role"] in ("camera", "wide") and f["channels"]]:
        if split_channels(f):
            return out
    for f in [f for f in files if f["role"] == "camera" and f["channels"]]:
        add(f, None, f"{f['name']} (camera mic)")
    if not out:
        f = next(f for f in files if f["channels"])
        add(f, None, f["name"])
    return out


# ---- 2. edit: shots, PiP, XML -------------------------------------------------------------
def _intervals(mask: np.ndarray, hop: float, min_len: float, join_gap: float) -> list[list[float]]:
    out: list[list[float]] = []
    t = 0
    while t < len(mask):
        if mask[t]:
            s = t
            while t < len(mask) and mask[t]:
                t += 1
            if out and s * hop - out[-1][1] <= join_gap:
                out[-1][1] = t * hop
            else:
                out.append([s * hop, t * hop])
        t += 1
    return [iv for iv in out if iv[1] - iv[0] >= min_len]


def screen_activity(path: Path, start: float, dur: float) -> np.ndarray:
    """1 where a screen recording shows something live (changing, not black), every HOP seconds."""
    w, h, fps = 96, 54, 1.0
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-ss", f"{max(0.0, start):.3f}", "-i", str(path),
                        "-t", f"{dur:.3f}", "-an", "-vf", f"fps={fps},scale={w}:{h},format=gray", "-f", "rawvideo", "-"],
                       capture_output=True)
    fr = np.frombuffer(r.stdout, dtype=np.uint8)
    n = len(fr) // (w * h)
    T = int(dur / spk.HOP)
    if n < 2:
        return np.zeros(T, bool)
    fr = fr[: n * w * h].reshape(n, h, w).astype(np.int16)
    lit = fr.mean(axis=(1, 2)) > 12
    change = np.concatenate([[0], np.abs(np.diff(fr, axis=0)).mean(axis=(1, 2))]) > 1.2
    # "live" = lit, and changed within the last 8 seconds
    recent = np.convolve(change.astype(float), np.ones(8), mode="full")[:n] > 0
    live = lit & recent
    pad = int(-min(0.0, start) / 1.0)  # the screen recording started after the programme
    live = np.concatenate([np.zeros(pad, bool), live])
    idx = (np.arange(T) * spk.HOP / 1.0).astype(int)
    return np.where(idx < len(live), live[np.minimum(idx, len(live) - 1)], False)


def plan(folder: Path, settings: dict, analysis: dict | None = None, on_step=None) -> dict:
    """The edit decisions (all in seconds on the programme clock, which starts at range[0])."""
    step = on_step or (lambda _s: None)
    opts = options(folder)
    an = analysis or read_json(folder / "analysis.json")
    files = {f["name"]: f for f in an["files"]}
    a, b = an["range"]
    L = b - a
    people = opts.get("speakers") or an["speakers"]
    people = [p for p in people if p.get("file") in files]
    for p in people:
        p["offset"] = files[p["file"]].get("offset", 0.0)
        p["path"] = files[p["file"]]["path"]
    cams = {n: f for n, f in files.items() if f["role"] in ("camera", "wide") and f.get("video")}
    wide = opts.get("wide_camera") or an.get("wide")
    if wide not in cams:
        wide = None

    step("listening for who talks when")
    acts = []
    for p in people:
        if p.get("source") == "picture":
            acts.append(frame_motion(Path(p["path"]), a - p["offset"], L))
        else:
            e = spk.audio_energy(Path(p["path"]), None if p.get("channel") is None else [int(p["channel"])],
                                 a, L, p["offset"])
            acts.append(spk.normalize(e.max(axis=0, keepdims=True))[0])
    T = min(len(x) for x in acts) if acts else 0
    act = np.array([x[:T] for x in acts]) if acts else np.zeros((1, 0))
    use_wide = bool(opts.get("wide") and wide)
    # how often the wide shot comes in (AutoPod-style): after this long with nobody clearly talking, and how
    # evenly two voices must overlap before it counts as "everybody talking"
    freq = opts.get("wide_frequency") if opts.get("wide_frequency") in WIDE_FREQUENCY else "normal"
    wide_after, both = WIDE_FREQUENCY[freq]
    cut_list = spk.shots(act, min_shot=float(opts["min_shot"]), wide=len(people) if use_wide else None,
                         wide_after=wide_after, both_threshold=both)
    cams_for = {i: p.get("camera") for i, p in enumerate(people)}
    if use_wide:
        cams_for[len(people)] = wide
    shots = []
    for s, e, who in cut_list:
        cam = cams_for.get(who) if cams_for.get(who) in cams else None
        shots.append([s, e, cam or next(iter(cams))])
    shots = break_monologues(shots, act, float(opts["max_shot"]), wide if use_wide else None,
                             [p.get("camera") for p in people if p.get("camera") in cams])
    shots = cover_gaps(shots, cams, a)

    # transcript (only when something needs it)
    words: list[dict] = []
    wants_copy = opts.get("post_copy") and (settings.get("ai") or {}).get("post_copy", True)
    if opts["cut_fillers"] or opts["cut_pauses"] or wants_copy or (folder / "transcript.json").exists():
        step("transcribing")
        try:
            words = transcript(folder, settings, people, a, L)
        except Exception as e:
            if opts["cut_fillers"] or opts["cut_pauses"]:
                raise  # those need the words
            print(f"  ! transcription failed, so no post copy: {e}")
            words = []
        snap = [{"word": w["word"], "start": w["start"], "end": w["end"]} for w in words]
        shots = [list(x) for x in spk.snap_to_words([tuple(x) for x in shots], snap)]

    keep = [[0.0, L]]
    removed = 0
    if (opts["cut_fillers"] or opts["cut_pauses"]) and words:
        from ..config import DEFAULT_BRAND, load_client
        from ..edit import plan_edit
        cfg = dict(DEFAULT_BRAND["edit"])
        try:
            cfg.update(load_client(str(folder.parent.parent), settings).brand["edit"])
        except SystemExit:
            pass
        cfg.update(remove_fillers=bool(opts["cut_fillers"]), remove_stutters=bool(opts["cut_fillers"]),
                   remove_restarts=bool(opts["cut_fillers"]),
                   max_pause=max(0.5, float(cfg.get("max_pause", 0.3)) * 2) if opts["cut_pauses"] else 1e9,
                   pad=max(0.08, float(cfg.get("pad", 0.08))), head_pad=0.3, tail_pad=0.6)
        ep = plan_edit(words, L, an["fps"], cfg)
        keep = [[sg.src_in / an["fps"], sg.src_out / an["fps"]] for sg in ep.segments]
        removed = len(ep.removed)

    pip = []
    screens = [f for f in files.values() if f["role"] == "screen" and f.get("video")]
    if opts["pip"] and screens:
        step("finding screen shares")
        for f in screens:
            live = screen_activity(Path(f["path"]), a - f["offset"], L)
            for s, e in _intervals(live, spk.HOP, 3.0, 3.0):
                pip.append([round(s, 2), round(e, 2), f["name"]])
    cues = []
    for w_i, w in enumerate(words):  # "look at this…", "let me pull it up" → a marker for the editor
        text = " ".join(x["word"] for x in words[w_i:w_i + 6])
        if PIP_CUES.match(text) and (not cues or w["start"] - cues[-1]["t"] > 10):
            cues.append({"t": round(w["start"], 2), "text": text})
    # words on the finished programme's clock (after any cut pauses / ums), for the post copy
    out_words, offset_before = [], []
    for w in words:
        k = next((i for i, (ks, ke) in enumerate(keep) if ks <= w["start"] < ke), None)
        if k is None:
            continue
        shift = sum(ke - ks for ks, ke in keep[:k]) - keep[k][0]
        out_words.append({**w, "start": round(w["start"] + shift, 3), "end": round(w["end"] + shift, 3)})
    return {"range": [a, b], "length": L, "people": people, "shots": shots, "keep": keep, "pip": pip,
            "cues": cues, "words": len(words), "program_words": out_words, "removed": removed,
            "wide": wide if use_wide else None}


def break_monologues(shots: list, act: np.ndarray, max_shot: float, wide: str | None, cams: list[str]) -> list:
    """Split a shot longer than max_shot with a 2.5 s cutaway (wide, or another person listening)."""
    if max_shot <= 0:
        return shots
    out = []
    for s, e, cam in shots:
        alts = [wide] if wide and wide != cam else [c for c in cams if c != cam]
        if not alts or e - s <= max_shot:
            out.append([s, e, cam])
            continue
        t, k = s, 0
        while e - t > max_shot:
            mid = t + max_shot * 0.6
            out.append([t, mid, cam])
            out.append([mid, mid + 2.5, alts[k % len(alts)]])
            t, k = mid + 2.5, k + 1
        out.append([t, e, cam])
    return out


def cover_gaps(shots: list, cams: dict, a: float) -> list:
    """A camera that wasn't rolling at that moment (started late, battery swap) → use one that was."""
    out = []
    for s, e, cam in shots:
        f = cams[cam]
        ok = f["offset"] <= a + s and a + e <= f["offset"] + f["duration"]
        if not ok:
            alt = next((n for n, g in cams.items() if g["offset"] <= a + s and a + e <= g["offset"] + g["duration"]), None)
            cam = alt or cam
        if out and out[-1][2] == cam:
            out[-1][1] = e
        else:
            out.append([s, e, cam])
    return out


def transcript(folder: Path, settings: dict, people: list[dict], a: float, L: float) -> list[dict]:
    """Words on the programme clock, from a mix of every mic (cached as transcript.json)."""
    cache = folder / "transcript.json"
    if cache.exists():
        data = read_json(cache, {})
        if data.get("range") == [a, L]:
            return data["words"]
    from ..transcribe import transcribe
    mix = folder / ".mix.wav"
    inputs, chains = [], []
    srcs = {}
    for p in people:
        srcs.setdefault((p["path"], p.get("channel")), p)
    for i, ((path, ch), p) in enumerate(srcs.items()):
        seek = a - p["offset"]
        inputs += (["-ss", f"{seek:.3f}"] if seek > 0 else []) + ["-i", path]
        pick = f"pan=mono|c0=c{int(ch)}," if ch is not None else "aformat=channel_layouts=mono,"
        delay = f"adelay={int(-seek * 1000)}:all=1," if seek < 0 else ""
        chains.append(f"[{i}:a]{pick}{delay}aresample=16000[m{i}]")
    graph = ";".join(chains) + ";" + "".join(f"[m{i}]" for i in range(len(srcs))) + \
        f"amix=inputs={len(srcs)}:normalize=0,alimiter=limit=0.9[a]"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", *inputs, "-filter_complex", graph, "-map", "[a]",
                    "-t", f"{L:.3f}", "-ac", "1", "-ar", "16000", str(mix)], check=True)
    data = transcribe(mix, folder, settings, [])
    words = data["words"]
    cache.write_text(json.dumps({"range": [a, L], "words": words}, indent=1))
    mix.unlink(missing_ok=True)
    (folder / "audio16k.wav").unlink(missing_ok=True)
    return words


def mic_gain(path: Path, channel, offset: float, a: float, L: float, target: float = -16.0) -> float:
    """Linear gain that brings this mic's speech to about `target` LUFS (capped ±12 dB)."""
    seek = max(0.0, a - offset)
    pick = f"pan=mono|c0=c{int(channel)}," if channel is not None else ""
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-ss", f"{seek:.3f}", "-i", str(path), "-t",
                        f"{min(L, 900):.3f}", "-vn", "-af", f"{pick}ebur128=framelog=quiet", "-f", "null", "-"],
                       capture_output=True, text=True)
    m = re.findall(r"I:\s+(-?[\d.]+) LUFS", r.stderr)
    if not m or float(m[-1]) < -60:
        return 1.0
    return 10 ** (max(-12.0, min(12.0, target - float(m[-1]))) / 20)


def build(folder: Path, client_dir: Path, settings: dict, on_step=None) -> Path:
    """Analyse if needed, plan, then write ready/<project>-multicam/ with the XML, preview and recipe."""
    from ..config import FORMATS
    from ..jobs import write_status
    from ..premiere_xml import Timeline
    from .render import render
    step = on_step or (lambda _s: None)
    t0 = time.time()
    opts = options(folder)
    an = read_json(folder / "analysis.json")
    if not an or opts.get("reanalyze"):
        an = analyze(folder, settings, on_step)
        if opts.get("reanalyze"):
            opts.pop("reanalyze")
            (folder / "options.json").write_text(json.dumps(opts, indent=2))
    pl = plan(folder, settings, an, on_step)
    a, L = pl["range"][0], pl["length"]
    fps = float(an["fps"]) or 30.0
    fmt = opts.get("format", "landscape")
    W, H = FORMATS.get(fmt, (1920, 1080))
    if fmt == "landscape":
        W, H = an["size"] if an["size"][0] >= an["size"][1] else (1920, 1080)
    job = client_dir / "ready" / f"{folder.name}-multicam"
    job.mkdir(parents=True, exist_ok=True)
    write_status(job, state="processing", step="building the edit", video=str(folder),
                 machine=settings["machine_name"], client=client_dir.name, error=None)

    step("balancing the mics")
    for p in pl["people"]:
        p["gain"] = round(mic_gain(Path(p["path"]), p.get("channel"), p["offset"], a, L), 4)

    infos = {}

    def info(name: str) -> MediaInfo:
        if name not in infos:
            infos[name] = probe(Path(next(f["path"] for f in an["files"] if f["name"] == name)))
        return infos[name]
    offsets = {f["name"]: f.get("offset", 0.0) for f in an["files"]}

    tl = Timeline(f"{folder.name} multicam", fps, (W, H))
    tl.video, tl.audio = [[], [], []], []  # V1 cameras, V2 screen, V3 speaker PiP; one audio track per mic
    fr = tl.frames
    rec = 0
    pip_corner = (0.5 - 0.17 - 0.03, 0.5 - 0.17 - 0.05)  # bottom right, inside the safe area
    for ks, ke in pl["keep"]:
        seg_len = fr(ke) - fr(ks)
        if seg_len <= 0:
            continue
        for s, e, cam in pl["shots"]:
            s2, e2 = max(s, ks), min(e, ke)
            if e2 - s2 <= 1 / fps:
                continue
            at = rec + fr(s2) - fr(ks)
            n = fr(e2) - fr(s2)
            tl.add_video(1, info(cam), at, fr(a + s2 - offsets[cam]), n, name=f"{cam} · shot")
            for ps, pe, scr in pl["pip"]:
                p2s, p2e = max(s2, ps), min(e2, pe)
                if p2e - p2s > 1 / fps:
                    at2 = rec + fr(p2s) - fr(ks)
                    n2 = fr(p2e) - fr(p2s)
                    tl.add_video(2, info(scr), at2, fr(a + p2s - offsets[scr]), n2, name=f"{scr} · screen")
                    tl.add_video(3, info(cam), at2, fr(a + p2s - offsets[cam]), n2, name=f"{cam} · PiP",
                                 zoom=0.34, center=pip_corner)
        for t_i, p in enumerate(pl["people"]):
            ch = p.get("channel")
            inf = info(p["file"])
            tl.add_audio(t_i + 1, inf, rec, fr(a + ks - p["offset"]), seg_len,
                         source_channel=int(ch or 0) + 1, level=p["gain"])
        rec += seg_len
    for c in pl["cues"]:  # markers on the programme timeline (approximate when pieces are cut out)
        t = c["t"]
        before = sum(min(ke, t) - ks for ks, ke in pl["keep"] if ks < t)
        tl.marker(fr(before), "Show it on screen?", c["text"])

    xml = tl.write(job / f"{folder.name} - multicam AutoCut.xml")
    tl.save(job / "timeline.json")
    recipe = {"range": pl["range"], "length": L, "fps": fps, "size": [W, H], "shots": pl["shots"],
              "keep": pl["keep"], "pip": pl["pip"], "pip_corner": pip_corner, "pip_zoom": 0.34,
              "people": [{k: p.get(k) for k in ("name", "file", "path", "channel", "offset", "gain", "camera")}
                         for p in pl["people"]],
              "files": {f["name"]: {"path": f["path"], "offset": f.get("offset", 0.0)} for f in an["files"]},
              "studio_sound": bool(opts.get("studio_sound", True))}
    (job / "multicam.json").write_text(json.dumps(recipe, indent=1))
    if settings.get("preview", True):
        step("rendering the preview")
        render(recipe, job / f"{folder.name} - multicam preview.mp4", height=720)
    out_s = sum(ke - ks for ks, ke in pl["keep"])
    copy_engine = None
    if pl["program_words"] and opts.get("post_copy") and (settings.get("ai") or {}).get("post_copy", True):
        step("writing the YouTube description and posts")
        from .. import marketing
        from ..config import load_client
        try:
            brand = load_client(str(client_dir), settings).brand
            pack = marketing.post_copy(pl["program_words"], brand, settings, "long", folder.name)
            marketing.write_copy(job, pack, pl["program_words"], "long", folder.name)
            copy_engine = pack.get("engine")
        except Exception as e:
            print(f"  ! post copy skipped: {e}")
    switches = sum(1 for i in range(1, len(pl["shots"])) if pl["shots"][i][2] != pl["shots"][i - 1][2])
    (job / "job.json").write_text(json.dumps({
        "kind": "multicam", "copy": copy_engine, "source": str(folder), "fps": fps, "size": [W, H], "source_seconds": L,
        "cut_seconds": out_s, "fillers_removed": pl["removed"], "xml": xml.name,
        "effects_applied": {"camera switches": switches, "picture-in-picture": len(pl["pip"]),
                            "speakers": len(pl["people"])},
        "speakers": [p["name"] for p in pl["people"]], "processing_seconds": round(time.time() - t0, 1)}, indent=2))
    (folder / "result.json").write_text(json.dumps({"job": str(job), "switches": switches, "pip": len(pl["pip"]),
                                                    "cues": pl["cues"], "length": out_s}, indent=1))
    write_status(job, state="done", step="done")
    return job
