"""Multicam tab: a podcast or interview shot on several cameras (plus any audio recorders and
screen recordings) → one finished edit that cuts to whoever is talking.

  sync.py     lines every file up by its audio (cross-correlation of the loudness envelopes)
  project.py  sorts the files (camera / wide / screen / audio), pairs each mic with the camera
              that shows that person, picks the shots, builds the Premiere XML
  render.py   renders the edit to MP4 in one ffmpeg pass (preview and final export)

Project folders live in clients/<slug>/multicam/<name>/ and are claimed by any Mac the
same way as Clips long videos (an atomic rename of `.pending`).
"""
