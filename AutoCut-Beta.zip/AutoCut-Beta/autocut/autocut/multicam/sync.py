"""Line up cameras and recorders by their sound.

Every camera mic hears the same room, so the shape of the loudness over time (who talks, the
laughs, the claps) is the same in every file, only shifted. The shift with the highest
cross-correlation is the offset. 10 ms resolution, which is under a third of a frame at 30 fps.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from ..speakers import audio_energy

RES = 0.01  # seconds per envelope sample


def envelope(path: Path, max_seconds: float | None = None) -> np.ndarray:
    """Onset envelope: where the sound gets louder. Robust to different mic gains and EQ."""
    db = audio_energy(path, None, 0.0, max_seconds, hop=RES)
    if db.shape[1] == 0:
        return np.zeros(0)
    level = db.max(axis=0)  # loudest channel
    level = np.maximum(level, np.percentile(level, 10))  # ignore the noise floor's flicker
    rise = np.diff(level, prepend=level[0])
    rise = np.clip(rise, 0, None)
    # also keep the slow shape (who's talking) at a lower weight
    slow = level - np.convolve(level, np.ones(50) / 50, mode="same")
    env = rise + 0.3 * np.clip(slow, 0, None)
    env = env - env.mean()
    return env / (env.std() + 1e-9)


def find_offset(ref: np.ndarray, other: np.ndarray, max_shift: float | None = None) -> tuple[float, float]:
    """Where `other` starts on `ref`'s clock, in seconds (negative = it started before the
    reference), and a confidence (≥ 6 is a sure match, < 3.5 is a guess)."""
    if len(ref) < 50 or len(other) < 50:
        return 0.0, 0.0
    n = 1 << int(np.ceil(np.log2(len(ref) + len(other))))
    corr = np.fft.irfft(np.fft.rfft(ref, n) * np.conj(np.fft.rfft(other, n)), n)
    # corr[k] = sum ref[t + k] * other[t]; negative lags wrap to the end
    lags = np.concatenate([np.arange(0, len(ref)), np.arange(-len(other) + 1, 0)])
    vals = np.concatenate([corr[:len(ref)], corr[n - len(other) + 1:]])
    if max_shift is not None:
        keep = np.abs(lags) <= int(max_shift / RES)
        lags, vals = lags[keep], vals[keep]
    # normalise by overlap so short overlaps at the edges don't win by luck
    overlap = np.minimum(len(ref) - np.clip(lags, 0, None), len(other) + np.clip(lags, None, 0))
    overlap = np.clip(overlap, 1, None)
    score = vals / np.sqrt(overlap)
    score[overlap < min(len(ref), len(other)) * 0.25] = -np.inf
    i = int(np.argmax(score))
    finite = score[np.isfinite(score)]
    conf = float((score[i] - finite.mean()) / (finite.std() + 1e-9)) if finite.size > 10 else 0.0
    # sub-sample peak
    lag = float(lags[i])
    if 0 < i < len(score) - 1 and np.isfinite(score[i - 1]) and np.isfinite(score[i + 1]):
        a, b, c = score[i - 1], score[i], score[i + 1]
        d = a - 2 * b + c
        if d < 0:
            lag += 0.5 * (a - c) / d
    return round(lag * RES, 3), round(conf, 1)
