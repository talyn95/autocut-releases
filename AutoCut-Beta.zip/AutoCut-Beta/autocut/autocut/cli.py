"""AutoCut command line. (Most people use AutoCut.app; these are for power users and debugging.)

  autocut app [--headless]             start the dashboard + worker (what AutoCut.app runs)
  autocut run VIDEO --client SLUG      rough-cut one video right now
  autocut watch                        process the shared queue without the dashboard
  autocut new-client "Client Name"     start a client folder from the template
  autocut check-client SLUG            onboarding QA: is this brand kit complete?
  autocut style-proof SLUG             render a caption-style sample for client sign-off
  autocut clients                      list clients
  autocut doctor [--download]          check this Mac (and fetch the speech model)
  autocut user add NAME [--admin]      add someone who can sign in (web-hosted AutoCut)
  autocut user password NAME           set a new password
  autocut user list | remove NAME
  autocut mcp                          AutoCut as a connector inside an AI app (docs/AI-ACCOUNTS.md)
  autocut dub <job folder> --lang es   AI dubbing in AutoCut's own voice (translated captions + XML + preview)
  autocut selftest                     quick check that this copy of AutoCut works here (updates run it first)
  autocut update [--check|--rollback]  signed update from the agency's feed (This Mac → Updates does the same)
  autocut pack check|install PATH      check or install a content pack (looks, storyboards, music styles)
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import yaml

from . import checks
from .config import clients_dir, list_clients, load_client, load_settings

MARK = {"ok": "✓", "warn": "!", "fail": "✗"}


def _print_checks(title: str, results: list[dict]) -> int:
    print(title)
    for r in results:
        print(f"  {MARK[r['status']]} {r['msg']}")
    ok = checks.all_ok(results)
    print("READY" if ok else "NOT READY — fix the ✗ items above")
    return 0 if ok else 1


def cmd_app(args, settings):
    if args.headless:
        from .app import serve
        serve(open_browser=False)
    else:
        from .macapp import main as mac_main
        mac_main()


def cmd_open(args, settings):
    """Open the dashboard if AutoCut is already running (exit 1 if it isn't)."""
    import urllib.request
    from .app import open_dashboard
    url = f"http://127.0.0.1:{settings['port']}/"
    try:
        urllib.request.urlopen(url + "api/ping", timeout=1)
    except OSError:
        return 1
    open_dashboard(url)
    return 0


def cmd_run(args, settings):
    from .pipeline import run_job
    client = load_client(args.client, settings)
    run_job(Path(args.video), client, settings,
            Path(args.transcript) if args.transcript else None, args.hook or "",
            args.preview or settings["preview"])


def cmd_watch(args, settings):
    from .jobs import Worker
    settings["process_jobs"] = True
    w = Worker(settings, poll=args.interval)
    print(f"Watching {clients_dir(settings)}/*/incoming as '{settings['machine_name']}'. Ctrl+C to stop.")
    w.start()
    try:
        while w.is_alive():
            time.sleep(1)
    except KeyboardInterrupt:
        w.stop()


def cmd_new_client(args, settings):
    from .app import create_client
    dest = create_client(args.name, settings)
    print(f"Created {dest}\nNext: fill in brand.yaml, add fonts/logo/b-roll, then: autocut check-client {dest.name}")


def cmd_check_client(args, settings):
    c = load_client(args.client, settings)
    return _print_checks(f"Brand kit check — {c.brand['client']} ({c.folder})", checks.check_client(c, settings))


def cmd_style_proof(args, settings):
    from .overlays import style_proof
    c = load_client(args.client, settings)
    work = c.folder / "ready" / "_style-proof"
    work.mkdir(parents=True, exist_ok=True)
    print(f"Style proof: {style_proof(c, work / f'{c.slug}-caption-style.mp4', work)}")


def cmd_doctor(args, settings):
    return _print_checks(f"AutoCut machine check — {settings['machine_name']}",
                         checks.doctor(settings, download=args.download))


def cmd_hyperframes_setup(args, settings):
    from .mograph import hyper
    return 0 if hyper.setup(settings) else 1


def cmd_music_setup(args, settings):
    from .sound import aimusic
    return 0 if aimusic.setup(settings) else 1


def cmd_music(args, settings):
    """Compose a music bed (and its stems) for a client: autocut music CLIENT SECONDS OUT.wav"""
    from pathlib import Path
    from . import sound
    client = load_client(args.client, settings) if args.client != "-" else None
    out = Path(args.out)
    meta = sound.score(client, settings, float(args.seconds), out, args.notes or "", "short",
                       stems_dir=out.with_name(out.stem + "-stems"),
                       override={"style": args.style, "energy": args.energy}, use_ai_brain=bool(args.notes))
    print(f"{out}  ({meta.get('style_name', '')}, {meta['engine']}, {meta.get('bpm', '')} BPM)")
    return 0


def cmd_sfx_pack(args, settings):
    from pathlib import Path
    from .sound import director, sfx
    client = load_client(args.client, settings) if args.client != "-" else None
    ident = director.identity(client, settings)
    files = sfx.pack(Path(args.out), args.flavour or ident.get("flavour", "clean"), ident.get("seed", 1))
    print("\n".join(str(f) for f in files.values()))
    return 0


def cmd_clients(args, settings):
    for d in list_clients(settings):
        name = (yaml.safe_load((d / "brand.yaml").read_text()) or {}).get("client", d.name)
        waiting = len([f for f in (d / "incoming").glob("*") if not f.name.startswith(".")]) \
            if (d / "incoming").exists() else 0
        print(f"  {d.name:30} {name}  ({waiting} waiting)")


def cmd_user(args, settings):
    import getpass
    import os
    from .auth import Auth
    from .config import clients_dir
    auth = Auth(settings, clients_dir(settings).parent)
    if args.action == "list":
        for u in auth.list_users():
            print(f"  {u['name']:30} {u['role']:7} last sign-in: {u['last_login'] or 'never'}")
        return 0
    if not args.name:
        print("Give a user name, e.g. autocut user add jordan@example.com --admin")
        return 1
    if args.action == "remove":
        auth.remove_user(args.name)
        print(f"Removed {args.name}")
        return 0
    pw = os.environ.get("AUTOCUT_NEW_PASSWORD") or getpass.getpass("Password (10+ characters): ")
    try:
        if args.action == "add":
            auth.add_user(args.name, pw, "admin" if args.admin else "editor")
            print(f"Added {args.name} ({'admin' if args.admin else 'editor'})")
        else:
            auth.set_password(args.name, pw)
            print(f"New password set for {args.name}")
    except ValueError as e:
        print(e)
        return 1
    return 0


def cmd_mcp(args, settings):
    from .mcp import serve
    serve()
    return 0


def cmd_voice_setup(args, settings):
    from .sound.voice import setup
    print(f"✓ AutoCut's voice is ready: {setup(settings)}")


def cmd_dub(args, settings):
    from .dub import dub
    text = Path(args.translation).read_text() if args.translation else None
    out = dub(Path(args.job), args.lang, settings, gender=args.voice, translation=text, preview=not args.no_preview)
    print(f"✓ dubbed: {out}  (AI voice: label it as AI-dubbed when you post)")


def cmd_selftest(args, settings):
    from .selftest import main as run
    return run()


def cmd_update(args, settings):
    from . import updates
    if args.rollback:
        r = updates.rollback(settings)
        print(r.get("error") or f"Back on AutoCut {r['version']}. Restart AutoCut to use it.")
        return 0 if r["ok"] else 1
    st = updates.check(settings, force=True)
    print(f"This computer: AutoCut {st['current']} ({st['mode']} updates, channel {st['channel']})")
    if st["error"]:
        print("  ! " + st["error"])
    if st.get("latest"):
        print(f"  Newest on the feed: {st['latest']}" + (" (update available)" if st["available"] else ""))
    if args.check or not st["available"]:
        return 0
    r = updates.install_latest(settings)
    print(r.get("error") or f"AutoCut {r['version']} is installed. Quit and reopen AutoCut to use it.")
    return 0 if r["ok"] else 1


def cmd_pack(args, settings):
    from . import content
    if args.action == "check":
        problems = content.check_pack(Path(args.path))
        print("\n".join(f"  ✗ {p}" for p in problems) or "  ✓ the pack is good")
        return 1 if problems else 0
    if args.action == "list":
        for p in content.summary()["packs"]:
            print(f"  {p['id']} {p['version']} ({p['source']}{'' if p['enabled'] else ', off'}): {p['name']}")
        return 0
    out = content.install_pack(Path(args.path))
    print(f"Installed {out['id']} into {out['path']}")
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(prog="autocut", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("app", help="dashboard + worker")
    a.add_argument("--headless", action="store_true", help="no menu bar / browser (server Macs, testing)")
    sub.add_parser("open", help="open the dashboard of a running AutoCut")
    r = sub.add_parser("run", help="rough-cut one video")
    r.add_argument("video")
    r.add_argument("--client", required=True)
    r.add_argument("--transcript", help="use an existing transcript JSON instead of transcribing")
    r.add_argument("--hook", help="hook/title text for motion-studio templates ({{HOOK}})")
    r.add_argument("--preview", action="store_true", help="also render a quick MP4 preview")
    w = sub.add_parser("watch", help="process the shared queue (no dashboard)")
    w.add_argument("--interval", type=float, default=5)
    n = sub.add_parser("new-client")
    n.add_argument("name")
    for name in ("check-client", "style-proof"):
        s = sub.add_parser(name)
        s.add_argument("client")
    sub.add_parser("clients")
    doc = sub.add_parser("doctor", help="check this Mac's setup")
    doc.add_argument("--download", action="store_true", help="also download + test the speech model")
    sub.add_parser("hyperframes-setup", help="set up the HyperFrames motion graphics engine (needs Node.js 22+)")
    sub.add_parser("music-setup", help="optional: install the ACE-Step AI music model (Apple Silicon or an NVIDIA GPU)")
    mu = sub.add_parser("music", help="compose an original music bed for a client")
    mu.add_argument("client", help="client id, or - for none")
    mu.add_argument("seconds")
    mu.add_argument("out")
    mu.add_argument("--style")
    mu.add_argument("--energy", choices=["low", "medium", "high"])
    mu.add_argument("--notes", help="what the video is about (the AI music director reads it)")
    sx = sub.add_parser("sfx-pack", help="a client's sound effects pack (WAVs)")
    sx.add_argument("client", help="client id, or - for none")
    sx.add_argument("out")
    sx.add_argument("--flavour")
    us = sub.add_parser("user", help="manage who can sign in (web-hosted AutoCut)")
    us.add_argument("action", choices=["add", "password", "list", "remove"])
    us.add_argument("name", nargs="?")
    us.add_argument("--admin", action="store_true")
    sub.add_parser("voice-setup", help="download AutoCut's own voice (voiceover + dubbing), one time")
    db = sub.add_parser("dub", help="AI dubbing: a finished video in another language, in AutoCut's own voice")
    db.add_argument("job", help="the video's folder under ready/")
    db.add_argument("--lang", required=True, help="es, fr, it, pt, hi or en")
    db.add_argument("--voice", choices=["male", "female"], default="male")
    db.add_argument("--translation", help="a text file with your own translation, one line per sentence (no AI needed)")
    db.add_argument("--no-preview", action="store_true")
    sub.add_parser("selftest", help="quick check that this copy of AutoCut works on this computer")
    sub.add_parser("mcp", help="run AutoCut as an MCP connector for an AI app (Claude Desktop, Claude Code, Cursor…)")
    up = sub.add_parser("update", help="install the newest signed update from the agency's feed")
    up.add_argument("--check", action="store_true", help="only say whether there is one")
    up.add_argument("--rollback", action="store_true", help="go back to the version before the last update")
    pk = sub.add_parser("pack", help="content packs: new looks, storyboards, music styles (docs/EXTENDING.md)")
    pk.add_argument("action", choices=["check", "install", "list"])
    pk.add_argument("path", nargs="?", default=".")
    args = p.parse_args(argv)
    settings = load_settings()
    fn = {"app": cmd_app, "open": cmd_open, "run": cmd_run, "watch": cmd_watch, "new-client": cmd_new_client,
          "check-client": cmd_check_client, "style-proof": cmd_style_proof,
          "clients": cmd_clients, "doctor": cmd_doctor, "user": cmd_user,
          "hyperframes-setup": cmd_hyperframes_setup, "music-setup": cmd_music_setup, "music": cmd_music,
          "sfx-pack": cmd_sfx_pack, "selftest": cmd_selftest, "dub": cmd_dub, "voice-setup": cmd_voice_setup, "mcp": cmd_mcp, "update": cmd_update, "pack": cmd_pack}[args.cmd]
    sys.exit(fn(args, settings) or 0)


if __name__ == "__main__":
    main()
