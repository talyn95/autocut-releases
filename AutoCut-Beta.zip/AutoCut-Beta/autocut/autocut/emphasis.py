"""Emphasis words: the few words a viewer should feel. Captions colour them, punch-ins zoom on them.

`pick(words, brand, settings)` returns word indices. Rules first (numbers and money, the client's highlight words,
power words, contrasts, the payoff word of a long sentence), at most about one every `EVERY` seconds; the AI brain
(when on and answering) re-picks from the same transcript, and its picks are checked the same way. No AI: rules only.
"""
from __future__ import annotations

import re

from .edit import norm

EVERY = 2.0  # seconds: about one emphasis word per caption line

POWER = set("""free never always only best worst biggest secret mistake mistakes guaranteed guarantee instantly
fast faster fastest easy easier simple save saves saving double triple half zero every nobody everyone everybody
huge massive crazy insane proven new now today stop important warning danger problem results result money profit
love hate win wins winning lose losing truth wrong right exactly actually literally finally""".split())
CONTRAST = set("but however instead except until unless without".split())
STOP = set("""a an the and or so to of in on at for with is are was were be been it its it's this that these those i
you he she we they me my your our their his her them us do does did have has had will would can could should
just very really like um uh okay yeah well then there here what when where which who how if as by from up out
about into over get got going gonna want wanna""".split())
NUM = re.compile(r"\d|%|\$")
NUM_WORDS = set("hundred thousand million billion percent".split())  # "three thousand dollars" said out loud


def _sentences(words: list[dict]) -> list[list[int]]:
    out, cur = [], []
    for i, w in enumerate(words):
        cur.append(i)
        if re.search(r"[.?!]$", w["word"].strip()):
            out.append(cur)
            cur = []
    if cur:
        out.append(cur)
    return out


def score(words: list[dict], brand: dict) -> dict[int, float]:
    """How much each word deserves emphasis (rules)."""
    cap = (brand or {}).get("captions") or {}
    keys = {norm(k) for k in cap.get("highlight_words") or []}
    out: dict[int, float] = {}
    for sent in _sentences(words):
        for pos, i in enumerate(sent):
            raw, n = words[i]["word"], norm(words[i]["word"])
            if not n or n in STOP:
                continue
            s = 0.0
            if NUM.search(raw) or n in NUM_WORDS:
                s += 3.0
            if n in keys:
                s += 3.0
            if n in POWER:
                s += 2.0
            if pos and norm(words[sent[pos - 1]]["word"]) in CONTRAST:
                s += 1.0  # the word right after "but" carries the turn
            if raw.rstrip().endswith(("!", "?")):
                s += 0.8
            if pos == len(sent) - 1 and len(sent) >= 6:
                s += 0.8  # the payoff at the end of a long sentence
            if len(n) >= 7:
                s += 0.4
            if s:
                out[i] = s
    return out


def thin(words: list[dict], cands: list[int], every: float = EVERY) -> list[int]:
    """Keep the strongest candidates (in the given order of preference) at least `every` seconds apart."""
    kept: list[int] = []
    for i in cands:
        if 0 <= i < len(words) and all(abs(words[i]["start"] - words[j]["start"]) >= every for j in kept):
            kept.append(i)
    return sorted(kept)


def rules(words: list[dict], brand: dict, every: float = EVERY) -> list[int]:
    sc = score(words, brand)
    return thin(words, sorted(sc, key=lambda i: (-sc[i], i)), every)


SCHEMA = {"type": "object", "properties": {"emphasis": {"type": "array", "items": {"type": "integer"}}},
          "required": ["emphasis"]}


def ai(words: list[dict], brand: dict, settings: dict, every: float = EVERY) -> list[int] | None:
    from . import brain
    if len(words) < 4:
        return None
    numbered = " ".join(f"{i}:{w['word'].strip()}" for i, w in enumerate(words[:900]))
    want = max(1, int((words[-1]["end"] - words[0]["start"]) / every))
    system = ("You are a short-form video editor. Pick the words a viewer should feel: the number, the promise, "
              "the twist, the payoff. Never filler or small words. Answer with word numbers only.")
    prompt = (f"Transcript (number:word):\n{numbered}\n\nPick about {want} emphasis words, spread out, "
              f"at most one per sentence unless it's a list. Return JSON {{\"emphasis\": [numbers]}}.")
    try:
        out = brain.ask(settings, system, prompt, schema=SCHEMA, timeout=90)
    except Exception:  # noqa: BLE001 — any AI trouble means rules
        return None
    if not isinstance(out, dict) or not isinstance(out.get("emphasis"), list):
        return None
    picks = [i for i in out["emphasis"] if isinstance(i, int) and 0 <= i < len(words) and norm(words[i]["word"])
             and norm(words[i]["word"]) not in STOP]
    if not picks:
        return None
    sc = score(words, brand)
    # the AI's choices first, then the strongest rule picks fill any long gaps it left
    return thin(words, picks + sorted((i for i in sc if sc[i] >= 3), key=lambda i: -sc[i]), every)


def pick(words: list[dict], brand: dict, settings: dict | None = None, use_ai: bool | None = None,
         every: float = EVERY) -> list[int]:
    mode = ((brand or {}).get("captions") or {}).get("emphasis", "auto")
    if mode == "off" or not words:
        return []
    if use_ai is None:
        use_ai = mode == "auto" and settings is not None
    return (ai(words, brand, settings or {}, every) if use_ai else None) or rules(words, brand, every)
