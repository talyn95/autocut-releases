"""Motion graphics showcase: renders a varied battery through the HyperFrames engine and reports on it.

Five fictional brands (brands/: dentistry, a gym, a restaurant, real estate, SaaS), each in its own colours and
fonts, at four levels of complexity:
  tier 1  the eight brand templates, across 9:16, 1:1, 4:5 and 16:9, positions, speeds and a green-screen variant
  tier 2  custom compositions: SVG line drawing, editorial serif layout (custom/)
  tier 3  custom: data story with live counters, icon chips and a map-pin drop
  tier 4  custom: a 4-scene promo with transitions between scenes
  tier L  the motion library: each brand gets its style DNA (handed out in memory, as AutoCut would), a look sheet of
          every kind of graphic in it (sheet-library.png: one row per brand, so the differences show), and storyboards
  tier T  transcript videos (transcripts/): a timed SRT and a plain script → kinetic typography, each with a custom font
          and a graphic of their own (drawn here), via mograph/script and mograph/customize
The custom files are what the custom-design AI is asked to write (see mograph/hyper.CUSTOM_GUIDE).

    PYTHONPATH=. python tests/showcase/run.py OUT_DIR [--only SUBSTRING]

Writes OUT_DIR/report.md, contact sheets and one reel per aspect ratio. Needs the HyperFrames runtime
(autocut hyperframes-setup, or AUTOCUT_HF_RUNTIME).
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

from PIL import Image

from autocut.config import load_client, load_settings
from autocut.mograph import hyper

HERE = Path(__file__).parent
SIZES = {"vertical": (1080, 1920), "square": (1080, 1080), "portrait": (1080, 1350), "landscape": (1920, 1080)}

TIER1 = [
    ("lumen-dental", "lower_third", "landscape", {"name": "Dr. Priya Nair", "title": "Lead Dentist, Lumen Dental Studio"}, {}),
    ("lumen-dental", "stat_counter", "portrait", {"value": "98%", "label": "would recommend us"}, {}),
    ("lumen-dental", "phrase_card", "square", {"text": "New patients welcome"}, {"position": "upper"}),
    ("ironclad-fitness", "slam", "vertical", {"word": "NO EXCUSES"}, {}),
    ("ironclad-fitness", "kinetic_type", "vertical", {"text": "Six weeks. / *Zero* shortcuts. / Real strength."}, {"speed": 1.3}),
    ("ironclad-fitness", "swipe", "landscape", {}, {}),
    ("saffron-sage", "hook_title", "square", {"text": "Fresh pasta, made *every* morning"}, {}),
    ("saffron-sage", "cta_outro", "portrait", {"text": "Reserve your table tonight", "sub": "saffronandsage.example"}, {}),
    ("harborline-realty", "stat_counter", "landscape", {"value": "$1,250,000", "label": "sold in 9 days"}, {}),
    ("harborline-realty", "lower_third", "vertical", {"name": "Marcus Ellery", "title": "Listing Agent"}, {}),
    ("harborline-realty", "hook_title", "landscape", {"text": "Waterfront living, *redefined*"}, {"background": "#00b140"}),
    ("pixelforge-labs", "phrase_card", "landscape", {"text": "Ship 2x faster"}, {"speed": 1.4}),
    ("pixelforge-labs", "kinetic_type", "landscape", {"text": "Your CI is slow. / Ours *isn't*."}, {}),
    ("pixelforge-labs", "cta_outro", "vertical", {"text": "Start free in *30 seconds*", "sub": "pixelforge.example"}, {}),
]
# still graphics (Graphics tab): brand, design, size, look, fields
STILLS = [
    ("lumen-dental", "quote", "post", "clean", {"quote": "I used to *dread* the dentist. Now my kids ask when we're going back.", "author": "Maria G.", "role": "Mom of three"}),
    ("lumen-dental", "tips", "portrait", "bold", {"title": "3 signs you need a *checkup*", "items": "Sensitive to cold drinks\nBleeding when you floss\nIt has been over 6 months"}),
    ("ironclad-fitness", "stat", "story", "dark", {"number": "+60 lb", "label": "average deadlift gain in *6 weeks*", "context": "Ironclad members, 2026"}),
    ("ironclad-fitness", "offer", "ad", "bold", {"kicker": "JANUARY ONLY", "headline": "Your first week is *free*", "offer": "No contract. No excuses.", "cta": "Claim your week"}),
    ("saffron-sage", "offer", "story", "bold", {"kicker": "THIS WEEKEND", "headline": "Truffle pasta *night*", "offer": "2 plates + wine $49", "cta": "Reserve a table", "fineprint": "Fri-Sun, 5-10pm"}),
    ("saffron-sage", "event", "post", "clean", {"kicker": "WINE DINNER", "title": "Five courses, *five* Tuscan wines", "date": "Thu, Nov 20", "time": "7 PM", "place": "Saffron & Sage", "cta": "Book a seat"}),
    ("harborline-realty", "testimonial", "post", "dark", {"review": "Harborline sold our house in nine days for over asking. Calm, honest and fast.", "name": "The Okafor family", "detail": "Sellers, Cape Halden"}),
    ("harborline-realty", "event", "ad", "clean", {"kicker": "OPEN HOUSE", "title": "14 Seawatch Lane", "date": "Sat, Nov 8", "time": "1-4 PM", "place": "Cape Halden", "cta": "RSVP"}),
    ("pixelforge-labs", "thumbnail", "thumbnail", "dark", {"title": "We cut builds by *82%*", "badge": "NEW"}),
    ("pixelforge-labs", "carousel", "portrait", "dark", {"title": "3 ways to ship *faster*", "items": "Cache everything | Your CI re-downloads the same 2 GB every run.\nSplit the tests | Run them in parallel shards, not one long queue.\nFail fast | Lint and type-check before the slow stuff.", "cta": "Try Pixelforge free"}),
]
TIERS = {"lumen-dental--checklist": 2, "saffron-sage--menu-card": 2, "harborline-realty--listing": 3,
         "pixelforge-labs--bar-chart": 3, "ironclad-fitness--promo": 4}


FONT_CANDIDATES = ["/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf", "/System/Library/Fonts/Supplemental/Georgia Bold.ttf",
                   "C:/Windows/Fonts/georgiab.ttf"]


def graphic(name: str, dest: Path) -> Path:
    """A simple drawn graphic standing in for the user's own (a plate of pasta, a barbell)."""
    from PIL import ImageDraw
    im = Image.new("RGBA", (900, 700), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    if "pasta" in name:
        d.ellipse((90, 60, 810, 640), fill=(245, 240, 230, 255), outline=(200, 190, 175, 255), width=10)
        for k in range(14):
            d.arc((250 + k * 8, 200 + k * 6, 650 - k * 8, 500 - k * 6), 20 * k, 20 * k + 250, fill=(232, 190, 90, 255), width=12)
        for x, y in ((380, 300), (470, 360), (540, 280)):
            d.ellipse((x, y, x + 40, y + 40), fill=(40, 30, 25, 255))
    else:
        d.rounded_rectangle((60, 320, 840, 380), 20, fill=(200, 200, 205, 255))
        for x in (120, 180, 660, 720):
            d.rounded_rectangle((x, 160, x + 50, 540), 18, fill=(30, 30, 34, 255), outline=(230, 60, 40, 255), width=8)
    im.save(dest)
    return dest


def client(slug: str, settings: dict):
    return load_client(str(HERE / "brands" / slug), settings)


def probe(f: Path) -> tuple[float, str]:
    out = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v", "-show_entries", "stream=pix_fmt:format=duration",
                          "-of", "json", str(f)], capture_output=True, text=True).stdout
    d = json.loads(out)
    return float(d["format"]["duration"]), d["streams"][0]["pix_fmt"]


def backdrop(W: int, H: int) -> Image.Image:
    """A neutral, footage-like backdrop for transparent graphics (cool top, warm bottom)."""
    g = Image.linear_gradient("L").resize((W, H))
    return Image.merge("RGB", [g.point(lambda v: 52 + v * 70 // 255), g.point(lambda v: 60 + v * 44 // 255),
                               g.point(lambda v: 74 + v * 12 // 255)])


def frames(mov: Path, dur: float, at: list[float], work: Path) -> list[Image.Image]:
    out = []
    for k in at:
        png = work / f"_{mov.stem}-{k}.png"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{dur * k:.3f}", "-i", str(mov), "-frames:v", "1",
                        "-pix_fmt", "rgba", str(png)], check=True)
        fg = Image.open(png).convert("RGBA")
        bg = backdrop(*fg.size).convert("RGBA")
        bg.alpha_composite(fg)
        out.append(bg.convert("RGB"))
        png.unlink()
    return out


def sheet(rows: list[tuple[str, list[Image.Image]]], out: Path, h: int = 300) -> None:
    pad = 8
    scaled = [(label, [t.resize((int(t.width * h / t.height), h)) for t in tiles]) for label, tiles in rows]
    W = max(sum(t.width for t in tiles) + pad * (len(tiles) - 1) for _, tiles in scaled)
    img = Image.new("RGB", (W, len(scaled) * (h + pad)), (255, 255, 255))
    for r, (_, tiles) in enumerate(scaled):
        x = 0
        for t in tiles:
            img.paste(t, (x, r * (h + pad)))
            x += t.width + pad
    img.save(out)


def reel(movs: list[Path], size: tuple[int, int], out: Path, work: Path) -> None:
    W, H = size
    bgp = work / f"_bg-{W}x{H}.png"
    backdrop(W, H).save(bgp)
    segs = []
    for i, m in enumerate(movs):
        seg = work / f"_seg-{W}x{H}-{i}.mp4"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-loop", "1", "-i", str(bgp), "-i", str(m), "-filter_complex",
                        f"[1]scale={W}:{H}:force_original_aspect_ratio=decrease[g];[0][g]overlay=(W-w)/2:(H-h)/2:shortest=1,format=yuv420p",
                        "-r", "30", "-c:v", "libx264", "-crf", "18", "-preset", "fast", str(seg)], check=True)
        segs.append(seg)
    lst = work / f"_list-{W}x{H}.txt"
    lst.write_text("".join(f"file '{s}'\n" for s in segs))
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy", str(out)], check=True)
    for s in segs:
        s.unlink()
    lst.unlink()
    bgp.unlink()


def main() -> int:
    out = Path(sys.argv[1]).resolve()
    only = sys.argv[sys.argv.index("--only") + 1] if "--only" in sys.argv else ""
    settings = load_settings()
    if not hyper.available(settings):
        print("HyperFrames isn't set up here (autocut hyperframes-setup).")
        return 1
    out.mkdir(parents=True, exist_ok=True)
    gsap = hyper.runtime_dir(settings) / "node_modules" / "gsap" / "dist" / "gsap.min.js"
    results = []

    for slug, tpl, size, params, opts in TIER1:
        name = f"{slug}--{tpl}--{size}"
        if only and only not in name:
            continue
        c = client(slug, settings)
        if tpl == "cta_outro":
            params = dict(params, logo=c.path(c.brand["logo"]["file"]))
        t0 = time.time()
        try:
            mov = hyper.make(tpl, c, SIZES[size], 30, out / "tier1" / f"{name}.mov", settings, **opts, **params)
            results.append({"tier": 1, "name": name, "ok": True, "seconds": round(time.time() - t0, 1), "file": mov})
        except Exception as e:  # keep going: the report shows what failed
            results.append({"tier": 1, "name": name, "ok": False, "seconds": round(time.time() - t0, 1), "error": str(e)[:600]})
        print(f"tier 1  {name:52s} {'ok' if results[-1]['ok'] else 'FAILED'}  {results[-1]['seconds']}s", flush=True)

    for f in sorted((HERE / "custom").glob("*.html")):
        slug, what, size = f.stem.split("--")
        name = f.stem
        if only and only not in name:
            continue
        c = client(slug, settings)
        project = out / "custom" / f"hf-{name}"
        if project.exists():
            shutil.rmtree(project)
        (project / "assets").mkdir(parents=True)
        shutil.copy2(f, project / "index.html")
        shutil.copy2(gsap, project / "assets" / "gsap.min.js")
        logo = c.path(c.brand["logo"]["file"])
        if logo and logo.is_file():
            shutil.copy2(logo, project / "assets" / "logo.png")
        t0 = time.time()
        tier = TIERS.get(f"{slug}--{what}", 2)
        try:
            mov = hyper.render_project(project, out / "custom" / f"{name}.mov", settings, "mov")
            results.append({"tier": tier, "name": name, "ok": True, "seconds": round(time.time() - t0, 1), "file": mov})
        except Exception as e:
            results.append({"tier": tier, "name": name, "ok": False, "seconds": round(time.time() - t0, 1), "error": str(e)[:600]})
        print(f"tier {tier}  {name:52s} {'ok' if results[-1]['ok'] else 'FAILED'}  {results[-1]['seconds']}s", flush=True)

    from autocut.mograph import customize, script
    for f in sorted((HERE / "transcripts").glob("*.*")):
        slug, what, size = f.stem.split("--")
        name = f"{f.stem}--transcript"
        if only and only not in name:
            continue
        t0 = time.time()
        try:
            folder = out / "transcript"
            folder.mkdir(parents=True, exist_ok=True)
            assets = [customize.describe(graphic(what, folder / f"{'pasta' if 'pasta' in what else 'barbell'}.png"))]
            font = next((Path(p) for p in FONT_CANDIDATES if Path(p).exists()), None)
            if font:
                assets.append(customize.describe(font))
            c = customize.apply(client(slug, settings), assets, folder / f"_custom-{slug}")
            mp4 = script.make_video(f, c, SIZES[size], folder / f"{name}.mp4", settings, customize.graphics(assets), use_ai=False)
            results.append({"tier": "T", "name": name.replace("--transcript", ""), "ok": True, "seconds": round(time.time() - t0, 1), "file": mp4})
        except Exception as e:
            results.append({"tier": "T", "name": name, "ok": False, "seconds": round(time.time() - t0, 1), "error": str(e)[:600]})
        print(f"tier T  {name:52s} {'ok' if results[-1]['ok'] else 'FAILED'}  {results[-1]['seconds']}s", flush=True)

    from autocut.mograph.library import build as lb, dna as dna_mod, storyboards
    lib_rows, given = [], []
    STORY = {"pixelforge-labs": ("stat_story", "landscape", "Where signups came from: Search 46, Referrals 28, Social 17, Other 9."),
             "saffron-sage": ("event", "portrait", '"Five courses, five Tuscan wines" "Thu, Nov 20" "7 PM" "Saffron & Sage"'),
             "ironclad-fitness": ("listicle", "vertical", '"3 lifts that *build* real strength" "Deadlift\nSquat\nOverhead press"')}
    for slug in ("lumen-dental", "ironclad-fitness", "saffron-sage", "harborline-realty", "pixelforge-labs"):
        name = f"{slug}--library"
        if only and only not in name:
            continue
        t0 = time.time()
        try:
            c = client(slug, settings)
            d = dna_mod.assign(c, settings, others=list(given))
            given.append(d)
            proj = out / "library" / f"hf-{slug}-sheet"
            shots = lb.sheet_project(lb.samples(c, d), d["look"], c, (1920, 1080), proj, gsap=gsap, hold=2.6)
            png = lb.render_sheet(proj, shots, settings, out / "library" / f"{slug}-sheet.png", cols=9, tile_w=360)
            lib_rows.append((f"{slug} · {d['look']}", Image.open(png).convert("RGB")))
            results.append({"tier": "L", "name": f"{slug}--sheet--{d['look']}", "ok": True, "seconds": round(time.time() - t0, 1), "pngs": [png]})
            if slug in STORY:
                rk, size, brief = STORY[slug]
                t0 = time.time()
                pl = storyboards.plan(rk, brief, c, None, d)
                sp = out / "library" / f"hf-{slug}-{rk}"
                storyboards.build(pl["scenes"], d["look"], c, SIZES[size], sp, d["transition"], gsap=gsap)
                mp4 = hyper.render_project(sp, out / "library" / f"{slug}--{rk}--{size}.mp4", settings, "mp4")
                results.append({"tier": "S", "name": f"{slug}--{rk}--{size}", "ok": True, "seconds": round(time.time() - t0, 1), "file": mp4})
        except Exception as e:
            results.append({"tier": "L", "name": name, "ok": False, "seconds": round(time.time() - t0, 1), "error": str(e)[:600]})
        print(f"tier L  {name:52s} {'ok' if results[-1]['ok'] else 'FAILED'}  {results[-1]['seconds']}s", flush=True)
    if lib_rows:
        W = max(im.width for _, im in lib_rows)
        sheet_img = Image.new("RGB", (W, sum(im.height + 8 for _, im in lib_rows)), (255, 255, 255))
        y = 0
        for _, im in lib_rows:
            sheet_img.paste(im, (0, y))
            y += im.height + 8
        sheet_img.save(out / "sheet-library.png")

    from autocut.design import stills
    for slug, tpl, size, style, fields in STILLS:
        name = f"{slug}--{tpl}--{size}--{style}"
        if only and only not in name:
            continue
        t0 = time.time()
        try:
            proj = out / "graphics" / f"hf-{name}"
            n = stills.build_project(stills.expand(tpl, fields), client(slug, settings), stills.SIZES[size][0], style, proj, gsap)
            pngs = stills.render_project(proj, n, settings)
            files = []
            for k, png in enumerate(pngs):
                dest = out / "graphics" / f"{name}{'-%02d' % (k + 1) if n > 1 else ''}.png"
                png.replace(dest)
                files.append(dest)
            shutil.rmtree(proj / "_frames", ignore_errors=True)
            results.append({"tier": "G", "name": name, "ok": True, "seconds": round(time.time() - t0, 1), "pngs": files})
        except Exception as e:
            results.append({"tier": "G", "name": name, "ok": False, "seconds": round(time.time() - t0, 1), "error": str(e)[:600]})
        print(f"graphics {name:56s} {'ok' if results[-1]['ok'] else 'FAILED'}  {results[-1]['seconds']}s", flush=True)
    stills_ok = [r for r in results if r["ok"] and r["tier"] == "G"]
    if stills_ok:
        rows = [(r["name"], [Image.open(p).convert("RGB") for p in r["pngs"]]) for r in stills_ok]
        sheet(rows, out / "sheet-graphics.png", h=360)

    work = out / "_work"
    work.mkdir(exist_ok=True)
    ok = [r for r in results if r["ok"] and r["tier"] not in ("G", "L")]
    for r in ok:
        r["duration"], r["pix_fmt"] = probe(r["file"])
        r["size"] = r["name"].rsplit("--", 1)[1]
    for tier in (1, 2, 3, 4, "T", "S"):
        at = [0.1, 0.25, 0.4, 0.55, 0.7, 0.95] if tier in ("T", "S") else [0.15, 0.4, 0.65, 0.9]
        rows = [(r["name"], frames(r["file"], r["duration"], at, work)) for r in ok if r["tier"] == tier]
        if rows:
            sheet(rows, out / f"sheet-tier{tier}.png")
    groups = {"9x16": ["vertical"], "16x9": ["landscape"], "1x1-4x5": ["square", "portrait"]}
    canvas = {"9x16": (1080, 1920), "16x9": (1920, 1080), "1x1-4x5": (1080, 1350)}
    for label, sizes in groups.items():
        movs = [r["file"] for r in sorted(ok, key=lambda r: (str(r["tier"]), r["name"])) if r["size"] in sizes and r["tier"] not in ("T", "S")]
        if movs:
            reel(movs, canvas[label], out / f"reel-{label}.mp4", work)
    shutil.rmtree(work)

    done = sum(1 for r in results if r["ok"])
    lines = ["# Motion graphics + graphics showcase", "", f"{done} of {len(results)} rendered.", "",
             "| Tier | Graphic | Result | Length | Render time | Alpha |", "|---|---|---|---|---|---|"]
    for r in results:
        kind = "still" if r["tier"] in ("G", "L") else f"{r.get('duration', 0):.1f}s"
        lines.append(f"| {r['tier']} | {r['name']} | {'ok' if r['ok'] else 'FAILED: ' + r['error'][:120]} | "
                     f"{kind} | {r['seconds']}s | {'yes' if 'yuva' in r.get('pix_fmt', '') else 'n/a' if r['tier'] in ('G', 'L') else 'no'} |")
    (out / "report.md").write_text("\n".join(lines) + "\n")
    print("\n".join(lines))
    return 0 if done == len(results) else 2


if __name__ == "__main__":
    sys.exit(main())
