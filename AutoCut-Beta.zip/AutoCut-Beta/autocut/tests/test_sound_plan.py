import unittest

import numpy as np

from autocut.sound import composer, director


LINES = [{"t": 0.4, "text": "Your roof took a beating this storm."}, {"t": 4.0, "text": "Most hail damage hides for months."},
         {"t": 8.5, "text": "We save homeowners $3,000 on average."}, {"t": 13.0, "text": "Book your free inspection today."}]


class SoundPlanTests(unittest.TestCase):
    def test_rules_plan_spots_numbers_power_words_and_the_offer(self):
        p = director.sound_plan(None, {}, 18.0, lines=LINES, use_ai=False)
        kinds = {(c["kind"], round(c["t"], 1)) for c in p["cues"]}
        self.assertIn(("number", 8.6), kinds)          # $3,000
        self.assertIn(("reveal", 13.0), kinds)         # a riser lands the last line
        self.assertEqual(p["breaks"], [13.0])          # and the drums drop for the bar before it
        self.assertTrue(any(k == "end" for k, _ in kinds))
        self.assertEqual(p["sections"][0]["t"], 0.0)
        self.assertEqual(p["via"], "rules")

    def test_story_starts_light_and_short_videos_get_no_break(self):
        p = director.sound_plan(None, {}, 8.0, lines=LINES[:2], kind="story", use_ai=False)
        self.assertEqual(p["sections"][0]["energy"], 1)
        self.assertEqual(p["breaks"], [])

    def test_ai_answers_are_cleaned(self):
        raw = {"sections": [{"t": 5, "energy": 9}, {"t": -2, "energy": 1}],
               "cues": [{"t": 3, "kind": "boom"}, {"t": 4, "kind": "laser"}, {"t": 99, "kind": "hit"}], "breaks": [1, 10, 50]}
        p = director._clean_plan(raw, 20.0)
        self.assertEqual(p["sections"][0], {"t": 0.0, "energy": 1})
        self.assertEqual(p["sections"][-1]["energy"], 3)
        self.assertEqual([c["kind"] for c in p["cues"]], ["boom"])
        self.assertEqual(p["breaks"], [10.0])
        self.assertIsNone(director._clean_plan({"sections": [], "cues": []}, 20.0))

    def test_composer_follows_the_energy_curve_and_breaks(self):
        b = {"style": "corporate", "seed": 3, "key": "C", "energy_curve": [[0, 1], [6, 3]], "breaks": [10.0]}
        audio, info = composer.compose(b, 16.0)
        e = info["meta"]["energy"]
        bar = 16.0 / len(e) if len(e) else 1
        self.assertEqual(e[0], 1)
        self.assertIn(0, e)                            # the break bar
        self.assertEqual(max(e), 3)
        self.assertTrue(np.isfinite(audio).all())
        self.assertGreater(float(np.abs(audio).max()), 0.01)


if __name__ == "__main__":
    unittest.main()
