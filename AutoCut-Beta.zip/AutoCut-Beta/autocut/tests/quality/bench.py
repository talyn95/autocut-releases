"""AutoCut quality benchmark: a fixed set of requests per area, scored automatically, so the nightly AI training can
show measurable progress (docs/QUALITY.md is the scoreboard).

    PYTHONPATH=. python tests/quality/bench.py designs OUT_DIR

Areas: designs (Graphics tab: Magic Design → still graphics). More areas are added on their training day (editing,
sound, looks, overlays, brain). Every case uses the five fictional showcase brands (tests/showcase/brands), never a
real client or person. The AI brain is switched off so a run is repeatable and free: it scores the rules path that
every computer without AI gets (the AI path starts from the same templates, so fixes carry over).

designs: each request goes through stills.magic_design, then each size × look is laid out exactly as the Graphics tab
does (build_project) and measured in a headless browser, design by design:
  contrast   text vs what's behind it (WCAG: 4.5:1 for normal text, 3:1 for large)
  size       nothing under 2.2% of the short side (fine print 1.8%)
  overlap    text blocks never sit on each other
  edges      text stays inside a 4% margin
  safe zone  stories keep text out of the top 12% and bottom 18% (platform UI)
  hierarchy  the biggest text is at least 1.8× the typical text
  content    a design says something: at least a headline and one more line; fills 30%+ of the frame
Score per design: 10 minus penalties (0 floor). Writes OUT/designs.json, contact sheets, and prints the summary.
"""
from __future__ import annotations

import json
import os
import statistics
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).parent
ROOT = HERE.parent.parent
sys.path.insert(0, str(ROOT))

BRANDS = ROOT / "tests" / "showcase" / "brands"
DESIGN_CASES = [  # brand, the request exactly as someone would type it in Magic Design
    ("lumen-dental", "quote card: 'I used to dread the dentist. Now my kids ask when we're going back.' Maria G."),
    ("lumen-dental", "stat: 98% of patients would recommend us"),
    ("lumen-dental", "tips post: 3 signs you need a checkup"),
    ("ironclad-fitness", "ad: 'Your first week is free' no contract, no excuses"),
    ("ironclad-fitness", "stat: +60 lb average deadlift gain in 6 weeks"),
    ("ironclad-fitness", "event: open house this Saturday 9am, free classes all day"),
    ("saffron-sage", "event: wine dinner Thursday 7pm, five courses five Tuscan wines"),
    ("saffron-sage", "product post for our new truffle pasta $24"),
    ("saffron-sage", "testimonial: 'Best pasta I've had outside Rome' Sarah K."),
    ("harborline-realty", "stat: $1,250,000 sold in 9 days"),
    ("harborline-realty", "open house event Sunday 1-4pm at 22 Bay Street"),
    ("harborline-realty", "offer: free home valuation this month"),
    ("pixelforge-labs", "tips: 5 ways to ship faster"),
    ("pixelforge-labs", "stat: 2x faster builds"),
    ("pixelforge-labs", "youtube thumbnail 'Our CI is 10x faster'"),
]
STYLES = ["bold", "clean", "dark"]

MEASURE_JS = r"""
(n) => {
  const ds = [...document.querySelectorAll('.d')];
  ds.forEach((d, i) => { d.style.opacity = i === n ? 1 : 0; d.style.visibility = i === n ? 'visible' : 'hidden'; });
  const d = ds[n], W = innerWidth, H = innerHeight, out = [];
  const ground = getComputedStyle(document.documentElement).getPropertyValue('--ground').trim();
  const walk = document.createTreeWalker(d, NodeFilter.SHOW_TEXT);
  const seen = new Map();
  while (walk.nextNode()) {
    const t = walk.currentNode, s = t.textContent.trim();
    if (!s) continue;
    const el = t.parentElement;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || parseFloat(cs.opacity) === 0) continue;
    const r = document.createRange(); r.selectNodeContents(t);
    const b = r.getBoundingClientRect();
    if (b.width < 1 || b.height < 1) continue;
    // what's behind it: the nearest ancestor with a solid background, else the design's ground colour
    let bg = null, a = el;
    while (a && a !== d) { const c = getComputedStyle(a).backgroundColor; if (c && !/rgba\(.*, ?0\)$/.test(c) && c !== 'transparent') { bg = c; break; } a = a.parentElement; }
    let block = el; while (block !== d && getComputedStyle(block).display === 'inline') block = block.parentElement;
    const key = block;
    const prev = seen.get(key);
    const sw = parseFloat(cs.webkitTextStrokeWidth || '0');
    const item = prev || {cls: (block.className || block.tagName).toString(), text: '', fs: parseFloat(cs.fontSize),
                          color: sw >= 2 ? cs.webkitTextStrokeColor : cs.color, bg: bg || ground,
                          x0: b.left, y0: b.top, x1: b.right, y1: b.bottom};
    item.text += (item.text ? ' ' : '') + s;
    item.fs = Math.max(item.fs, parseFloat(cs.fontSize));
    item.x0 = Math.min(item.x0, b.left); item.y0 = Math.min(item.y0, b.top); item.x1 = Math.max(item.x1, b.right); item.y1 = Math.max(item.y1, b.bottom);
    if (!prev) { seen.set(key, item); out.push(item); }
  }
  return {W, H, items: out, imgs: [...d.querySelectorAll('img')].filter(i => i.getBoundingClientRect().width > 4).length};
}
"""


def _rgb(c: str) -> tuple[float, float, float]:
    c = c.strip()
    if c.startswith("#"):
        c = c.lstrip("#")
        if len(c) == 3:
            c = "".join(ch * 2 for ch in c)
        return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))
    nums = [float(x) for x in c[c.index("(") + 1:c.index(")")].replace("/", ",").split(",")[:3]]
    return tuple(nums)


def _lum(rgb) -> float:
    def ch(v):
        v /= 255
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(x) for x in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a: str, b: str) -> float:
    la, lb = sorted((_lum(_rgb(a)), _lum(_rgb(b))), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def score_design(m: dict, size_name: str) -> tuple[float, list[str]]:
    """10 minus penalties, with the reasons."""
    W, H, items = m["W"], m["H"], m["items"]
    short = min(W, H)
    pen, why = 0.0, []

    def hit(p, reason):
        nonlocal pen
        pen += p
        why.append(reason)
    if not items:
        return 0.0, ["no text"]
    big = max(i["fs"] for i in items)
    c_pen = 0.0
    for i in items:
        need = 3.0 if i["fs"] >= short * 0.04 else 4.5
        cr = contrast(i["color"], i["bg"])
        if cr < need:
            c_pen += 1.5
            why.append(f"contrast {cr:.1f}:1 '{i['text'][:24]}'")
    pen += min(3.0, c_pen)
    s_pen = 0.0
    for i in items:
        floor = short * (0.018 if any(k in i["cls"] for k in ("fine", "ctx")) else 0.022)
        if i["fs"] < floor - 0.5:
            s_pen += 1
            why.append(f"small {i['fs']:.0f}px '{i['text'][:24]}'")
    pen += min(2.0, s_pen)
    o_pen = 0.0
    deco = ("mark", "stars")  # a decorative quote mark / star row: its glyph box is far bigger than what's drawn
    for a in range(len(items)):
        for b in range(a + 1, len(items)):
            p, q = items[a], items[b]
            if any(k in p["cls"] or k in q["cls"] for k in deco):
                continue
            ix = max(0, min(p["x1"], q["x1"]) - max(p["x0"], q["x0"]))
            iy = max(0, min(p["y1"], q["y1"]) - max(p["y0"], q["y0"]))
            small = min((p["x1"] - p["x0"]) * (p["y1"] - p["y0"]), (q["x1"] - q["x0"]) * (q["y1"] - q["y0"]))
            if small and ix * iy / small > 0.08:
                o_pen += 2
                why.append(f"overlap '{p['text'][:16]}' / '{q['text'][:16]}'")
    pen += min(4.0, o_pen)
    e_pen = 0.0
    for i in items:
        mx, my = W * 0.04, H * 0.04
        if i["x0"] < mx - 1 or i["y0"] < my - 1 or i["x1"] > W - mx + 1 or i["y1"] > H - my + 1:
            e_pen += 1.5
            why.append(f"edge '{i['text'][:24]}'")
    pen += min(3.0, e_pen)
    if size_name == "story":
        z_pen = 0.0
        for i in items:
            if i["y0"] < H * 0.12 or i["y1"] > H * 0.82:
                z_pen += 1
                why.append(f"story UI zone '{i['text'][:24]}'")
        pen += min(2.0, z_pen)
    typical = statistics.median(i["fs"] for i in items)
    if len(items) > 1 and big / typical < 1.8:
        hit(1, f"weak hierarchy ({big / typical:.1f}x)")
    words = sum(len(i["text"].split()) for i in items)
    if len(items) < 2 or words < 4:
        hit(2, "says too little")
    x0 = min(i["x0"] for i in items); y0 = min(i["y0"] for i in items)
    x1 = max(i["x1"] for i in items); y1 = max(i["y1"] for i in items)
    if (x1 - x0) * (y1 - y0) / (W * H) < 0.30 and not m.get("imgs"):
        hit(1, "mostly empty")
    return max(0.0, round(10 - pen, 1)), why


def run_designs(out: Path) -> dict:
    from PIL import Image, ImageDraw
    from playwright.sync_api import sync_playwright
    from autocut import brain
    from autocut.config import load_client, load_settings
    from autocut.design import stills
    from autocut.mograph import hyper
    brain.ask = lambda *a, **k: None  # rules path: repeatable and free
    settings = load_settings()
    gsap = hyper.runtime_dir(settings) / "node_modules" / "gsap" / "dist" / "gsap.min.js"
    work = Path(tempfile.mkdtemp(prefix="acq-"))
    out.mkdir(parents=True, exist_ok=True)
    results = []
    with sync_playwright() as pw:
        try:
            br = pw.chromium.launch()
        except Exception:  # Playwright's own browser isn't downloaded: use a Chromium that is (AUTOCUT_CHROME, or a common place)
            exe = os.environ.get("AUTOCUT_CHROME") or next((str(p) for p in Path("/opt/pw-browsers").glob("chromium-*/chrome-linux/chrome")), None)
            br = pw.chromium.launch(executable_path=exe)
        for ci, (slug, prompt) in enumerate(DESIGN_CASES):
            client = load_client(str(BRANDS / slug), settings)
            spec = stills.magic_design(prompt, settings, client.brand)
            designs = [d for d in stills.expand(spec["template"], spec["fields"])]
            for size_name in spec["sizes"]:
                for style in STYLES:
                    W, H = stills.SIZES[size_name][0]
                    proj = work / f"c{ci}-{size_name}-{style}"
                    frames = stills.build_project(designs, client, (W, H), style, proj, gsap)
                    pg = br.new_page(viewport={"width": W, "height": H})
                    pg.goto((proj / "index.html").as_uri())
                    pg.wait_for_timeout(250)
                    for n in range(frames):
                        m = pg.evaluate(MEASURE_JS, n)
                        sc, why = score_design(m, size_name)
                        png = out / f"c{ci:02d}-{size_name}-{style}-{n}.png"
                        pg.screenshot(path=str(png))
                        results.append({"case": ci, "brand": slug, "prompt": prompt, "template": spec["template"], "size": size_name,
                                        "style": style, "frame": n, "score": sc, "why": why, "png": png.name,
                                        "fields": spec["fields"]})
                    pg.close()
        br.close()
    # contact sheets, one per size, with the score on each
    for size_name in sorted({r["size"] for r in results}):
        rs = [r for r in results if r["size"] == size_name]
        W, H = stills.SIZES[size_name][0]
        tw = 260
        th = round(tw * H / W)
        cols = 9
        sheet = Image.new("RGB", (cols * (tw + 8) + 8, ((len(rs) + cols - 1) // cols) * (th + 30) + 8), "#1b1d22")
        dr = ImageDraw.Draw(sheet)
        for k, r in enumerate(rs):
            im = Image.open(out / r["png"]).convert("RGB").resize((tw, th))
            x, y = 8 + (k % cols) * (tw + 8), 8 + (k // cols) * (th + 30)
            sheet.paste(im, (x, y))
            dr.text((x + 2, y + th + 4), f"{r['brand'][:12]} {r['template']} {r['style']}  {r['score']}", fill="#ffffff")
        sheet.save(out / f"sheet-designs-{size_name}.jpg", quality=88)
    summary = {
        "area": "designs", "n": len(results),
        "score": round(statistics.mean(r["score"] for r in results), 2),
        "by_template": {t: round(statistics.mean(r["score"] for r in results if r["template"] == t), 2)
                        for t in sorted({r["template"] for r in results})},
        "by_style": {s: round(statistics.mean(r["score"] for r in results if r["style"] == s), 2) for s in STYLES},
        "by_size": {s: round(statistics.mean(r["score"] for r in results if r["size"] == s), 2) for s in sorted({r["size"] for r in results})},
        "problems": _top_problems(results),
    }
    (out / "designs.json").write_text(json.dumps({"summary": summary, "results": results}, indent=1))
    return summary


def _top_problems(results: list[dict], k: int = 12) -> list[tuple[str, int]]:
    from collections import Counter
    c = Counter()
    for r in results:
        for w in r["why"]:
            c[w.split(" '")[0].split(" (")[0].split(" ")[0] if not w.startswith("story") else "story UI zone"] += 1
    return c.most_common(k)


if __name__ == "__main__":
    area, out = sys.argv[1], Path(sys.argv[2])
    if area != "designs":
        sys.exit(f"area not built yet: {area}")
    os.environ.setdefault("AUTOCUT_NO_NETWORK", "1")
    s = run_designs(out)
    print(json.dumps(s, indent=1))
