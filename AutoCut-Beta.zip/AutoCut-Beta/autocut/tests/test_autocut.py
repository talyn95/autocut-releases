"""AutoCut tests. Run from the repo root:  .venv/bin/python -m unittest -v
(needs ffmpeg; no speech model — the end-to-end test uses the demo's saved transcript)."""
import json
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

TMP = Path(tempfile.mkdtemp(prefix="autocut-test-"))
(TMP / "settings.yaml").write_text(
    f"machine_name: test-mac\nclients_dir: {TMP / 'clients'}\nmotion_studio_path: ''\npreview: false\n"
    "motion_blur_samples: 1\nupdates:\n  feed_url: ''\n")  # tests never reach the real update feed
os.environ["AUTOCUT_SETTINGS"] = str(TMP / "settings.yaml")

from autocut import captions, jobs  # noqa: E402
from autocut.config import EXAMPLES_DIR, ROOT, load_client, load_settings  # noqa: E402
from autocut.edit import plan_edit  # noqa: E402

EDIT_CFG = {"remove_fillers": True, "filler_words": ["um", "uh"], "remove_stutters": True,
            "max_pause": 0.3, "pad": 0.08, "head_pad": 0.15, "tail_pad": 0.35}


def w(word, start, end):
    return {"word": word, "start": start, "end": end}


def setUpModule():
    shutil.copytree(EXAMPLES_DIR / "demo-roofing-co", TMP / "clients" / "demo-roofing-co")


def tearDownModule():
    shutil.rmtree(TMP, ignore_errors=True)


class EditTests(unittest.TestCase):
    def test_fillers_and_stutters_removed(self):
        words = [w("So", 0.5, 0.7), w("um,", 0.8, 1.2), w("we", 1.5, 1.6), w("we", 1.65, 1.8),
                 w("fix", 1.85, 2.1), w("roofs.", 2.15, 2.5)]
        plan = plan_edit(words, 5.0, 30, EDIT_CFG)
        self.assertEqual([r["word"] for r in plan.removed], ["um,", "we"])
        self.assertEqual([x["word"] for x in plan.words], ["So", "we", "fix", "roofs."])
        self.assertLess(plan.seconds, 5.0)

    def test_segments_are_contiguous_on_the_timeline(self):
        words = [w(f"word{i}", i * 1.0, i * 1.0 + 0.4) for i in range(10)]  # 0.6s gaps → cut each
        plan = plan_edit(words, 11.0, 29.97, EDIT_CFG)
        for a, b in zip(plan.segments, plan.segments[1:]):
            self.assertEqual(a.rec_out, b.rec_in)
            self.assertLessEqual(a.src_out, b.src_in)

    def test_filler_audio_never_kept_inside_a_segment(self):
        words = [w("So", 0.5, 0.7), w("uh", 0.72, 0.9), w("yes", 0.95, 1.2)]  # gaps < max_pause
        plan = plan_edit(words, 3.0, 30, EDIT_CFG)
        for seg in plan.segments:
            self.assertFalse(seg.src_in < 0.8 * 30 < seg.src_out, "filler midpoint left in the cut")


class TranscriptEditTests(unittest.TestCase):
    WORDS = [w("So", 0, .2), w("we", .4, .6), w("do", .7, .9), w("a", 1.0, 1.1), w("um,", 1.3, 1.6),
             w("we", 2.2, 2.4), w("do", 2.5, 2.7), w("a", 2.8, 2.9), w("free", 3.0, 3.3), w("roof", 3.4, 3.7),
             w("inspection.", 3.8, 4.4), w("Call", 5.0, 5.3), w("us", 5.4, 5.6), w("today.", 5.7, 6.1)]
    CFG = {**EDIT_CFG, "remove_restarts": True}

    def test_false_start_keeps_only_the_retake(self):
        plan = plan_edit(self.WORDS, 7, 30, self.CFG)
        self.assertEqual(" ".join(x["word"] for x in plan.words), "So we do a free roof inspection. Call us today.")
        self.assertEqual({r["reason"] for r in plan.removed}, {"restart"})

    def test_manual_cut_keep_and_fix(self):
        plan = plan_edit(self.WORDS, 7, 30, self.CFG, force_remove={0}, force_keep={4}, fixes={"9": "ROOF"})
        said = [x["word"] for x in plan.words]
        self.assertNotIn("So", said)
        self.assertIn("um,", said)
        self.assertIn("ROOF", said)

    def test_retimed_words_keep_their_transcript_index(self):
        plan = plan_edit(self.WORDS, 7, 30, self.CFG)
        self.assertEqual([x["i"] for x in plan.words][:2], [0, 5])


class MotionTests(unittest.TestCase):
    """AutoCut Motion templates render on-brand clips (small + fast here; full size in the app)."""
    def test_easing_endpoints(self):
        from autocut.mograph import ease
        for f in (ease.out_cubic, ease.in_out_expo, ease.out_expo, ease.out_back, ease.out_elastic):
            self.assertAlmostEqual(f(0.0), 0.0, places=3)
            self.assertAlmostEqual(f(1.0), 1.0, places=3)

    def test_every_template_renders(self):
        from autocut.media import probe
        from autocut.mograph.engine import Look
        from autocut.mograph.templates import TEMPLATES, make
        client = load_client("demo-roofing-co", load_settings())
        look = Look(client, (270, 480))
        params = {"hook_title": {"text": "Hail damage"}, "slam": {"word": "free"},
                  "stat_counter": {"value": "$3,000", "label": "saved"}, "phrase_card": {"text": "Free inspection"},
                  "lower_third": {"name": "Jordan Reyes", "title": "Owner"}, "swipe": {},
                  "cta_outro": {"text": "Book now", "sub": "Link in bio", "logo": client.folder / "assets/logo/logo.png"},
                  "kinetic_type": {"text": "Hail damage hides / We find it *free*"}}
        self.assertEqual(set(params), set(TEMPLATES))
        for name, p in params.items():
            out = make(name, look, 12, TMP / f"mg_{name}.mov", samples=2, **p)
            info = probe(out)
            self.assertEqual((info.width, info.height), (270, 480), name)
            self.assertGreater(info.duration, 0.5, name)

    def test_counter_parses_money_and_percent(self):
        from autocut.mograph.templates import parse_number
        self.assertEqual(parse_number("$3,000"), ("$", 3000.0, "", 0))
        self.assertEqual(parse_number("12.5%"), ("", 12.5, "%", 1))


class GenerationTests(unittest.TestCase):
    """Icon library, stock B-roll (network mocked), agency credit."""
    def test_icon_library_picks_sensible_icons(self):
        from autocut.broll import stem
        from autocut.effects.iconlib import index, sticker
        ix = index()
        self.assertEqual(ix[stem("money")], "banknote")
        self.assertEqual(ix[stem("roofs")], "house")
        self.assertNotIn(stem("estimate"), ix)  # no loose tag-only matches on screen
        from PIL import Image
        self.assertEqual(Image.open(sticker("house", "#E63946", 128)).size, (128, 128))

    def test_stock_topics_and_fetch(self):
        from unittest import mock
        from autocut import stock
        client = load_client("demo-roofing-co", load_settings())
        words = [w("gutters", 1, 1.4), w("gutters", 5, 5.4), w("chimney", 9, 9.4), w("roof", 12, 12.4)]
        self.assertEqual(stock.topics(words, {"roof"}, "Demo Roofing Co", 2), ["gutters", "chimney"])
        fake = [{"provider": "pexels", "id": 7, "url": "https://example/x.mp4", "duration": 8, "credit": "A. Person", "page": "p"}]

        def fake_download(url, dest):
            dest.write_bytes(b"video")
            return dest
        settings = {**load_settings(), "stock": {"pexels_api_key": "k", "pixabay_api_key": ""}}
        with mock.patch.object(stock, "search_pexels", return_value=fake), mock.patch.object(stock, "_download", fake_download):
            got = stock.fetch(client, words, settings, {"roof"}, "vertical")
        self.assertTrue(got and got[0].exists())
        tags = json.loads((client.folder / "assets" / "tags.json").read_text())
        self.assertIn("gutters", tags[got[0].relative_to(client.folder).as_posix()])
        self.assertIn("A. Person", (client.folder / "assets/broll/stock/CREDITS.csv").read_text())

    def test_agency_credit_png(self):
        from autocut.overlays import add_credit
        from PIL import Image
        out = add_credit(None, (540, 960), "Made by Triumphant Media", TMP / "credit.png")
        img = Image.open(out)
        self.assertEqual(img.size, (540, 960))
        self.assertGreater(img.getchannel("A").crop((300, 900, 540, 960)).getextrema()[1], 100)  # text bottom-right


class CreateTabTests(unittest.TestCase):
    def test_prompt_reading(self):
        from autocut.mograph.prompt import rule_parse
        s = rule_parse("lower third for 'Jordan Reyes' 'Owner, Acme Roofing' in square and vertical, green screen")
        self.assertEqual((s["template"], s["params"]["name"], s["params"]["title"]), ("lower_third", "Jordan Reyes", "Owner, Acme Roofing"))
        self.assertEqual(set(s["sizes"]), {"square", "vertical"})
        self.assertEqual(s["background"], "#00b140")
        s = rule_parse("stat counter '98%' 'customers who'd recommend us' 16:9 at the top, blue #1d4ed8")
        self.assertEqual((s["params"]["value"], s["params"]["label"]), ("98%", "customers who'd recommend us"))
        self.assertEqual((s["sizes"], s["position"], s["colors"]), (["landscape"], "top", ["#1d4ed8"]))
        s = rule_parse("hook title 'Stop overpaying' all sizes, 3 seconds")
        self.assertEqual(len(s["sizes"]), 4)
        self.assertEqual(s["params"]["dur"], 3.0)
        self.assertEqual(rule_parse("swipe transition in orange and navy 4k")["colors"], ["#f97316", "#1d3557"])

    def test_render_item(self):
        from autocut.mograph.prompt import list_items, new_item, render_item
        settings = load_settings()
        spec = {"template": "phrase_card", "params": {"text": "Free estimate", "dur": 1.0}, "sizes": ["square"],
                "formats": ["mov", "webm", "mp4"], "position": "bottom", "background": None, "colors": ["#16a34a"],
                "fps": 12, "client": None}
        item = new_item(spec, settings)
        render_item(item, settings)
        listed = next(x for x in list_items(settings) if x["dir"] == str(item))
        self.assertEqual(listed["state"], "done")
        self.assertEqual(sorted(Path(f).suffix for f in listed["files"]), [".mov", ".mp4", ".webm"])


class ClipsTests(unittest.TestCase):
    def test_scoring_prefers_strong_hooks_and_whole_sentences(self):
        from autocut.clips.analyze import candidates
        script = (["Okay so anyway the weather was fine today and nothing much happened at all really."] * 3 +
                  ["Did you know most people never check their roof after a storm?",
                   "I lost forty thousand dollars learning this the hard way and it was insane.",
                   "That's why we inspect every roof for free the morning after the hail."] +
                  ["And then we went to lunch and talked about nothing in particular for a while."] * 3)
        words, t = [], 0.0
        for sentence in script:
            for x in sentence.split():
                words.append(w(x, t, t + 0.3))
                t += 0.36
            t += 0.5
        cands = candidates(words, [], min_len=8, max_len=30, count=3)
        self.assertTrue(cands[0]["title"].startswith("Did you know"))
        self.assertIn("opens with a question", cands[0]["reasons"])
        for c in cands:
            self.assertTrue(c["text"].rstrip().endswith((".", "?", "!")))

    def test_layout_filters(self):
        from autocut.clips.reframe import filter_graph
        two = {"layout": "split", "people": [{"cx": .25, "cy": .5, "w": .2, "h": .7}, {"cx": .75, "cy": .5, "w": .2, "h": .7}]}
        self.assertIn("vstack", filter_graph(two, "auto", 1920, 1080, 1080, 1920))
        pip = {"layout": "pip", "facecam": {"cx": .87, "cy": .2, "w": .18, "h": .3}, "people": []}
        g = filter_graph(pip, "auto", 1920, 1080, 1080, 1920)
        self.assertIn("vstack", g)
        self.assertIn("boxblur", g)  # facecam sits over a blurred fill
        self.assertIn("scale=1920:1080", filter_graph(two, "auto", 1920, 1080, 1920, 1080))  # same shape: no reframe

    def test_clip_job_end_to_end(self):
        """A .clip.json from the Clips tab: reframed (split) and cut into a vertical job."""
        from autocut.jobs import Worker
        settings = load_settings()
        client = load_client("demo-roofing-co", settings)
        src = TMP / "wide.mp4"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=s=640x360:r=24:d=10",
                        "-f", "lavfi", "-i", "sine=d=10", "-shortest", "-c:v", "libx264", "-c:a", "aac", str(src)], check=True)
        words = [w(x, 1 + i * 0.4, 1.3 + i * 0.4) for i, x in enumerate("This is the part everyone needs to hear today .".split())]
        (TMP / "lf-transcript.json").write_text(json.dumps({"words": words}))
        det = {"layout": "split", "people": [{"cx": .25, "cy": .5, "w": .2, "h": .7}, {"cx": .75, "cy": .5, "w": .2, "h": .7}]}
        spec = {"name": "wide-clip01", "source": str(src), "transcript": str(TMP / "lf-transcript.json"), "start": 0.5,
                "end": 6.0, "layout": "auto", "detect": det, "hook": "This part", "formats": ["vertical"],
                "effects": {k: False for k in ("broll", "subject_cutout", "overlays", "popups", "media", "cover",
                                               "motion_graphics", "lower_third", "graphic_cards")}}
        f = client.folder / "footage" / "wide-clip01.clip.json"
        f.write_text(json.dumps(spec))
        self.assertTrue(Worker(settings).process(f, client.folder))
        job = client.folder / "ready" / "wide-clip01-vertical"
        self.assertTrue(next(job.glob("*AutoCut.xml")).exists())
        from autocut.media import probe
        info = probe(client.folder / "footage" / "wide-clip01-vertical.mp4")
        self.assertEqual((info.width, info.height), (1080, 1920))


class CaptionTests(unittest.TestCase):
    def test_lines_break_on_count_and_sentences(self):
        words = [w("One", 0, .2), w("two", .3, .5), w("three.", .6, .8), w("Four", .9, 1.1)]
        lines = captions.group_lines(words, per_line=3, max_secs=2)
        self.assertEqual([[x["word"] for x in l] for l in lines], [["One", "two", "three."], ["Four"]])

    def test_ass_colour_is_bgr(self):
        self.assertEqual(captions.ass_color("#E63946"), "&H004639E6")


class QueueTests(unittest.TestCase):
    def test_only_one_mac_can_claim_a_file(self):
        inc = TMP / "claimtest" / "incoming"
        inc.mkdir(parents=True)
        f = inc / "take.mp4"
        f.write_bytes(b"x")
        first = jobs.claim(f, "mac-a")
        second = jobs.claim(f, "mac-b")
        self.assertIsNotNone(first)
        self.assertTrue(first.exists())
        self.assertIsNone(second)


class EndToEndTests(unittest.TestCase):
    def test_demo_video_to_premiere_xml(self):
        from autocut.pipeline import run_job
        settings = load_settings()
        client = load_client("demo-roofing-co", settings)
        sample = client.folder / "sample"
        xml = run_job(sample / "test-take-01.mp4", client, settings,
                      transcript=sample / "test-take-01.transcript.json",
                      effects={"music": True, "sound_design": True})  # other tests may have saved these off
        root = ET.parse(xml).getroot()
        tracks = root.findall("sequence/media/video/track")
        from autocut.premiere_xml import TRACKS
        self.assertEqual(len(tracks), len(TRACKS))
        self.assertGreaterEqual(len(tracks[TRACKS["edit"] - 1].findall("clipitem")), 2)  # cuts + end card
        self.assertEqual(len(tracks[TRACKS["captions"] - 1].findall("clipitem")), 1)     # captions overlay
        for path in root.iter("pathurl"):
            self.assertTrue(path.text.startswith("file://localhost/"))
        atracks = root.findall("sequence/media/audio/track")
        self.assertEqual(len(atracks), 3)  # A1 dialogue, A2 sound effects, A3 music
        a1 = [c.findtext("name") for c in atracks[0].findall("clipitem")]
        self.assertTrue(a1 and all(n.endswith((".mp4", ".wav")) for n in a1))
        self.assertGreaterEqual(len(atracks[1].findall("clipitem")), 1)
        self.assertTrue(all("sfx" in (c.findtext("file/pathurl") or "sfx") or c.find("file/pathurl") is None for c in atracks[1].findall("clipitem")))
        self.assertEqual(len(atracks[2].findall("clipitem")), 1)
        for t in atracks:  # nothing overlaps on a track
            spans = sorted((int(c.findtext("start")), int(c.findtext("end"))) for c in t.findall("clipitem"))
            self.assertTrue(all(a[1] <= b[0] for a, b in zip(spans, spans[1:])), spans)
        summary = json.loads((xml.parent / "job.json").read_text())
        self.assertGreater(summary["fillers_removed"], 0)
        self.assertLess(summary["cut_seconds"], summary["source_seconds"])


class EffectsTests(unittest.TestCase):
    def test_overrides_beat_client_defaults(self):
        from autocut.effects import resolve
        brand = load_client("demo-roofing-co", load_settings()).brand
        self.assertTrue(resolve(brand)["popups"])
        self.assertFalse(resolve(brand, {"popups": False})["popups"])

    def test_number_cards(self):
        from autocut.effects.cards import find_cards
        brand = load_client("demo-roofing-co", load_settings()).brand
        cards = find_cards([w("takes", 1, 1.2), w("20", 1.3, 1.5), w("minutes", 1.5, 1.8),
                            w("save", 3, 3.2), w("3000", 3.3, 3.6), w("dollars", 3.6, 3.9)], brand)
        self.assertEqual([(c["value"], c["label"]) for c in cards], [("20", "MINUTES"), ("$3,000", "")])

    def test_popups_match_words_and_respect_spacing(self):
        from autocut.effects import Occupancy
        from autocut.effects.popups import find_popups
        client = load_client("demo-roofing-co", load_settings())
        words = [w("your", 1, 1.2), w("roof", 1.3, 1.6), w("home", 2.0, 2.3), w("money", 14, 14.3)]
        pops = find_popups(words, client, Occupancy(), 30)
        self.assertEqual([p["word"] for p in pops], ["roof", "money"])  # "home" too soon after "roof"
        self.assertEqual(pops[0]["sticker"].name, "house.png")

    def test_switches_saved_without_losing_comments(self):
        from autocut.app import set_effects
        brand = TMP / "brand-copy.yaml"
        shutil.copy(EXAMPLES_DIR / "demo-roofing-co" / "brand.yaml", brand)
        set_effects(brand, {"overlays": False})
        text = brand.read_text()
        self.assertIn("BRAND PROFILE", text)
        self.assertIn("overlays: false", text)

    def test_all_effects_render(self):
        """Every effect on (cutout uses whichever segmentation engine this machine has)."""
        from autocut.pipeline import run_job
        settings = load_settings()
        client = load_client("demo-roofing-co", settings)
        sample = client.folder / "sample"
        fx = {k: True for k in ("captions", "broll", "punch_ins", "graphic_cards", "lower_third",
                                "popups", "overlays", "subject_cutout")}
        xml = run_job(sample / "test-take-01.mp4", client, settings,
                      transcript=sample / "test-take-01.transcript.json", effects=fx, hook="Hail?")
        applied = json.loads((xml.parent / "job.json").read_text())["effects_applied"]
        for k in ("punch_ins", "lower_third", "popups", "overlays", "graphic_cards"):
            self.assertGreater(applied.get(k, 0), 0, k)
        names = [c.findtext("name") for c in ET.parse(xml).getroot().iter("clipitem")]
        self.assertIn("Lower third", names)
        self.assertTrue(any(n.startswith("Pop-up:") for n in names))


def make_image(path: Path, size=(800, 600), color=(40, 120, 200), alpha=False):
    from PIL import Image
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGBA" if alpha else "RGB", size, color + ((128,) if alpha else ())).save(path)
    return path


class MediaTests(unittest.TestCase):
    def setUp(self):
        self.settings = load_settings()
        self.client = load_client("demo-roofing-co", self.settings)
        self.words = [w(f"w{i}", i * 0.5, i * 0.5 + 0.4) for i in range(80)]  # 40 seconds of speech
        self.words[30] = w("inspection", 15.0, 15.4)
        self.words[60] = w("shingles", 30.0, 30.4)

    def test_keyword_spread_and_library_placement(self):
        from autocut.effects import Occupancy
        from autocut.effects.media import plan_media, save_tags, load_tags
        c = self.client
        make_image(c.folder / "assets/uploads/t/report.png")
        make_image(c.folder / "assets/uploads/t/site.jpg")
        make_image(c.folder / "assets/graphics/gaf.png", alpha=True)
        tags = load_tags(c)
        tags["assets/graphics/gaf.png"] = "shingle"
        save_tags(c, tags)
        placed = plan_media(self.words, c, [
            {"file": "assets/uploads/t/report.png", "keywords": "inspection", "style": "auto"},
            {"file": "assets/uploads/t/site.jpg", "keywords": "", "style": "auto"},
        ], 40.0, Occupancy())
        by_name = {p["path"].name: p for p in placed}
        self.assertAlmostEqual(by_name["report.png"]["start"], 14.9, places=1)   # on its keyword
        self.assertEqual(by_name["report.png"]["style"], "float")               # PNG → floating card
        self.assertEqual(by_name["site.jpg"]["style"], "full")                  # camera photo → full screen
        self.assertAlmostEqual(by_name["gaf.png"]["start"], 29.9, places=1)     # library tag "shingle" ~ "shingles"
        spans = sorted((p["start"], p["start"] + p["length"]) for p in placed)
        for (a0, a1), (b0, _) in zip(spans, spans[1:]):
            self.assertLessEqual(a1, b0, "media overlapped")

    def test_renders(self):
        from autocut.effects.media import render_float, render_full
        from autocut.media import probe
        img = make_image(TMP / "render-src.jpg", size=(400, 300))
        full = render_full(img, (270, 480), 30, 0.5, TMP / "full.mov")
        flt = render_float(img, "screenshots", (270, 480), 30, 0.5, TMP / "float.mov")
        for f in (full, flt):
            info = probe(f)
            self.assertEqual((info.width, info.height), (270, 480))
            self.assertGreater(info.duration, 0.4)


class FeatureTests(unittest.TestCase):
    """Extra formats, loudness, cover, saved timeline + MP4 export, stats."""
    @classmethod
    def setUpClass(cls):
        from autocut.pipeline import run_job
        cls.settings = load_settings()
        client = load_client("demo-roofing-co", cls.settings)
        sample = client.folder / "sample"
        fx = {k: False for k in ("broll", "subject_cutout", "overlays", "popups", "media", "lower_third")}
        fx["cover"] = True
        cls.main = run_job(sample / "test-take-01.mp4", client, cls.settings,
                           transcript=sample / "test-take-01.transcript.json", effects=fx)
        cls.square = run_job(sample / "test-take-01.mp4", client, cls.settings, effects=fx, fmt="square")
        jobs.write_status(cls.main.parent, state="done")  # what the worker does after a cut

    def test_square_version_reuses_the_edit(self):
        root = ET.parse(self.square).getroot()
        sc = root.find("sequence/media/video/format/samplecharacteristics")
        self.assertEqual((sc.findtext("width"), sc.findtext("height")), ("1080", "1080"))
        self.assertEqual(self.square.parent.name, "test-take-01-square")
        self.assertTrue((self.square.parent / "transcript.json").exists())

    def test_dialogue_is_levelled(self):
        root = ET.parse(self.main).getroot()
        a1 = root.findall("sequence/media/audio/track")[0]
        levels = [float(v.text) for v in a1.iter("value")]
        self.assertTrue(levels, "no Audio Levels on the dialogue")
        self.assertTrue(all(0.25 <= x <= 3.99 for x in levels))

    def test_cover_and_mp4_export(self):
        from autocut.jobs import Worker
        from autocut.media import probe
        from PIL import Image
        job = self.main.parent
        self.assertEqual(Image.open(job / "cover.png").size, (1080, 1920))
        Worker(self.settings).export(job)
        out = job / f"{job.name} - final.mp4"
        info = probe(out)
        self.assertEqual((info.width, info.height), (1080, 1920))
        self.assertTrue(info.audio_channels)

    def test_stats(self):
        st = jobs.stats(self.settings)
        self.assertGreaterEqual(st["week"]["videos"], 1)
        self.assertGreater(st["all"]["footage_min"], 0)


class DashboardTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from http.server import ThreadingHTTPServer
        from autocut.app import App, make_handler
        cls.app = App()
        cls.app.worker.paused = True
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(cls.app))
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()

    def req(self, path, method="GET", body=None):
        r = urllib.request.Request(self.base + path, data=body, method=method)
        try:
            with urllib.request.urlopen(r) as resp:
                return resp.status, json.loads(resp.read() or b"{}")
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read() or b"{}")

    def test_state_lists_clients(self):
        status, data = self.req("/api/state")
        self.assertEqual(status, 200)
        self.assertIn("demo-roofing-co", [c["slug"] for c in data["clients"]])

    def test_bad_brand_yaml_is_rejected_and_file_untouched(self):
        brand = TMP / "clients" / "demo-roofing-co" / "brand.yaml"
        before = brand.read_text()
        status, _ = self.req("/api/client/demo-roofing-co/brand", "PUT", b"colors: [unclosed")
        self.assertEqual(status, 400)
        self.assertEqual(brand.read_text(), before)

    def test_files_outside_clients_folder_are_refused(self):
        status, _ = self.req("/files?path=/etc/hosts")
        self.assertEqual(status, 400)

    def test_upload_lands_in_incoming(self):
        status, _ = self.req("/api/client/demo-roofing-co/upload?name=clip.mp4", "PUT", b"fake video")
        self.assertEqual(status, 200)
        self.assertTrue((TMP / "clients" / "demo-roofing-co" / "incoming" / "clip.mp4").exists())

    def test_upload_options_follow_the_video_into_its_job(self):
        opts = json.dumps({"effects": {"popups": False}, "hook": "Big news"})
        from urllib.parse import quote
        status, _ = self.req(f"/api/client/demo-roofing-co/upload?name=opt.mp4&options={quote(opts)}", "PUT", b"x")
        self.assertEqual(status, 200)
        inc = TMP / "clients" / "demo-roofing-co" / "incoming"
        dest = jobs.claim(inc / "opt.mp4", "test-mac")
        self.assertEqual(jobs.read_options(dest.parent.parent / "ready" / "opt")["hook"], "Big news")

    def test_effect_switch_endpoint(self):
        status, data = self.req("/api/client/demo-roofing-co/effects", "PUT", json.dumps({"music": False}).encode())
        self.assertEqual(status, 200)
        self.assertFalse(data["effects"]["music"])

    def test_media_library_upload_tags_and_remove(self):
        status, data = self.req("/api/client/demo-roofing-co/media?category=fonts&name=photo.jpg", "PUT", b"x")
        self.assertEqual(status, 400)
        self.assertIn("Fonts", data["error"])
        img = make_image(TMP / "upload.png").read_bytes()
        status, data = self.req("/api/client/demo-roofing-co/media?category=screenshots&name=My%20Report%20(v2).png",
                                "PUT", img)
        self.assertEqual(status, 200)
        rel = data["rel"]
        self.assertEqual(rel, "assets/screenshots/My Report v2.png")
        status, _ = self.req("/api/client/demo-roofing-co/media-tags", "POST",
                             json.dumps({"rel": rel, "tags": "report, estimate"}).encode())
        self.assertEqual(status, 200)
        _, lib = self.req("/api/client/demo-roofing-co/media")
        item = next(i for i in lib["items"] if i["rel"] == rel)
        self.assertEqual(item["tags"], "report, estimate")
        with urllib.request.urlopen(self.base + "/api/thumb?path=" + urllib.request.quote(item["path"])) as r:
            self.assertEqual(r.headers["Content-Type"], "image/jpeg")
        self.req("/api/client/demo-roofing-co/media-delete", "POST", json.dumps({"rel": rel}).encode())
        self.assertFalse((TMP / "clients/demo-roofing-co" / rel).exists())
        self.assertTrue((TMP / "clients/demo-roofing-co/assets/.trash/My Report v2.png").exists())

    def test_media_delete_cannot_escape_assets(self):
        status, _ = self.req("/api/client/demo-roofing-co/media-delete", "POST",
                             json.dumps({"rel": "brand.yaml"}).encode())
        self.assertEqual(status, 400)
        self.assertTrue((TMP / "clients/demo-roofing-co/brand.yaml").exists())

    def test_per_video_media_upload(self):
        status, data = self.req("/api/client/demo-roofing-co/job-asset?batch=abc&name=shot.png", "PUT",
                                make_image(TMP / "shot.png").read_bytes())
        self.assertEqual(status, 200)
        self.assertEqual(data["file"], "assets/uploads/abc/shot.png")
        status, _ = self.req("/api/client/demo-roofing-co/job-asset?batch=abc&name=notes.txt", "PUT", b"hi")
        self.assertEqual(status, 400)

    def test_same_video_name_twice_keeps_both(self):
        for _ in range(2):
            status, _ = self.req("/api/client/demo-roofing-co/upload?name=twice.mp4", "PUT", b"fake")
            self.assertEqual(status, 200)
        inc = TMP / "clients" / "demo-roofing-co" / "incoming"
        self.assertTrue((inc / "twice.mp4").exists() and (inc / "twice-2.mp4").exists())

    def test_add_device_info_and_icon(self):
        status, m = self.req("/api/machine")
        self.assertEqual(status, 200)
        self.assertTrue(m["lan_name"].endswith(".local"))
        self.assertIn("listen_on_network", m)
        with urllib.request.urlopen(self.base + "/icon.png") as r:
            self.assertEqual(r.headers["Content-Type"], "image/png")

    def test_transcript_view_and_edits(self):
        from autocut.pipeline import run_job
        settings = load_settings()
        client = load_client("demo-roofing-co", settings)
        sample = client.folder / "sample"
        xml = run_job(sample / "test-take-01.mp4", client, settings,
                      transcript=sample / "test-take-01.transcript.json",
                      effects={k: False for k in ("broll", "subject_cutout", "overlays", "popups", "cover")})
        job = xml.parent
        jobs.write_status(job, state="done", video=str(sample / "test-take-01.mp4"))
        from urllib.parse import quote
        status, view = self.req("/api/job/transcript?dir=" + quote(str(job)))
        self.assertEqual(status, 200)
        um = next(x for x in view["words"] if x["word"].lower().startswith("um"))
        self.assertEqual(um["auto"], "filler")
        status, _ = self.req("/api/job/edits", "POST", json.dumps(
            {"dir": str(job), "keep": [um["i"]], "remove": [], "fixes": {"1": "SO"}}).encode())
        self.assertEqual(status, 200)
        self.assertEqual(jobs.read_options(job)["edits"]["keep"], [um["i"]])
        _, view = self.req("/api/job/transcript?dir=" + quote(str(job)))
        self.assertIsNone(next(x for x in view["words"] if x["i"] == um["i"])["cut"])
        self.assertEqual(view["words"][1]["word"], "SO")

    def test_remove_waiting_upload_and_job(self):
        self.req("/api/client/demo-roofing-co/upload?name=oops.mp4", "PUT", b"fake")
        status, _ = self.req("/api/waiting/remove", "POST", json.dumps({"client": "demo-roofing-co", "file": "oops.mp4"}).encode())
        self.assertEqual(status, 200)
        self.assertFalse((TMP / "clients/demo-roofing-co/incoming/oops.mp4").exists())
        job = TMP / "clients/demo-roofing-co/ready/throwaway"
        jobs.write_status(job, state="done")
        status, _ = self.req("/api/job/remove", "POST", json.dumps({"dir": str(job)}).encode())
        self.assertEqual(status, 200)
        self.assertFalse(job.exists())
        status, _ = self.req("/api/job/remove", "POST", json.dumps({"dir": str(TMP / "clients/demo-roofing-co")}).encode())
        self.assertEqual(status, 400)

    def test_status_writes_from_two_threads(self):
        job = TMP / "clients/demo-roofing-co/ready/racey"
        errors = []

        def hammer():
            try:
                for _ in range(200):
                    jobs.write_status(job, step="x")
            except Exception as e:
                errors.append(e)
        ts = [threading.Thread(target=hammer) for _ in range(4)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(errors, [])

    def test_longform_upload_and_make_clips(self):
        status, data = self.req("/api/client/demo-roofing-co/longform?name=show.mp4&options=%7B%22count%22%3A3%7D", "PUT", b"fake video")
        self.assertEqual(status, 200)
        folder = Path(data["dir"])
        self.assertTrue((folder / ".pending").exists())
        (folder / "analysis.json").write_text(json.dumps({"source": str(folder / "show.mp4"), "duration": 100,
                                                          "candidates": [], "layout": {"layout": "follow"}}))
        status, made = self.req("/api/longform/make", "POST", json.dumps(
            {"dir": str(folder), "clips": [{"id": 1, "start": 10, "end": 40, "title": "Hook"}], "formats": ["vertical"]}).encode())
        self.assertEqual(status, 200)
        spec = json.loads((TMP / "clients/demo-roofing-co/incoming" / (made["queued"][0] + ".clip.json")).read_text())
        self.assertEqual((spec["start"], spec["end"], spec["formats"]), (10.0, 40.0, ["vertical"]))
        (TMP / "clients/demo-roofing-co/incoming" / (made["queued"][0] + ".clip.json")).unlink()
        status, _ = self.req("/api/longform/make", "POST", json.dumps(
            {"dir": str(folder), "clips": [{"id": 2, "start": 90, "end": 400}]}).encode())
        self.assertEqual(status, 400)  # beyond the end of the video

    def test_create_endpoints(self):
        status, spec = self.req("/api/create/parse", "POST", json.dumps({"prompt": "slam 'WOW' square"}).encode())
        self.assertEqual((status, spec["template"], spec["sizes"]), (200, "slam", ["square"]))
        status, _ = self.req("/api/create/render", "POST", json.dumps({**spec, "template": "nope"}).encode())
        self.assertEqual(status, 400)

    def test_new_client_from_template(self):
        status, data = self.req("/api/clients", "POST", json.dumps({"name": "Test Co"}).encode())
        self.assertEqual(status, 200)
        self.assertTrue((TMP / "clients" / data["slug"] / "brand.yaml").exists())

class CentredAndColourTests(unittest.TestCase):
    def test_pop_captions_only_show_spoken_words(self):
        """No hidden placeholder words: the visible line stays centred instead of stepping across."""
        client = load_client("demo-roofing-co", load_settings())
        brand = {**client.brand, "captions": {**client.brand["captions"], "style": "pop"}}
        words = [w("one", 0, .3), w("two", .4, .7), w("three", .8, 1.1)]
        out = TMP / "pop.ass"
        captions.write_ass(words, 2.0, brand, (1080, 1920), out)
        body = out.read_text()
        self.assertNotIn("\\alpha&HFF&", body)
        first = [l for l in body.splitlines() if l.startswith("Dialogue")][0]
        self.assertIn("ONE" if brand["captions"]["uppercase"] else "one", first)
        self.assertNotIn("TWO" if brand["captions"]["uppercase"] else "two", first)

    def test_backdrops_are_brand_tinted_not_gray(self):
        from autocut.config import brand_backdrop
        for primary in ("#E63946", "#808080", "#000000", "#2A9D8F"):
            for c in brand_backdrop({"colors": {"primary": primary}}):
                r, g, b = int(c[2:4], 16), int(c[4:6], 16), int(c[6:8], 16)
                self.assertGreater(max(r, g, b) - min(r, g, b), 10, f"{primary} → {c} is gray")


class SpeakerTests(unittest.TestCase):
    def test_shots_follow_the_talker_with_a_minimum_length(self):
        import numpy as np
        from autocut.speakers import HOP, shots
        T = int(30 / HOP)
        act = np.zeros((2, T))
        act[0, :100] = 1          # 0–10 s person 0
        act[1, 100:105] = 1       # a 0.5 s "mm-hm" from person 1: too short to cut to
        act[0, 105:150] = 1
        act[1, 150:] = 1          # 15–30 s person 1
        cuts = shots(act, min_shot=1.8)
        self.assertEqual([c[2] for c in cuts], [0, 1])
        self.assertAlmostEqual(cuts[1][0], 15.0, delta=0.6)
        self.assertEqual(cuts[0][0], 0.0)
        self.assertAlmostEqual(cuts[-1][1], 30.0, delta=0.11)

    def test_wide_shot_when_both_talk(self):
        import numpy as np
        from autocut.speakers import HOP, shots
        T = int(20 / HOP)
        act = np.zeros((2, T))
        act[0, :80] = 1
        act[:, 80:130] = 1         # crosstalk
        act[1, 130:] = 1
        self.assertEqual([c[2] for c in shots(act, min_shot=1.8, wide=2)], [0, 2, 1])

    def test_speaker_jump_cut_filter(self):
        from autocut.clips.reframe import filter_graph, resolve_layout
        det = {"layout": "speakers", "people": [{"cx": .25, "cy": .5, "w": .2, "h": .7}, {"cx": .75, "cy": .5, "w": .2, "h": .7}]}
        g = filter_graph(det, "auto", 1920, 1080, 1080, 1920, [(0, 3, 0), (3, 6, 1), (6, 9, 0)])
        self.assertIn("overlay=enable='between(t,3.000,5.999)'", g)
        self.assertEqual(resolve_layout(det, "auto", 1920, 1080, 1920, 1080), "speakers")  # punch-ins in 16:9 too
        self.assertEqual(resolve_layout({"layout": "speakers", "people": [det["people"][0]]}, "auto", 1920, 1080, 1080, 1920),
                         "follow")


def _tone_bursts(path, pattern, total, freq):
    """A mono WAV that is loud while `pattern` says this person talks: list of (start, end)."""
    expr = "+".join(f"between(t,{a},{b})" for a, b in pattern) or "0"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", f"anoisesrc=d={total}:a=0.4:seed={freq}",
                    "-af", f"volume='0.02+0.98*({expr})':eval=frame,lowpass=f={freq}", "-ar", "16000", str(path)], check=True)


class MulticamTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        """A 24 s two-person shoot: two cameras (started at different times), two mics and a screen recording."""
        cls.folder = TMP / "clients/demo-roofing-co/multicam/ep-test"
        cls.folder.mkdir(parents=True, exist_ok=True)
        host = [(0.5, 4), (9, 12.5), (17, 20)]
        guest = [(4.5, 8.5), (13, 16.5), (20.5, 23.5)]
        _tone_bursts(TMP / "host.wav", host, 24, 3000)
        _tone_bursts(TMP / "guest.wav", guest, 24, 1500)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(TMP / "host.wav"), "-i", str(TMP / "guest.wav"),
                        "-filter_complex", "amix=inputs=2:normalize=0", str(TMP / "room.wav")], check=True)
        for name, start in (("cam-a.mp4", 0.0), ("cam-b.mp4", 2.0)):  # cam B started rolling 2 s late
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=s=320x180:r=25",
                            "-ss", str(start), "-i", str(TMP / "room.wav"), "-shortest", "-c:v", "libx264", "-preset",
                            "ultrafast", "-c:a", "aac", str(cls.folder / name)], check=True)
        shutil.copy(TMP / "host.wav", cls.folder / "host-mic.wav")
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", "1", "-i", str(TMP / "guest.wav"),
                        str(cls.folder / "guest-mic.wav")], check=True)  # guest recorder started 1 s late
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc=s=320x180:r=10:d=8",
                        "-c:v", "libx264", "-preset", "ultrafast", str(cls.folder / "screen-share.mp4")], check=True)
        (cls.folder / "options.json").write_text(json.dumps({"min_shot": 1.5, "post_copy": False}))
        from autocut.multicam.project import build
        settings = {**load_settings(), "preview": True}
        cls.job = build(cls.folder, cls.folder.parent.parent, settings)
        cls.analysis = json.loads((cls.folder / "analysis.json").read_text())

    def test_sync_finds_the_offsets(self):
        off = {f["name"]: f["offset"] for f in self.analysis["files"]}
        self.assertAlmostEqual(off["cam-b.mp4"], 2.0, delta=0.04)
        self.assertAlmostEqual(off["guest-mic.wav"], 1.0, delta=0.04)
        self.assertAlmostEqual(off["host-mic.wav"], 0.0, delta=0.04)
        roles = {f["name"]: f["role"] for f in self.analysis["files"]}
        self.assertEqual(roles["screen-share.mp4"], "screen")
        self.assertEqual(roles["guest-mic.wav"], "audio")

    def test_cuts_follow_the_mics(self):
        recipe = json.loads((self.job / "multicam.json").read_text())
        people = {p["file"]: p["camera"] for p in recipe["people"]}
        a = recipe["range"][0]
        def cam_at(t):  # programme time t (source clock t + a)
            return next(c for s, e, c in recipe["shots"] if s <= t - a < e)
        self.assertEqual(cam_at(10.5), people["host-mic.wav"])
        self.assertEqual(cam_at(14.5), people["guest-mic.wav"])
        self.assertNotEqual(people["host-mic.wav"], people["guest-mic.wav"])
        self.assertTrue(recipe["pip"], "the screen recording should be shown as picture-in-picture")

    def test_xml_and_preview(self):
        xml = next(self.job.glob("*AutoCut.xml"))
        root = ET.parse(xml).getroot()
        tracks = root.findall("./sequence/media/audio/track")
        self.assertEqual(len(tracks), 2)  # one track per mic
        self.assertTrue(root.findall(".//parameter[parameterid='center']"))  # the speaker PiP is moved to a corner
        from autocut.media import probe
        prev = probe(next(self.job.glob("*preview.mp4")))
        self.assertGreater(prev.duration, 15)
        self.assertEqual(json.loads((self.job / "job.json").read_text())["kind"], "multicam")

    def test_cut_fillers_switch_keeps_everything_by_default(self):
        recipe = json.loads((self.job / "multicam.json").read_text())
        self.assertEqual(len(recipe["keep"]), 1)  # ums and pauses stay unless switched on


class ProjectUploadTests(unittest.TestCase):
    """Several files / a dropped folder = one project (Clips and Multicam)."""
    setUpClass = classmethod(DashboardTests.setUpClass.__func__)
    tearDownClass = classmethod(DashboardTests.tearDownClass.__func__)
    req = DashboardTests.req
    def test_project_upload_then_start(self):
        status, data = self.req("/api/project/new", "POST", json.dumps(
            {"kind": "multicam", "client": "demo-roofing-co", "name": "Episode 9", "options": {"pip": False}}).encode())
        self.assertEqual(status, 200)
        d = urllib.request.quote(data["dir"])
        for name in ("cam-a.mp4", "host.wav"):
            self.assertEqual(self.req(f"/api/project/upload?dir={d}&name={name}", "PUT", b"x")[0], 200)
        self.assertEqual(self.req(f"/api/project/upload?dir={d}&name=notes.txt", "PUT", b"x")[0], 400)
        self.assertEqual(self.req("/api/project/start", "POST", json.dumps({"dir": data["dir"]}).encode())[0], 200)
        self.assertTrue((Path(data["dir"]) / ".pending").exists())
        items = self.req("/api/multicam")[1]
        self.assertIn("Episode 9", [i["name"] for i in items])
        status, _ = self.req("/api/multicam/edit", "POST", json.dumps({"dir": data["dir"], "options": {"cut_fillers": True}}).encode())
        self.assertEqual(status, 200)
        self.assertTrue(json.loads((Path(data["dir"]) / "options.json").read_text())["cut_fillers"])
        # a Clips project refuses audio files
        status, lf = self.req("/api/project/new", "POST", json.dumps({"kind": "longform", "client": "demo-roofing-co", "name": "Stream"}).encode())
        self.assertEqual(self.req(f"/api/project/upload?dir={urllib.request.quote(lf['dir'])}&name=a.wav", "PUT", b"x")[0], 400)

    def test_ai_status_and_post_copy_endpoints(self):
        status, a = self.req("/api/ai")
        self.assertEqual(status, 200)
        self.assertIn("local", a)
        self.assertIn("recommended_model", a)
        job = TMP / "clients/demo-roofing-co/ready/copy-endpoint"
        job.mkdir(parents=True, exist_ok=True)
        words = [w(x, i * 0.4, i * 0.4 + 0.3) for i, x in enumerate("We inspect every roof for free after a storm.".split())]
        (job / "copy-source.json").write_text(json.dumps({"kind": "short", "title": "", "words": words}))
        status, pack = self.req("/api/job/copy", "POST", json.dumps({"dir": str(job)}).encode())
        self.assertEqual(status, 200)
        self.assertIn("short_form", pack)
        self.assertEqual(self.req("/api/job/copy?dir=" + urllib.request.quote(str(job)))[1]["short_form"], pack["short_form"])

    def test_clips_project_with_two_videos(self):
        """A folder holding part 1 and part 2 of a stream: both analysed, clips know which video they're from."""
        from autocut.clips.analyze import analyze
        folder = TMP / "clients/demo-roofing-co/longform/two-parts"
        folder.mkdir(parents=True, exist_ok=True)
        script = "Did you know most people never check their roof? That's why we inspect every roof for free.".split()
        for part in ("part1", "part2"):
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=s=320x180:r=10:d=30",
                            "-f", "lavfi", "-i", "sine=d=30", "-shortest", "-c:v", "libx264", "-preset", "ultrafast",
                            "-c:a", "aac", str(folder / f"{part}.mp4")], check=True)
            work = folder / ".parts" / part
            work.mkdir(parents=True, exist_ok=True)
            words = [w(x, 1 + i * 0.4, 1.3 + i * 0.4) for i, x in enumerate(script * 2)]
            (work / "transcript.json").write_text(json.dumps({"words": words}))
        (folder / "options.json").write_text(json.dumps({"min_len": 5, "max_len": 30, "count": 2, "layout": "center"}))
        res = analyze(folder, load_settings())
        self.assertEqual(len(res["parts"]), 2)
        self.assertEqual({Path(c["source"]).name for c in res["candidates"]}, {"part1.mp4", "part2.mp4"})
        self.assertEqual(res["layout"]["layout"], "center")
        c = next(c for c in res["candidates"] if c["source"].endswith("part2.mp4"))
        status, made = self.req("/api/longform/make", "POST", json.dumps(
            {"dir": str(folder), "clips": [{"id": c["id"], "start": c["start"], "end": c["end"], "title": "x"}]}).encode())
        self.assertEqual(status, 200)
        spec_path = TMP / "clients/demo-roofing-co/incoming" / (made["queued"][0] + ".clip.json")
        self.assertTrue(json.loads(spec_path.read_text())["source"].endswith("part2.mp4"))
        spec_path.unlink()

class StoryTests(unittest.TestCase):
    def test_moments_pick_pictures_for_what_is_said(self):
        from autocut.effects import Occupancy
        from autocut.effects.story import find_moments
        client = load_client("demo-roofing-co", load_settings())
        text = ("Okay so let me explain how this works today. The hail hits your roof, water leaks into the attic, "
                "and six months later your family is calling the insurance company. That is why we do this.")
        words, t = [], 0.0
        for x in text.split():
            words.append(w(x, t, t + 0.3))
            t += 0.38
        moments = find_moments(words, client, Occupancy(), t + 1)
        self.assertEqual(len(moments), 1)
        m = moments[0]
        self.assertGreaterEqual(len(m["beats"]), 3)
        self.assertLessEqual(m["end"] - m["start"], client.brand["story"]["max_seconds"] + 0.01)
        said = [b["word"] for b in m["beats"]]
        self.assertIn("hail", said)
        self.assertTrue(all(b["t"] >= 0 for b in m["beats"]))
        self.assertEqual(find_moments(words[:8], client, Occupancy(), 4.0), [])  # nothing to picture

    def test_storyboard_renders_with_icon_image_video_and_speaker(self):
        from autocut.effects import story
        from autocut.media import probe
        client = load_client("demo-roofing-co", load_settings())
        img = make_image(TMP / "story-photo.png")
        clip = TMP / "story-clip.mp4"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=s=320x180:r=15:d=4",
                        "-c:v", "libx264", "-preset", "ultrafast", str(clip)], check=True)
        mo = {"start": 0, "end": 3.0, "beats": [
            {"t": 0.3, "word": "hail", "kind": "icon", "icon": "cloud-hail"},
            {"t": 1.0, "word": "photo", "kind": "image", "path": str(img)},
            {"t": 1.6, "word": "crew", "kind": "video", "path": str(clip)}]}
        size = (360, 640)
        bw, bh = story.speaker_box(size, 3)
        speaker = story.video_frames(str(clip), 0, 3, 15, bw, bh)
        out = story.render_moment(mo, client, size, 15, TMP / "story.mov", 1, speaker)
        info = probe(out)
        self.assertEqual((info.width, info.height), size)
        self.assertAlmostEqual(info.duration, 3.0, delta=0.15)

    def test_effect_switch_and_track(self):
        from autocut.effects import KEYS, resolve
        from autocut.premiere_xml import TRACKS
        self.assertIn("story", KEYS)
        self.assertLess(TRACKS["story"], TRACKS["captions"])  # captions stay readable over the storyboard
        brand = load_client("demo-roofing-co", load_settings()).brand
        self.assertFalse(resolve(brand, {"story": False})["story"])

class _Fake:
    """A tiny HTTP server standing in for Ollama or the Claude API; records what it was sent."""
    def __init__(self, routes):
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        self.calls = []
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _reply(self):
                n = int(self.headers.get("Content-Length") or 0)
                body = json.loads(self.rfile.read(n) or b"{}") if n else {}
                outer.calls.append({"path": self.path, "headers": dict(self.headers), "body": body})
                key = next((k for k in routes if self.path.startswith(k)), None)
                out = routes[key](body) if key else {}
                data = json.dumps(out).encode()
                self.send_response(200 if key else 404)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            do_GET = do_POST = _reply
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = f"http://127.0.0.1:{self.server.server_port}"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def close(self):
        self.server.shutdown()


def _ollama(answer):
    return _Fake({"/api/tags": lambda b: {"models": [{"name": "gemma3:12b"}]},
                  "/api/chat": lambda b: {"message": {"content": json.dumps(answer(b) if callable(answer) else answer)}}})


class BrainTests(unittest.TestCase):
    def setUp(self):
        from autocut import brain
        self.brain = brain
        brain.USAGE_FILE = TMP / "ai-usage-test.json"
        brain.USAGE_FILE.unlink(missing_ok=True)

    def settings(self, **ai):
        return {**load_settings(), "ai": {"local_url": "http://127.0.0.1:9", "local_model": "auto", "claude_backup": True,
                                          "claude_api_key": "", "claude_model": "claude-opus-5-5",
                                          "claude_monthly_limit_usd": 25, "post_copy": True, **ai}}

    def test_local_model_answers_first(self):
        fake = _ollama({"answer": "yes"})
        try:
            out = self.brain.ask(self.settings(local_url=fake.url), "system text", "question",
                                 {"type": "object", "properties": {"answer": {"type": "string"}}, "required": ["answer"]})
        finally:
            fake.close()
        self.assertEqual(out, {"answer": "yes"})
        self.assertEqual(self.brain.last_engine(), "local")
        chat = next(c for c in fake.calls if c["path"] == "/api/chat")["body"]
        self.assertEqual(chat["messages"][0], {"role": "system", "content": "system text"})
        self.assertEqual(chat["format"]["required"], ["answer"])  # answer constrained to the schema

    def test_claude_is_the_backup_with_a_monthly_cap(self):
        msg = {"id": "msg_1", "type": "message", "role": "assistant", "model": "claude-opus-5-5",
               "content": [{"type": "text", "text": json.dumps({"answer": "from claude"})}],
               "stop_reason": "end_turn", "stop_sequence": None, "usage": {"input_tokens": 1000, "output_tokens": 200}}
        fake = _Fake({"/v1/messages": lambda b: msg})
        old = os.environ.get("ANTHROPIC_BASE_URL")
        os.environ["ANTHROPIC_BASE_URL"] = fake.url
        schema = {"type": "object", "properties": {"answer": {"type": "string"}}, "required": ["answer"]}
        try:
            out = self.brain.ask(self.settings(claude_api_key="test-key"), "sys", "q", schema)  # local is down
            self.assertEqual(out, {"answer": "from claude"})
            self.assertEqual(self.brain.last_engine(), "claude")
            sent = fake.calls[-1]
            self.assertEqual(sent["body"]["model"], "claude-opus-5-5")
            self.assertEqual(sent["body"]["fallbacks"], "default")
            self.assertIn("server-side-fallback-2026-07-01", sent["headers"].get("anthropic-beta", ""))
            self.assertFalse(sent["body"]["output_config"]["format"]["schema"]["additionalProperties"])
            self.assertAlmostEqual(self.brain.usage()["usd"], 0.008, places=4)
            # over the monthly limit: Claude isn't used, and with no local model there's no AI answer
            self.assertIsNone(self.brain.ask(self.settings(claude_api_key="test-key", claude_monthly_limit_usd=0.005),
                                             "sys", "q", schema))
            # no key: never Claude
            self.assertIsNone(self.brain.ask(self.settings(), "sys", "q", schema))
        finally:
            fake.close()
            if old is None:
                os.environ.pop("ANTHROPIC_BASE_URL", None)
            else:
                os.environ["ANTHROPIC_BASE_URL"] = old

    def test_recommended_model_by_memory(self):
        self.assertEqual(self.brain.recommended_model(8), "gemma3:4b")
        self.assertEqual(self.brain.recommended_model(32), "gemma3:12b")
        self.assertEqual(self.brain.recommended_model(64), "gemma3:27b")


class MarketingTests(unittest.TestCase):
    def test_post_copy_without_ai_uses_rules(self):
        from autocut import marketing
        brand = load_client("demo-roofing-co", load_settings()).brand
        settings = {**load_settings(), "ai": {"local_url": "http://127.0.0.1:9", "claude_api_key": ""}}
        words = [w(x, i * 0.4, i * 0.4 + 0.3) for i, x in enumerate(
            "Hail damage hides on your roof. Most homeowners never see it until the ceiling stains. We check for free.".split())]
        pack = marketing.post_copy(words, brand, settings)
        self.assertEqual(pack["engine"], "rules")
        self.assertIn("#DemoRoofing", pack["short_form"]["hashtags"])
        self.assertTrue(all(h.startswith("#") for h in pack["short_form"]["hashtags"]))
        job = TMP / "copyjob"
        job.mkdir(exist_ok=True)
        md = marketing.write_copy(job, pack, words)
        self.assertIn("## YouTube", md.read_text())
        self.assertTrue((job / "copy-source.json").exists())

    def test_ai_copy_and_long_form_chapters(self):
        from autocut import marketing
        brand = load_client("demo-roofing-co", load_settings()).brand
        answer = {"hooks": ["Your roof is lying to you", "a", "b"],
                  "short_form": {"title": "Hidden hail damage", "caption": "Look up.", "hashtags": ["roofing", "#hail"]},
                  "youtube": {"title": "Hail damage, explained", "description": "What to check after a storm."},
                  "linkedin": {"post": "L"}, "facebook": {"post": "F"}}
        fake = _ollama(answer)
        words, t = [], 0.0
        for i in range(600):  # ~6 minutes of talk
            words.append(w("word." if i % 12 == 11 else "word", t, t + 0.4))
            t += 0.6
        try:
            pack = marketing.post_copy(words, brand, {**load_settings(), "ai": {"local_url": fake.url}}, "long", "Episode 1")
        finally:
            fake.close()
        self.assertEqual(pack["engine"], "local")
        self.assertEqual(pack["short_form"]["hashtags"], ["#roofing", "#hail"])
        self.assertGreaterEqual(len(pack["chapters"]), 3)
        self.assertIn("0:00", pack["youtube"]["description"])
        system = fake.calls[-1]["body"]["messages"][0]["content"]
        self.assertIn("HOOKS", system)                  # the marketing playbook
        self.assertIn("free roof inspections", system)  # the client's brief

    def test_ai_ranks_clips_with_hooks(self):
        from autocut.clips.analyze import llm_rerank
        cands = [{"id": 1, "start": 0, "end": 30, "text": "a", "score": 50.0, "reasons": []},
                 {"id": 2, "start": 40, "end": 70, "text": "b", "score": 60.0, "reasons": []}]
        fake = _ollama({"clips": [{"id": 1, "score": 95, "title": "The big one", "hooks": ["h1", "h2", "h3"],
                                   "why": "Strong payoff", "platform": "TikTok"},
                                  {"id": 2, "score": 20, "title": "Meh", "hooks": [], "why": "", "platform": ""}]})
        try:
            self.assertTrue(llm_rerank(cands, {**load_settings(), "ai": {"local_url": fake.url}}))
        finally:
            fake.close()
        self.assertEqual(cands[0]["id"], 1)  # re-ordered by the blended score
        self.assertEqual((cands[0]["title"], cands[0]["hooks"], cands[0]["platform"]), ("The big one", ["h1", "h2", "h3"], "TikTok"))
        self.assertEqual(cands[0]["score"], round(0.4 * 50 + 0.6 * 95, 1))
        self.assertIn("AI pick", cands[0]["reasons"])


class CreativeUpgradeTests(unittest.TestCase):
    def test_highlight_captions_box_behind_the_spoken_word(self):
        client = load_client("demo-roofing-co", load_settings())
        brand = {**client.brand, "captions": {**client.brand["captions"], "style": "highlight"}}
        out = TMP / "hl.ass"
        captions.write_ass([w("one", 0, .3), w("two", .4, .7)], 2.0, brand, (1080, 1920), out)
        lines = [l for l in out.read_text().splitlines() if l.startswith("Dialogue")]
        boxes = [l for l in lines if l.startswith("Dialogue: 0,")]
        texts = [l for l in lines if l.startswith("Dialogue: 1,")]
        self.assertEqual(len(boxes), len(texts))
        self.assertIn("\\1a&HFF&", boxes[0])   # invisible fill
        self.assertIn("\\bord", boxes[0])       # thick brand-colour outline = the box

    def test_kinetic_type_and_speed(self):
        from autocut.media import probe
        from autocut.mograph.engine import Look
        from autocut.mograph.templates import kinetic_type, make
        client = load_client("demo-roofing-co", load_settings())
        look = Look(client, (360, 640), 15)
        dur, _ = kinetic_type(look, "Hail damage hides / We find it *free*")
        out = make("kinetic_type", look, 15, TMP / "kt.mov", samples=1, speed=1.5,
                   text="Hail damage hides / We find it *free*")
        self.assertAlmostEqual(probe(out).duration, dur / 1.5, delta=0.15)

    def test_reference_palette_and_pacing(self):
        from PIL import Image
        from autocut.mograph import reference
        img = Image.new("RGB", (200, 100), (220, 30, 40))
        img.paste((20, 40, 160), (100, 0, 200, 100))
        img.save(TMP / "ref.png")
        settings = {**load_settings(), "ai": {"local_url": "http://127.0.0.1:9", "claude_api_key": ""}}
        res = reference.analyze([TMP / "ref.png"], settings)
        def near(hexc, rgb):
            return sum(abs(int(hexc[i:i + 2], 16) - v) for i, v in zip((1, 3, 5), rgb)) < 40
        self.assertTrue(any(near(c, (220, 30, 40)) for c in res["palette"]))
        self.assertTrue(any(near(c, (20, 40, 160)) for c in res["palette"]))
        self.assertEqual(len(res["colors"]), 2)
        dark = Image.new("RGB", (200, 100), (12, 60, 70))  # mostly a very dark teal, with a gold band
        dark.paste((214, 168, 46), (0, 70, 200, 100))
        dark.save(TMP / "ref-dark.png")
        lead = reference.analyze([TMP / "ref-dark.png"], settings)["colors"][0]
        self.assertTrue(near(lead, (214, 168, 46)), lead)  # the readable gold leads, not the near-black teal
        busy = TMP / "busy.mp4"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=s=320x180:r=25:d=4",
                        "-c:v", "libx264", "-preset", "ultrafast", str(busy)], check=True)
        self.assertGreater(reference.pacing(busy)["speed"], 1.0)

    def test_follow_tracks_a_moving_person(self):
        import numpy as np
        from autocut.clips import reframe
        state = {"x": 0.3}

        def fake_frame(source, t, width=640):
            state["x"] = 0.3 + 0.4 * min(1.0, t / 8)  # walks from left to right over 8 s
            return np.zeros((270, 480, 3), np.uint8)

        def fake_seg(frame):
            m = np.zeros(frame.shape[:2], float)
            cx = int(state["x"] * frame.shape[1])
            m[60:260, cx - 40:cx + 40] = 1
            return m
        import autocut.effects.cutout as cutout
        old_frame, old_seg = reframe._frame, cutout.get_segmenter
        reframe._frame, cutout.get_segmenter = fake_frame, (lambda engine="auto": fake_seg)
        try:
            track = reframe.track_person(Path("x.mp4"), 0, 10, {"cx": 0.3, "cy": 0.5, "w": 0.2, "h": 0.7})
        finally:
            reframe._frame, cutout.get_segmenter = old_frame, old_seg
        self.assertIsNotNone(track)
        self.assertLess(track[0][1], 0.4)
        self.assertGreater(track[-1][1], 0.6)  # the camera followed them
        cmds = reframe._track_cmds(track, 606, 1920)
        self.assertTrue(cmds.startswith("0.00 crop x "))

class AuthTests(unittest.TestCase):
    def setUp(self):
        from autocut.auth import Auth
        self.dir = Path(tempfile.mkdtemp(dir=TMP))
        self.auth = Auth({"web": {"require_login": True}}, self.dir)

    def test_first_admin_needs_the_setup_code(self):
        self.assertTrue(self.auth.setup_code)
        with self.assertRaises(PermissionError):
            self.auth.setup_first_admin("WRONG", "boss", "a-long-password")
        self.auth.setup_first_admin(self.auth.setup_code.lower(), "boss", "a-long-password")
        self.assertIsNone(self.auth.setup_code)
        with self.assertRaises(PermissionError):  # only once
            self.auth.setup_first_admin("ANY", "other", "a-long-password")

    def test_passwords_are_hashed_and_checked(self):
        self.auth.add_user("Editor@Example.com", "a-long-password", "editor")
        stored = json.loads((self.dir / "users.json").read_text())["editor@example.com"]
        self.assertNotIn("a-long-password", json.dumps(stored))
        self.assertTrue(stored["hash"].startswith("pbkdf2_sha256$600000$"))
        token = self.auth.login("editor@example.com", "a-long-password", "1.2.3.4")
        self.assertEqual(self.auth.session(token)["role"], "editor")
        with self.assertRaises(ValueError):
            self.auth.add_user("x", "short", "editor")  # bad name and short password

    def test_lockout_after_five_wrong_passwords(self):
        from autocut.auth import LoginError
        self.auth.add_user("pat", "a-long-password", "admin")
        for _ in range(5):
            with self.assertRaises(LoginError):
                self.auth.login("pat", "wrong", "5.5.5.5")
        with self.assertRaisesRegex(LoginError, "15 minutes"):
            self.auth.login("pat", "a-long-password", "5.5.5.5")
        self.assertTrue(self.auth.login("pat", "a-long-password", "6.6.6.6"))  # another address is fine

    def test_sessions_expire_and_end_on_password_change(self):
        self.auth.add_user("pat", "a-long-password", "admin")
        t = self.auth.login("pat", "a-long-password", "1.1.1.1")
        self.auth.sessions[t]["expires"] = time.time() - 1
        self.assertIsNone(self.auth.session(t))
        t = self.auth.login("pat", "a-long-password", "1.1.1.1")
        self.auth.set_password("pat", "another-long-one")
        self.assertIsNone(self.auth.session(t))

    def test_always_one_admin(self):
        self.auth.add_user("pat", "a-long-password", "admin")
        with self.assertRaises(ValueError):
            self.auth.set_role("pat", "editor")
        with self.assertRaises(ValueError):
            self.auth.remove_user("pat")


class HostedDashboardTests(unittest.TestCase):
    """The dashboard with sign-in on, as it runs when web-hosted."""
    @classmethod
    def setUpClass(cls):
        from http.server import ThreadingHTTPServer
        from autocut.app import App, make_handler
        cls.app = App()
        cls.app.worker.paused = True
        cls.app.settings["web"] = {**cls.app.settings.get("web", {}), "require_login": True}
        cls.app.auth.file = TMP / "hosted-users.json"
        cls.app.auth.file.unlink(missing_ok=True)
        cls.app.auth.add_user("boss", "a-long-password", "admin")
        cls.app.auth.add_user("ed", "a-long-password", "editor")
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(cls.app))
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.app.settings["web"]["require_login"] = False

    def req(self, path, method="GET", body=None, cookie=None, header=True):
        h = {"X-AutoCut": "1"} if header else {}
        if cookie:
            h["Cookie"] = cookie
        r = urllib.request.Request(self.base + path, data=body, method=method, headers=h)

        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *a, **k):
                return None
        try:
            with urllib.request.build_opener(NoRedirect).open(r) as resp:
                return resp.status, resp.headers, resp.read()
        except urllib.error.HTTPError as e:
            return e.code, e.headers, e.read()

    def login(self, name):
        status, headers, _ = self.req("/api/login", "POST", json.dumps({"name": name, "password": "a-long-password"}).encode())
        self.assertEqual(status, 200)
        cookie = headers["Set-Cookie"]
        self.assertIn("HttpOnly", cookie)
        return cookie.split(";")[0]

    def test_everything_needs_sign_in(self):
        self.assertEqual(self.req("/")[0], 302)
        self.assertEqual(self.req("/api/state")[0], 401)
        self.assertEqual(self.req("/files?path=/etc/passwd")[0], 401)
        self.assertEqual(self.req("/login")[0], 200)
        status, headers, _ = self.req("/login")
        self.assertEqual(headers["X-Frame-Options"], "DENY")

    def test_requests_from_other_sites_are_blocked(self):
        cookie = self.login("boss")
        status, _, _ = self.req("/api/pause", "POST", b'{"paused": true}', cookie=cookie, header=False)
        self.assertEqual(status, 403)

    def test_editors_cant_touch_admin_things(self):
        ed = self.login("ed")
        self.assertEqual(self.req("/api/state", cookie=ed)[0], 200)
        self.assertEqual(self.req("/api/users", cookie=ed)[0], 403)
        self.assertEqual(self.req("/api/local-settings", "PUT", b"x: 1", cookie=ed)[0], 403)
        _, _, body = self.req("/api/machine", cookie=ed)
        self.assertEqual(json.loads(body)["local_settings"], "")
        boss = self.login("boss")
        self.assertEqual(self.req("/api/users", cookie=boss)[0], 200)

    def test_chunked_upload_and_sign_out(self):
        cookie = self.login("boss")
        _, _, body = self.req("/api/project/new", "POST", json.dumps({"kind": "longform", "client": "demo-roofing-co",
                                                                      "name": "chunks"}).encode(), cookie=cookie)
        d = urllib.request.quote(json.loads(body)["dir"])
        data = os.urandom(300_000)
        for i, off in enumerate(range(0, len(data), 100_000)):
            st, _, b = self.req(f"/api/project/upload?dir={d}&name=v.mp4&upload_id=abcdefgh-1&chunk={i}&chunks=3&offset={off}",
                                "PUT", data[off:off + 100_000], cookie=cookie)
            self.assertEqual(st, 200, b)
        self.assertEqual((Path(urllib.request.unquote(d)) / "v.mp4").read_bytes(), data)
        self.req("/api/logout", "POST", b"{}", cookie=cookie)
        self.assertEqual(self.req("/api/state", cookie=cookie)[0], 401)


class PackageTests(unittest.TestCase):
    def test_download_for_premiere_relinks(self):
        import io
        import zipfile
        from autocut.media import probe
        from autocut.package import package
        from autocut.premiere_xml import Timeline
        job = TMP / "clients/demo-roofing-co/ready/pkg-job"
        job.mkdir(parents=True, exist_ok=True)
        clip = EXAMPLES_DIR / "demo-roofing-co/sample/test-take-01.mp4"
        tl = Timeline("pkg", 30, (1080, 1920))
        tl.add_video("edit", probe(clip), 0, 0, 60)
        tl.write(job / "pkg - AutoCut.xml")
        tl.save(job / "timeline.json")

        class Stream:  # write-only, like the HTTP response
            def __init__(self):
                self.b = io.BytesIO()

            def write(self, x):
                return self.b.write(x)

            def flush(self):
                pass
        s = Stream()
        package(job, s)
        z = zipfile.ZipFile(io.BytesIO(s.b.getvalue()))
        self.assertIn("pkg-job/media/test-take-01.mp4", z.namelist())
        xml = z.read("pkg-job/pkg - AutoCut.xml").decode()
        self.assertIn("file://localhost/Users/Shared/AutoCut-Downloads/pkg-job/media/test-take-01.mp4", xml)
        self.assertNotIn(str(EXAMPLES_DIR), xml)


class CrossPlatformTests(unittest.TestCase):
    def test_premiere_pathurl_mac_and_windows(self):
        from autocut.premiere_xml import pathurl
        self.assertEqual(pathurl("/Users/Shared/AutoCut/a b.mp4"), "file://localhost/Users/Shared/AutoCut/a%20b.mp4")
        self.assertEqual(pathurl(r"C:\Users\Public\AutoCut\a b.mp4"),
                         "file://localhost/C%3A/Users/Public/AutoCut/a%20b.mp4")

    def test_windows_gpu_encoder_is_test_run(self):
        from unittest import mock
        from autocut import media
        old = media._HW
        try:
            media._HW = None
            with mock.patch.object(media, "has_encoder", lambda n: n in ("h264_nvenc", "h264_qsv")), \
                    mock.patch.object(media.subprocess, "run",
                                      lambda cmd, **k: mock.Mock(returncode=0 if "h264_qsv" in cmd else 1)):
                self.assertEqual(media.video_encoder("final")[:2], ["-c:v", "h264_qsv"])  # no NVIDIA card: skip nvenc
            media._HW = None
            with mock.patch.object(media, "has_encoder", lambda n: False):
                self.assertEqual(media.video_encoder()[:2], ["-c:v", "libx264"])
        finally:
            media._HW = old

    def test_memory_and_windows_scripts(self):
        from autocut.brain import memory_gb
        self.assertGreater(memory_gb(), 0.5)
        win = ROOT / "windows"
        for f in ("install.ps1", "update.ps1", "AutoCut.cmd", "autocut.ico"):
            self.assertTrue((win / f).exists(), f)
        self.assertIn("windows\\install.ps1", (ROOT / "Install AutoCut (Windows).cmd").read_text())
        self.assertNotIn("clients_dir", (ROOT / "settings.yaml").read_text())  # each computer picks its own folder


class HyperFramesTests(unittest.TestCase):
    """The HyperFrames engine: project building always; a real render only where its runtime is set up."""

    def setUp(self):
        self.settings = load_settings()
        self.client = load_client(str(EXAMPLES_DIR / "demo-roofing-co"), self.settings)

    def test_builds_a_valid_project_for_every_template(self):
        from autocut.mograph import hyper
        params = {"hook_title": {"text": "Your roof took a *beating*"}, "slam": {"word": "FREE"},
                  "stat_counter": {"value": "$3,000.50", "label": "average saved"}, "phrase_card": {"text": "Free <b>"},
                  "lower_third": {"name": "Jordan Reyes", "title": "Owner"}, "swipe": {},
                  "cta_outro": {"text": "Book now", "sub": "acme.com"}, "kinetic_type": {"text": "One / Two *three*"}}
        for t in hyper.TEMPLATES:
            with self.subTest(t):
                proj = TMP / "hf" / t
                dur = hyper.build(t, self.client, (1080, 1920), proj, params[t], position="center")
                page = (proj / "index.html").read_text()
                self.assertEqual(re.findall(r"__[A-Z_]+__", page), [])  # every placeholder filled
                self.assertIn('data-duration="%g"' % dur, page)
                self.assertIn('window.__timelines["main"] = tl', page)
                self.assertIn('src="assets/gsap.min.js"', page)
                self.assertNotIn("<b>", page.split("<body>")[1].split("<script>")[0])  # text is escaped
        page = (TMP / "hf" / "stat_counter" / "index.html").read_text()
        self.assertIn('"number": 3000.5', page)
        self.assertIn('"decimals": 2', page)
        self.assertIn('class="w accent"><span class="hl"></span>three', (TMP / "hf" / "kinetic_type" / "index.html").read_text())

    def test_kinetic_beats_hold_by_word_count(self):
        from autocut.mograph import hyper
        beats = hyper._beats("Hail damage hides / We find it free")
        self.assertEqual(len(beats), 2)
        self.assertGreater(beats[1]["end"] - beats[1]["start"], beats[0]["end"] - beats[0]["start"])
        self.assertEqual(hyper.on("#ffffff"), "#111111")
        self.assertEqual(hyper.on("#1d3557"), "#ffffff")

    def test_unavailable_runtime_falls_back_to_classic(self):
        from autocut.mograph import hyper
        from unittest import mock
        from autocut.mograph.prompt import parse
        s = dict(self.settings, hyperframes={"enabled": True, "runtime_dir": str(TMP / "no-runtime")})
        with mock.patch.dict(os.environ, {"AUTOCUT_HF_RUNTIME": ""}):
            self.assertFalse(hyper.available(s))
            s = dict(s, ai={**s["ai"], "claude_backup": False, "local_url": "http://127.0.0.1:9"})
            self.assertEqual(parse("lower third for 'A B' 'C'", s)["engine"], "classic")

    @unittest.skipUnless(os.environ.get("AUTOCUT_HF_RUNTIME"), "HyperFrames runtime not set up here")
    def test_renders_transparent_prores(self):
        from autocut.mograph import hyper
        self.assertTrue(hyper.available(self.settings))
        out = hyper.make("phrase_card", self.client, (1080, 1080), 30, TMP / "hf-render" / "pc.mov", self.settings,
                         text="Free inspection", dur=1.2)
        info = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_name,pix_fmt", "-of", "csv=p=0",
                               str(out)], capture_output=True, text=True).stdout
        self.assertIn("prores", info)
        self.assertIn("yuva", info)

    @unittest.skipUnless(os.environ.get("AUTOCUT_HF_RUNTIME"), "HyperFrames runtime not set up here")
    def test_studio_edit_then_rerender(self):
        from autocut.mograph import prompt as mp
        s = dict(self.settings, clients_dir=str(TMP / "hf-clients" / "clients"))
        spec = {"template": "phrase_card", "params": {"text": "Before edit", "dur": 1.0}, "sizes": ["square"],
                "formats": ["mov"], "engine": "hyperframes", "fps": 30}
        item = mp.new_item(spec, s)
        mp.render_item(item, s)
        listed = next(i for i in mp.list_items(s) if i["dir"] == str(item))
        self.assertEqual(listed["studio"], ["phrase_card-square"])
        page = item / "hf-phrase_card-square" / "index.html"
        page.write_text(page.read_text().replace("Before edit", "After edit"))  # what a Studio edit does
        (item / ".rerender").touch()
        mp.render_item(item, s)
        self.assertFalse((item / ".rerender").exists())
        self.assertTrue(json.loads((item / "status.json").read_text())["edited"])
        self.assertIn("After edit", (item / "hf-phrase_card-square" / "index.html").read_text())


class ReportTests(unittest.TestCase):
    def test_problem_report_has_logs_and_no_secrets(self):
        import zipfile
        from autocut import report
        s = load_settings()
        s = dict(s, ai={**s["ai"], "claude_api_key": "sk-ant-SECRET123"}, stock={"pexels_api_key": "PEXELSSECRET"})
        job = TMP / "clients" / "acme" / "ready" / "report-job"
        job.mkdir(parents=True, exist_ok=True)
        (job / "status.json").write_text('{"state": "error"}')
        (job / "log.txt").write_text("step 3 failed: boom")
        out = report.build(s, "It stopped at transcribing", TMP / "reports", job=job)
        with zipfile.ZipFile(out) as z:
            names = z.namelist()
            everything = b"".join(z.read(n) for n in names)
        self.assertIn("1-what-happened.txt", names)
        self.assertIn("3-health-check.txt", names)
        self.assertTrue(any(n.endswith("report-job/log.txt") for n in names))
        self.assertIn(b"step 3 failed: boom", everything)
        self.assertIn(b"It stopped at transcribing", everything)
        self.assertNotIn(b"SECRET123", everything)
        self.assertNotIn(b"PEXELSSECRET", everything)


class CompetitiveFeatureTests(unittest.TestCase):
    """0.16: Graphics tab, Studio Sound, Remove retakes, Find clips about…, multicam wide frequency."""

    @staticmethod
    def _words(lines):
        out, t = [], 0.0
        for line, pause in lines:
            for w in line.split():
                out.append({"word": w, "start": round(t, 2), "end": round(t + 0.3, 2)})
                t += 0.35
            t += pause
        return out

    def test_remove_retakes_keeps_last_take_and_deliberate_repeats(self):
        from autocut.edit import find_retakes
        ws = self._words([("We inspect every roof in about thirty minutes.", 0.8), ("Um,", 0.5),
                          ("we inspect every roof in under thirty minutes, and it's free.", 0.8),
                          ("Not once.", 0.3), ("Not once.", 0.5), ("Our crews are local and licensed.", 1.0)])
        gone = " ".join(ws[i]["word"] for i in sorted(find_retakes(ws, {"um"})))
        self.assertEqual(gone, "We inspect every roof in about thirty minutes.")

    def test_find_clips_about_a_topic(self):
        from autocut.clips.analyze import relevance, topic_terms
        terms = topic_terms("pricing and hidden fees")
        self.assertGreater(relevance("Our pricing is simple: no hidden fees, ever. Fees kill trust.", terms),
                           relevance("We started the company in a garage in 2009.", terms))
        self.assertEqual(relevance("anything", set()), 0.0)

    def test_studio_sound_cleans_the_demo_voice(self):
        from autocut.audio import studio_sound
        from autocut.media import probe
        src = EXAMPLES_DIR / "demo-roofing-co" / "sample" / "test-take-01.mp4"
        out = studio_sound(src, TMP / "studio-sound.wav")
        info, orig = probe(out), probe(src)
        self.assertEqual(info.audio_channels, 2)
        self.assertAlmostEqual(info.duration, orig.duration, delta=0.2)

    def test_multicam_wide_frequency(self):
        from autocut.multicam.project import DEFAULTS, WIDE_FREQUENCY
        self.assertEqual(DEFAULTS["wide_frequency"], "normal")
        self.assertLess(WIDE_FREQUENCY["more"][0], WIDE_FREQUENCY["less"][0])
        self.assertTrue(DEFAULTS["studio_sound"])

    def test_design_projects_for_every_template_and_size(self):
        from autocut.design import stills
        c = load_client(str(ROOT / "tests" / "showcase" / "brands" / "saffron-sage"), load_settings())
        fields = {"quote": {"quote": "Best <pasta> in *town*", "author": "Ana", "role": "Guest"},
                  "stat": {"number": "98%", "label": "come back"}, "offer": {"headline": "Pasta *night*", "cta": "Book"},
                  "testimonial": {"review": "Lovely", "name": "Jo"}, "thumbnail": {"title": "I tried *everything*"},
                  "tips": {"title": "3 tips", "items": "One\nTwo\nThree"},
                  "event": {"kicker": "OPEN", "title": "Grand opening", "date": "Sat"},
                  "carousel": {"title": "5 ways", "items": "A | aa\nB | bb", "cta": "Follow"}}
        gsap = TMP / "gsap.min.js"
        gsap.write_text("/* stub */")
        for t, f in fields.items():
            for size in stills.SIZES:
                with self.subTest(t=t, size=size):
                    proj = TMP / "design" / f"{t}-{size}"
                    n = stills.build_project(stills.expand(t, f), c, stills.SIZES[size][0], "bold", proj, gsap)
                    page = (proj / "index.html").read_text()
                    self.assertEqual(n, 4 if t == "carousel" else 1)
                    self.assertIn('window.__timelines["main"] = tl', page)
                    self.assertNotIn("<pasta>", page)  # text is escaped
        self.assertIn('class="acc">town</span>', (TMP / "design" / "quote-post" / "index.html").read_text())

    def test_design_csv_and_magic_fallback(self):
        from autocut.design import stills
        rows = stills.rows_from_csv("Headline,offer,CTA\nFresh *pasta*,2 for $30,Book\n,,\nBrunch,Coffee,Go\n", "offer")
        self.assertEqual([r["headline"] for r in rows], ["Fresh *pasta*", "Brunch"])
        with self.assertRaises(ValueError):
            stills.rows_from_csv("nope\n1\n", "offer")
        s = dict(load_settings(), ai={**load_settings()["ai"], "claude_backup": False, "local_url": "http://127.0.0.1:9"})
        spec = stills.magic_design("stat: 98% of patients would recommend us, all sizes", s)
        self.assertEqual((spec["template"], spec["fields"]["number"]), ("stat", "98%"))
        self.assertEqual(spec["sizes"], list(stills.SIZES))

    @unittest.skipUnless(os.environ.get("AUTOCUT_HF_RUNTIME"), "HyperFrames runtime not set up here")
    def test_design_render_bulk_and_carousel(self):
        from PIL import Image
        from autocut.design import stills
        s = dict(load_settings(), clients_dir=str(TMP / "design-clients" / "clients"))
        item = stills.new_item({"template": "offer", "rows": [{"headline": "One"}, {"headline": "Two"}],
                                "sizes": ["post"], "styles": ["bold", "clean"]}, s)
        stills.render_item(item, s)
        files = json.loads((item / "status.json").read_text())["files"]
        self.assertEqual(len(files), 4)
        self.assertEqual(Image.open(item / files[0]).size, (1080, 1080))
        item = stills.new_item({"template": "carousel", "fields": {"title": "Ways", "items": "A | a\nB | b"},
                                "sizes": ["portrait"], "styles": ["dark"]}, s)
        stills.render_item(item, s)
        files = json.loads((item / "status.json").read_text())["files"]
        self.assertEqual(sum(f.endswith(".png") for f in files), 4)
        self.assertTrue(any(f.endswith(".pdf") for f in files))


class KnowledgeAndAssetsTests(unittest.TestCase):
    """0.17: the video-marketing knowledge base, the Strategist, and your own images in the Graphics tab."""

    def test_every_ai_task_gets_its_knowledge(self):
        from autocut import marketing
        for task, topics in marketing.TASKS.items():
            prompt = marketing.system_prompt({"client": "Acme", "marketing": {"offer": "free audits"}}, task)
            self.assertIn("# CORE", prompt)
            self.assertIn("free audits", prompt)
            for t in topics:
                self.assertIn(marketing.knowledge(t).split("\n\n")[-1][:40], prompt, (task, t))
        self.assertIn("ROAS", marketing.knowledge(*marketing.topics_for("what CPL should our Meta ads hit")))
        self.assertLess(len(marketing.system_prompt(None, "clips").split()), 2500)  # fits the small local model

    def test_strategist_without_ai_returns_the_playbook(self):
        from autocut import marketing
        s = dict(load_settings(), ai={**load_settings()["ai"], "claude_backup": False, "local_url": "http://127.0.0.1:9"})
        r = marketing.strategist("how do I price a retainer?", s, None, None)
        self.assertIsNone(r["engine"])
        self.assertIn("RUNNING A VIDEO MARKETING AGENCY", r["answer"])

    def test_assets_roles_cutout_and_placement(self):
        from PIL import Image, ImageDraw
        from autocut.design import assets
        d = TMP / "assets"
        d.mkdir(exist_ok=True)
        im = Image.new("RGB", (600, 600), (240, 240, 240))
        ImageDraw.Draw(im).rectangle((220, 120, 380, 520), fill=(30, 110, 80))
        im.save(d / "product-bottle.jpg")
        logo = Image.new("RGBA", (900, 300), (0, 0, 0, 0))
        ImageDraw.Draw(logo).rectangle((50, 100, 850, 200), fill=(200, 30, 30, 255))
        logo.save(d / "brand.png")
        self.assertEqual(assets.describe(d / "product-bottle.jpg")["role"], "product")
        self.assertEqual(assets.describe(d / "brand.png")["role"], "logo")  # wide + transparent
        out = assets.cutout_object(d / "brand.png", d / "brand-cut.png")  # already transparent: just trimmed
        self.assertEqual(Image.open(out).size, (801, 101))  # PIL rectangles include their end pixels
        row = assets.apply("photo", {"headline": "x"}, [{"path": str(d / "product-bottle.jpg"), "role": "photo"}], d)
        self.assertEqual(row["photo"], str(d / "product-bottle.jpg"))

    def test_magic_design_picks_product_for_a_product_image(self):
        from PIL import Image
        from autocut.design import stills
        p = TMP / "assets" / "thing.jpg"
        p.parent.mkdir(exist_ok=True)
        Image.new("RGB", (100, 100), (200, 100, 50)).save(p)
        s = dict(load_settings(), ai={**load_settings()["ai"], "claude_backup": False, "local_url": "http://127.0.0.1:9"})
        spec = stills.magic_design("Turn these into a marketable social graphic", s, None, [{"path": str(p), "role": "product"}])
        self.assertEqual(spec["template"], "product")


class TranscriptVideoTests(unittest.TestCase):
    """Transcript → kinetic typography video, and the logos/fonts/graphics that customize the motion generator."""

    def setUp(self):
        self.settings = load_settings()
        self.d = TMP / "tv"
        self.d.mkdir(parents=True, exist_ok=True)

    def test_reads_srt_vtt_text_and_json(self):
        from autocut.mograph import script
        (self.d / "a.srt").write_text("1\n00:00:01,000 --> 00:00:03,000\nHello <i>there</i> friend\n\n"
                                      "2\n00:00:03,500 --> 00:00:04,500\nBye.\n")
        words, timed = script.read_transcript(self.d / "a.srt")
        self.assertTrue(timed)
        self.assertEqual([w["word"] for w in words], ["Hello", "there", "friend", "Bye."])
        self.assertAlmostEqual(words[0]["start"], 1.0)
        self.assertLessEqual(words[2]["end"], 3.0)
        self.assertAlmostEqual(words[3]["start"], 3.5)
        (self.d / "a.vtt").write_text("WEBVTT\n\n00:01.000 --> 00:02.000\nOne two\n")
        words, _ = script.read_transcript(self.d / "a.vtt")
        self.assertEqual([w["word"] for w in words], ["One", "two"])
        (self.d / "a.txt").write_text("# Title\nFirst line. Second, line here.")
        words, timed = script.read_transcript(self.d / "a.txt")
        self.assertFalse(timed)
        self.assertEqual(words[0]["word"], "First")
        self.assertTrue(all(b["start"] > a["end"] for a, b in zip(words, words[1:])))  # paced in order
        (self.d / "a.json").write_text(json.dumps({"words": [{"word": "Hi", "start": 0.5, "end": 0.8}]}))
        self.assertEqual(script.read_transcript(self.d / "a.json"), ([{"word": "Hi", "start": 0.5, "end": 0.8}], True))

    def test_plan_picks_treatments(self):
        from autocut.mograph import script
        words = script.pace("Most teams lose 30% of their week. Status meetings. Orbitly fixes that! "
                            "First, connect your tools. Second, open the dashboard. Um this is a longer sentence that "
                            "goes on and on for quite a few words, really.")
        g = self.d / "dashboard.png"
        g.write_bytes(b"x")
        bs = script.plan(words, [g])
        treat = {" ".join(w["word"] for w in b["words"]): b["treat"] for b in bs}
        self.assertEqual(treat["Most teams lose 30% of their week."], "stat")
        self.assertEqual(treat["Orbitly fixes that!"], "slam")
        self.assertEqual(treat["First, connect your tools."], "list")
        self.assertEqual(treat["Second, open the dashboard."], "image")  # named in the beat
        self.assertTrue(all(len(b["words"]) <= 9 for b in bs))
        self.assertNotIn("Um", " ".join(treat))  # fillers dropped
        self.assertFalse(any(len(b["words"]) == 1 for b in bs))  # no lone words

    def test_builds_a_composition(self):
        from autocut.mograph import script
        client = load_client(str(EXAMPLES_DIR / "demo-roofing-co"), self.settings)
        words = script.pace("We saved $3,000. Call <now>!")
        bs = script.plan(words, [])
        total = script.build(words, bs, client, (1080, 1920), self.d / "proj", self.settings, cta="Book today")
        page = (self.d / "proj" / "index.html").read_text()
        self.assertIn(f'data-duration="{total}"', page)
        self.assertIn('window.__timelines["main"] = tl', page)
        self.assertIn("v: 3000.0", page)  # the counter
        self.assertIn("Book today", page)
        self.assertIn("&lt;now&gt;", page)  # escaped
        self.assertNotIn("Math.random", page)

    def test_customize_logo_and_fonts(self):
        from PIL import Image
        from autocut.mograph import customize
        from autocut.mograph.engine import family_from_filename
        client = load_client(str(EXAMPLES_DIR / "demo-roofing-co"), self.settings)
        logo = self.d / "acme-logo.png"
        Image.new("RGBA", (200, 80), (255, 0, 0, 255)).save(logo)
        pic = self.d / "truck.jpg"
        Image.new("RGB", (100, 100)).save(pic)
        font = next(Path(p) for p in ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
                                       "/System/Library/Fonts/Supplemental/Arial Bold.ttf", "C:/Windows/Fonts/arialbd.ttf"]
                    if Path(p).exists())
        assets = [customize.describe(p) for p in (logo, pic, font)]
        self.assertEqual([a["role"] for a in assets], ["logo", "graphic", "font"])
        self.assertEqual(customize.describe(self.d / "talk.srt")["kind"], "transcript")
        c = customize.apply(client, assets, self.d / "custom")
        self.assertEqual(c.brand["logo"]["file"], str(logo.resolve()))
        self.assertEqual(c.brand["fonts"]["headline"], assets[2]["family"])
        self.assertTrue((Path(c.brand["fonts"]["folder"]) / font.name).exists())
        self.assertEqual(client.brand["logo"]["file"], load_client(str(EXAMPLES_DIR / "demo-roofing-co"), self.settings).brand["logo"]["file"])  # untouched
        self.assertEqual(customize.graphics(assets), [pic])
        self.assertEqual(family_from_filename(Path("Gotham-BoldItalic.woff2")), ("Gotham", 700))

    def test_dashboard_accepts_a_pasted_script(self):
        from autocut import app as appmod
        from autocut.mograph import prompt as mp
        s = dict(self.settings, clients_dir=str(TMP / "tv-clients" / "clients"))
        mp.library_dir(s).mkdir(parents=True, exist_ok=True)
        self.assertTrue(hasattr(appmod, "make_handler"))
        item = mp.new_item({"template": "transcript", "params": {"source": str(TMP / "20260101-120000-my-script.txt")},
                            "sizes": ["vertical"]}, s)
        self.assertIn("transcript-my-script", item.name)

    @unittest.skipUnless(os.environ.get("AUTOCUT_HF_RUNTIME"), "HyperFrames runtime not set up here")
    def test_render_item_makes_a_video_with_sound(self):
        from autocut.mograph import prompt as mp
        s = dict(self.settings, clients_dir=str(TMP / "tv-clients" / "clients"))
        sample = EXAMPLES_DIR / "demo-roofing-co" / "sample"
        rec = self.d / "talk.mp4"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-t", "6", "-i", str(sample / "test-take-01.mp4"), "-c", "copy", str(rec)], check=True)
        spec = {"template": "transcript", "params": {"source": str(rec), "cta": "Call today", "ai": False},
                "sizes": ["square"], "formats": ["mp4"], "engine": "hyperframes", "fps": 24}
        item = mp.new_item(spec, s)
        work = item / "_work-transcript-square"
        work.mkdir(parents=True)
        words = json.loads((sample / "test-take-01.transcript.json").read_text())["words"]
        (work / "transcript.json").write_text(json.dumps({"words": [w for w in words if w["end"] < 5.5]}))
        mp.render_item(item, s)
        st = json.loads((item / "status.json").read_text())
        self.assertEqual(st["state"], "done", st.get("error"))
        out = item / "transcript-square.mp4"
        streams = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type", "-of", "csv=p=0", str(out)],
                                 capture_output=True, text=True).stdout.split()
        self.assertEqual(sorted(streams), ["audio", "video"])
        self.assertTrue((item / "poster-square.jpg").exists())
        self.assertTrue((item / "hf-transcript-square" / "voice.txt").exists())


class MotionLibraryTests(unittest.TestCase):
    """Looks × layouts × storyboards, and the style DNA that keeps clients apart."""

    def setUp(self):
        self.settings = load_settings()
        self.root = TMP / "lib-clients" / "clients"
        if self.root.exists():
            shutil.rmtree(self.root)
        self.root.mkdir(parents=True)
        for b in ("lumen-dental", "ironclad-fitness", "saffron-sage", "pixelforge-labs", "harborline-realty"):
            shutil.copytree(ROOT / "tests" / "showcase" / "brands" / b, self.root / b)
        self.s = dict(self.settings, clients_dir=str(self.root))

    def test_every_layout_in_every_look_builds(self):
        from autocut.mograph.library import build, looks
        from autocut.mograph.library.elements import LAYOUTS
        client = load_client(str(self.root / "saffron-sage"), self.s)
        p = {"name": "Dr. <Nair>", "title": "Lead", "text": "Fresh *pasta* daily", "kicker": "New", "items": "Jan: 120\nFeb: 1,800.5",
             "value": "72%", "label": "would return", "author": "Maria", "stars": 4, "sub": "x.example", "x": 30, "y": 70}
        n = 0
        for lk in looks.LOOKS:
            for kind, lays in LAYOUTS.items():
                for lay in lays:
                    proj = TMP / "lib" / "p"
                    d = build.build_element(kind, lay, lk, client, (1080, 1920) if n % 2 else (1920, 1080), proj, p)
                    page = (proj / "index.html").read_text()
                    self.assertIn('window.__timelines["main"] = tl', page, (lk, kind, lay))
                    self.assertIn(f'data-duration="{d:.3f}"', page)
                    self.assertNotIn("<Nair>", page)  # escaped
                    self.assertNotIn("Math.random", page)
                    self.assertNotIn("{{", page.split("<script>")[1], (lk, kind, lay))
                    n += 1
        self.assertGreaterEqual(n, len(looks.LOOKS) * 41)

    def test_colour_roles_are_readable(self):
        from autocut.mograph.hyper import _luma
        from autocut.mograph.library import looks
        from autocut.mograph.library.compose import roles
        for colors in ({"primary": "#facc15", "secondary": "#ffffff"}, {"primary": "#1d3557", "secondary": "#0b0f1a"},
                       {"primary": "#14B8A6", "secondary": "#F8FAFC"}):
            for lk, L in looks.LOOKS.items():
                for overlay in (True, False):
                    r = roles({"key": lk, **L}, colors, overlay)
                    if r["panel"].startswith("#") and r["ink"].startswith("#") and L["panel"] != "none":
                        self.assertGreater(abs(_luma(r["panel"]) - _luma(r["ink"])), 90, (lk, colors))
                    if r["accent"].startswith("#") and r["accent_ink"].startswith("#"):
                        self.assertGreater(abs(_luma(r["accent"]) - _luma(r["accent_ink"])), 80, (lk, colors))
                    if overlay and L["panel"] == "none":
                        self.assertEqual(r["ink"], "#ffffff")  # floats over footage
                    self.assertGreater(_luma(r["float_accent"]), 140)

    def test_dna_keeps_clients_apart(self):
        from autocut.config import list_clients
        from autocut.mograph.library import dna
        dnas = {}
        for f in list_clients(self.s):
            c = load_client(str(f), self.s)
            dnas[c.slug] = dna.get(c, self.s)
            self.assertTrue((f / dna.FILE).exists())
        self.assertEqual(len({d["look"] for d in dnas.values()}), len(dnas))  # five clients, five looks
        self.assertEqual(dnas["ironclad-fitness"]["look"], "sport")  # suits the business
        for a in dnas.values():
            for b in dnas.values():
                if a is not b:
                    self.assertLess(dna.similarity(a, b), 0.5)
        c = load_client(str(self.root / "lumen-dental"), self.s)
        again = dna.get(c, self.s)
        self.assertEqual(again, dnas["lumen-dental"])  # stable once handed out
        shuffled = dna.assign(c, self.s, shuffle=1)
        self.assertNotEqual(shuffled["look"], again["look"])
        rows = dna.overview(self.s)
        self.assertEqual(len(rows), 5)
        self.assertTrue(all(r["closest"] < 0.5 for r in rows))

    def test_storyboard_plan_and_build(self):
        from autocut.mograph.library import dna, storyboards
        c = load_client(str(self.root / "pixelforge-labs"), self.s)
        d = dna.get(c, self.s)
        for key, recipe in storyboards.RECIPES.items():
            pl = storyboards.plan(key, "", c, None, d)
            self.assertEqual(pl["via"], "rules")
            self.assertTrue(pl["scenes"], key)
            self.assertNotIn("{", json.dumps(pl["scenes"]).replace("{\"", ""), key)  # every slot filled
            total = storyboards.build(pl["scenes"], d["look"], c, (1080, 1920), TMP / "sb" / key, d["transition"])
            page = (TMP / "sb" / key / "index.html").read_text()
            self.assertAlmostEqual(total, sum(s["dur"] for s in pl["scenes"]), places=2)
            self.assertEqual(page.count('class="clip scene full"'), len(pl["scenes"]))
            self.assertEqual(page.count('data-track-index="3"'), len(pl["scenes"]) - 1)  # a transition on every cut
        pl = storyboards.plan("listicle", '"3 lifts" "Deadlift\nSquat\nPress"', c, None, d)
        self.assertEqual([s["params"].get("kicker") for s in pl["scenes"][1:4]], ["Tip 1", "Tip 2", "Tip 3"])
        pl = storyboards.plan("stat_story", "Search 46, Referrals 28, Other 9.", c, None, d)
        self.assertEqual(pl["slots"]["data"], "Search: 46\nReferrals: 28\nOther: 9")

    def test_prompt_rules_for_library_graphics(self):
        from autocut.mograph.prompt import rule_parse
        r = rule_parse("line chart of monthly sales Jan 40 Feb 55 Mar 80 Apr 120 landscape")
        self.assertEqual((r["template"], r["layout"]), ("chart", "line"))
        self.assertEqual(r["params"]["items"], "Jan: 40\nFeb: 55\nMar: 80\nApr: 120")
        r = rule_parse("donut chart 72% 'would recommend us' vertical neon")
        self.assertEqual((r["layout"], r["look"], r["params"]["value"], r["params"]["label"]), ("donut", "neon", "72%", "would recommend us"))
        self.assertEqual(rule_parse("checklist 'Free inspection / Photo report'")["params"]["items"], "Free inspection\nPhoto report")
        self.assertEqual(rule_parse("testimonial 'Best in town' 'Maria G.'")["params"]["author"], "Maria G.")
        self.assertEqual(rule_parse("lower third for 'Jordan Reyes' 'Owner'")["template"], "lower_third")

    def test_routing_and_registry(self):
        from autocut.mograph import library
        from autocut.mograph.library import registry
        c = load_client(str(self.root / "lumen-dental"), self.s)
        look, d = library.resolve({"template": "lower_third"}, c, self.s)
        self.assertEqual(look, d["look"])
        self.assertEqual(library.resolve({"template": "lower_third", "look": "original"}, c, self.s), (None, None))
        self.assertEqual(library.resolve({"template": "lower_third", "look": "neon"}, c, self.s)[0], "neon")
        kind, p, allowed = library.kind_params("stat_counter", {"value": "$1,250,000", "label": "sold"})
        self.assertEqual((kind, p["items"], allowed), ("chart", "sold: $1,250,000", ["counters"]))
        self.assertEqual(library.kind_params("stat_counter", {"value": "98%"})[2][0], "donut")
        self.assertGreater(len(registry.catalog()), 400)
        self.assertEqual(registry.search("clean lower third name bar", 1, "block")[0]["name"], "lt-clean-bar")

    @unittest.skipUnless(os.environ.get("AUTOCUT_HF_RUNTIME"), "HyperFrames runtime not set up here")
    def test_renders_routed_lower_third_and_storyboard(self):
        from autocut.mograph import prompt as mp
        item = mp.new_item({"template": "lower_third", "params": {"name": "Ana Ruiz", "title": "Owner", "dur": 2},
                            "sizes": ["landscape"], "formats": ["mov"], "engine": "hyperframes", "client": "ironclad-fitness", "fps": 24}, self.s)
        mp.render_item(item, self.s)
        st = json.loads((item / "status.json").read_text())
        self.assertEqual((st["state"], st["look"]), ("done", "sport"), st.get("error"))
        out = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v", "-show_entries", "stream=pix_fmt", "-of", "csv=p=0",
                              str(item / "lower_third-landscape.mov")], capture_output=True, text=True).stdout
        self.assertIn("yuva", out)  # transparent
        from autocut.mograph.library import storyboards
        c = load_client(str(self.root / "saffron-sage"), self.s)
        scenes = storyboards.plan("offer", "", c, None, None)["scenes"]
        item = mp.new_item({"template": "storyboard", "params": {"recipe": "offer", "scenes": scenes}, "sizes": ["square"],
                            "formats": ["mp4"], "engine": "hyperframes", "client": "saffron-sage", "fps": 24}, self.s)
        mp.render_item(item, self.s)
        st = json.loads((item / "status.json").read_text())
        self.assertEqual(st["state"], "done", st.get("error"))
        self.assertTrue((item / "storyboard-square.mp4").exists() and (item / "poster-square.jpg").exists())
        streams = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type", "-of", "csv=p=0",
                                  str(item / "storyboard-square.mp4")], capture_output=True, text=True).stdout.split()
        self.assertEqual(sorted(streams), ["audio", "video"])  # scored: music + effects
        self.assertTrue((item / "storyboard-square-sound" / "music.wav").exists())


class SoundTests(unittest.TestCase):
    """Original music, sound effects, the sound designer, each client's sound identity and the optional AI model."""

    def setUp(self):
        self.d = TMP / "sound"
        self.d.mkdir(parents=True, exist_ok=True)

    def test_every_style_composes_to_the_exact_length(self):
        import hashlib
        import numpy as np
        from autocut.sound import composer, synth
        for style in composer.STYLES:
            with self.subTest(style):
                mix, ex = composer.compose({"style": style, "key": "E", "seed": 3}, 13.7)
                self.assertEqual(mix.shape, (2, synth.n_of(13.7)))
                self.assertLessEqual(float(np.max(np.abs(mix))), 0.9)
                self.assertGreater(float(np.sqrt(np.mean(mix[:, : synth.SR * 8] ** 2))), 0.02)  # not silent
                self.assertEqual(set(ex["stems"]), {"drums", "bass", "harmony", "top"})
                self.assertGreater(ex["meta"]["bars"], 1)
        a, _ = composer.compose({"style": "lofi", "seed": 9}, 8)
        b, _ = composer.compose({"style": "lofi", "seed": 9}, 8)
        self.assertEqual(hashlib.md5(a.tobytes()).hexdigest(), hashlib.md5(b.tobytes()).hexdigest())  # same client, same music

    def test_harmony_and_tempo_fit(self):
        from autocut.sound.composer import chord_pcs, fit_tempo, voice
        names = "C C# D D# E F F# G G# A A# B".split()
        self.assertEqual([names[x % 12] for x in chord_pcs(6, "major")[0]], ["A", "C", "E"])
        self.assertEqual([names[x % 12] for x in chord_pcs(2, "dorian", True)[0]], ["D", "F", "A", "C"])
        v1 = voice(chord_pcs(1, "major")[0], 48, 60, None)
        v2 = voice(chord_pcs(5, "major")[0], 48, 60, v1)
        self.assertLessEqual(sum(min(abs(a - b) for b in v1) for a in v2), 4)  # smooth voice leading
        bpm, bars = fit_tempo(112, 30.0)
        self.assertAlmostEqual(bars * 240 / bpm, 30.0 - 1.8, places=6)  # the last bar lands on the final chord
        self.assertTrue(0.88 * 112 <= bpm <= 1.12 * 112)

    def test_effects_every_kind_and_flavour(self):
        import numpy as np
        from autocut.sound import sfx
        for fl in sfx.FLAVOURS:
            for k in sfx.KINDS:
                x = sfx.make(k, fl, 2)
                self.assertEqual(x.shape[0], 2, (k, fl))
                self.assertGreater(float(np.max(np.abs(x))), 0.5, (k, fl))
                self.assertLessEqual(float(np.max(np.abs(x))), 0.91, (k, fl))

    def test_sound_designer_restraint_and_timing(self):
        from autocut.sound import design
        ev = [{"t": 0.3, "kind": "reveal"}, {"t": 2.0, "kind": "slam"}, {"t": 2.4, "kind": "sticker"},
              {"t": 5.0, "kind": "transition"}, {"t": 5.5, "kind": "graphic"}, {"t": 9.0, "kind": "end"}, {"t": 4, "kind": "nonsense"}]
        cues = design.plan(ev, 10.0, "normal")
        kinds = [c["event"] for c in cues]
        self.assertIn("slam", kinds)
        self.assertNotIn("sticker", kinds)  # too close to the slam, which matters more
        self.assertTrue(all(b["at"] - a["at"] >= 1.2 for a, b in zip(cues, cues[1:])))
        placed = design.materialise(cues, self.d / "fx", "clean", 1)
        riser = next(c for c in placed if c["kind"] == "riser")
        self.assertEqual(riser["start"], 0.0)
        self.assertGreater(riser["src_in"], 0)  # its head is trimmed so it still ends on the reveal
        whoosh = next(c for c in placed if c["kind"] == "whoosh")
        self.assertAlmostEqual(whoosh["start"] + 0.45 * (whoosh["length"] + whoosh["src_in"]), 5.0, places=1)
        self.assertTrue(all(a["start"] + a["length"] <= b["start"] + 1e-6 for a, b in zip(placed, placed[1:])))
        out = design.render(placed, 10.0, self.d / "fx.wav")
        self.assertTrue(out.exists())

    def test_sound_identity_per_client(self):
        from autocut.config import list_clients
        from autocut.sound import director
        root = TMP / "sound-clients" / "clients"
        if root.exists():
            shutil.rmtree(root)
        root.mkdir(parents=True)
        for b in ("lumen-dental", "ironclad-fitness", "saffron-sage", "pixelforge-labs", "harborline-realty"):
            shutil.copytree(ROOT / "tests" / "showcase" / "brands" / b, root / b)
        s = dict(load_settings(), clients_dir=str(root))
        ids = {}
        for f in list_clients(s):
            c = load_client(str(f), s)
            ids[c.slug] = director.identity(c, s)
            self.assertTrue((f / director.FILE).exists())
        self.assertEqual(ids["ironclad-fitness"]["style"], "sport")
        self.assertEqual(ids["pixelforge-labs"]["style"], "tech")
        self.assertEqual(ids["pixelforge-labs"]["flavour"], "digital")  # from its motion look (Mono Developer)
        self.assertEqual(len({(d["style"], d["key"]) for d in ids.values()}), 5)  # no two clients sound the same
        demo = load_client(str(EXAMPLES_DIR / "demo-roofing-co"), s)
        director.identity(demo, s)
        self.assertFalse((demo.folder / director.FILE).exists())  # the bundled demo is never written to
        b = director.brief(load_client(str(root / "ironclad-fitness"), s), s, "Your first week is free, book now", 20,
                           use_ai=False)
        self.assertEqual((b["style"], b["energy"]), ("sport", "high"))
        self.assertIn("instrumental", b["prompt"])

    def test_ai_music_through_a_local_api(self):
        """The ACE-Step REST flow (submit, poll, download, fit to length) against a stand-in server."""
        import http.server
        import socketserver
        from autocut.sound import aimusic, synth, composer
        wav = self.d / "ace-src.wav"
        synth.write_wav(wav, composer.compose({"style": "pop", "seed": 1}, 14)[0])
        seen = {}

        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _json(self, obj):
                body = json.dumps(obj).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self):
                if self.path == "/health":
                    return self._json({"ok": True})
                self.send_response(200)
                self.end_headers()
                self.wfile.write(wav.read_bytes())

            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                if self.path == "/release_task":
                    seen.update(body)
                    return self._json({"data": {"task_id": "t1", "status": "queued"}})
                return self._json({"data": [{"task_id": "t1", "status": 1,
                                             "result": json.dumps([{"file": "/v1/audio?path=%2Ftmp%2Fx.wav"}])}]})

        srv = socketserver.TCPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        try:
            ace = self.d / "ace-step"
            (ace / ".venv").mkdir(parents=True, exist_ok=True)
            (ace / "pyproject.toml").write_text("[project]\nname='x'\n")
            s = dict(load_settings(), music_ai={"engine": "auto", "url": f"http://127.0.0.1:{srv.server_address[1]}", "dir": str(ace)})
            self.assertTrue(aimusic.status(s)["running"])
            out = aimusic.generate({"prompt": "upbeat pop instrumental", "bpm": 118, "key": "D", "seed": 4}, 10.0, self.d / "ace.wav", s)
            self.assertEqual(out, self.d / "ace.wav")
            self.assertEqual((seen["lyrics"], seen["bpm"], seen["key_scale"], seen["seed"]), ("[Instrumental]", 118, "D Major", 4))
            dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(out)],
                                       capture_output=True, text=True).stdout)
            self.assertAlmostEqual(dur, 10.0, delta=0.1)
        finally:
            srv.shutdown()

    def test_timeline_audio_roles(self):
        from autocut.premiere_xml import Timeline
        tl = Timeline("t", 30, (1080, 1920))
        self.assertEqual(tl.audio_layout, "roles")
        p = tl.save(self.d / "tl.json")
        data = json.loads(p.read_text())
        del data["audio_layout"]
        p.write_text(json.dumps(data))
        self.assertEqual(Timeline.load(p).audio_layout, "stereo")  # timelines from before keep their old meaning


if __name__ == "__main__":
    unittest.main()


class EvolutionTests(unittest.TestCase):
    """Built to evolve: content packs, the catalog, migrations, the AI providers and signed updates with roll-back."""

    def test_signatures(self):
        from autocut import ed25519
        # RFC 8032 test vector 1
        seed = bytes.fromhex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60")
        self.assertEqual(ed25519.public_key(seed).hex(), "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a")
        self.assertEqual(ed25519.sign(seed, b"").hex()[:32], "e5564300c360ac729086e2cc806e828a")
        s2, pub = ed25519.keygen()
        sig = ed25519.sign(s2, b"feed")
        self.assertTrue(ed25519.verify(pub, b"feed", sig))
        self.assertFalse(ed25519.verify(pub, b"feeD", sig))
        self.assertFalse(ed25519.verify(pub, b"feed", sig[:-1] + bytes([sig[-1] ^ 1])))
        self.assertFalse(ed25519.verify(ed25519.public_key(seed), b"feed", sig))

    def test_builtin_pack_adds_working_content(self):
        import numpy as np
        from autocut import content, marketing
        from autocut.mograph.library import storyboards
        from autocut.mograph.library.looks import LOOKS
        from autocut.sound import composer, sfx
        from autocut.sound.director import STYLE_FITS
        content.reload()
        s = content.summary()
        pack = next(p for p in s["packs"] if p["id"] == "trends-2026-autumn")
        self.assertEqual(pack["problems"], [])
        self.assertIn("risograph", LOOKS)
        self.assertEqual(LOOKS["risograph"]["head"], ("Archivo Black", 400))
        self.assertEqual(LOOKS["aurora"]["panel"], "gradient")
        self.assertEqual(LOOKS["aurora"]["exit"], LOOKS["glass"]["exit"])  # inherited from its base
        self.assertIn("myth_fact", storyboards.RECIPES)
        self.assertEqual(sfx.LOOK_FLAVOUR["risograph"], "tape")
        self.assertIn("arcade", STYLE_FITS["synthwave"])
        mix, _ = composer.compose({"style": "synthwave", "seed": 2}, 6)
        self.assertGreater(float(np.sqrt(np.mean(mix ** 2))), 0.02)
        self.assertGreater(float(np.abs(sfx.make("whoosh", "tape", 1)).max()), 0.01)
        self.assertIn("Myth-vs-fact", marketing.knowledge("motion"))
        # the pack's storyboard plans with the rules (no AI) and every scene gets a real layout
        from autocut.config import load_client
        client = load_client(str(TMP / "clients" / "demo-roofing-co"), load_settings())
        plan = storyboards.plan("myth_fact", 'Myth "You need a new roof" fact "Most roofs just need a repair" 70%',
                                client, None)
        self.assertEqual([x["kind"] for x in plan["scenes"]], ["title", "title", "chart", "list", "end_card"])

    def test_pack_checks_install_switch_off_remove(self):
        from autocut import content
        from autocut.mograph.library.looks import LOOKS
        src = TMP / "packsrc" / "office"
        src.mkdir(parents=True, exist_ok=True)
        good = {"id": "office-pack", "name": "Office pack", "version": "1.2.0",
                "looks": {"tealbold": {"base": "swiss", "name": "Teal Bold", "speed": 1.2}},
                "music_styles": {"bossa": {"base": "acoustic", "name": "Bossa breeze", "bpm": 96}},
                "storyboards": {"quick_tip": {"name": "Quick tip", "slots": [["tip", "the tip", "Do this"], ["sub", "", ""]],
                                              "scenes": [{"kind": "title", "params": {"text": "{tip}"}},
                                                         {"kind": "end_card", "params": {"text": "Follow", "sub": "{sub}"}}]}},
                "knowledge": {"hooks": "Office rule: open on the result."}}
        (src / "pack.json").write_text(json.dumps(good))
        self.assertEqual(content.check_pack(src), [])
        bad = dict(good, looks={"corporate": {"name": "x"}, "weird": {"name": "Weird", "panel": "lava", "ease": "zoom"}},
                   storyboards={"broken": {"name": "B", "slots": [["a", "b", "c"]], "scenes": [{"kind": "title", "layouts": ["nope"]}]}},
                   music_styles={"loud": {"name": "Loud", "bpm": 400, "drums": {"1": {"cowbell": "x"}}}})
        badsrc = TMP / "packsrc" / "bad"
        badsrc.mkdir(parents=True, exist_ok=True)
        (badsrc / "pack.json").write_text(json.dumps(bad))
        problems = " | ".join(content.check_pack(badsrc))
        for frag in ("'corporate' is built in", "panel 'lava'", "ease must be", "no title layout nope", "bpm must be",
                     "drum 'cowbell'"):
            self.assertIn(frag, problems)
        with self.assertRaises(ValueError):
            content.install_pack(badsrc)  # nothing installed when it has problems
        self.assertNotIn("weird", LOOKS)
        out = content.install_pack(src)
        self.assertTrue((content.packs_dir() / "office-pack" / "pack.json").exists())
        self.assertIn("tealbold", LOOKS)
        from autocut import marketing
        self.assertIn("open on the result", marketing.knowledge("hooks"))
        self.assertEqual(LOOKS["tealbold"]["pack"], out["id"])
        content.set_enabled("office-pack", False)
        self.assertNotIn("tealbold", LOOKS)
        # a client using a pack look keeps it: while the pack is off the look it's built on stands in, nothing is lost
        from autocut.config import load_client
        from autocut.mograph.library import dna
        cl_dir = TMP / "clients" / "pack-client"
        shutil.copytree(TMP / "clients" / "demo-roofing-co", cl_dir, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns("ready", "footage", "incoming"))
        client = load_client(str(cl_dir), load_settings())
        (cl_dir / dna.FILE).write_text(json.dumps({"look": "tealbold", "look_base": "swiss", "layouts": {}}))
        d = dna.get(client, load_settings())
        self.assertEqual((d["look"], d["look_unavailable"]), ("swiss", "tealbold"))
        dna.save(client, dict(d, transition="iris"))  # an unrelated change while the pack is off
        self.assertEqual(json.loads((cl_dir / dna.FILE).read_text())["look"], "tealbold")
        self.assertNotIn("open on the result", marketing.knowledge("hooks"))
        content.set_enabled("office-pack", True)
        self.assertIn("tealbold", LOOKS)
        self.assertEqual(dna.get(client, load_settings())["look"], "tealbold")
        shutil.rmtree(cl_dir)
        content.remove_pack("office-pack")
        self.assertNotIn("tealbold", LOOKS)
        self.assertIn("corporate", LOOKS)
        # a zip with anything but data is refused
        import zipfile
        z = TMP / "packsrc" / "evil.zip"
        with zipfile.ZipFile(z, "w") as f:
            f.writestr("evil/pack.json", json.dumps(dict(good, id="evil")))
            f.writestr("evil/run.py", "print('hi')")
        with self.assertRaises(ValueError):
            content.install_pack(z)

    def test_catalog_drives_models_and_features(self):
        from autocut import brain, content
        self.assertEqual(brain.recommended_model(64), "gemma3:27b")
        self.assertEqual(brain.recommended_model(8), "gemma3:4b")
        self.assertEqual(brain.cfg({"ai": {"claude_model": "auto"}})["claude_model"], content.catalog()["ai"]["claude"]["default"])
        self.assertEqual(brain.cfg({"ai": {"claude_model": "my-pinned"}})["claude_model"], "my-pinned")
        self.assertEqual(brain.prices("unknown-model"), max((m["usd_in"], m["usd_out"]) for m in content.catalog()["ai"]["claude"]["models"].values()))
        # a pack can add a new local-model tier and an experiment switch
        d = content.packs_dir() / "models-next"
        d.mkdir(parents=True, exist_ok=True)
        (d / "pack.json").write_text(json.dumps({"id": "models-next", "name": "Next models", "catalog": {
            "ai": {"local": {"tiers": [{"min_gb": 96, "model": "nextmodel:70b"}, {"min_gb": 48, "model": "gemma3:27b"},
                                       {"min_gb": 20, "model": "gemma3:12b"}, {"min_gb": 0, "model": "gemma3:4b"}]}},
            "features": {"try_this": {"default": True, "label": "Try this"}}}}))
        try:
            content.reload()
            self.assertEqual(brain.recommended_model(128), "nextmodel:70b")
            self.assertTrue(content.feature({}, "try_this"))
            self.assertFalse(content.feature({"features": {"try_this": False}}, "try_this"))
        finally:
            shutil.rmtree(d)
            content.reload()
        self.assertEqual(brain.recommended_model(128), "gemma3:27b")

    def test_openai_compatible_provider(self):
        from http.server import BaseHTTPRequestHandler, HTTPServer
        from autocut import brain
        seen = []

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, obj):
                b = json.dumps(obj).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

            def do_GET(self):
                self._send({"data": [{"id": "local-llm"}]})

            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                seen.append(body)
                if "response_format" in body:  # like a server that doesn't take JSON schemas
                    self.send_response(400)
                    self.end_headers()
                    return
                self._send({"choices": [{"message": {"content": '```json\n{"title": "Hi"}\n```'}}]})

        srv = HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        try:
            st = {"ai": {"local_url": "http://127.0.0.1:9", "openai_url": f"http://127.0.0.1:{srv.server_port}/v1",
                         "claude_backup": False}}
            out = brain.ask(st, "sys", "write a title", schema={"type": "object", "properties": {"title": {"type": "string"}},
                                                                "required": ["title"]})
            self.assertEqual(out, {"title": "Hi"})
            self.assertEqual(brain.last_engine(), "compatible")
            self.assertEqual(seen[-1]["model"], "local-llm")
            self.assertTrue(brain.status(st)["compatible"]["running"])
        finally:
            srv.shutdown()

    def test_migrations_and_whats_new(self):
        from autocut import __version__, migrations
        migrations.STATE_FILE.write_text(json.dumps({"version": "0.19.0"}))
        r = migrations.run(load_settings(), log=lambda *a: None)
        self.assertEqual(r["from"], "0.19.0")
        self.assertTrue((TMP / "packs").is_dir())
        wn = migrations.whats_new()
        self.assertEqual(wn["since"], "0.19.0")
        vs = [s["version"] for s in wn["sections"]]
        self.assertEqual(vs[0], __version__)
        self.assertEqual(vs[-1], "0.20.0")  # everything after 0.19.0, newest first
        self.assertTrue(all(s["items"] for s in wn["sections"]))
        self.assertEqual(migrations.run(load_settings(), log=lambda *a: None)["ran"], [])  # each runs once
        migrations.dismiss_whats_new()
        self.assertEqual(migrations.whats_new()["sections"], [])

    def test_signed_update_install_and_rollback(self):
        """A fake installed AutoCut gets a signed update from a feed folder, is self-tested, swapped and rolled back;
        a tampered download, a wrong key and an older version are all refused."""
        import hashlib
        import zipfile
        from autocut import __version__, ed25519, updates
        base = TMP / "upd"
        shutil.rmtree(base, ignore_errors=True)
        inst, feed_dir = base / "AutoCut", base / "feed"
        feed_dir.mkdir(parents=True)
        inst.mkdir()
        for name in ("autocut", "requirements.txt", "CHANGELOG.md", "settings.yaml", "templates", "examples"):
            src = ROOT / name
            (shutil.copytree(src, inst / name, ignore=shutil.ignore_patterns("__pycache__", "ready", "footage"))
             if src.is_dir() else shutil.copy2(src, inst / name))
        (inst / ".venv").mkdir()
        (inst / ".venv" / "keep.txt").write_text("mine")
        (inst / "my-notes.txt").write_text("the user's own file")
        # the new release: same code, newer version, one new file
        new = base / "build" / "AutoCut"
        shutil.copytree(inst, new, ignore=shutil.ignore_patterns(".venv", "my-notes.txt"))
        init = new / "autocut" / "__init__.py"
        init.write_text(init.read_text().replace(f'"{__version__}"', '"99.0.0"'))
        (new / "NEW-IN-99.txt").write_text("hello")
        z = feed_dir / "AutoCut-update-99.0.0.zip"
        with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as f:
            for p in new.rglob("*"):
                if p.is_file():
                    f.write(p, p.relative_to(new).as_posix())
        seed, pub = ed25519.keygen()
        keyfile = base / "release_key.pub"
        keyfile.write_text(pub.hex() + "\n")

        def publish(version="99.0.0", sha=None, key=seed):
            body = json.dumps({"app": "autocut", "channels": {"stable": {
                "version": version, "url": z.name, "sha256": sha or hashlib.sha256(z.read_bytes()).hexdigest(),
                "notes": ["Big things"]}}, "packs": []}).encode()
            (feed_dir / "feed.json").write_bytes(body)
            (feed_dir / "feed.json.sig").write_text(ed25519.sign(key, body).hex())

        saved = (updates.ROOT, updates.WORK, updates.MANIFEST, updates.KEY_FILE)
        updates.ROOT, updates.WORK, updates.MANIFEST = inst, inst / ".autocut-updates", inst / ".autocut-manifest.json"
        updates.KEY_FILE = keyfile
        settings = {"updates": {"feed_url": str(feed_dir / "feed.json"), "channel": "stable"}}
        try:
            publish(key=ed25519.keygen()[0])  # signed by someone else
            st = updates.check(settings, force=True)
            self.assertFalse(st["available"])
            self.assertIn("isn't signed", st["error"])
            publish(version="0.0.1")  # an old (replayed) release
            self.assertFalse(updates.check(settings, force=True)["available"])
            publish(sha="0" * 64)  # the zip doesn't match the signed checksum
            r = updates.install_latest(settings, log=lambda *a: None)
            self.assertFalse(r["ok"])
            self.assertIn("doesn't match", r["error"])
            self.assertIn(__version__, (inst / "autocut" / "__init__.py").read_text())
            publish()
            st = updates.check(settings, force=True)
            self.assertTrue(st["available"])
            self.assertEqual(st["latest"], "99.0.0")
            r = updates.install_latest(settings, log=lambda *a: None)
            self.assertTrue(r["ok"], r)
            self.assertIn('"99.0.0"', (inst / "autocut" / "__init__.py").read_text())
            self.assertTrue((inst / "NEW-IN-99.txt").exists())
            self.assertEqual((inst / ".venv" / "keep.txt").read_text(), "mine")  # never touched
            self.assertEqual((inst / "my-notes.txt").read_text(), "the user's own file")
            vs = updates.rollback_versions()
            self.assertEqual(vs[0]["version"], __version__)
            r = updates.rollback(settings, log=lambda *a: None)
            self.assertTrue(r["ok"], r)
            self.assertIn(f'"{__version__}"', (inst / "autocut" / "__init__.py").read_text())
            self.assertFalse((inst / "NEW-IN-99.txt").exists())  # the new version's files went with it
            self.assertEqual(updates.rollback_versions()[0]["version"], "99.0.0")  # and it can come back
            # a release that fails its own self-test never replaces the working one
            init.write_text(init.read_text().replace('"99.0.0"', '"99.1.0"') + "\nraise SystemExit('broken')\n")
            with zipfile.ZipFile(z, "w") as f:
                for p in new.rglob("*"):
                    if p.is_file():
                        f.write(p, p.relative_to(new).as_posix())
            publish(version="99.1.0")
            r = updates.install_latest(settings, log=lambda *a: None)
            self.assertFalse(r["ok"])
            self.assertIn("self-test", r["error"])
            self.assertIn(f'"{__version__}"', (inst / "autocut" / "__init__.py").read_text())
        finally:
            updates.ROOT, updates.WORK, updates.MANIFEST, updates.KEY_FILE = saved

    def test_selftest_and_update_api(self):
        from autocut import selftest
        r = selftest.run()
        self.assertTrue(r["ok"], r)
        from autocut.app import App
        app = App()
        st = app.updates_state()
        self.assertEqual(st["mode"] if st["mode"] != "git" else "manual", "manual")  # no feed set in the tests
        self.assertIn("trends-2026-autumn", [p["id"] for p in st["content"]["packs"]])
        self.assertIn("claude_default", st["models"])
        app.set_local("updates", {"channel": "beta"})
        self.assertEqual(app.settings["updates"]["channel"], "beta")
        self.assertEqual(load_settings()["machine_name"], "test-mac")  # the rest of the settings file is kept
        app.set_local("updates", {"channel": "stable"})


class OwnHardwareAndMirrorTests(unittest.TestCase):
    """Each person's own computer sets its own heavy settings; updates survive any one host being gone."""

    def test_hardware_classes_and_picks(self):
        from autocut import hardware
        base = {"os": "mac", "chip": "x", "cores": 8, "memory_gb": 8.0, "nvidia": None, "apple_silicon": True,
                "encoder": "h264_videotoolbox", "hardware_encoder": True, "disk_free_gb": 300, "disk_path": "/"}
        air = dict(base)
        studio = dict(base, cores=20, memory_gb=64.0)
        pc = dict(base, os="windows", apple_silicon=False, cores=4, memory_gb=7.8, encoder="libx264", hardware_encoder=False)
        gamer = dict(pc, cores=16, memory_gb=31.9, nvidia={"name": "RTX 4070", "vram_gb": 12.0})
        self.assertEqual([hardware.tier(x) for x in (air, studio, pc, gamer)], ["light", "pro", "light", "pro"])
        self.assertEqual(hardware.tier(dict(base, memory_gb=15.8)), "standard")  # a 16 GB machine reports a bit less
        self.assertEqual(hardware.recommend(studio)["whisper_model"], "large-v3-turbo")
        self.assertEqual(hardware.recommend(pc)["whisper_model"], "small")
        self.assertEqual(hardware.recommend(dict(pc, cores=12, memory_gb=16))["whisper_model"], "medium")
        self.assertTrue(hardware.recommend(gamer)["ai_music"])
        self.assertFalse(hardware.recommend(pc)["ai_music"])
        self.assertEqual(hardware.whisper_model({"model": "large-v3"}), "large-v3")  # set by hand wins
        s = hardware.summary(load_settings())
        self.assertIn(s["tier"], hardware.TIERS)
        self.assertIn(s["settings"]["whisper_model"], ("small", "medium", "large-v3-turbo"))
        b = hardware.benchmark(load_settings())
        self.assertGreater(b["encode_fps"], 0)
        self.assertLess(b["ten_minute_video_min"][0], b["ten_minute_video_min"][1])
        self.assertEqual(hardware.cached()["benchmark"], b)

    def _feed(self, folder: Path, seed: bytes, version: str = "99.0.0"):
        import hashlib
        import zipfile
        from autocut import ed25519
        folder.mkdir(parents=True, exist_ok=True)
        z = folder / f"AutoCut-update-{version}.zip"
        with zipfile.ZipFile(z, "w") as f:
            f.writestr("autocut/__init__.py", f'__version__ = "{version}"\n')
        body = json.dumps({"app": "autocut", "channels": {"stable": {"version": version, "url": z.name,
                           "sha256": hashlib.sha256(z.read_bytes()).hexdigest()}}, "packs": []}).encode()
        (folder / "feed.json").write_bytes(body)
        (folder / "feed.json.sig").write_text(ed25519.sign(seed, body).hex())
        return z

    def test_mirror_used_when_the_main_address_is_down_and_bad_mirrors_ignored(self):
        from autocut import ed25519, updates
        base = TMP / "mirrors"
        shutil.rmtree(base, ignore_errors=True)
        seed, pub = ed25519.keygen()
        evil = self._feed(base / "evil", ed25519.keygen()[0], "98.0.0")
        good = self._feed(base / "nas", seed)
        keyfile = base / "k.pub"
        keyfile.write_text(pub.hex())
        saved = updates.KEY_FILE
        updates.KEY_FILE = keyfile
        try:
            st = {"updates": {"feed_url": "https://127.0.0.1:9/feed.json",
                              "mirrors": [str(base / "evil" / "feed.json"), str(base / "nas" / "feed.json")]}}
            self.assertEqual(updates.sources(st)[0], "https://127.0.0.1:9/feed.json")
            feed = updates.read_feed(st)  # main down, first mirror wrongly signed → the NAS copy
            self.assertEqual(feed["_source"], str(base / "nas" / "feed.json"))
            got = updates._download(st, feed, feed["channels"]["stable"], base / "dl.zip", 10)
            self.assertEqual(got.read_bytes(), good.read_bytes())
            # a mirror whose file was swapped is skipped
            good.write_bytes(evil.read_bytes())
            with self.assertRaises(ValueError):
                updates._download(st, feed, feed["channels"]["stable"], base / "dl2.zip", 10)
            with self.assertRaises(ValueError) as e:
                updates.read_feed({"updates": {"feed_url": str(base / "evil" / "feed.json")}})
            self.assertIn("isn't signed", str(e.exception))
        finally:
            updates.KEY_FILE = saved

    def test_synology_mirror_script(self):
        from autocut import ed25519
        base = TMP / "nasmirror"
        shutil.rmtree(base, ignore_errors=True)
        seed, pub = ed25519.keygen()
        self._feed(base / "src", seed)
        kit = base / "kit"
        kit.mkdir()
        shutil.copy2(ROOT / "tools" / "mirror_feed.py", kit)
        shutil.copy2(ROOT / "autocut" / "ed25519.py", kit)
        (kit / "release_key.pub").write_text(pub.hex())
        run = lambda: subprocess.run(["python3", "-I", str(kit / "mirror_feed.py"), str(base / "src" / "feed.json"),  # noqa: E731
                                      str(base / "out")], capture_output=True, text=True)
        r = run()
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertEqual((base / "out" / "feed.json").read_bytes(), (base / "src" / "feed.json").read_bytes())
        self.assertTrue((base / "out" / "AutoCut-update-99.0.0.zip").exists())
        self.assertIn("up to date", run().stdout)
        (kit / "release_key.pub").write_text(ed25519.keygen()[1].hex())  # a different key: nothing copied
        (base / "src" / "feed.json").write_bytes((base / "src" / "feed.json").read_bytes() + b" ")
        self.assertEqual(run().returncode, 1)


class AccountsAndConnectorTests(unittest.TestCase):
    """People's own ChatGPT / Grok / Claude accounts, and AutoCut as an MCP connector inside AI apps."""

    @classmethod
    def setUpClass(cls):
        import base64
        from http.server import BaseHTTPRequestHandler, HTTPServer
        cls.seen = []
        png = base64.b64encode(b"\x89PNG\r\n\x1a\n" + b"0" * 64).decode()

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, code, obj):
                b = json.dumps(obj).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

            def do_GET(self):
                if self.headers.get("Authorization") != "Bearer sk-good":
                    return self._send(401, {"error": {"message": "bad key"}})
                self._send(200, {"data": [{"id": x} for x in ("gpt-4o", "gpt-5.5", "gpt-5.5-mini", "gpt-5.5-2026-06-01",
                                                               "gpt-image-1", "text-embedding-3", "whisper-1")]})

            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                cls.seen.append((self.path, body))
                if self.path.endswith("/images/generations"):
                    return self._send(200, {"data": [{"b64_json": png}]})
                text = '{"title": "Storm-proof your roof"}' if "response_format" in body else "ready"
                self._send(200, {"choices": [{"message": {"content": text}}], "usage": {"prompt_tokens": 1000, "completion_tokens": 500}})

        cls.srv = HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        from autocut import content
        cls.saved = json.loads(json.dumps(content.catalog()["ai"]["accounts"]))
        for pid in ("chatgpt", "grok"):
            content.catalog()["ai"]["accounts"][pid]["base"] = f"http://127.0.0.1:{cls.srv.server_port}/v1"

    @classmethod
    def tearDownClass(cls):
        from autocut import content
        content.catalog()["ai"]["accounts"].update(cls.saved)
        cls.srv.shutdown()

    def test_auto_model_ask_cap_and_images(self):
        from autocut import accounts, brain
        st = {"ai": {"local_url": "http://127.0.0.1:9", "chatgpt_api_key": "sk-good", "claude_backup": True,
                     "cloud_order": ["chatgpt", "claude", "grok"]}}
        self.assertEqual(accounts.model(st, "chatgpt"), "gpt-5.5")  # the best one it has; not mini, not dated
        self.assertEqual(accounts.image_model(st, "chatgpt"), "gpt-image-1")
        schema = {"type": "object", "properties": {"title": {"type": "string"}}, "required": ["title"]}
        out = brain.ask(st, "sys", "a title please", schema)
        self.assertEqual(out, {"title": "Storm-proof your roof"})
        self.assertEqual(brain.last_engine(), "chatgpt")
        path, body = self.seen[-1]
        self.assertEqual((path, body["model"], body["response_format"]["json_schema"]["strict"]), ("/v1/chat/completions", "gpt-5.5", True))
        by = brain.usage()["by"]["chatgpt"]
        self.assertGreater(by["usd"], 0)
        t = accounts.test(st, "chatgpt")
        self.assertTrue(t["ok"], t)
        self.assertFalse(accounts.test(dict(st, ai={**st["ai"], "chatgpt_api_key": "sk-bad"}), "chatgpt")["ok"])
        # monthly cap: over it, the account steps aside
        capped = {"ai": {**st["ai"], "chatgpt_monthly_limit_usd": 0}}
        self.assertFalse(accounts.available(capped, "chatgpt")[0])
        self.assertIsNone(brain.ask(capped, "sys", "x", schema))
        # images from the account, into the client's media library, on a computer without the local image model
        from autocut import aiimage
        from autocut.config import load_client
        tmpc = TMP / "img-client" / "demo-roofing-co"  # its own copy: the fake image mustn't reach other tests' media
        shutil.copytree(TMP / "clients" / "demo-roofing-co", tmpc, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns("ready", "footage", "incoming"))
        try:
            client = load_client(str(tmpc), load_settings())
            if not aiimage.engine():
                p = aiimage.generate(client, "a roofer giving a thumbs up", settings=st)
                self.assertTrue(p.exists())
                self.assertTrue(p.read_bytes().startswith(b"\x89PNG"))
                self.assertEqual(self.seen[-1][1]["size"], "1024x1024")
        finally:
            shutil.rmtree(tmpc.parent, ignore_errors=True)
        st2 = accounts.status(st)
        self.assertTrue(st2["chatgpt"]["connected"])
        self.assertNotIn("sk-good", json.dumps(st2))  # keys never leave masked
        self.assertFalse(st2["grok"]["connected"])

    def test_prefer_cloud_order(self):
        from autocut import brain
        st = {"ai": {"local_url": "http://127.0.0.1:9", "grok_api_key": "sk-good", "cloud_order": ["claude", "grok", "chatgpt"]}}
        self.assertEqual(brain.ask(st, "s", "hi", prefer="cloud"), "ready")
        self.assertEqual(brain.last_engine(), "grok")  # Claude has no key here, so the next account answers
        st["ai"]["claude_backup"] = False
        self.assertIsNone(brain.ask(st, "s", "hi"))  # cloud backup off: only local (not running here)

    def test_mcp_protocol_and_tools(self):
        import io
        from autocut import mcp
        settings = load_settings()
        lines = [{"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-03-26"}},
                 {"jsonrpc": "2.0", "method": "notifications/initialized"},
                 {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
                 {"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {"name": "list_clients", "arguments": {}}},
                 {"jsonrpc": "2.0", "id": 4, "method": "tools/call", "params": {"name": "nope"}},
                 {"jsonrpc": "2.0", "id": 5, "method": "bogus"}]
        out = io.StringIO()
        mcp.serve(io.StringIO("\n".join(json.dumps(x) for x in lines) + "\n"), out)
        res = [json.loads(x) for x in out.getvalue().splitlines()]
        self.assertEqual([r["id"] for r in res], [1, 2, 3, 4, 5])  # the notification gets no answer
        self.assertEqual(res[0]["result"]["protocolVersion"], "2025-03-26")
        self.assertIn("queue_videos", [t["name"] for t in res[1]["result"]["tools"]])
        self.assertIn("demo-roofing-co", res[2]["result"]["content"][0]["text"])
        self.assertEqual(res[3]["error"]["code"], -32602)
        self.assertEqual(res[4]["error"]["code"], -32601)
        # queue footage by client name, with a hook; copies arrive whole (dot-file first)
        r = mcp.handle({"jsonrpc": "2.0", "id": 9, "method": "tools/call", "params": {"name": "queue_videos", "arguments": {
            "client": "Demo Roofing Co", "paths": [str(EXAMPLES_DIR / "demo-roofing-co/sample/test-take-01.mp4")], "hook": "Hail damage?"}}}, settings)
        self.assertFalse(r["result"].get("isError"), r)
        inc = TMP / "clients" / "demo-roofing-co" / "incoming"
        name = r["result"]["structuredContent"]["queued"][0]
        self.assertTrue((inc / name).exists())
        self.assertEqual(json.loads((inc / (name + ".autocut.json")).read_text())["hook"], "Hail damage?")
        (inc / name).unlink()
        (inc / (name + ".autocut.json")).unlink()
        r = mcp.handle({"jsonrpc": "2.0", "id": 10, "method": "tools/call", "params": {"name": "queue_videos", "arguments": {"client": "Nobody", "paths": []}}}, settings)
        self.assertTrue(r["result"]["isError"])
        # the dashboard isn't running in this test: a plain message, not a crash
        r = mcp.handle({"jsonrpc": "2.0", "id": 11, "method": "tools/call", "params": {"name": "autocut_status"}},
                       dict(settings, port=9))
        self.assertIn("isn't open", r["result"]["content"][0]["text"])

    def test_claude_desktop_setup_keeps_other_connectors(self):
        from autocut import mcp
        f = TMP / "Claude" / "claude_desktop_config.json"
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(json.dumps({"mcpServers": {"other": {"command": "x"}}, "theme": "dark"}))
        saved = mcp.claude_desktop_config
        mcp.claude_desktop_config = lambda: f
        try:
            mcp.install_claude_desktop()
            data = json.loads(f.read_text())
            self.assertEqual(set(data["mcpServers"]), {"other", "autocut"})
            self.assertEqual(data["theme"], "dark")
            self.assertEqual(data["mcpServers"]["autocut"]["args"][-2:], ["autocut", "mcp"])
            self.assertTrue(f.with_name(f.name + ".autocut-backup").exists())
            self.assertTrue(mcp.info(load_settings())["claude_desktop"]["added"])
        finally:
            mcp.claude_desktop_config = saved


class MotionFeelTests(unittest.TestCase):
    """After Effects-style easing: bezier speed curves plus scale / rotation / glow / shadow layers on every graphic."""

    def test_feels_defaults_and_overrides(self):
        from autocut.mograph import feel
        from autocut.mograph.library import looks
        self.assertEqual(feel.pick(looks.get("brutal")), "punchy")
        self.assertEqual(feel.pick(looks.get("playful")), "elastic")
        self.assertEqual(feel.pick(looks.get("corporate"), "bouncy"), "bouncy")  # a chosen feel wins
        self.assertEqual(feel.pick({"key": "aurora", "base": "glass"}), "glow")  # a pack look inherits its base's
        self.assertEqual(feel.pick({"key": "x", "feel": "cinematic"}), "cinematic")
        for k, f in feel.FEELS.items():
            for curve in ("inn", "out", "io"):
                self.assertEqual(len(f[curve]), 4, k)
                self.assertTrue(0 <= f[curve][0] <= 1 and 0 <= f[curve][2] <= 1, k)  # x handles stay in range

    def test_the_kit_carries_the_feel(self):
        from autocut.config import load_client
        from autocut.mograph.library import build
        client = load_client(str(EXAMPLES_DIR / "demo-roofing-co"), load_settings())
        proj = TMP / "feel-el"
        build.build_element("title", "boxed", "corporate", client, (1080, 1920), proj, {"text": "Hello *there*"}, feel="bouncy")
        page = (proj / "index.html").read_text()
        self.assertIn('"inn": [0.34, 1.56, 0.64, 1]', page)  # the bouncy overshoot curve
        self.assertIn("function feel(", page)
        self.assertIn(".fe {", page)
        self.assertIn("--fu:", page)
        self.assertNotIn("ease: L.ease", page)
        build.build_element("title", "boxed", "corporate", client, (1080, 1920), proj, {"text": "Hello"})
        self.assertIn('"inn": [0.22, 1, 0.36, 1]', (proj / "index.html").read_text())  # corporate's own: smooth

    def test_prompts_name_a_feel(self):
        from autocut.mograph.prompt import rule_parse
        self.assertEqual(rule_parse("a bouncy lower third for Jane Doe, CEO").get("feel"), "bouncy")
        self.assertEqual(rule_parse("lower third Jane Doe, CEO with a glowing finish").get("feel"), "glow")
        self.assertIsNone(rule_parse("lower third Jane Doe, CEO").get("feel"))

    def test_pack_looks_may_name_a_feel(self):
        from autocut import content
        content.ensure_loaded()
        _, errs = content._check_look("feelok", {"base": "glass", "name": "Feel OK", "feel": "elastic"})
        self.assertEqual(errs, [])
        _, errs = content._check_look("feelbad", {"base": "glass", "name": "Feel Bad", "feel": "wobbly"})
        self.assertTrue(any("feel must be" in e for e in errs))


class FirstRunAndResultsTests(unittest.TestCase):
    """Brand kit from a website, the monthly results summary and the Getting started checklist."""

    @classmethod
    def setUpClass(cls):
        from http.server import HTTPServer, SimpleHTTPRequestHandler
        import functools
        site = ROOT / "tests" / "fixtures" / "site"

        class Quiet(SimpleHTTPRequestHandler):
            def log_message(self, *a):
                pass
        cls.srv = HTTPServer(("127.0.0.1", 0), functools.partial(Quiet, directory=str(site)))
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.url = f"http://127.0.0.1:{cls.srv.server_port}/"

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def test_scan_a_website_into_a_client(self):
        from autocut import brandscan
        from autocut.config import load_client
        st = dict(load_settings(), ai={"local_url": "http://127.0.0.1:9", "claude_backup": False})
        saved = brandscan.download_google_font
        brandscan.download_google_font = lambda fam, dest: []  # no internet in the tests
        try:
            p = brandscan.scan(self.url, st, TMP / "scan-site")
        finally:
            brandscan.download_google_font = saved
        self.assertEqual(p["name"], "Bayview Pediatric Dental")
        self.assertEqual(p["colors"]["primary"], "#14A3A1")  # the theme colour
        self.assertEqual(p["colors"]["secondary"], "#0D3B4C")  # the dark brand colour, not grey text
        self.assertEqual((p["fonts"]["headline"], p["fonts"]["caption"]), ("Fredoka", "Nunito"))
        self.assertTrue(p["logo"].endswith("logo.png"))
        self.assertEqual(p["marketing"]["location"], "Tampa, FL")
        self.assertEqual(p["cta"]["text"], "Book a Visit")
        self.assertEqual(p["phone"], "+1-813-555-0142")
        self.assertIn("instagram", p["socials"])
        self.assertIn("Amara Okafor", p["vocabulary"])
        self.assertEqual(p["via"], "rules")
        self.assertTrue(any("couldn't download" in n for n in p["notes"]))
        d = brandscan.create(dict(p, name="Bayview Test Dental"), st)
        try:
            client = load_client(str(d), st)
            b = client.brand
            self.assertEqual(b["colors"]["primary"], "#14A3A1")
            self.assertEqual(b["fonts"]["headline"], "Fredoka")
            self.assertEqual(b["logo"]["file"], "assets/logo/logo.png")
            self.assertTrue((d / "assets/logo/logo.png").exists())
            self.assertEqual(b["marketing"]["industry"], "dentist")
            self.assertEqual(b["website"], self.url)
            self.assertIn("BRAND PROFILE", (d / "brand.yaml").read_text())  # the template's comments are kept
        finally:
            shutil.rmtree(d)
        with self.assertRaises(ValueError):
            brandscan.scan("http://127.0.0.1:9/nothing", st, TMP / "scan-none")

    def test_month_results_and_popup(self):
        from autocut import results, migrations
        settings = load_settings()
        job = TMP / "clients" / "demo-roofing-co" / "ready" / "results-job"
        job.mkdir(parents=True, exist_ok=True)
        last = results._prev(time.strftime("%Y-%m"))
        (job / "status.json").write_text(json.dumps({"state": "done", "finished": f"{last}-15T10:00:00"}))
        (job / "job.json").write_text(json.dumps({"source_seconds": 600, "processing_seconds": 300}))
        clip = TMP / "clients" / "demo-roofing-co" / "ready" / "results-clip"
        clip.mkdir(parents=True, exist_ok=True)
        (clip / "status.json").write_text(json.dumps({"state": "done", "finished": f"{last}-16T10:00:00"}))
        (clip / "options.json").write_text(json.dumps({"clip": {"start": 1, "end": 30}}))
        try:
            m = results.month(settings, last)
            self.assertEqual(m["counts"].get("rough_cuts"), 1)
            self.assertEqual(m["counts"].get("clips"), 1)
            self.assertEqual(m["videos"], 2)
            self.assertAlmostEqual(m["hours_saved"], round((10 * float(settings["minutes_saved_per_footage_minute"]) + 15) / 60, 1))
            self.assertEqual(m["turnaround_minutes"], 5.0)
            self.assertEqual(m["top_clients"][0][1], 2)
            st = migrations.state()
            st.pop("results_seen", None)
            migrations._save(st)
            self.assertEqual(results.popup(settings)["month"], last)
            results.seen(last)
            self.assertIsNone(results.popup(settings))  # once
        finally:
            shutil.rmtree(job)
            shutil.rmtree(clip)

    def test_getting_started_and_welcome(self):
        from autocut import onboarding
        settings = load_settings()
        onboarding.update(welcomed=False, hidden=False)
        o = onboarding.info(settings)
        self.assertFalse(o["welcomed"])
        self.assertEqual(o["total"], 5)
        self.assertEqual([s["key"] for s in o["steps"]][:2], ["client", "video"])
        onboarding.update(welcomed=True, hidden=True)
        o = onboarding.info(settings)
        self.assertTrue(o["welcomed"] and o["hidden"])


class ExplainerAndStatsTests(unittest.TestCase):
    """The Explainer split edit style (speaker panel + explaining graphics), and the opt-in shared monthly totals."""
    SCRIPT = ("Here's the roof checklist we use on every single storm call. It cost me $2,500 to build, and I'm giving it "
              "to you for free. First, check the shingles for dark spots and missing granules. Next, look in the gutters "
              "for piles of grit. Finally, walk the attic with a flashlight and look for daylight. Hi, I'm Jordan Reyes, "
              "and I've been fixing roofs in Denver for twelve years. Comment checklist and I'll send it over.")

    def _words(self):
        from autocut.mograph import script
        return script.pace(self.SCRIPT)

    def test_caption_groups(self):
        from autocut.mograph import explainer
        gs = explainer.caption_groups(self._words())
        self.assertTrue(all(1 <= len(g) <= 3 for g in gs))
        self.assertEqual(sum(len(g) for g in gs), len(self._words()))
        self.assertTrue(all(len(g) > 1 or g[0]["word"].endswith((".", ",", "!", "?")) or k == 0 for k, g in enumerate(gs)))

    def test_plan_finds_every_element(self):
        from PIL import Image
        from autocut.mograph import explainer
        graphic = TMP / "roof-checklist.png"
        Image.new("RGB", (400, 240), "#ffffff").save(graphic)
        sc = explainer.plan(self._words(), [graphic], {"edit": {}})
        kinds = [s["kind"] for s in sc]
        self.assertEqual(kinds, ["media", "interlude", "step", "step", "step", "intro", "card"])
        self.assertEqual(sc[0]["image"], graphic)
        inter = sc[1]
        self.assertTrue(inter["strike"])  # $2,500 … free: struck through with a FREE badge
        self.assertEqual(explainer.clean(inter["words"][inter["badge"]]["word"]).lower(), "free")
        self.assertEqual(explainer.clean(inter["words"][inter["num"]]["word"]), "$2,500")
        self.assertEqual([s["label"] for s in sc[2:5]], ["Shingles", "Gutters", "Attic"])
        self.assertEqual(sc[5]["name"], "Jordan Reyes")
        self.assertIn("twelve", " ".join(w["word"] for w in sc[5]["words"]))  # the name card holds through its sentence
        # no "I'm giving" name card, no interlude in the opening sentence
        self.assertEqual(sum(s["kind"] == "intro" for s in sc), 1)

    def test_build_composition(self):
        from autocut.mograph import explainer
        settings = load_settings()
        client = load_client("demo-roofing-co", settings)
        take = TMP / "explainer-take.mp4"
        subprocess.run(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "color=c=#3366aa:s=540x960:d=1",
                        "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo", "-t", "1", "-c:v", "libx264", "-pix_fmt", "yuv420p",
                        "-c:a", "aac", str(take)], check=True)
        pop = TMP / "explainer-cut.webm"
        pop.write_bytes(b"\x1aE\xdf\xa3")  # stands in for the cut-out
        words = self._words()
        sc = explainer.plan(words, [], client.brand)
        proj = TMP / "hf-explainer"
        total = explainer.build(words, sc, client, (1080, 1920), proj, settings, take, words[-1]["end"] + 1, (0.2, 0.5), pop,
                                band=(10, 200))
        page = (proj / "index.html").read_text()
        self.assertAlmostEqual(total, words[-1]["end"] + 0.6, places=2)
        self.assertIn('src="assets/take.mp4"', page)
        self.assertIn("muted", page)
        self.assertIn('id="pop"', page)
        self.assertIn('class="track"', page)
        self.assertEqual(page.count('class="dot"'), 3)
        self.assertIn('class="badge"', page)
        self.assertIn('class="card intro"', page)
        self.assertIn("Demo Roofing", page)
        self.assertNotIn("#808080", page.lower())
        ev = json.loads((proj / "events.json").read_text())
        self.assertTrue({"slam", "graphic", "sticker"} <= {e["kind"] for e in ev})
        # no pop-out: nothing refers to it
        explainer.build(words, sc, client, (1080, 1920), proj, settings, take, words[-1]["end"] + 1, (0.2, 0.5), None)
        self.assertNotIn('id="pop"', (proj / "index.html").read_text())
        g = explainer.geometry((1080, 1920), (1080, 1920), (0.2, 0.5))
        self.assertLess(g["y0"], g["oy"] / g["s"])  # the band starts above the panel edge
        self.assertGreater(g["y1"] - g["y0"], 100)

    def test_explainer_needs_a_video(self):
        from autocut.mograph import explainer
        settings = load_settings()
        client = load_client("demo-roofing-co", settings)
        src = TMP / "notes.txt"
        src.write_text("hello there")
        with self.assertRaises(ValueError):
            explainer.make_video(src, client, (1080, 1920), TMP / "x.mp4", settings)

    def test_stats_opt_in_only_and_numbers_only(self):
        from http.server import BaseHTTPRequestHandler, HTTPServer
        from autocut import migrations, results, stats
        got = []

        class H(BaseHTTPRequestHandler):
            def do_POST(self):
                got.append(json.loads(self.rfile.read(int(self.headers["Content-Length"]))))
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"ok")

            def log_message(self, *a):
                pass
        srv = HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        settings = dict(load_settings(), stats_url=f"http://127.0.0.1:{srv.server_port}/")
        last = results._prev(time.strftime("%Y-%m"))
        job = TMP / "clients" / "demo-roofing-co" / "ready" / "stats-job"
        job.mkdir(parents=True, exist_ok=True)
        (job / "status.json").write_text(json.dumps({"state": "done", "finished": f"{last}-10T10:00:00"}))
        (job / "job.json").write_text(json.dumps({"source_seconds": 300, "processing_seconds": 120}))
        st = migrations.state()
        for k in ("stats_share", "stats_sent", "stats_name", "stats_agency"):
            st.pop(k, None)
        migrations._save(st)
        try:
            self.assertIsNone(stats.maybe_send(settings))  # never asked: nothing goes
            self.assertEqual(got, [])
            stats.consent(False)
            self.assertIsNone(stats.maybe_send(settings))
            stats.consent(True)
            r = stats.maybe_send(settings)
            self.assertEqual(len(got), 1)
            self.assertEqual(got[0]["month"], last)
            self.assertGreaterEqual(got[0]["videos"], 1)
            self.assertEqual(got[0]["avg_turnaround_minutes"], 2.0)
            self.assertNotIn("agency", got[0])
            blob = json.dumps(got[0]).lower()
            self.assertNotIn("demo", blob)  # no client names
            self.assertNotIn("stats-job", blob)  # no video names
            self.assertEqual(r, got[0])
            self.assertIsNone(stats.maybe_send(settings))  # once a month
            stats.consent(True, True, "Bright Lane Media")
            self.assertEqual(stats.maybe_send(settings, force=True)["agency"], "Bright Lane Media")
            self.assertEqual(stats.url(dict(settings, stats_url="http://example.com/x")), "")  # https only
        finally:
            shutil.rmtree(job)
            srv.shutdown()
            stats.consent(False)


class PackagePermissionTests(unittest.TestCase):
    """Zips keep their Unix permissions when AutoCut unpacks them (installers and updates)."""

    def test_extract_keeps_executable_bits(self):
        from autocut import updates
        src = TMP / "perm-src"
        src.mkdir(exist_ok=True)
        (src / "Install AutoCut.command").write_text("#!/bin/bash\necho hi\n")
        os.chmod(src / "Install AutoCut.command", 0o755)
        (src / "notes.md").write_text("x")
        z = TMP / "perm.zip"
        with zipfile.ZipFile(z, "w") as zf:
            for f in src.iterdir():
                zf.write(f, f"pkg/{f.name}")
        out = TMP / "perm-out"
        with zipfile.ZipFile(z) as zf:
            updates.extract(zf, out)
        if os.name != "nt":
            self.assertTrue(os.access(out / "pkg" / "Install AutoCut.command", os.X_OK))
            self.assertFalse(os.access(out / "pkg" / "notes.md", os.X_OK))
