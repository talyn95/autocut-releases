import subprocess
import tempfile
import unittest
from pathlib import Path

from autocut.sound import voice


class VoiceTests(unittest.TestCase):
    def test_blend_parsing_needs_no_model(self):
        class K:
            def get_voice_style(self, n):
                return {"a": 1.0, "b": 3.0}[n]
        self.assertEqual(voice._style(K(), "am_michael"), "am_michael")
        self.assertAlmostEqual(voice._style(K(), "a:50,b:50"), 2.0)

    @unittest.skipUnless(voice.available({}), "voice model not on this computer")
    def test_speak_writes_48k_mono(self):
        with tempfile.TemporaryDirectory() as td:
            out = voice.speak("AutoCut test.", Path(td) / "v.wav")
            info = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=sample_rate,channels", "-of", "csv=p=0", str(out)],
                                  capture_output=True, text=True).stdout.strip()
            self.assertEqual(info, "48000,1")


if __name__ == "__main__":
    unittest.main()
