#!/bin/sh
# First start: write the hosted settings into the data volume (edit /data/settings.yaml later as needed).
set -e
if [ ! -f /data/settings.yaml ]; then
  cat > /data/settings.yaml <<YAML
machine_name: ${MACHINE_NAME:-autocut-server}
clients_dir: /data/clients
listen_on_network: true
port: 8765
process_jobs: true
web:
  require_login: true
  trust_proxy: true
  public_url: "${PUBLIC_URL:-}"
ai:
  local_url: "${OLLAMA_URL:-http://127.0.0.1:11434}"
YAML
  echo "Wrote /data/settings.yaml"
fi
exec python -m autocut app --headless
