# Hosting AutoCut on the web (protected)

The web-hosted AutoCut is the same app, with sign-in turned on, reachable at your own address
(for example `https://autocut.triumphantmedia.com`) from any computer or phone.

## Pick a route

| | **A. Your Mac Studio + Cloudflare Tunnel** (recommended to start) | **B. A cloud server** |
|---|---|---|
| Monthly cost | $0 (you need a domain on Cloudflare's free plan) | about $40–$400+, depending on CPU/GPU |
| Speed | Fast: Apple's media engine encodes, the free AI runs on the Mac | Slower without a GPU: rendering, transcription and the AI run on CPU |
| Where footage lives | In the office | On the server |
| Uptime | Only while the Mac is on and online | Always on |
| Office Macs share the queue | Yes, as today | No (it's its own AutoCut) |

Route A is the quickest, cheapest way to see how it performs: nothing new to pay for, and the Mac
Studio does the heavy lifting. Move to B later if you need it always on, or for people outside the office
at scale.

## What protects it (both routes)

- **Sign-in on every page and API call.** Accounts are `admin` (team, settings, updates) or `editor` (all the editing work).
- **Passwords** are never stored, only salted PBKDF2-SHA256 hashes (600,000 rounds). 10 characters minimum.
- **Lockout:** 5 wrong passwords from one address → that address waits 15 minutes.
- **Sessions:** a random token in an HttpOnly, SameSite cookie (Secure over HTTPS), 12 hours by default.
- **Cross-site protection:** every change must come from the dashboard itself (a custom header other sites
  can't send), plus a strict Content-Security-Policy, no framing, HSTS on HTTPS.
- **Admin-only:** the team list, machine settings (they can hold API keys) and updates.
- **Audit log:** every sign-in and change is written to `audit.log` next to the clients folder.
- **HTTPS everywhere:** Cloudflare (route A) or Caddy with Let's Encrypt (route B).
- Route A adds one more: the Mac only listens to itself; the only way in is the tunnel.
  For a second lock, put **Cloudflare Access** in front (email one-time codes for your team's addresses).

---

## Route A: the Mac Studio + Cloudflare Tunnel

You need: AutoCut installed on the Mac Studio (as today), and a domain whose DNS is on Cloudflare (free plan is fine).

1. **Turn on sign-in.** Dashboard → **This Mac** → *Settings for this Mac only*, add the following, then **Save**:

   ```yaml
   web:
     require_login: true
     trust_proxy: true
     public_url: https://autocut.yourdomain.com
   ```

   Leave `listen_on_network` off: the tunnel connects on the Mac itself, so nothing is exposed to the network.

2. **Create the first admin** in Terminal:

   ```bash
   ~/AutoCut/.venv/bin/python -m autocut user add you@yourdomain.com --admin
   ```

   Then quit AutoCut (✂ → Quit) and open it again.

3. **Connect the tunnel** (Terminal, one time):

   ```bash
   brew install cloudflared
   cloudflared tunnel login                     # pick your domain in the browser that opens
   cloudflared tunnel create autocut
   cloudflared tunnel route dns autocut autocut.yourdomain.com
   ```

   Create `~/.cloudflared/config.yml` (the tunnel ID was printed by `create`):

   ```yaml
   tunnel: <TUNNEL-ID>
   credentials-file: /Users/<you>/.cloudflared/<TUNNEL-ID>.json
   ingress:
     - hostname: autocut.yourdomain.com
       service: http://localhost:8765
     - service: http_status:404
   ```

   Start it now and at every boot:

   ```bash
   sudo cloudflared service install
   ```

4. Open `https://autocut.yourdomain.com`, sign in, and add the team under **This Mac → Team**.

5. *(Optional, recommended)* **Cloudflare Access**: Cloudflare dashboard → Zero Trust → Access → Applications →
   *Add a self-hosted application* for `autocut.yourdomain.com`, policy *Allow* → *Emails* → your team's addresses.
   People then confirm a one-time email code before they even see the AutoCut sign-in.

Uploads go up in 48 MB pieces, so big videos work through Cloudflare (which limits a single request to 100 MB).

## Route B: a cloud server (Docker)

You need: a Linux server (Ubuntu 24.04; 8+ CPU cores, 16 GB+ memory, 200 GB+ disk; a GPU if you want the
free AI and fast transcription there), Docker installed, and a DNS `A` record for `autocut.yourdomain.com`
pointing at the server. Open ports 80 and 443 only.

```bash
git clone <your copy of AutoCut> autocut && cd autocut/deploy
DOMAIN=autocut.yourdomain.com docker compose up -d --build
docker compose exec autocut python -m autocut user add you@yourdomain.com --admin
```

(Or open `https://autocut.yourdomain.com/login`; the first-run setup code is in `docker compose logs autocut`.)

Caddy gets the HTTPS certificate automatically. Everything AutoCut keeps (clients, jobs, users, audit log,
models) is in the `autocut-data` volume: back it up.

The free AI on the server: `docker compose --profile ai up -d` and
`docker compose exec ollama ollama pull gemma3:12b` (needs a GPU to be quick; without one, set a Claude API key
and let Claude do the AI work within the monthly cap).

Update later: `git pull && docker compose up -d --build`.

---

## Working with the hosted AutoCut

- **Premiere:** in the browser, rough cuts have **Download for Premiere**: one zip with the XML and every clip
  it uses. Unzip it into `/Users/Shared/AutoCut-Downloads/` and import the XML. Premiere finds everything
  with no relinking. (Unzipped elsewhere, Premiere asks once; point it at any file in `media/`.)
  The zips are big: the graphics layers are high-quality ProRes.
- **Show XML / Folder** only work on the machine running AutoCut; in the browser you download instead.
- **The office Macs** (route A) keep working exactly as before and share the same queue and users.
- **Who did what:** `audit.log` next to the clients folder (on route B, inside the `autocut-data` volume).
