Drop the client font files here (.ttf/.otf). Install them on every editing Mac too.
