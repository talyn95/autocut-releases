# Changelog

## 0.26.2
- **Updates switched on:** AutoCut now checks Triumphant Media's signed update feed by itself and offers new versions
  with one click (This Mac → Updates). New computers download the installer from the releases page
- Releases publish with `tools/release.py publish-git` (into the public releases repo; the weekly upgrade does it) or
  `publish-github` (GitHub Releases through the REST API, for GitHub Actions)

## 0.26.1
- **Mac installer fix:** "Install AutoCut.command" lost its permission to run inside the download (and launchers lost it
  in one-click updates), so double-clicking it could fail. Zips now keep their permissions when they're unpacked.
  The Mac download is also a .dmg now: open it and double-click Install AutoCut

## 0.26.0
- **Explainer split edit style** (Create tab → Transcript to video → Style): drop the speaker's raw take and AutoCut
  rough-cuts it, puts them in a rounded panel at the bottom with their head popping over the edge, captions two or
  three words at a time in the middle, and graphics above that explain what they're saying: a card that builds word
  by word with the key words in the brand colour, your screenshot with a price sticker that counts up, a big serif
  number that gets struck through with a FREE badge (the speaker drops away for that beat), a numbered step tracker
  for "first… next… finally…", and a name card that types "Hi, I'm …". Punch-ins between sentences hide the cuts.
  Music and sound effects are added like other videos. Also from your AI app: `make_explainer_video`
- **Share monthly totals (opt-in):** the monthly results pop-up and This Mac ask whether to share the totals (videos
  made, hours saved, average footage-to-XML time) with Triumphant Media. Numbers only, never client names or footage;
  off unless you say yes; see exactly what's sent in This Mac. Owners: docs/STATS.md (a Google Sheet receiver)
- Developers: `python -m unittest` no longer reads or writes the computer's real AutoCut settings while testing

## 0.25.0
- **New client from a website** (Clients tab, and the welcome tour): paste their web address and AutoCut drafts the
  brand kit: logo, brand colours, fonts (free Google Fonts downloaded), what they do, where, tone, offer, call to
  action, names to spell right and hashtags. Check it, change anything, create
- **Your month in AutoCut:** at the start of each month a summary pops up: videos edited, hours of editing saved,
  average footage-to-XML time, busiest clients. The **Results** button shows it any time
- **Simpler first run:** a welcome tour for new owners, a Getting started checklist that ticks itself off, a one-line
  explanation on every tab, and the less-used effects, media and extra shapes tucked under "More options"

## 0.24.0
- **After Effects-style motion feels:** every motion graphic now moves on bezier speed curves like keyframes with Easy
  Ease, plus secondary layers that trail the main move: scale (grows, slams or pushes in), a slight rotation that eases
  out, a glow that blooms as things land, and a drop shadow that tightens as they touch down. Exits accelerate away.
  Seven feels: Smooth (Easy Ease), Snappy (exponential), Bouncy (overshoot), Elastic (spring), Cinematic (slow push),
  Punchy (slam) and Glow (bloom)
- Each look has its own feel; change it per graphic (Create tab → Motion feel, or say "bouncy", "snappy", "glowing" in
  the prompt) or per client (Look book → Motion feel). Transcript-to-video uses the client's feel too

## 0.23.0
- **Connect your AI accounts** (This Mac → AI accounts): Claude, ChatGPT (OpenAI) and Grok (xAI) for extra brainpower
  and AI images, each with a monthly cap and a Test button. The free local AI still goes first; "Use my AI account"
  sends a job to your accounts first. Models pick themselves from what your account has, so new ones are used as
  they come out
- **AI images on any computer:** "Generate with AI" uses a connected ChatGPT or Grok account when the local Mac image
  model isn't installed
- **AutoCut as a connector in your AI app (MCP):** one click adds AutoCut to Claude Desktop; Claude Code, Cursor and
  other MCP apps work too. Ask your AI to queue footage, make motion graphics and social graphics, compose music or
  ask the Strategist, and AutoCut does it on your computer (`autocut mcp`, docs/AI-ACCOUNTS.md)

## 0.22.0
- **No central computer:** AutoCut's code and updates live in the cloud (GitHub). A release robot (GitHub Actions)
  tests, signs and publishes every update, so no office computer is involved and replacing one changes nothing
  (docs/OWNER-GUIDE.md)
- **Office copy of updates:** This Mac → Updates takes an optional second address (e.g. your Synology). AutoCut uses it
  when the main one can't be reached; every copy is checked against the same signature. `tools/mirror_feed.py` keeps the
  Synology copy current on a schedule
- **This computer:** This Mac / This PC shows the machine's processor, memory, graphics, free space and class
  (Light / Standard / Pro), with a speed test that estimates how long a 10-minute video takes. The speech model now picks
  itself to fit the computer ("auto"), alongside the local AI size and AI music
- Owner's guide, testers' hardware table, and the release robot setup

## 0.21.0
- **One-click signed updates** (This Mac → Updates): AutoCut checks the agency's update feed daily, shows a banner when
  a new version is ready, and installs it with one click. Every update is signed by Triumphant Media, checked against
  the key built into AutoCut, tested on your computer before it switches on, and the version before is kept so you can
  **roll back** with one click. Clients, footage and settings are never touched. Works from any web address or a shared
  office folder; stable and beta channels
- **What's new** after every update, and one-time update steps that run on their own
- **Content packs**: new looks, storyboards, music styles and sound flavours (plus marketing know-how) arrive as small
  data packs, from the update feed or a .zip, with no new version needed. Every entry is checked before it's used and
  packs can be switched off. The first one, *Trends: autumn 2026*, adds the Aurora Glow and Risograph Print looks, a
  myth-vs-fact storyboard, a synthwave music style and a tape sound flavour
- **AI that keeps up**: which models AutoCut uses now lives in a catalog that updates change, so "auto" settings move to
  better free models and new Claude models as they come out. New: any **OpenAI-compatible** AI server (LM Studio,
  vLLM, llama.cpp, Jan) as another free option
- `autocut selftest`, `autocut update`, `autocut pack`; `tools/release.py` makes signed releases (docs/RELEASING.md);
  docs/EXTENDING.md and ROADMAP.md for what comes next

## 0.20.0
- **Music, composed on this computer:** original, royalty-free beds in 10 styles, fitted to each video (the last chord
  lands on the last frame), mixed for voice, with stems. Each client gets a signature sound (style, key, motif) that
  differs from your other clients; the AI music director (with a new music playbook) picks energy and tempo per video
- **Sound design:** 13 synthesized effects in 8 flavours, placed on transitions, graphics, stickers, slams, reveals and
  the end card, with restraint
- **Premiere XML audio tracks:** A1 the subject's dialogue, A2 sound effects, A3 music (preview/export duck the music)
- Storyboards and transcript videos come out scored; **Create → Music & sound**; **Look book → Sound**
- Optional **AI music (ACE-Step 1.5, MIT)**: `autocut music-setup`; falls back to the Composer
- CLI: `autocut music`, `autocut sfx-pack`

## 0.19.0
- **Motion library** (docs/LIBRARY.md): 18 looks × 41 layouts (lower thirds, titles, 10 chart types, callouts, lists,
  testimonials, end cards, transitions), each look a full design system modelled on a best-selling marketplace category
  or a 2026 trend and written from scratch (nothing copied from paid marketplaces)
- **Style DNA**: every client is handed its own look, layout order and transition, suited to the business and kept
  apart from the other clients; graphics follow it automatically. **Look book** shows, changes, shuffles and previews it
  and flags clients that look alike
- **Storyboards**: 12 proven structures (PAS ad, listicle, testimonial, before/after, launch, event, data story, how-to,
  explainer, hiring, listing, offer); the AI writes every scene from one line, you edit the scenes, AutoCut draws them
- New Create-tab graphics: **Chart / graph**, **List / steps**, **Testimonial**, **Callout**; prompts pick the chart type
  ("line chart…", "donut 72%…") and a look ("…in neon")
- **HyperFrames registry**: 448 open-source blocks searchable in the Look book; custom designs start from the closest ones

## 0.18.0
- **Transcript to video** (Create tab, Katana-style): a script, transcript (TXT/SRT/VTT/JSON) or recording becomes a
  kinetic typography video: words land as they're said, highlighted key words, counting numbers, numbered steps,
  punchline slams, your graphics when they're mentioned, a logo + call-to-action end card, and the voice in sync.
  Editable in HyperFrames Studio, with Re-render
- **Your logo, fonts & graphics** in the motion generator: upload a logo, TTF/OTF/WOFF fonts and images; they apply to
  every engine (templates, custom AI designs, transcript videos)
- WOFF/WOFF2 fonts are read by name when the font file can't be parsed
- Showcase: tier T renders two transcript videos (a timed SRT and a plain script) with a custom font and graphic

## 0.17.0
- **Video marketing knowledge base** (`autocut/knowledge/`): hooks, retention, platforms, paid ads and testing, copy
  frameworks, scripts and shoots, content strategy, agency operations, design, motion and the trade's language.
  Every AI feature now reads the parts it needs (clips, post copy, graphics, motion), sized for the free local model
- **Strategist** (top right): an AI head of content for each client: hooks, scripts, 30-day plans, ad angles,
  interview questions, repurposing and copy reviews. Without an AI it shows the matching playbook
- **Graphics with your own images**: photos, products (cut out automatically), logos and "match this look" references;
  new Product spotlight and Photo + headline designs; the AI looks at the images when writing the copy
- No-client designs no longer show "Custom" as a footer

## 0.16.0
Matching the best in each class (docs/COMPETITIVE.md):
- **Graphics tab** (Canva): brand designs from a prompt (AI-written copy), every social size at once, bold/clean/dark
  looks, bulk create from a CSV, carousels with a PDF, YouTube thumbnails with the person cut out, Edit in Studio
- **Studio Sound** (Descript): one-click voice cleanup for short form edits, clips and every multicam mic
- **Remove retakes** (Descript): a line said again, even reworded, keeps only the last take
- **Find clips about…** (Opus Clip): steer the Clip generator to a topic; the rules and the AI both rank by it
- **Multicam** (AutoPod): wide-shot frequency (less / normal / more) and an editable "Voice from" per person
- Showcase covers the Graphics tab across all five test brands

## 0.15.0
- **Report a problem** (top right): one zip on the Desktop with the tester's description, AutoCut's version, the
  computer, the health check, settings with every key removed, the app log and the latest jobs' logs (no footage)
- Windows writes an app log (%LOCALAPPDATA%\AutoCut\AutoCut.log)
- Beta guides: HyperFrames in the install and health check, a new motion graphics test plan (fit to frame, custom
  designs, Edit in Studio, transparency in an editor), Report a problem

## 0.14.0
- **Edit in Studio**: HyperFrames graphics open in HyperFrames Studio (timeline, properties, live preview; served
  from this computer), and **Re-render** turns your Studio edits into new files
- **Showcase** (`tests/showcase/run.py`): five fictional brands (dentistry, gym, restaurant, real estate, SaaS) from
  templates to custom data stories and a 4-scene promo, with contact sheets, reels and a report
- Fixes found by it: one-line slams and big numbers shrink to fit the frame (a long word ran off 9:16); a dark brand
  text colour no longer disappears over footage; the vertical lower third is bigger
- Dashboard: the Sign out button and name badge no longer show when sign-in is off; gallery titles drop *asterisks*

## 0.13.0
- **HyperFrames engine** for the Motion graphic generator (HTML + GSAP rendered frame by frame in headless Chrome;
  open source, Apache 2.0, runs on this computer, telemetry off): new versions of all eight graphics in the client's
  colours and fonts, built to HyperFrames' motion craft (long-tailed arrivals, short exits, per-word blur-ins,
  phone-safe zones on 9:16). Transparent ProRes 4444; every render keeps an editable HyperFrames project
- **Custom designs**: `custom: …` (or Details → Custom design) has the AI write a whole composition (charts, steps,
  lists, logo reveals…), checked by rendering, with one automatic repair
- `autocut hyperframes-setup`; the Mac and Windows installers offer it; doctor reports it; Details → Engine

## 0.12.0
- **Every computer runs on its own**: no server and nothing shared by default. The Mac installer's default is now
  **On its own**; the shared office queue is an optional extra. New versions install from a new package and keep
  clients, footage and settings
- **Windows 10/11 PCs**: `Install AutoCut (Windows).cmd` installs Python 3.12, ffmpeg and the free AI (Ollama) with
  winget, plus Start menu and Desktop shortcuts. Clients live in C:\Users\Public\AutoCut, settings in %APPDATA%\AutoCut
- Fast encoding on Windows with NVIDIA, Intel or AMD graphics (each test-run before use), GPU decoding for multicam,
  NVIDIA transcription when CUDA is available (falls back to the CPU by itself)
- Premiere XML links work on Windows; client fonts install on Windows; Show in File Explorer; Chrome/Edge app window
- The dashboard says **This PC** and **File Explorer** on Windows; beta package adds `PASTE INTO CLAUDE (Windows).md`

## 0.11.0
- **Web-hosted AutoCut, protected** (deploy/HOSTING.md): sign-in on every page and API call (`web.require_login`),
  admin and editor roles, PBKDF2 password hashes, lockout after 5 wrong passwords, HttpOnly/SameSite/Secure
  session cookies, a dashboard-only request header against cross-site attacks, strict security headers, an
  audit log, and admin-only team/settings/updates. First admin via a one-time setup code or `autocut user add`
- **Team** panel (This Mac, admins): add people, set roles and passwords, remove
- Big uploads go up in 48 MB pieces (works through Cloudflare and other proxies), with retries
- **Download for Premiere**: a zip of the XML and every clip it uses, pre-linked to
  /Users/Shared/AutoCut-Downloads/ so Premiere opens it without relinking
- Two hosting routes: the Mac Studio behind a Cloudflare Tunnel (free), or a server with Docker + Caddy (HTTPS)

## 0.10.1
- References: the accent colour must be bright enough to read (a near-black "saturated" colour no longer wins)
- Clip titles and the no-AI post copy drop ums and weak openers ("Um, so…"); fallback hashtags favour concrete nouns

## 0.10.0
- **AI brain** (`brain.py`): a free local model on each Mac (Ollama + gemma3, sized to the Mac's memory; the
  installer sets it up) does the thinking. Claude is the backup only: when the local model can't answer, or when
  you choose "Use Claude". A monthly spending cap stops Claude for the rest of the month (`ai:` settings)
- **Marketing knowledge** (`marketing.py`): a built-in short-form marketing playbook (hooks, retention, platforms,
  copy frameworks) plus each client's marketing brief (new `marketing:` section in brand.yaml: audience, offer,
  voice, location, goals, platforms, hashtags, words to avoid)
- **Post copy for every video**: titles, captions, hashtags, three hook options, YouTube title and description
  (with chapters for long videos), LinkedIn and Facebook posts. More ▾ → Post copy, with Copy buttons and Rewrite
- **Clip generator**: the AI reviews the best moments together (score, title, three hooks, why, best platform),
  hooks are one click to use as the title, ±1 s trim nudges, and "Use Claude for ranking"
- Clips follow the speaker as they move (smoothed, camera-operator style) instead of one fixed crop
- New caption style `highlight`: a brand-colour box behind the word being said, centred
- **Motion graphic generator**: reference images or videos (palette, light/dark, pacing, and the AI's read of the
  mood, typography and motion) are matched; new premium **kinetic typography** template; any template can play
  faster or slower to match a reference's pacing
- This Mac shows the AI's status and this month's Claude spend

## 0.9.1
- Installer: `--yes` runs hands-free (no dialogs, safe defaults) so Claude Code or a script can install AutoCut
- Beta tester package: `beta/START HERE.md` (install, test plan, bug reports) and `beta/PASTE INTO CLAUDE.md`

## 0.9.0
- **Story cutaways** (new on/off effect, on by default): when the speaker describes something, a storyboard
  cutaway tells it in pictures, timed to the words: flat icons on 3D brand-colour tiles, the client's tagged
  images, picture-in-picture B-roll videos, animated arrows, a camera push with 3D tilt, and the speaker
  framed on screen. Own track (V10) under the captions; settings in `story:` in brand.yaml
- "3D render" style for AI images in the media library (tag them and story cutaways use them)
- Tabs renamed and reordered: Short form edits, Motion graphic generator, Long form editor, Clip generator
- Long form editor works with a single camera too

## 0.8.0
- **Multicam tab**: drop every camera, audio recorder and screen recording from a podcast or interview.
  AutoCut syncs them by sound, pairs each mic with the camera that shows that person, cuts to whoever is
  talking (simple jump cuts, a shortest-shot setting, wide shot on crosstalk or silence, a cutaway in long
  monologues) and shows screen recordings as picture-in-picture with the speaker in the corner.
  Ums, ahs and pauses are **kept** unless you switch them off. Premiere XML with each mic on its own
  track, a preview, full MP4 export, and an optional hand-off to Clips. "Who's who" and file roles
  can be corrected, then **Re-edit**
- Clips: **Jump between speakers** layout (now the default for two or more people): the vertical clip
  cuts to whoever is talking (separate mic channels when there are any, otherwise who's moving)
- Clips: drop many videos at once (each its own project) or folders (each folder = one project,
  folder of folders = one project per folder). A project with several videos ranks moments across all of them
- Centred text: pop captions no longer reserve space for words not yet said (no more staggered,
  off-centre lines); hook titles and CTA text rise as whole centred lines
- No gray backgrounds: Create previews, caption-style proofs and motion-pack reels sit on a brand-tinted
  gradient; the "whole frame" Clips layout keeps colour instead of a darkened blur; warmer dashboard colours
- Faster delivery: the Mac's media engine (VideoToolbox) encodes previews, exports, clips and Create
  renders; captions, pop-ups and overlays render in parallel with the graphics

## 0.7.0
- **Clips tab** (Opus Clips-style): long podcasts/streams → scored, sentence-aligned clip suggestions with reasons;
  layouts follow / two speakers / facecam + gameplay (picture-in-picture) / whole frame; any shapes; clips run
  through the full edit and spread across all Macs
- **Create tab**: prompt-based motion graphics at any size/position/background, ProRes/WebM with alpha, MP4, GIF;
  shared motion library
- Icon library: 2,100+ Lucide icons as brand-colour pop-up stickers
- Free stock B-roll from Pexels/Pixabay for topics the client library doesn't cover
- Optional local AI image generation (FLUX.1-schnell) in the media library
- "Made by Triumphant Media" in the app, optional agency credit in videos
- Optional local AI model (Ollama) for prompt reading and clip ranking

## 0.6.0
- AutoCut Motion: built-in After Effects-style motion graphics engine (Skia) with eased keyframes,
  motion blur, masked reveals, staggered words, draw-on shapes, gradients, glows and light sweeps
- Templates: hook title, keyword slam, stat counter, phrase card, lower third, swipe transition, CTA outro
- Graphic cards and lower thirds use it by default (`graphics.style: pro`); "Motion graphics" switch
  places the hook title, slams, swipes and animated end card
- "Preview motion pack" on the Clients tab for sign-off
- Fix: caption-sample / cover previews could fail to load (cache-buster in the file path)

## 0.5.0
- Transcript editor: click words to cut/restore, ⌥-click to fix caption typos, save & re-cut
- False-start detection ("we do a — we do a free inspection" keeps the retake)
- Dialogue levelled to -14 LUFS (Audio Levels on the dialogue clips; previews/exports match)
- "Also make": square / 4:5 / landscape versions from the same edit
- Export a finished full-quality MP4 from the dashboard (no Premiere needed)
- Cover image effect (speaker cut out over brand colour with the hook text)
- Reliability: heartbeat + "stalled" detection with Retry, remove waiting uploads / finished jobs
  (recoverable), safer concurrent status writes
- Mac notifications when a cut or export finishes; time-saved stats on the Queue

## 0.4.1
- Double-click installers: "Install AutoCut" (Mac Studio / single Mac) and "Install AutoCut on this Mac"
  (every other Mac, from the Mac Studio's shared folder). Homebrew is installed automatically
- Installer questions are Mac dialogs; laptops can be set to upload-only
- Phones, iPads and other computers can use the dashboard in a browser (opt-in), with XML download
- "Add another device" card with copyable addresses; INSTALL.md one-page guide

## 0.4.0
- Drag-and-drop media: screenshots, photos (incl. iPhone HEIC), logos, graphics and clips
  - per video (Queue): optional "show when I say…" keyword and look (floating card / full screen)
  - per client (Media library): categories, thumbnails, keyword tags, safe remove (to assets/.trash)
- "Your media" effect switch; media never overlaps cards or cutouts
- Install a client's fonts on a Mac from the dashboard
- Safer uploads: clean file names, no overwriting a same-named video, type checks with clear messages,
  stray drops can't navigate away from the dashboard
- Better word matching (plurals, -ing/-er/-ed) for b-roll, stickers and media keywords

## 0.3.0
- Creative effects with on/off switches: punch-in zooms, graphic cards, lower third,
  pop-up stickers (12 built-in + client stickers), texture overlays (grain, vignette, light leaks),
  subject cutout (hook text behind the speaker, speaker pops out over a brand panel)
- Motion graphics is now a switch too
- Switches per client (Clients tab, saved into brand.yaml with comments kept), per upload and per re-run
- Hook text box on uploads; per-video choices travel with the video through the shared queue
- Person segmentation runs locally: Apple Vision on Macs, ONNX fallback

## 0.2.0
- AutoCut.app: menu-bar app with a dashboard (Queue / Clients / This Mac)
- Shared queue across the Mac Studio and Mac Minis (atomic claims, per-job status, logs)
- Drag-and-drop upload, previews, re-run, brand kit editor with live checks, caption samples
- One-click updates from the Mac Studio; installer with --main / --join / --solo
- Motion Studio renders lock across Macs; Motion Studio can live in the shared folder
- Per-client vocabulary for better spelling of names and places
- Test suite (tests/)

## 0.1.0
- Rough cuts: filler/stutter/pause removal, kinetic captions, b-roll, watermark,
  CTA end card, Motion Studio bridge, Premiere FCP7 XML, previews
