# The motion library

AutoCut's database of motion graphics: **18 looks** (style families) × **41 layouts** across
8 kinds of graphic (= 738 distinct designs before a single brand colour is applied), **12 storyboard
structures**, and a searchable index of the **448 open-source HyperFrames registry blocks**. Every client is handed its
own **style DNA** (a look + an order of layouts + a transition), chosen to suit the business and to stay clear of every
other client on the computer, so 20–30 agencies with 10+ clients each don't end up with look-alike graphics.

Code: `autocut/mograph/library/` (looks.py, elements.py, storyboards.py, dna.py, build.py, compose.py, registry.py).

## Where the designs come from (and what was not copied)

The brief was to study what sells on the big template marketplaces and rebuild it. We studied **categories, styles and
techniques**, not files:

- **Envato Elements / Motion Array** listings and category filters (lower thirds, titles, call-outs, infographics,
  broadcast packages, openers, product promos, transitions) and the style words their bestsellers use: clean/corporate,
  minimal line, glitch, neon, retro, social/bubbly, luxury, sports, kinetic typography.
- **2026 trend round-ups** (G2, agency blogs): imperfect hand-made motion (paper, grain, jitter), 2D/3D hybrids,
  kinetic typography, saturated "maximal" colour.
- **The HyperFrames registry** (GitHub, Apache-2.0): 448 blocks and components, which AutoCut indexes and can hand to
  the AI as source to adapt (see below).

**Nothing was copied from Envato, Motion Array or any paid marketplace.** Their licences cover use in your own
projects, not redistribution inside software handed to other agencies; shipping their files (or ports of them) to 20–30
agencies would expose Triumphant Media and every agency using AutoCut. A visual *style* (thin lines, glitch, neon,
serif editorial) isn't anyone's property; a specific template's design and files are. So every look and layout here is
written from scratch in HTML/GSAP, and the registry is used under its open-source licence with attribution.

Sources consulted: [Envato Elements lower thirds](https://elements.envato.com/video-templates/lower+thirds),
[Envato titles/transitions](https://elements.envato.com/video-templates/titles/transitions/compatible-with-after-effects),
[Motion Array lower thirds](https://motionarray.com/browse/motion-graphics-templates/lower-thirds/),
[Speckyboy free lower thirds round-up](https://speckyboy.com/free-lower-thirds-after-effects-templates.md),
[G2 graphic design trends 2026](https://learn.g2.com/graphic-design-trends),
[Tangence motion graphic trends 2026](https://www.tangence.com/blog/?p=1093),
[HyperFrames](https://github.com/heygen-com/hyperframes) (Apache-2.0).

## Looks

A look is a design system, not a palette: typefaces, casing and tracking, corner radius and strokes, how panels are
drawn (solid, glass, outline, paper, neon, block, gradient or none), shadows, an accent motif, a texture, and a motion
vocabulary (how words enter and leave, the easing, the pace). The client's colours always fill it in, with every
text/background pair checked for contrast; text without a panel floats over footage in white with a lifted accent.

| Look | Built from | Mood | Suits | Type | Motion · motif |
|---|---|---|---|---|---|
| **Corporate Clean** (`corporate`) | 'Clean corporate lower thirds' and broadcast packages (Envato, Motion Array) | trustworthy, calm, professional | finance, law, insurance, dental, medical, b2b… | Inter / Inter | rise · tab |
| **Minimal Line** (`minimal`) | 'Minimal titles' packs: thin animated lines that stay out of the footage's way | calm, modern, premium | architecture, interior, design, photography, wellness, spa… | Outfit / Outfit | mask · rule |
| **Editorial Serif** (`editorial`) | Magazine and documentary title packs: big serif, italic accents, rules | thoughtful, premium, storytelling | restaurant, food, hospitality, publishing, boutique, wine… | Playfair Display / Lato | rise · rule |
| **Swiss Grid** (`swiss`) | International-style typographic packs: grids, flush-left caps, hard blocks | confident, structured, modern | agency, architecture, saas, engineering, manufacturing, logistics… | Archivo Black / Inter | slide · ticks |
| **Neo-Brutalist** (`brutal`) | Bold social packs: thick outlines, hard offset shadows, stamped type | loud, playful, youthful | streetwear, gaming, creator, music, events, bar… | Archivo Black / Space Mono | stamp · stripes |
| **Glass Tech** (`glass`) | SaaS/app promo packs: frosted panels, soft glows, blur-ins | modern, techy, clean | saas, software, app, fintech, ai, startup… | Outfit / Inter | blur · dot |
| **Neon Night** (`neon`) | Neon/night-life title packs: glowing outlines that flicker on | electric, nightlife, energetic | bar, nightclub, dj, music, gaming, esports… | Oswald / Oswald | flicker · corners |
| **Glitch Digital** (`glitch`) | Glitch title/transition packs: RGB split, slices, scanlines, mono type | edgy, digital, techy | cybersecurity, it, gaming, tech, electronics, esports… | Space Mono / IBM Plex Mono | glitch · slash |
| **Retro 70s** (`retro`) | Retro/vintage packs: chunky type, sunset stripes, bouncy motion | warm, nostalgic, fun | cafe, coffee, ice cream, vintage, skate, surf… | Archivo Black / Nunito | bounce · stripes |
| **Hand-made Paper** (`handmade`) | 2026's swing to imperfect motion: paper, grain, scribbles, slight jitter | human, warm, authentic | nonprofit, education, kids, craft, farm, organic… | EB Garamond / Nunito | draw · scribble |
| **Luxury Serif** (`luxury`) | Luxury/fashion/real-estate packs: tracked serif caps, hairlines, slow fades | elegant, exclusive, slow | luxury, real estate, jewelry, fashion, hotel, wedding… | EB Garamond / Lato | fade · corners |
| **Sport Bold** (`sport`) | Sports broadcast and fitness promo packs: italic condensed caps, slashes, speed | fast, aggressive, energetic | fitness, gym, sports, crossfit, martial arts, automotive… | Oswald / Oswald | slide · slash |
| **Playful Pop** (`playful`) | Social media packs: rounded pills, bouncy pops, dots and stickers | friendly, fun, approachable | kids, pet, daycare, dentist, bakery, ecommerce… | Nunito / Nunito | pop · dot |
| **Broadcast News** (`broadcast`) | News/broadcast packages: two-tier bars, tickers, hard cuts, live tags | urgent, credible, informative | news, media, politics, podcast, public sector, local… | Roboto / Roboto | wipe · tab |
| **Soft Organic** (`organic`) | Wellness/beauty packs: blobs, soft gradients, floating rises | soft, caring, natural | wellness, yoga, skincare, salon, spa, nutrition… | Poppins / Poppins | rise · blob |
| **Mono Developer** (`mono`) | Code/terminal packs: monospace, outline boxes, type-on with a cursor | precise, nerdy, honest | developer, devtools, saas, api, data, cloud… | JetBrains Mono / JetBrains Mono | type · cursor |
| **Maximal Gradient** (`gradient`) | 2026's bold-colour trend: saturated layered gradients, heavy type, pops | bold, vibrant, modern | marketing, agency, events, beauty, fashion, ecommerce… | Montserrat / Montserrat | pop · chrome |
| **Cinematic** (`cinematic`) | Trailer/opener title packs: wide-tracked light caps, letterbox bars, slow blur | dramatic, premium, story | film, production, wedding, travel, automotive, hotel… | Montserrat / Montserrat | blur · rule |

## Layouts

Each layout is a structure with its own signature move; the look supplies the rest, so a layout reads differently
in every look.

| Kind | Layouts | |
|---|---|---|
| lower third | 10 | tab, underline, bracket, pills, split, slash, dot, badge, bars, outline |
| title | 6 | stack, mask, outline, boxed, split, bignum |
| chart | 10 | bars, columns, line, donut, meter, compare, counters, waffle, timeline, funnel |
| callout | 3 | arrow, ring, tag |
| list | 3 | steps, checklist, cards |
| quote | 2 | quote, review |
| end card | 3 | center, split, stack |
| transition | 4 | wipe, slats, iris, diagonal |

Data in charts: `Label: value` per line (`Jan: 120`, `Google: 42%`, `Revenue: $1.2M`); single-number charts (donut,
meter, waffle) take one value. Numbers count up with their prefix/suffix and decimals kept.

## Storyboards

Whole short videos from proven marketing structures. The AI writes every slot from a one-line brief in the client's
voice (or, without an AI, quoted phrases and numbers from the brief fill them, and the rest are clearly-marked
examples to replace). Each scene names the layouts that suit it; the client's DNA picks among them, and the client's
transition covers every cut.

| Structure | For | Scenes |
|---|---|---|
| **Problem → agitate → solve ad** (`pas_ad`) | paid social ads, 15–25 s | title → chart → title → quote → end card |
| **Tips listicle** (`listicle`) | organic reels and shorts, 20–40 s | title → title ×n → list → end card |
| **Client testimonial** (`testimonial`) | trust content, retargeting, 20–30 s | title → quote → chart → end card |
| **Before / after** (`before_after`) | results content and ads, 15–25 s | title → chart → list → end card |
| **Product launch** (`launch`) | launches and new services, 20–30 s | title → title → list → chart → end card |
| **Event promo** (`event`) | events, open houses, workshops, 15–25 s | title → list → title → end card |
| **Data story** (`stat_story`) | thought leadership, reports, 20–30 s | title → chart → title → end card |
| **How-to in steps** (`how_to`) | educational reels, 20–40 s | title → title ×n → list → end card |
| **Explainer** (`explainer`) | FAQ answers, service explainers, 20–30 s | title → title → list → chart → end card |
| **We're hiring** (`hiring`) | recruitment, 15–25 s | title → title → list → end card |
| **Property listing** (`listing`) | real estate listings, 20–30 s | title → chart → list → title → end card |
| **Limited-time offer** (`offer`) | promotions and sales, 10–20 s | title → chart → title → end card |

## Style DNA

`motion-style.json` in each client's folder: `look`, `layouts` (an order per kind), `transition`, `brand_fonts`.
Handed out the first time a client needs it: looks are ranked by fit to the business (its name, industry and tone in
brand.yaml against each look's "suits" list) minus how many other clients already use them; for each kind, the
layouts other clients lead with least come first (much harder if they share the look). **Look book** (Create tab)
shows it, changes the look, shuffles to the next-best, toggles brand fonts (the client's own font files, else the
look's typefaces), renders a preview of the look, and lists every client with the one it is most alike
(`similarity`: same look counts half, each kind's lead layout shares the rest; anything at 50%+ is flagged).

Library graphics in the Create tab follow the DNA automatically when a client is picked: lower thirds, hook titles,
phrase cards, stat counters, end cards and swipes are drawn in the client's look and layout, plus the library-only
charts, lists, testimonials and callouts. **Details → Look / Layout** override it for one graphic; "AutoCut original
templates" brings back the previous designs. Slams and kinetic typography keep their own engines.

## HyperFrames registry

`registry.json` is the catalog of 448 blocks/components (name, description, tags), so search works offline. When a
custom design is requested, AutoCut finds the closest blocks and, if the computer is online, installs their source with
`hyperframes add` into a scratch folder and gives it to the AI as a starting point to adapt to the brief and brand
(**Look book → Registry blocks → Use** picks one by hand). The registry is © HeyGen and contributors, Apache-2.0.

## Adding to it

- A look: one entry in `looks.LOOKS` (+ `compose.BOX` for how its panels enter). Run the tests: every layout is built
  in every look, and colour roles are checked for contrast.
- A layout: a function `fn(c, params, sid, t0, dur) -> Part` in `elements.py`, added to `LAYOUTS[kind]`. Use the kit
  (`textIn`, `boxIn`, `lineIn`, `strokeIn`, `popIn`, `countUp`, `out`) so it moves in every look's vocabulary.
- A storyboard: one entry in `storyboards.RECIPES` (slots with hints and example copy, scenes with suitable layouts).
- `PYTHONPATH=. python tests/showcase/run.py OUT --only library` renders every brand's look sheet side by side.

## Motion feel (mograph/feel.py)

How things move, After Effects style. A feel is a set of cubic-bezier speed curves (entrance, exit, in-out: the graph
editor's influence handles) plus secondary keyframe layers that ride on CSS custom properties, so they stack on any
look's entrance: `--fs` scale (individual `scale` property), `--fr` rotation (`rotate`), `--fg` glow and `--fl` shadow
lift (drop-shadow filters on the element's container, so a wipe or mask doesn't clip them). `feel(sel, t, d, weight)`
and `feelOut(sel, t, d)` in the kit add them; `textIn`, `boxIn`, `popIn` and `out` call them, and every tween in the kit
eases on `EIN` / `EOUT` / `EIO`.

| Feel | Curves | Layers |
|---|---|---|
| smooth | Easy Ease out (0.22, 1, 0.36, 1) | grow from 94%, soft shadow settles |
| snappy | exponential (0.16, 1, 0.3, 1) | grow from 88%, crisp |
| bouncy | overshoot (0.34, 1.56, 0.64, 1) | grow from 70%, −5° tilt |
| elastic | overshoot + elastic spring on scale | grow from 60%, 4° tilt |
| cinematic | slow in-out (0.45, 0, 0.15, 1) | push in from 108%, soft bloom |
| punchy | very fast settle (0.05, 0.7, 0.1, 1) | slam from 130%, −3°, big shadow snaps tight |
| glow | Easy Ease | strong accent bloom that settles to 30% |

Which feel: Create tab choice (or a feel word in the prompt) → the client's DNA (`feel`, Look book) → the look's own
(`LOOK_FEEL`, or a pack look's `"feel"` token, or its base look's). Add a feel by adding an entry to `FEELS`.
