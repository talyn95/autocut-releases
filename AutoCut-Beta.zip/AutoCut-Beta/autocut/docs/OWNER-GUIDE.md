# AutoCut owner's guide

For the person who runs AutoCut for everyone else: how it's set up, how to operate it, and how to send your people
updates. Nothing here depends on any one computer in your office.

## The big picture

```
            ┌────────────────── the cloud (nothing in your office) ──────────────────┐
  you  ──▶  │  Claude Code (claude.ai/code)  ──▶  GitHub: private "autocut" repo      │
            │      makes the change, tests it          │  a version tag starts the    │
            │                                          ▼  release robot (Actions)     │
            │                         GitHub: public "autocut-releases" → feed        │
            └──────────────────────────────────────────┬──────────────────────────────┘
                                                       │ signed updates
                       ┌──────────────┬────────────────┼───────────────┬──────────────┐
                       ▼              ▼                ▼               ▼              ▼
                  your Mac      editor's PC     agency owner's    enrollee's      … every person's
                                                   MacBook          laptop          own computer
                       ▲
                       └── optional: the office Synology keeps a copy of the feed (a mirror)
```

- **Each person's computer does all the work.** Transcribing, editing, rendering, the local AI, music: all on their
  own machine, with their own clients and footage. There is no AutoCut server. How fast it is depends on their
  hardware, and This Mac → **This computer** shows what their machine can handle (with a speed test).
- **The code lives on GitHub** (a private repo), not on a computer. Any computer, or none (Claude Code in the
  browser), can work on it. Replacing or losing an office computer changes nothing.
- **Updates are built in the cloud.** A GitHub Action tests, signs and publishes each release to a public releases
  repo. Every AutoCut checks there, shows a banner, and installs with one click, tested on that computer first, with
  Roll back.
- **The Synology is optional.** It can hold a copy of the feed for the office; AutoCut uses it when GitHub can't be
  reached. If the NAS is off or replaced, nothing breaks.
- **Two things to keep safe**, neither on a computer: your GitHub login and the **release key** (in a password manager
  and as a GitHub secret).

## Where things live (set up October 2026)

- Code: private repo `talyn95/triumphant-media`, branch **`autocut-code`** (your `main` branch keeps your own files).
- Updates and installers: public repo `talyn95/autocut-releases` (https://github.com/talyn95/autocut-releases; its
  page has the download links for new computers). Every AutoCut checks
  `https://raw.githubusercontent.com/talyn95/autocut-releases/main/feed.json`.
- The weekly upgrade (Mondays 5:39am Central) builds, tests, signs and publishes there by itself when everything passes.

## One-time setup (about 30 minutes)

1. **GitHub.** Make a GitHub account (or organization, e.g. `triumphant-media`), and two repositories:
   - `autocut`: **private**, the code.
   - `autocut-releases`: **public** and empty, where the release robot puts the signed update files. It holds only the
     files your people already receive (the update zips), never the private repo.
2. **Connect GitHub to Claude** (claude.ai → Settings → Connectors → GitHub, allow both repos). Then, in a Claude Code
   session, say: *"Push AutoCut to triumphant-media/autocut and set the update address to the releases repo."*
3. **Give the release robot its keys** (GitHub → `autocut` → Settings → Secrets and variables → Actions):
   - Secret `AUTOCUT_RELEASE_KEY`: the contents of `AutoCut-release.key` (64 characters).
   - Secret `RELEASES_TOKEN`: a fine-grained token (GitHub → Settings → Developer settings → Fine-grained tokens) with
     access to **only** `autocut-releases`, permission **Contents: Read and write**.
   - Variable `RELEASES_REPO`: `talyn95/autocut-releases`.
4. **The release key** also goes in your password manager. It's what proves an update is yours. If it's lost, every
   computer needs one manual reinstall; if it leaks, make a new one at once (docs/RELEASING.md, "Rotating the key").
5. **Everyone installs once** from the zip (AutoCut-Beta.zip for Macs, AutoCut-Windows-Beta.zip for PCs, also at the
   releases page). From then on, updates come by themselves.

### Optional: the Synology mirror

1. On the Synology, make a shared folder `autocut`, and inside it `mirror` and `updates`.
2. Copy three files into `mirror`: `tools/mirror_feed.py`, `autocut/ed25519.py`, `autocut/release_key.pub`.
3. Control Panel → Task Scheduler → Create → Scheduled Task → User-defined script, every hour:
   `python3 /volume1/autocut/mirror/mirror_feed.py https://raw.githubusercontent.com/talyn95/autocut-releases/main/feed.json /volume1/autocut/updates`
4. On office computers: This Mac → Updates → Where updates come from → **Office copy**:
   `/Volumes/autocut/updates/feed.json` on a Mac (connect to the share once) or `\\<nas-name>\autocut\updates\feed.json`
   on a PC. People outside the office don't need it.

The mirror only copies files that carry your signature, so even a compromised NAS can't push anything.

## Operating AutoCut (every person, on their own computer)

| Tab | What it's for |
|---|---|
| **Short form edits** | Drop talking-head footage for a client → a Premiere rough cut (fillers and pauses gone, captions, B-roll, graphics, music on its own track) |
| **Motion graphic generator** | Type what you want (or pick a storyboard, or paste a transcript) → brand graphics and kinetic-type videos |
| **Graphics** | Social posts, thumbnails, ads and carousels in the client's brand |
| **Long form editor** | Multicam podcasts and interviews, cut to whoever's talking |
| **Clip generator** | Long video → vertical clips with a virality score |
| **Clients** | Each client's brand kit, look (style DNA) and sound |
| **This Mac / This PC** | This computer (speed test), AI brain, music, **Updates**, **Content packs**, settings |

Each person's AutoCut keeps its own clients folder (`/Users/Shared/AutoCut` on a Mac, `C:\Users\Public\AutoCut` on a
PC). New computer? Install AutoCut and copy that folder across (Migration Assistant does it on a Mac).

## More AI power (optional)

Each person can connect their own Claude, ChatGPT or Grok account (This Mac → AI accounts) for extra brainpower and AI
images, billed to their account with a monthly cap, and add AutoCut to Claude Desktop as a connector so they can ask
their AI app to make graphics or queue footage. docs/AI-ACCOUNTS.md has both.

## Sending your people an update

**Everyday route: ask Claude.** Open claude.ai/code, pick the `autocut` repo, and say what you want:

> "Add a bold yellow box caption style. When the tests pass, release it to everyone."

Claude makes the change, runs the tests, bumps the version, writes the What's new notes, and pushes a version tag.
The release robot (GitHub Actions) then tests it again, builds it, signs it and publishes it, in about 10 minutes.
Every AutoCut sees it within a day (or straight away with **Check for updates**), shows a banner, and installs with one
click. Watch it under the repo's **Actions** tab.

**Try it on a few computers first:** say "release it as a beta". Computers set to the Beta channel get it; when it's
good, say "release it to everyone".

**Only new looks, storyboards or music?** That's a content pack, not a new version: "Make a content pack with two
new looks for med spas and release it." People see **Add** next to it under Content packs.

**Something wrong after an update?** On that computer: This Mac → Updates → **Roll back**. For everyone: ask Claude to
fix it and release again (updates never go backwards, so the fix needs a newer version).

## Marketing numbers from your users (optional)

Each computer can share its monthly totals with you (videos made, hours saved, average turnaround), only if its owner
says yes, and never anything about their clients. Set up the Google Sheet receiver in docs/STATS.md, put its address in
`autocut/content/catalog.json` → `stats.url`, and ship a release.

## When you replace computers

| What changes | What to do |
|---|---|
| A new computer for you or anyone | Install AutoCut from the releases page; copy their clients folder across if they want their history |
| Your office Mac Studio is retired | Nothing. Nothing runs on it |
| The Synology is replaced or off | Nothing breaks; re-create the mirror task on the new one if you want the office copy |
| Someone leaves | Their computer, their copy. Remove them from GitHub if they had access |

## Performance is each person's own

AutoCut runs entirely on the computer it's installed on. Triumphant Media doesn't run servers for anyone's editing, and
speed depends on that person's hardware. This Mac → **This computer** shows the machine's class (Light / Standard /
Pro), what it runs well, and a speed test with a rough time for a 10-minute video. Heavy options pick themselves to fit
(speech model, local AI size, AI music only on capable machines). Put the same in your terms of use: performance
depends on the user's hardware. Recommended: Apple Silicon Mac or a Windows 10/11 PC, 16 GB memory, 100 GB free.
