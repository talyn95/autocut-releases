# AI accounts and the AutoCut connector

Two ways to bring more AI power to AutoCut. Both are optional: AutoCut works with its free local AI (or simple rules)
and never needs an account.

## 1. Connect your own AI accounts (This Mac → AI accounts)

| Account | Maker | Where to get a key | Used for |
|---|---|---|---|
| Claude | Anthropic | console.anthropic.com → API keys | writing, reading prompts and references, custom designs |
| ChatGPT | OpenAI | platform.openai.com → API keys | the same, plus AI images |
| Grok | xAI | console.x.ai | the same, plus AI images |

- **An API key is a developer account, not your chat subscription.** ChatGPT Plus, Claude Pro and SuperGrok
  subscriptions can't be plugged into other apps; their makers only allow API keys, billed per use. To use a chat
  subscription with AutoCut, use the connector below instead.
- **Order:** AutoCut asks the free local AI first, then an OpenAI-compatible server if you have one, then your
  accounts in the order shown ("Ask sooner ↑" changes it). "Use my AI account" switches in the dashboard (Clip
  generator ranking, post copy, Strategist, custom designs) send the job to your accounts first.
- **Models pick themselves:** "auto" uses the best model your account actually has, from a preference list in
  `autocut/content/catalog.json` (`ai.accounts`). New models are picked up as they appear; an update or a content
  pack can move the list. Type a model id instead to pin one.
- **Monthly caps:** each account stops being used for the rest of the month once its cap is reached (cautious
  estimates; the maker's billing page has the real figure).
- **AI images:** Clients → Media library → "Generate with AI" uses the local image model on Apple Silicon Macs if it's
  installed, otherwise a connected ChatGPT or Grok account, so it now works on Windows PCs too.
- Keys are stored only in this computer's own settings file and are never shown in full again.

## 2. Use AutoCut from your AI app (This Mac → Use AutoCut from your AI app)

AutoCut can be a connector (an MCP server) inside AI apps. You ask in plain words; your AI app does the thinking on
your subscription, and AutoCut does the work on this computer.

> "Queue the three videos in my Downloads for Demo Roofing, hook: Hail damage?"
> "Make a lower third for Harborline Realty: Dana Ruiz, Listing Agent, in vertical and square."
> "Give me a 30-second upbeat music bed for Ironclad's gym promo."

Tools: autocut status, list clients, queue videos, list jobs, make motion graphic, make graphic, check render,
compose music, ask strategist, open dashboard. AutoCut must be open on the computer while you use them.

- **Claude Desktop:** press "Add AutoCut to Claude Desktop", then quit Claude Desktop completely and open it again.
  (It adds an `autocut` entry to Claude Desktop's `claude_desktop_config.json`, keeps everything else, and saves a
  backup.)
- **Claude Code, Cursor, LM Studio, VS Code and other MCP apps:** copy the snippet shown on the panel into the app's
  MCP settings. The command is this computer's Python with `-m autocut mcp`.
- **ChatGPT:** ChatGPT's developer mode only connects to connectors reachable over the internet (HTTPS). A local one
  needs OpenAI's connector tunnel; that's an advanced setup, and the dashboard and Claude Desktop routes are simpler.
- **Grok:** connect a Grok account under AI accounts (section 1).

The connector only talks to the AutoCut on the same computer (127.0.0.1). If AutoCut asks for a sign-in
(`web.require_login`, the hosted setup), the connector can't use it.
