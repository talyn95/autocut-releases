# Music and sound design

AutoCut scores every edit itself: original music in each client's own sound, and sound effects placed on what happens
on screen. Code: `autocut/sound/`.

## In the Premiere XML

| Track | What's on it |
|---|---|
| **A1** | The subject's audio: the dialogue (the Studio Sound version when it's on), one clip per cut |
| **A2** | Sound effects: one clip per effect (whoosh, swish, riser, impact, pop, click, shimmer…), each with its level |
| **A3** | Music: one clip, the full length of the edit, at its bed level |

Each lives in the job folder (`studio-sound.wav`/`dialogue.wav`, `sfx/`, `music.wav` and `music-stems/` with drums,
bass, harmony and top), so the editor can swap, move, re-level or mute any of them. Stereo camera audio is folded to
dual-mono so the dialogue needs one track. Multicam projects keep one track per microphone (A1, A2, …). The preview
and "Export MP4" mix the three with the music ducking under the voice. Timelines saved before 0.20 (dialogue on A1/A2)
still export as they were.

## Music: the AutoCut Composer (always available, free)

An arranger and synthesizer in Python/numpy (`composer.py`, `synth.py`). It writes the music on the computer, note by
note: nothing is sampled, downloaded or licensed, so it is original and royalty-free for client work.

- **10 styles:** Corporate uplift, Lo-fi chill, Cinematic, Upbeat pop, Modern hip-hop, Warm acoustic, Tech / electronic,
  Luxury minimal, Sport / hype, Playful. Each has its own tempo, harmony (progressions with smooth voice leading),
  instruments (electric piano, piano, plucked strings, marimba, strings, pads, leads, sub/808/plucked bass) and drums.
- **Fitted to the video:** the tempo is nudged so a whole number of bars lands on the final chord, which rings out on
  the last frame; a light intro, the body, lifts with risers, and a big last two bars.
- **Mixed for voice:** a gentle dip where speech sits, sidechain pumping only in the styles that want it, a limiter.
- Mastered to -14 LUFS, placed at -17 dB under the dialogue (`music.ai_level_db`).

## The music director and each client's sound

- **Sound identity** (`sound-style.json` in the client folder): a style that suits the business and the other clients
  use least, a key that differs from theirs, a seed (the client's motif and instrument colours) and an effects flavour
  from the client's motion look. Same client, same sound, every video. Change it in **Look book → Sound** (or Shuffle).
- **Per video,** the AI brain reads `knowledge/music.md` (genre by business, energy by video type, mixing under voice,
  sonic branding, when to use effects) and what the video says, then picks the energy and tempo (and a better style if
  the client's doesn't fit). Rules do it without an AI.
- brand.yaml `music:` `source` (auto = the client's own track if set, else composed | file | composed | none),
  `style` and `energy` to force them.

## Optional: AI music (ACE-Step 1.5)

[ACE-Step 1.5](https://github.com/ace-step/ACE-Step-1.5) is an open-source music model under the MIT licence; its model
card says generated music may be used commercially and that it was trained on licensed, royalty-free/public-domain and
synthetic data. `autocut music-setup` installs it (needs uv; a Mac with Apple Silicon, 16 GB+ memory, or an NVIDIA GPU;
the model downloads on first use, several GB). AutoCut then starts its local API, sends the music director's prompt,
tempo, key and seed, fits the result to the video, and falls back to the Composer if anything fails.
`music_ai: {engine: composer}` in This Mac's settings turns it off.

Not chosen: Meta's MusicGen weights are non-commercial; Stable Audio's community licence caps revenue at $1M a year.

## Sound design

`sfx.py` synthesizes 13 kinds of effect in 8 flavours (clean, hard, digital, airy, soft, cinematic, paper, bubbly).
`design.py` maps edit events to them: transitions and B-roll → whoosh, graphics → swish, lower third → swipe, slam and
hook → impact/hit, numbers and stickers → pop, reveals → a riser that ends on the moment, end card → impact + shimmer.
Each effect's peak lands on its event; effects stay at least 1.2 s apart (light 2.5 s, rich 0.6 s), about one every
3–4 s, and the more important event wins a clash. Switch: **Sound design**; brand.yaml `sound:` density, level, flavour.

## The AI sound designer (cue sheet)

Before the effects and the music are made, `director.sound_plan()` spots the whole video like a trailer editor: it
reads what is said (timed sentences), what moves on screen (the edit's events) and the client's `sound.notes`
("dark and punchy, a riser before the offer"), and returns a **cue sheet** (`cue-sheet.json` in the job):

- **sections**: the music's energy over time (0 silent, 1 light, 2 body, 3 full). The Composer follows it bar by bar.
- **breaks**: up to two key lines that land in space; the drums drop for the bar before and a riser fills it.
- **cues**: extra moments that deserve a sound (a big number, the brand name, the offer, the end card).

It asks the AI brain (local first, knowledge/music.md "Spotting a video"); with no AI, rules do it: hits on numbers
and power words, a break and riser into the last line (usually the offer), the end hit. Short form edits
(pipeline), Create-tab renders and `mix_video()` all use it. Settings: `sound.ai_plan` (on), `sound.ai_plan_brain` (on).

## AutoCut's own voice

`voice.py` speaks text with a local voice model (Kokoro, Apache-2.0): free, offline, no account. `speak(text, out,
voice="am_michael:60,am_onyx:40")` writes a 48 kHz broadcast-ready WAV. Voices can be blended. No voice cloning.

## AI dubbing

A finished short → More → **Dub into another language** (or `autocut dub <job folder> --lang es`, or the MCP tool
`dub_video`). `dub.py` translates each sentence with the AI brain, keeping it about as long as the original (no AI? paste
your own translation, one line per sentence), then voices it with AutoCut's own voice: the built-in Kokoro voice for that
language (Spanish, French, Italian, Portuguese, Hindi, English; male or female). It never imitates the speaker. Each
line starts where the original did; a line that's too long is re-spoken faster (up to 1.3×), and if it still runs over
it pushes the next line back a little rather than being cut or talking over it.

Out comes `dub-<lang>/` in the job: `dub.wav`, translated captions in the client's style (`captions-<lang>.srt/.ass/.mov`),
a Premiere XML with the dub on A1 (the original music and effects kept on A2/A3, the translated captions on V11), a
preview MP4 and `dub.json` (every line, its speed, whether it fit). The sequence name and a marker say it's AI-dubbed:
label it as AI when posting. The voice model downloads once (about 340 MB): the Dub window offers it, or
`autocut voice-setup`.

## Also

- Storyboards and transcript videos come out scored (music + effects), with `music.wav` and `effects.wav` alongside.
- **Create tab → Music & sound:** a bed of any length in any style, with stems and the client's effects pack.
- CLI: `autocut music CLIENT SECONDS OUT.wav [--style --energy --notes]`, `autocut sfx-pack CLIENT FOLDER`.
