# Shared monthly totals (marketing numbers)

Every AutoCut computer counts its own month: videos edited, hours of editing saved (estimated), average
footage-to-XML time. That's the "Your month in AutoCut" pop-up. Owners **can choose** to share those totals with
Triumphant Media, so you can say things like "AutoCut agencies saved 1,240 editing hours in October".

## What's sent, and what never is

Once a month, from each computer that said yes, one row (`autocut/stats.py`):

| Field | Example | |
|---|---|---|
| month | 2026-10 | the month the totals are for |
| install | 3f9c… | a random id made on that computer, so a month isn't counted twice; not linked to a person |
| version, os, tier, chip | 0.26.0, mac, pro, arm64 | which AutoCut, and how fast the computer is |
| videos, pieces | 42, 61 | videos edited; everything made (videos + graphics + motion + music) |
| hours_saved, footage_minutes | 31.5, 380 | estimate, from results.py `ESTIMATES` |
| avg_turnaround_minutes, fastest_minutes | 6.2, 2.9 | measured footage-to-XML time |
| rough_cuts, clips, multicam, extra_shapes, graphics, motion_graphics, music | | counts by kind |
| agency | Bright Lane Media | **only** if they also ticked "Include my agency name (for case studies)" |

Never sent: client names, video names, transcripts, footage, graphics, brand kits, anything about an agency's
clients. Nothing is sent at all unless the person says yes (the monthly pop-up asks once; This Mac → Share monthly
totals changes it any time, and shows exactly what would be sent).

## Turning it on (one time, the owner)

1. Make a Google Sheet called **AutoCut stats**. Extensions → Apps Script, paste this, save:

   ```javascript
   const FIELDS = ["received", "month", "install", "agency", "version", "os", "tier", "chip", "videos", "pieces",
     "hours_saved", "footage_minutes", "avg_turnaround_minutes", "fastest_minutes", "rough_cuts", "clips",
     "multicam", "extra_shapes", "graphics", "motion_graphics", "music"];
   function doPost(e) {
     const row = JSON.parse(e.postData.contents);
     const sheet = SpreadsheetApp.getActive().getSheetByName("rows") || SpreadsheetApp.getActive().insertSheet("rows");
     if (sheet.getLastRow() === 0) sheet.appendRow(FIELDS);
     // one row per computer per month: replace a repeat
     const data = sheet.getDataRange().getValues();
     for (let i = data.length - 1; i > 0; i--) if (data[i][1] === row.month && data[i][2] === row.install) sheet.deleteRow(i + 1);
     row.received = new Date();
     sheet.appendRow(FIELDS.map(f => row[f] === undefined || row[f] === null ? "" : row[f]));
     return ContentService.createTextOutput("ok");
   }
   ```

2. Deploy → New deployment → type **Web app**, execute as **Me**, who has access **Anyone**. Copy the URL
   (`https://script.google.com/macros/s/…/exec`).
3. Put it in `autocut/content/catalog.json` → `"stats": {"url": "<that URL>"}` and ship a release
   (docs/RELEASING.md). Releases are signed, so nobody else can point computers somewhere else; content packs can't
   change this address either. (To try it on one computer first: `stats_url: <URL>` in that computer's settings.)

Computers send last month's row at start-up and once a day until it's gone (a day offline just delays it).

## Reading it

A second tab with formulas gives the headline numbers, e.g. for October:

```
Hours saved      =SUMIFS(rows!K:K, rows!B:B, "2026-10")
Videos edited    =SUMIFS(rows!I:I, rows!B:B, "2026-10")
Computers        =COUNTIFS(rows!B:B, "2026-10")
Avg turnaround   =AVERAGEIFS(rows!M:M, rows!B:B, "2026-10", rows!M:M, "<>")
```

Or point Looker Studio at the sheet for charts. Anything you publish is an estimate (time saved uses fixed minutes
per piece; see results.py), so say "about" or "estimated".
