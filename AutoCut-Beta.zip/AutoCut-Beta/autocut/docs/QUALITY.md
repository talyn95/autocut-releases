# AutoCut quality scoreboard

The nightly AI training (one area a day) runs a fixed benchmark, `tests/quality/bench.py`, on the five fictional
showcase brands (never real people or clients), and keeps a change only when its area improves and nothing else drops.
Scores are 0–10. "Auto" is the benchmark's automatic score (readability, contrast, safe zones, overlaps, edges,
hierarchy, content); "Craft" is a look at the rendered contact sheets. The AI is switched off for the benchmark so runs
are repeatable and free: it measures the rules path every computer has; the AI path is taught the same rules.

    PYTHONPATH=. python tests/quality/bench.py designs OUT_DIR

| Area | Auto | Craft | Last trained |
|---|---|---|---|
| Designs (Graphics, Magic Design) | **9.13** (was 7.94) | 7.5 (was 5.5) | 2026-10-26 |
| Editing | not scored yet | | Tuesdays |
| Sound design & music | not scored yet | | Wednesdays |
| Looks | not scored yet | | Thursdays |
| Overlays | not scored yet | | Fridays |
| AI brain | not scored yet | | Saturdays |

## 2026-10-26 · Designs (Monday) · 0.28.1

Benchmark built tonight: 15 Magic Design requests (3 per brand) × their sizes × 3 looks = 81 designs.
Before → after, same scorer: **7.94 → 9.13**. By template: quote 7.5 → 10, event 8.5 → 10, offer 8.0 → 10,
testimonial 8.0 → 9.0, stat 7.56 → 8.5, tips 7.83 → 8.0, product 9.0 = 9.0, thumbnail 7.5 = 7.5.
Contrast failures 22 → 1; overlaps 6 → 0; text at the edges 3 → 0.

- Quotes no longer end at an apostrophe ("…kids ask when we" → the whole quote); the name after a quote fills author/name.
- Events: day, time and place are pulled out into their own pills; the kind of event becomes the kicker; a button is added.
- Offers get all three parts: headline, terms line ("No contract, no excuses." / "This month only"), button; "LIMITED TIME" kicker when there's a deadline or a free offer.
- Stats keep their sign and unit ("+60 lb", not "60 lb" with a stray "+"); big numbers shrink to fit the width ($1,250,000 ran off a story).
- Headlines in sentence case; tips split their items from "title: a, b, c".
- Text colour by real contrast (WCAG) everywhere (hyper.on, used by motion graphics too): dark text on teal/purple instead of white.
- Brand accents used as text are adjusted until they read (3:1 large, 4.5:1 small kickers); star ratings too.
- Logos that would vanish into the background (lime or gold on cream) are shown in one solid colour (3:1, WCAG 1.4.11).
- The AI path: knowledge/design.md gained checkable rules; Magic Design's prompt gained two worked examples.

Craft notes (contact sheets): before, most rules-path designs were a lone lowercase headline in a big empty frame
(5.5). After, every design has a full hierarchy (kicker, headline, support, button, logo) and reads at thumb size
(7.5). Still weak: a stat or a tips title with nothing else to say ("2x faster builds", "5 ways to ship faster" with no
items: the rules can't invent content; the AI path fills them), thumbnails without a photo, stories that sit high
with a lot of air below.
