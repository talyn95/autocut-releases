# Releasing AutoCut

Every computer running AutoCut 0.21 or newer can update itself with one click (This Mac → Updates) from the agency's
**update feed**: a folder of files at a web address (or a shared office folder). Updates are signed, so a computer only
installs what was made with the agency's private release key.

## One-time setup

1. **The release key.** `python3 tools/release.py keygen` made it. The public half is `autocut/release_key.pub`
   (in the repo, shipped in every version). The private half is a 64-character hex string; keep it in a password
   manager and, for releases made from a Claude Code cloud session, as an environment secret named
   `AUTOCUT_RELEASE_KEY`. Never commit it. Anyone holding it can push code to every AutoCut.
2. **The feed address.** Anywhere that serves static files over HTTPS works: a public GitHub repository's Releases
   (or GitHub Pages), a folder on the agency website, S3/R2, or a shared office folder (`/Volumes/…` or `\\server\…`).
   The feed URL is the address of `feed.json` there.
3. **Point the computers at it.** This Mac → Updates → "Where updates come from" (or `updates: feed_url:` in the
   settings file). To set it for every new install, put it in the repo's `settings.yaml` under `updates:`.

Computers on 0.20 or older don't have the updater or the key yet: send them the 0.21 zip once; after that, everything
comes through the feed.

## Making a release

**Normally the release robot does it** (`.github/workflows/release.yml`, set up in docs/OWNER-GUIDE.md): after the
change and the CHANGELOG section are committed with the new version, push a tag (`git tag v0.22.0 && git push origin
v0.22.0`; `v0.22.1-beta` goes to the beta channel) or press Run workflow in the Actions tab. It runs the tests,
builds, signs with the `AUTOCUT_RELEASE_KEY` secret and publishes to the `feed` release of the public releases repo,
whose address never changes: `https://github.com/<owner>/autocut-releases/releases/download/feed/feed.json`.

By hand, from any computer with the key:

1. Make the change, run the tests (`python3 -m unittest`), bump `autocut/__init__.py` `__version__`, and write the
   `CHANGELOG.md` section for the version (the notes and What's new come from it). Commit.
2. Build and sign:
   ```bash
   python3 tools/release.py build                 # stable channel
   python3 tools/release.py build --channel beta  # or beta first (a few computers set to Beta try it)
   ```
   This writes `dist/`: `AutoCut-update-<version>.zip` (the code), the two installer zips for new computers, `AutoCut-<version>.dmg` (the
   Mac download as a disk image: needs `hdiutil` on a Mac, or xorriso + `AUTOCUT_DMG_TOOL` on Linux, as the workflow does),
   `pack-*.zip` for every pack in `packs/`, `feed.json` and `feed.json.sig`. The release is self-tested before it's
   signed, and `verify` runs at the end. Keep `dist/feed.json` between releases (the other channel's entry is kept).
3. Upload everything in `dist/` to the feed address (replace `feed.json` and `feed.json.sig` last).
   Triumphant Media's feed is the public repo `talyn95/autocut-releases` (served from
   `https://raw.githubusercontent.com/talyn95/autocut-releases/main/feed.json`):
   `python3 tools/release.py publish-git --repo-dir <clone of autocut-releases>` commits the files there and pushes
   (the weekly upgrade does this). From GitHub Actions, `publish-github --repo <owner/repo>` uses GitHub Releases instead.
4. Computers see the banner within a day (or at once with "Check for updates"). They install, self-test, switch,
   restart, and show What's new. If something's wrong on a computer, **Roll back** there; for everyone, release a fix
   with a higher version (feeds never go backwards).

`--min-version X` marks a release that older versions must not jump to directly (they're told to install the zip).

## Content packs only

New looks, storyboards and music styles don't need a code release: add the pack under `packs/`, check it
(`python3 -m autocut pack check packs/<id>`), and run `tools/release.py build` again (the version stays the same; only
the pack list changes). Computers see "Add" next to the pack on This Mac → Content packs.

## How a computer installs (updates.py)

1. Download `feed.json` + `.sig`, verify the Ed25519 signature against `release_key.pub`
2. Download the zip, check its SHA-256 against the signed feed
3. Unpack into `<AutoCut folder>/.autocut-updates/staging`; install new Python packages if `requirements.txt` changed
4. Run the new version's `autocut selftest` with this computer's Python; any failure stops here, nothing changed
5. Move the current code to `.autocut-updates/versions/<version>-<time>` and the new code into place (all or nothing),
   keep the last 3 versions for Roll back
6. Restart on request; `migrations.py` runs any one-time steps and What's new shows the new changelog sections

Never touched: `.venv`, `.git`, and everything in the data folder (clients, footage, settings, packs, models).

## Rotating the key

Generate a new key with `keygen --force --out new.key` (it appends the new public key to `release_key.pub`), release a
version signed with the **old** key that ships both public keys, then sign later releases with the new key and remove
the old public key in a later release.

## Git installs

A computer whose AutoCut folder is a git checkout with a remote (the older shared-Mac setup) keeps updating with
`git pull` (mac/update.sh, windows/update.ps1) when no feed is set.
