# Extending AutoCut

AutoCut is built to keep up as motion design, editing styles and AI models move on. New things arrive in one of
three ways, from the lightest to the heaviest:

| What changes | How it arrives | Restart? | Who can make it |
|---|---|---|---|
| A new look, storyboard, music style, sound flavour, marketing know-how | **Content pack** (data, `pack.json`) | No | Anyone; checked before use |
| A better free AI model, a new Claude model, an experiment switch | **Catalog** (`autocut/content/catalog.json`) or a pack's `catalog` section | No | A pack (ai / whisper / features) or an update |
| New layouts, templates, instruments, effects, engines, features | **Signed app update** (docs/RELEASING.md) | Yes (one click) | Releases signed with the agency key |

Rule of thumb: if it's a new *combination* of things AutoCut can already draw or play, make it a pack. If it needs a
new drawing routine, instrument or pipeline step, it's code and ships in an update.

## Content packs

A pack is a folder with a `pack.json` (and optionally `knowledge/*.md`). Start one with
`python3 tools/release.py new-pack my-pack` (it lands in `packs/my-pack`), check it with
`python3 -m autocut pack check packs/my-pack`, and either:

- publish it on the update feed (everything in `packs/` is zipped and signed by `tools/release.py build`), or
- zip the folder and add it on a computer: **This Mac → Content packs → Add a pack**, or `autocut pack install x.zip`.

Packs installed on a computer live in `<data folder>/packs/` (next to `clients/`), so updates never remove them.
Packs that ship inside AutoCut live in `autocut/content/packs/`. A pack can be switched off on the This Mac tab.

```json
{
  "id": "spring-2027", "name": "Trends: spring 2027", "version": "1.0.0", "author": "Triumphant Media",
  "description": "One line for the This Mac tab.", "min_app": "0.21.0",
  "looks": { … }, "storyboards": { … }, "music_styles": { … }, "style_fits": { … },
  "sfx_flavours": { … }, "look_flavour": { … }, "knowledge": { … }, "catalog": { … }
}
```

Keys are lowercase letters, digits, dashes and underscores. Packs only **add**: a key that's built in is refused, so
no existing client's look or sound ever changes under them. If two packs use the same key, the first (by id) wins and
the other is flagged. Every entry is checked against what AutoCut can actually draw or play; a bad entry is skipped
and listed under the pack on the This Mac tab, and the rest of the pack still works.

When a pack is switched off, clients that were handed one of its looks or music styles temporarily use the built-in
one it was based on (`base`); their own choice comes back when the pack does.

### looks

Start from a built-in look with `base` and change what makes it different. Every token is described at the top of
`autocut/mograph/library/looks.py`; the allowed values are the ones the built-in looks use (the check lists them).

```json
"looks": {
  "aurora": {
    "base": "glass", "name": "Aurora Glow",
    "inspired_by": "where the idea comes from (a trend, a marketplace category)",
    "mood": ["dreamy", "modern"], "fits": ["wellness", "skincare", "app"],
    "head": ["Poppins", 600], "num": ["Poppins", 700],
    "panel": "gradient", "motif": "blob", "ease": "sine.out", "speed": 0.85, "palette": "duo"
  }
}
```

`fits` (industry words) and `mood` decide which new clients the look suits; the style DNA (`dna.py`) hands new looks
out like the built-in ones, keeping clients apart. Fonts: any of the fonts HyperFrames bundles
(`hyper.BUNDLED_FONTS`); a client's own brand fonts still win.

### storyboards

Slots are the copy (`[name, hint for the AI, default]`); scenes use the existing kinds and layouts
(`lower_third, title, chart, callout, list, quote, end_card, transition`; layouts in `elements.LAYOUTS`).
`{slot}` fills a scene's text, `"each": "items"` repeats a scene per line of a slot (`{item}`, `{n}`),
`{brand}` and `{count}` are always available. Include a `sub` slot (website or handle) for the end card.

```json
"storyboards": {
  "myth_fact": {
    "name": "Myth vs fact", "use": "educational reels, 18–30 s",
    "slots": [["myth", "the belief (max 8 words, *one keyword*)", "Myth: you need a *new* roof"],
              ["fact", "the truth (max 9 words)", "Most roofs just need a repair"],
              ["cta", "call to action", "Book a free inspection"], ["sub", "website or handle", ""]],
    "scenes": [{"kind": "title", "layouts": ["mask", "boxed"], "params": {"text": "{myth}", "kicker": "Myth"}, "dur": 3.0},
               {"kind": "title", "params": {"text": "{fact}", "kicker": "Fact"}, "dur": 3.0},
               {"kind": "end_card", "params": {"text": "{cta}", "sub": "{sub}"}, "dur": 3.6}]
  }
}
```

### music_styles, style_fits

Start from a built-in style (`sound/composer.py` STYLES) and change tempo, mode, chords, instruments and drums.
Drums are three energy levels of 16-step patterns (`x` hit, `o` soft, `.` rest). `ace` is the prompt for the optional
ACE-Step AI music model. `style_fits` adds industry words that point new clients at a style.

```json
"music_styles": {
  "synthwave": {"base": "tech", "name": "Synthwave drive", "bpm": 100, "mode": "minor",
                "progs": [[1, 6, 3, 7]], "arp": ["lead_saw", "up16"],
                "drums": {"1": {"kick": "x.......x......."}, "2": {…}, "3": {…}},
                "mood": "retro, nostalgic, driving", "ace": "synthwave instrumental, 80s analog synth arpeggios"}
},
"style_fits": {"synthwave": ["arcade", "retro", "car wash"]}
```

### sfx_flavours, look_flavour

A flavour shapes all 13 synthesized sound effects: `bright`, `hard`, `room` (0–1), `length` (0.3–3), optional
`glitchy` / `grain`. `look_flavour` gives a new look its sound.

### knowledge

Marketing know-how appended to a knowledge topic (`core, hooks, retention, platforms, ads, copy, scripts, strategy,
agency, design, motion, music, prompting`). Either `"knowledge": {"motion": "text…"}` or files in the pack's
`knowledge/` folder named after the topic (`knowledge/motion.md`). Every AI feature that reads that topic picks it up.

### catalog

A pack may add to three parts of `catalog.json`: `ai` (a new local model tier, a new Claude model and its price,
OpenAI-compatible presets), `whisper` (speech model repos) and `features` (experiment switches). Engine versions
(`engines`) change only with an app update, because templates are tested against them.

## The catalog (`autocut/content/catalog.json`)

Everything outside AutoCut that changes over time, in one file:

- `ai.local.tiers`: the free local model by computer memory (`local_model: auto` follows it)
- `ai.claude`: the default Claude model (`claude_model: auto` follows it) and prices for the monthly cap
- `ai.openai_compatible.presets`: addresses of common local AI servers (LM Studio, vLLM, llama.cpp, Jan)
- `whisper`: speech-to-text models; `music.acestep_repo`: the AI music model
- `engines`: the pinned HyperFrames and GSAP versions (moving the pin reinstalls the runtime on each computer)
- `features`: experiment switches, `{"name": {"default": false, "label": "…", "about": "…"}}`; code asks
  `content.feature(settings, "name")`, and This Mac → Content packs → Experiments turns them on per computer

## Adding code (in an update)

- **A layout**: a function in `mograph/library/elements.py` added to `LAYOUTS[kind]`; every look draws it.
  Add it to a showcase case and to `docs/LIBRARY.md`.
- **A look token value** (a new panel, motif, entrance): teach `compose.py`/`elements.py` to draw it and use it in at
  least one built-in look; packs can then use it too (the checks allow what the built-ins use).
- **An instrument or drum**: `sound/synth.py` + composer; use it in a built-in style so packs can use it.
- **An effect**: see "Adding a new effect" in CLAUDE.md.
- **An AI provider**: a `_ask_<name>(settings, system, prompt, schema, images, timeout)` in `brain.py`, added to
  `ENGINES` and the order in `ask()`, with its status in `status()` and the This Mac AI panel.
- **Saved data that changes shape**: add a migration in `migrations.py` (never edit an old one).
- **Anything that could fail on someone's computer**: add a check to `selftest.py`; updates run it before switching.

Then follow docs/RELEASING.md.
