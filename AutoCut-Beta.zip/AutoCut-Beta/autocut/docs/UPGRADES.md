# Weekly upgrades

Every Monday AutoCut gets one substantial upgrade, picked from what competitors just shipped (or the area upgraded least
recently), tested, and published automatically once the whole gate passes. Read this first to choose the next area.

Areas rotate: AI brain/LLM · motion graphics · short-form edits and captions · Explainer split · clip generator ·
sound and music · social graphics · multicam/long form · brand kit and first run.

| Date | Area | What changed | Why | Competitor trigger | Version | Published |
|---|---|---|---|---|---|---|
| 2026-10-26 | Short-form edits and captions (owner's pick) | 13 new caption styles + gallery, emphasis words (AI + rules), 9:16 safe zones, icon pops; smart punch-ins on emphasis words; AI dubbing in AutoCut's own voice (6 languages) with translated captions, XML and preview; teleprompter recorder in the dashboard | The owner asked to match what the Captions app does well for talking-head editing, ethically: our own designs and names, open models only, no cloning | Captions (captions.ai): caption styles, AI zooms, AI dubbing, teleprompter. Quiet week otherwise (no dated launches found from Descript, CapCut, Opus Clip, Submagic, FireCut) | 0.29.0 | yes |

## Next steps (from the 2026-10-26 run)

- Smooth (animated) push-ins as well as hard punches: needs scale keyframes in the XML writer and the preview renderer
- Dub lip-sync and "fix a word" in the voice: only with the speaker's own footage and consent, open models, labelled AI
- Japanese and Chinese dubbing: Kokoro has the voices; needs their phonemizers bundled
- Teleprompter: pick the camera/microphone, a remote (phone) scroll control, keep several takes and pick the best
- Caption styles in the Clip generator's per-clip panel and in the Effects/Explainer edits
