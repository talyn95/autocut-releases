# Content packs for the update feed

Each folder here with a `pack.json` is checked, zipped and signed into the feed by `python3 tools/release.py build`.
Start one with `python3 tools/release.py new-pack <id>`; the format is in docs/EXTENDING.md. Packs that should ship
inside AutoCut itself go in `autocut/content/packs/` instead.
