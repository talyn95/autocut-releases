@echo off
rem Double-click to install AutoCut on this Windows PC.
title Install AutoCut
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\install.ps1" %*
echo.
pause
