# AutoCut roadmap and tech radar

How AutoCut keeps up: what we watch, how each kind of change gets in, and what's next. Review it monthly (see
"The monthly check" below) and keep it short: move things between rings, delete what's done or dead.

## How change gets in

| Change | Path | Effort |
|---|---|---|
| A new visual trend, music style, storyboard structure | Content pack (docs/EXTENDING.md) on the update feed | An hour; no restart |
| A better free AI model, a new Claude model, a new speech model | `content/catalog.json` (or a pack's catalog section) | Minutes; "auto" settings follow |
| A new layout, template, instrument, effect, engine version | Code + signed update (docs/RELEASING.md) | A release; one click per computer |
| A new AI provider or engine | `brain.ENGINES`, a module like `sound/aimusic.py`, with a rules fallback | A release |

## Tech radar

**Adopt** (in AutoCut now, keep current)
- HyperFrames + GSAP for motion graphics (pinned in the catalog; bump `engines` after testing the showcase)
- Local Whisper (MLX / faster-whisper) for transcripts; Ollama + Gemma 3 as the free brain; Claude as backup
- Composer (numpy synthesis) for music and sound effects; ACE-Step 1.5 as the optional AI music model
- Content packs and signed updates for everything that changes faster than code

**Trial** (worth a pack, a catalog entry or a switched-off experiment)
- OpenAI-compatible local servers (LM Studio, vLLM, llama.cpp) as a second free brain: in 0.21
- Newer open models with vision for reading references and footage (watch Gemma, Qwen-VL, Llama vision releases)
- Word-level forced alignment for tighter caption timing
- Voice cleanup models (DeepFilterNet-class) to sit next to the ffmpeg Studio Sound chain

**Assess** (watch; prototype when a client need appears)
- Local text-to-video and image-to-video for B-roll (Wan, LTX-Video, Hunyuan-class) as they get fast enough on a Mac
- AI voiceover and voice cloning that runs locally (Kokoro is used for drafts; consent rules first)
- Generative upscaling and frame interpolation for old footage
- Auto-reframe with face/pose models beyond segmentation; eye-contact correction
- Native Premiere project export (beyond FCP7 XML) and DaVinci Resolve timelines

**Hold** (not now)
- Cloud-only render services and per-seat SaaS AI in the core path: every feature must work offline with a rules fallback
- Copying paid marketplace templates (Envato, Motion Array): we model categories, never assets

## Next up

1. Publish the first update feed (agency picks the host) and move every computer to 0.21 once by zip
2. A pack every season: 2–3 looks from that season's best-selling template categories, 1–2 storyboards, 1 music style
3. Layouts that packs keep asking for (a new chart type, a social-proof wall, a map pin) → code release
4. Engine bumps: HyperFrames/GSAP after the showcase passes on the new version

## The monthly check

Once a month (a scheduled Claude Code task can do the research and draft this):
- What's new in motion design (marketplace best-sellers, award reels), short-form editing styles, and AI models
  (local LLMs, speech, music, video), with licences
- Which of those AutoCut should add, ranked by value to the agency's clients, and which path (pack / catalog / code)
- Draft the pack or catalog change; code changes go to a branch with tests, then a beta release
