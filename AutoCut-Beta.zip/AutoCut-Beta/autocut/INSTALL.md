# Installing AutoCut: one page

AutoCut runs **on each computer by itself**: a Mac or a Windows PC. There's no server and nothing is shared.
Each computer has its own clients, footage and finished work. Install it on every computer the same way.

| Computer | What to do | Time |
|---|---|---|
| **Mac** (macOS 13+, Apple Silicon best) | Double-click **Install AutoCut** → **On its own** | 15–30 min, once |
| **Windows 10/11 PC** (64-bit) | Double-click **Install AutoCut (Windows).cmd** | 15–30 min, once |
| **Phone / iPad** | Optional: open a computer's dashboard address in the browser (see the end) | 10 sec |

---

## Mac

1. Download the AutoCut package and double-click it to unzip.
2. Open the unzipped **autocut** folder.
3. **Right-click → Open** on **Install AutoCut** (the first time only, because macOS asks about
   files from the internet). Click **Open** again if asked.
4. Choose **On its own**. Answer the questions; the defaults are fine.
   Type your Mac password when asked (it's for Homebrew, the Mac tool installer). The cursor doesn't move while you type, and that's normal.

When it finishes, **✂** appears in the menu bar. Click it, then **Open Dashboard**.

- AutoCut: `~/AutoCut`. Clients, footage and finished work: `/Users/Shared/AutoCut/clients`.
- This Mac's own settings: `~/Library/Application Support/AutoCut/settings.yaml` (also under **This Mac** in the dashboard).

## Windows PC

1. Download the AutoCut package. Right-click it → **Extract All…** (don't run it from inside the zip).
2. Open the extracted **autocut** folder and double-click **Install AutoCut (Windows).cmd**.
   If Windows shows "Windows protected your PC", click **More info → Run anyway**.
3. Answer the questions in the window; the defaults are fine. Approve the installs Windows asks about.
   It installs Python 3.12, ffmpeg and the free AI (Ollama) with winget, which is built into Windows.

When it finishes, AutoCut opens in the browser. Start it later from **AutoCut** in the Start menu or on the Desktop.
A small AutoCut window sits in the taskbar while it runs: **close that window to quit AutoCut**.

- AutoCut: `%USERPROFILE%\AutoCut`. Clients, footage and finished work: `C:\Users\Public\AutoCut\clients`.
- This PC's own settings: `%APPDATA%\AutoCut\settings.yaml` (also under **This PC** in the dashboard).
- Speed: an NVIDIA, Intel or AMD graphics chip encodes the videos (AutoCut finds and tests it). An NVIDIA card
  also speeds up transcription if NVIDIA's CUDA libraries are installed. Without them, the CPU does the work, more slowly.
- Mac-only for now: AI image generation (mflux), Kinetik Motion Studio, and the menu-bar icon.

## Installed by Claude Code (beta testers)

Send the AutoCut-Beta package. It has `START HERE.md`, `PASTE INTO CLAUDE.md` (Mac), `PASTE INTO CLAUDE (Windows).md`
and the `autocut` folder. The tester pastes the right file into Claude Code, which runs the installer hands-free:
`bash ~/AutoCut/mac/install.sh --solo --yes` on a Mac (after the tester installs Homebrew, which needs their password),
or `windows\install.ps1 -Yes` on Windows.

## Updating later

New versions come as a new package: install it the same way on each computer. The old copy of the app is renamed
(not deleted), and clients, footage and settings are kept because they live outside the app folder.

## Phones and iPads (optional)

To upload footage or check jobs from a phone on the office Wi-Fi, turn it on for one computer: in its dashboard,
**This Mac / This PC → Settings for this … only**, add `listen_on_network: true`, save, then quit and reopen AutoCut.
The address to open is shown there under **Add another device**. Anyone on the office network can then open it.

## If something goes wrong

| Problem | Fix |
|---|---|
| **Mac: "Install AutoCut" can't be opened** | Right-click → Open (not double-click) the first time |
| **Windows: "Windows protected your PC"** | More info → Run anyway |
| **Windows: the AutoCut shortcut does nothing** | Open http://127.0.0.1:8765. If that fails, double-click `windows\AutoCut.cmd` in `%USERPROFILE%\AutoCut` and send what it says |
| **Anything else** | Dashboard → **This Mac / This PC** shows a health check. Send the **Log** of a failed job |

---

### The older shared office setup (optional)

A Mac can still run as an **office server** whose queue other Macs share over the network (choose **Office server**
in the Mac installer; README → *Sharing one queue between Macs*). Most people don't need this: with every computer
on its own, nothing depends on another machine being on.
