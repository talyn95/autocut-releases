# Refresh AutoCut on this PC. Run by the dashboard's "Update AutoCut" button, or by hand:
#   powershell -ExecutionPolicy Bypass -File $env:USERPROFILE\AutoCut\windows\update.ps1
$ErrorActionPreference = "Stop"
$Repo = Split-Path -Parent $PSScriptRoot
Set-Location $Repo
$vpy = Join-Path $Repo ".venv\Scripts\python.exe"
$remote = $null
if (Get-Command git -ErrorAction SilentlyContinue) { try { $remote = git remote 2>$null } catch {} }
if (-not $remote) {
    Write-Output "This PC gets new versions of AutoCut as a package (AutoCut-Beta.zip)."
    Write-Output "Unzip the new one and double-click 'Install AutoCut (Windows).cmd' inside it."
    Write-Output "Your clients, footage and settings are kept: they live outside the AutoCut folder."
    exit 1
}
if (git status --porcelain) {
    Write-Output "This PC has uncommitted code changes in ${Repo}:"
    git status --short
    Write-Output "Commit them (or discard them) before updating, so nothing is lost."
    exit 1
}
$before = git rev-parse --short HEAD
git pull --ff-only
$after = git rev-parse --short HEAD
& $vpy -m pip install -r requirements.txt -q
if ($before -eq $after) { Write-Output "Already up to date ($after)." }
else {
    Write-Output "Updated $before -> ${after}:"
    git log --oneline "$before..$after"
    Write-Output "Close the AutoCut window and open AutoCut again to use the new version."
}
