@echo off
rem Starts AutoCut on this PC (the Start menu and Desktop shortcuts run this).
rem Keep this window open (it starts minimised); close it to quit AutoCut.
title AutoCut
cd /d "%~dp0.."
set PYTHONUTF8=1
rem Already running? Just open the dashboard.
".venv\Scripts\python.exe" -m autocut open >/dev/null 2>&1 && exit /b 0
if not exist "%LOCALAPPDATA%\AutoCut" mkdir "%LOCALAPPDATA%\AutoCut"
echo AutoCut is running on this PC. Keep this window open; close it to quit AutoCut.
echo (Its log: %LOCALAPPDATA%\AutoCut\AutoCut.log)
".venv\Scripts\python.exe" -m autocut app >> "%LOCALAPPDATA%\AutoCut\AutoCut.log" 2>&1
