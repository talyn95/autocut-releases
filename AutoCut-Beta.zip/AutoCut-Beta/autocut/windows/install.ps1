# AutoCut installer for a Windows 10/11 PC. Everything runs on this PC: no server, nothing shared.
#
#   Double-click "Install AutoCut (Windows).cmd" in the AutoCut folder, or in PowerShell:
#       powershell -ExecutionPolicy Bypass -File windows\install.ps1
#   Hands-free (no questions; for Claude Code or another script): add -Yes
#
# Installs (with winget, built into Windows): Python 3.12, ffmpeg and, if you say yes, Ollama (the free AI).
# AutoCut itself goes in %USERPROFILE%\AutoCut; clients and footage in C:\Users\Public\AutoCut.
param([switch]$Yes)
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

function Say($msg) { Write-Host "`n> $msg" -ForegroundColor Cyan }
function Ask($question, $default = "yes") {
    if ($Yes) { Write-Host "  $question -> $default (hands-free install)"; return $default -eq "yes" }
    $hint = if ($default -eq "yes") { "[Y/n]" } else { "[y/N]" }
    $a = Read-Host "$question $hint"
    if ([string]::IsNullOrWhiteSpace($a)) { return $default -eq "yes" }
    return $a.Trim().ToLower().StartsWith("y")
}
function Refresh-Path {
    $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [Environment]::GetEnvironmentVariable("Path", "User")
}
function Winget-Install($id, $name) {
    Write-Host "  installing $name ..."
    winget install --id $id -e --silent --accept-package-agreements --accept-source-agreements | Out-Null
    Refresh-Path
}

# 0. Put AutoCut in %USERPROFILE%\AutoCut ------------------------------------------------
$Here = Split-Path -Parent $PSScriptRoot
$Dest = Join-Path $env:USERPROFILE "AutoCut"
if ((Resolve-Path $Here).Path.TrimEnd("\") -ne $Dest.TrimEnd("\")) {
    if (Test-Path $Dest) {
        $old = "$Dest-old-$(Get-Date -Format yyyyMMdd-HHmmss)"
        Write-Host "Moving the previous copy to $old (your clients and settings are kept; they live elsewhere)"
        Move-Item $Dest $old
    }
    Write-Host "Copying AutoCut to $Dest"
    Copy-Item $Here $Dest -Recurse
}
Get-ChildItem $Dest -Recurse -File | Unblock-File   # files from a downloaded zip are blocked until unblocked

# 1. Tools ------------------------------------------------------------------------------------
Say "Checking tools (first time takes 5-15 minutes)"
if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    Write-Host "winget isn't on this PC. Install 'App Installer' from the Microsoft Store, then run this again." -ForegroundColor Red
    exit 1
}
Refresh-Path
$py = $null
try { $py = (& py -3.12 -c "import sys; print(sys.executable)" 2>$null) } catch {}
if (-not $py) {
    Winget-Install "Python.Python.3.12" "Python 3.12"
    try { $py = (& py -3.12 -c "import sys; print(sys.executable)" 2>$null) } catch {}
    if (-not $py) {
        $py = @((Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"),
                (Join-Path $env:ProgramFiles "Python312\python.exe")) | Where-Object { Test-Path $_ } | Select-Object -First 1
    }
}
if (-not $py -or -not (Test-Path $py)) { Write-Host "Python 3.12 didn't install. Install it from python.org, then run this again." -ForegroundColor Red; exit 1 }
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) { Winget-Install "Gyan.FFmpeg" "ffmpeg" }
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
    # winget puts ffmpeg's folder on PATH for new windows; find it for this one
    $ff = Get-ChildItem (Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Packages") -Recurse -Filter ffmpeg.exe -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($ff) { $env:Path = "$($ff.DirectoryName);$env:Path" } else { Write-Host "ffmpeg didn't install. Run: winget install Gyan.FFmpeg" -ForegroundColor Red; exit 1 }
}

# 2. Python environment -------------------------------------------------------------------------
Say "Installing AutoCut's Python packages"
$venv = Join-Path $Dest ".venv"
if (-not (Test-Path (Join-Path $venv "Scripts\python.exe"))) { & $py -m venv $venv }
$vpy = Join-Path $venv "Scripts\python.exe"
& $vpy -m pip install --upgrade pip -q
& $vpy -m pip install -r (Join-Path $Dest "requirements.txt") -q
if ($LASTEXITCODE -ne 0) { Write-Host "Couldn't install the Python packages (see above)." -ForegroundColor Red; exit 1 }

# 3. This PC's folders ------------------------------------------------------------------------------
$Shared = Join-Path $env:PUBLIC "AutoCut"
New-Item -ItemType Directory -Force (Join-Path $Shared "clients") | Out-Null
New-Item -ItemType Directory -Force (Join-Path $env:APPDATA "AutoCut") | Out-Null
Write-Host "  Clients, footage and finished work: $Shared\clients"

# 4. The free AI brain (Ollama + a model sized to this PC's memory) ------------------------------------
$memGB = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)
if ($memGB -ge 48) { $model = "gemma3:27b"; $size = 17 } elseif ($memGB -ge 20) { $model = "gemma3:12b"; $size = 8 } else { $model = "gemma3:4b"; $size = 3 }
if (Ask "Install the free AI brain? It runs on this PC at no cost: picks clips, writes hooks, titles, captions and hashtags, and reads motion-graphic prompts. Downloads about $size GB ($model for this PC's $memGB GB of memory)." "yes") {
    Say "Installing the free AI brain ($model)"
    if (-not (Get-Command ollama -ErrorAction SilentlyContinue)) { Winget-Install "Ollama.Ollama" "Ollama" }
    $ollama = (Get-Command ollama -ErrorAction SilentlyContinue).Source
    if (-not $ollama) { $ollama = Join-Path $env:LOCALAPPDATA "Programs\Ollama\ollama.exe" }
    if (Test-Path $ollama) {
        $up = $false
        try { Invoke-WebRequest http://127.0.0.1:11434/api/tags -UseBasicParsing -TimeoutSec 2 | Out-Null; $up = $true } catch {}
        if (-not $up) { Start-Process $ollama -ArgumentList "serve" -WindowStyle Hidden; Start-Sleep 5 }
        & $ollama pull $model
        if ($LASTEXITCODE -eq 0) { Write-Host "  AI brain ready." } else { Write-Host "  ! Couldn't download the AI model now. Later, in PowerShell: ollama pull $model" }
    } else { Write-Host "  ! Ollama didn't install. Get it from https://ollama.com, then: ollama pull $model" }
}

# 4b. HyperFrames: the motion graphics engine (needs Node.js 22+, about 250 MB) ------------------------
if (Ask "Install the HyperFrames motion graphics engine? It makes the cleanest, most professional motion graphics and lets the AI design custom ones. Downloads about 250 MB." "yes") {
    Say "Setting up HyperFrames"
    if (-not (Get-Command node -ErrorAction SilentlyContinue)) { Winget-Install "OpenJS.NodeJS.LTS" "Node.js" }
    & $vpy -X utf8 -m autocut hyperframes-setup
    if ($LASTEXITCODE -ne 0) { Write-Host "  ! HyperFrames didn't set up. Later: $vpy -m autocut hyperframes-setup" }
}

# 5. Shortcuts --------------------------------------------------------------------------------------
Say "Adding AutoCut to the Start menu and Desktop"
$launcher = Join-Path $Dest "windows\AutoCut.cmd"
$icon = Join-Path $Dest "windows\autocut.ico"
$shell = New-Object -ComObject WScript.Shell
$places = @([Environment]::GetFolderPath("Programs"), [Environment]::GetFolderPath("Desktop"))
if (Ask "Start AutoCut automatically when you sign in to Windows?" "no") { $places += [Environment]::GetFolderPath("Startup") }
foreach ($dir in $places) {
    $lnk = $shell.CreateShortcut((Join-Path $dir "AutoCut.lnk"))
    $lnk.TargetPath = $launcher
    $lnk.WorkingDirectory = $Dest
    $lnk.WindowStyle = 7   # minimised: the AutoCut window sits in the taskbar; close it to quit AutoCut
    if (Test-Path $icon) { $lnk.IconLocation = $icon }
    $lnk.Description = "AutoCut video editing"
    $lnk.Save()
}

# 6. Check + download the speech model ------------------------------------------------------------
Say "Checking this PC and downloading the speech model (one time, about 1.5 GB)"
Push-Location $Dest
& $vpy -X utf8 -m autocut doctor --download
Pop-Location

Say "Done. Opening AutoCut (it also has a Start menu and Desktop shortcut)."
Start-Process $launcher -WorkingDirectory $Dest -WindowStyle Minimized
