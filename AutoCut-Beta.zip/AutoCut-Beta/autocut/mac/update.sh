#!/bin/bash
# Pull the latest AutoCut code and refresh packages + the app. Run by the
# dashboard's "Update AutoCut" button, or by hand: bash ~/AutoCut/mac/update.sh
set -e
REPO="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO"
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

if ! git remote get-url origin >/dev/null 2>&1; then
  echo "This Mac gets new versions of AutoCut as a package (AutoCut-Beta.zip)."
  echo "Unzip the new one and double-click \"Install AutoCut.command\" inside it."
  echo "Your clients, footage and settings are kept: they live outside the AutoCut folder."
  exit 1
fi
if [ -n "$(git status --porcelain)" ]; then
  echo "This Mac has uncommitted code changes in $REPO:"
  git status --short
  echo "Commit them (or discard them) before updating, so nothing is lost."
  exit 1
fi
BEFORE="$(git rev-parse --short HEAD)"
git pull --ff-only
AFTER="$(git rev-parse --short HEAD)"
.venv/bin/pip install -r requirements.txt -q
if [ "$(uname)" = "Darwin" ]; then bash mac/build_app.sh >/dev/null; fi
if [ "$BEFORE" = "$AFTER" ]; then
  echo "Already up to date ($AFTER)."
else
  echo "Updated $BEFORE → $AFTER:"
  git log --oneline "$BEFORE..$AFTER"
  echo "Quit AutoCut from the ✂ menu and open it again to use the new version."
fi
