#!/bin/bash
# Lives in the Mac Studio's shared AutoCut folder. On any other Mac:
#   Finder → Go → Connect to Server → smb://<mac-studio>.local/AutoCut, then double-click this.
cd "$(dirname "$0")" || exit 1
clear
echo "AutoCut — joining the office setup"
echo "=================================="
bash "$(pwd)/join.sh"
echo
read -r -p "All done — press Enter to close this window."
