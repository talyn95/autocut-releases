#!/bin/bash
# Run on a Mac Mini (or any extra Mac) to join the office AutoCut setup:
#   1. Finder → Go → Connect to Server → smb://<mac-studio>.local/AutoCut  (tick "Remember password")
#   2. Terminal:  bash /Volumes/AutoCut/join.sh
set -e
SHARE="$(cd "$(dirname "$0")" && pwd)"
URL="$(mount | awk -v p="$SHARE" '$3 == p {print $1}' | sed 's#^//[^@]*@#smb://#; s#^//#smb://#')"
DEST="$HOME/AutoCut"
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

# A brand-new Mac has no git yet: Homebrew brings Apple's developer tools (and git) with it.
if ! command -v brew >/dev/null 2>&1; then
  echo "Installing Homebrew first (enter your Mac password when asked — the cursor won't move while you type)…"
  sudo -v  # Homebrew needs an administrator password once
  NONINTERACTIVE=1 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do [ -x "$b" ] && eval "$("$b" shellenv)"; done
fi
command -v git >/dev/null 2>&1 || brew install git

# The code repo lives on the Mac Studio's disk; tell git that's expected.
git config --global --add safe.directory "$SHARE/code.git"
git config --global --add safe.directory /Users/Shared/AutoCut/code.git
if [ -e "$DEST" ] && [ ! -d "$DEST/.git" ]; then
  mv "$DEST" "$HOME/AutoCut-old-$(date +%Y%m%d-%H%M%S)"  # an old unzipped copy: keep it aside
fi
if [ -d "$DEST/.git" ]; then
  git -C "$DEST" pull -q --ff-only
else
  git clone -q "$SHARE/code.git" "$DEST"
fi
# Updates come from the Mac Studio, through the same path on every Mac.
git -C "$DEST" remote set-url origin /Users/Shared/AutoCut/code.git
AUTOCUT_SHARE_PATH="$SHARE" bash "$DEST/mac/install.sh" --join "$URL"
