#!/bin/bash
# AutoCut installer for an office Mac.
#
#   Main Mac (the Mac Studio — holds the shared queue + code):
#       bash ~/AutoCut/mac/install.sh --main
#
#   Every other Mac (Mac Minis): connect to the Mac Studio in Finder first
#   (Go → Connect to Server → smb://<mac-studio-name>.local/AutoCut), then:
#       bash /Volumes/AutoCut/join.sh
#   (join.sh copies the code from the Mac Studio and runs this script with --join)
#
#   Hands-free (no dialogs; for running from Claude Code or another script): add --yes.
#   Every question then takes the default shown in its ask line below. Homebrew must already
#   be installed in that case, because installing it needs your Mac password.
set -e
REPO="$(cd "$(dirname "$0")/.." && pwd)"
SHARED="/Users/Shared/AutoCut"
ROLE=""
SHARE_URL=""
while [ $# -gt 0 ]; do
  case "$1" in
    --main) ROLE=main ;;
    --join) ROLE=join; SHARE_URL="$2"; shift ;;
    --solo) ROLE=solo ;;
    --yes) export AUTOCUT_NONINTERACTIVE=1 ;;
  esac
  shift
done
if [ -z "$ROLE" ]; then
  echo "Usage: install.sh --main | --join <smb-url> | --solo"; exit 1
fi
say() { printf "\n\033[1m▸ %s\033[0m\n" "$1"; }

# Yes/No question as a Mac dialog (falls back to the Terminal). ask "Question?" [yes|no] && …
# With --yes (AUTOCUT_NONINTERACTIVE=1) nothing is asked: the second argument is the answer.
ask() {
  if [ -n "$AUTOCUT_NONINTERACTIVE" ]; then
    echo "  $1 → ${2:-yes} (hands-free install)"
    [ "${2:-yes}" = "yes" ]
    return
  fi
  local a
  a=$(osascript -e "button returned of (display dialog \"$1\" buttons {\"No\", \"Yes\"} default button \"Yes\" with title \"AutoCut\")" 2>/dev/null) \
    || { read -r -p "$1 [Y/n] " a; [ "${a:-Y}" != "n" ] && [ "${a:-Y}" != "N" ] && a=Yes; }
  [ "$a" = "Yes" ]
}

set_local() {  # set_local key value — this Mac's own settings file
  mkdir -p "$(dirname "$LOCAL_SETTINGS")"
  touch "$LOCAL_SETTINGS"
  grep -v "^$1:" "$LOCAL_SETTINGS" > "$LOCAL_SETTINGS.tmp" || true
  echo "$1: $2" >> "$LOCAL_SETTINGS.tmp"
  mv "$LOCAL_SETTINGS.tmp" "$LOCAL_SETTINGS"
}
LOCAL_SETTINGS="$HOME/Library/Application Support/AutoCut/settings.yaml"

# Homebrew installs ffmpeg/Python/git (and Apple's developer tools with it).
ensure_brew() {
  for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do [ -x "$b" ] && eval "$("$b" shellenv)"; done
  if ! command -v brew >/dev/null 2>&1 && [ -n "$AUTOCUT_NONINTERACTIVE" ]; then
    echo "Homebrew isn't installed yet, and installing it needs your Mac password."
    echo "In Terminal, run this, type your password when asked, then run the AutoCut install again:"
    echo '  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"'
    exit 1
  fi
  if ! command -v brew >/dev/null 2>&1; then
    say "Installing Homebrew (enter your Mac password when asked — the cursor won't move while you type)"
    sudo -v  # Homebrew needs an administrator password once
    NONINTERACTIVE=1 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do [ -x "$b" ] && eval "$("$b" shellenv)"; done
  fi
  command -v brew >/dev/null 2>&1 || { echo "Homebrew didn't install. See https://brew.sh, then run this again."; exit 1; }
}

# 1. Tools ------------------------------------------------------------------
say "Checking tools (first time takes 5–15 minutes)"
ensure_brew
for pkg in ffmpeg python@3.12 git node; do
  brew list "$pkg" >/dev/null 2>&1 || brew install "$pkg"
done

# 2. Python environment ----------------------------------------------------------
say "Installing AutoCut's Python packages"
PY="$(brew --prefix python@3.12)/bin/python3.12"
[ -d "$REPO/.venv" ] || "$PY" -m venv "$REPO/.venv"
"$REPO/.venv/bin/pip" install --upgrade pip -q
"$REPO/.venv/bin/pip" install -r "$REPO/requirements.txt" -q
xattr -dr com.apple.quarantine "$REPO" 2>/dev/null || true

# 3. Shared folder ----------------------------------------------------------------
mkdir -p "$(dirname "$LOCAL_SETTINGS")"
case "$ROLE" in
  main|solo)
    say "Setting up AutoCut's folder at $SHARED"
    mkdir -p "$SHARED/clients"
    chmod 777 "$SHARED" "$SHARED/clients" 2>/dev/null || true
    if [ "$ROLE" = main ]; then
      # The code is published here too, so the Mac Minis install + update from it.
      if [ ! -d "$SHARED/code.git" ]; then
        git -C "$REPO" rev-parse >/dev/null 2>&1 || { git -C "$REPO" init -q && git -C "$REPO" add -A && git -C "$REPO" commit -qm "AutoCut"; }
        git clone -q --bare "$REPO" "$SHARED/code.git"
        git -C "$REPO" remote remove origin 2>/dev/null || true
        git -C "$REPO" remote add origin "$SHARED/code.git"
        git -C "$REPO" fetch -q origin
        git -C "$REPO" branch -q -u origin/"$(git -C "$REPO" rev-parse --abbrev-ref HEAD)" 2>/dev/null || true
      else
        # Re-installing a newer AutoCut on the main Mac: publish it so the other Macs' "Update AutoCut" gets it.
        git -C "$REPO" remote remove origin 2>/dev/null || true
        git -C "$REPO" remote add origin "$SHARED/code.git"
        BR="$(git -C "$REPO" rev-parse --abbrev-ref HEAD)"
        if git -C "$REPO" push -q origin "HEAD:$BR"; then
          git -C "$REPO" fetch -q origin && git -C "$REPO" branch -q -u "origin/$BR" 2>/dev/null || true
          echo "  Published this version for the other Macs (they get it with This Mac → Update AutoCut)."
        else
          echo "  ! Couldn't publish this version to $SHARED/code.git automatically."
          echo "    The other Macs keep their current version until it's pushed (see README → Shipping a change)."
        fi
      fi
      cp "$REPO/mac/join.sh" "$SHARED/join.sh"
      cp "$REPO/mac/Install AutoCut on this Mac.command" "$SHARED/"
      chmod +x "$SHARED/join.sh" "$SHARED/Install AutoCut on this Mac.command"
      MS_SRC="$HOME/Desktop/Kinteic Graphics/motion-studio"
      if [ -d "$MS_SRC" ] && [ ! -d "$SHARED/motion-studio" ]; then
        if ask "Copy Kinetik Motion Studio into the shared folder so every Mac can use it?" no; then
          rsync -a --exclude node_modules "$MS_SRC/" "$SHARED/motion-studio/"
          (cd "$SHARED/motion-studio" && npm install --silent)
          echo "  Copied. Keep designing in $SHARED/motion-studio from now on."
        fi
      fi
      say "Sharing $SHARED on the office network (asks for your Mac password)"
      sudo sharing -a "$SHARED" -S AutoCut 2>/dev/null || echo "  (already shared)"
      echo "  ➜ Make sure File Sharing is ON: System Settings → General → Sharing → File Sharing."
      echo "  ➜ Other Macs connect with:  smb://$(scutil --get LocalHostName).local/AutoCut"
      if ask "Let phones, iPads and other computers in the office open the AutoCut dashboard in a web browser (to upload footage and check jobs)? Anyone on your office network will be able to open it." no; then
        set_local listen_on_network true
        echo "  ➜ Other devices open:  http://$(scutil --get LocalHostName).local:8765"
      fi
    fi
    ;;
  join)
    say "Linking the Mac Studio's shared folder"
    SRC="${AUTOCUT_SHARE_PATH:-/Volumes/AutoCut}"
    if [ -e "$SHARED" ] && [ ! -L "$SHARED" ]; then
      echo "$SHARED already exists as a real folder on this Mac. Rename it, then run this again."; exit 1
    fi
    # Same path on every Mac, so Premiere XML file links work everywhere.
    ln -sfn "$SRC" "$SHARED"
    [ -n "$SHARE_URL" ] && set_local share_url "\"$SHARE_URL\""
    if ask "Should this Mac also cut videos? (Choose No for a laptop that only uploads and opens finished rough cuts.)" yes; then
      set_local process_jobs true
    else
      set_local process_jobs false
    fi
    ;;
esac

if [ "$ROLE" != "join" ] && [ "$(uname -m)" = "arm64" ]; then
  if ask "Install AI image generation? (Makes clip art, illustrations and backgrounds on this Mac. Downloads several GB the first time it's used.)" no; then
    "$REPO/.venv/bin/pip" install -q mflux && echo "  AI images installed." || echo "  ! Couldn't install mflux — you can try later: $REPO/.venv/bin/pip install mflux"
  fi
fi

# The free AI brain (Ollama + a model sized to this Mac's memory) --------------------
MEM_GB=$(( $(sysctl -n hw.memsize 2>/dev/null || echo 17179869184) / 1073741824 ))
if [ "$MEM_GB" -ge 48 ]; then MODEL=gemma3:27b; SIZE=17
elif [ "$MEM_GB" -ge 20 ]; then MODEL=gemma3:12b; SIZE=8
else MODEL=gemma3:4b; SIZE=3; fi
if ask "Install the free AI brain? It runs on this Mac at no cost: picks clips, writes hooks, titles, captions and hashtags, and reads motion-graphic prompts. Downloads about $SIZE GB ($MODEL for this Mac's $MEM_GB GB of memory)." yes; then
  say "Installing the free AI brain ($MODEL)"
  brew list ollama >/dev/null 2>&1 || brew install ollama
  brew services start ollama >/dev/null 2>&1 || true
  for _ in 1 2 3 4 5 6 7 8 9 10; do curl -s http://127.0.0.1:11434/api/tags >/dev/null 2>&1 && break; sleep 2; done
  ollama pull "$MODEL" && echo "  AI brain ready." \
    || echo "  ! Couldn't download the AI model now. Later, in Terminal: ollama pull $MODEL"
fi

# HyperFrames: the motion graphics engine (HTML + GSAP rendered in headless Chrome, ~250 MB) ------
if ask "Install the HyperFrames motion graphics engine? It makes the cleanest, most professional motion graphics and lets the AI design custom ones. Downloads about 250 MB." yes; then
  say "Setting up HyperFrames"
  "$REPO/.venv/bin/python" -m autocut hyperframes-setup \
    || echo "  ! HyperFrames didn't set up. Later, in Terminal: ~/AutoCut/.venv/bin/python -m autocut hyperframes-setup"
fi

# 4. The app ------------------------------------------------------------------------
say "Building /Applications/AutoCut.app"
bash "$REPO/mac/build_app.sh"

if ask "Start AutoCut automatically when this Mac logs in?" no; then
  osascript -e 'tell application "System Events" to make login item at end with properties {path:"/Applications/AutoCut.app", hidden:true}' >/dev/null 2>&1 \
    && echo "  Added to Login Items." || echo "  Couldn't add automatically — add AutoCut in System Settings → General → Login Items."
fi

# 5. Check + download the speech model --------------------------------------------
say "Checking this Mac and downloading the speech model (one time, ~1.5 GB)"
cd "$REPO"
.venv/bin/python -m autocut doctor --download || true

say "Done. Opening AutoCut — look for ✂ in the menu bar."
open /Applications/AutoCut.app
