#!/bin/bash
# Builds /Applications/AutoCut.app — a thin launcher for the code in this repo.
# Re-run any time (install.sh and update.sh do it for you).
set -e
REPO="$(cd "$(dirname "$0")/.." && pwd)"
APP="${1:-/Applications/AutoCut.app}"
VERSION="$(cd "$REPO" && .venv/bin/python -c 'import autocut; print(autocut.__version__)' 2>/dev/null || echo 0.0.0)"

rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"

cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>AutoCut</string>
  <key>CFBundleDisplayName</key><string>AutoCut</string>
  <key>CFBundleIdentifier</key><string>com.triumphantmedia.autocut</string>
  <key>CFBundleVersion</key><string>$VERSION</string>
  <key>CFBundleShortVersionString</key><string>$VERSION</string>
  <key>CFBundleExecutable</key><string>AutoCut</string>
  <key>CFBundleIconFile</key><string>AutoCut</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>LSMinimumSystemVersion</key><string>12.0</string>
  <key>LSUIElement</key><true/>
  <key>NSHighResolutionCapable</key><true/>
</dict>
</plist>
PLIST

cat > "$APP/Contents/MacOS/AutoCut" <<LAUNCH
#!/bin/bash
# AutoCut launcher. The real code lives in: $REPO
REPO="$REPO"
export PATH="/opt/homebrew/bin:/usr/local/bin:\$PATH"
PY="\$REPO/.venv/bin/python"
cd "\$REPO" || exit 1
# Already running? Just bring up the dashboard.
"\$PY" -m autocut open && exit 0
mkdir -p "\$HOME/Library/Logs"
exec "\$PY" -m autocut app >>"\$HOME/Library/Logs/AutoCut.log" 2>&1
LAUNCH
chmod +x "$APP/Contents/MacOS/AutoCut"

# Icon: mac/icon.png → AutoCut.icns
ICONSET="$(mktemp -d)/AutoCut.iconset"
mkdir -p "$ICONSET"
for s in 16 32 128 256 512; do
  sips -z $s $s "$REPO/mac/icon.png" --out "$ICONSET/icon_${s}x${s}.png" >/dev/null
  sips -z $((s*2)) $((s*2)) "$REPO/mac/icon.png" --out "$ICONSET/icon_${s}x${s}@2x.png" >/dev/null
done
iconutil -c icns "$ICONSET" -o "$APP/Contents/Resources/AutoCut.icns"

xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true
touch "$APP"
echo "Built $APP"
