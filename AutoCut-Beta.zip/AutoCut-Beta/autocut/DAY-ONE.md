# Day one: getting AutoCut running in the office

Goal for the day: AutoCut is installed on your own computer and a real client video goes from raw footage to a
Premiere rough cut. Every person installs AutoCut on their own computer the same way; nothing is shared and no
computer is the server (docs/OWNER-GUIDE.md). The "office server" setup below is optional and old: skip it unless
you specifically want several Macs to share one queue.

## 1. Optional: an office queue server (≈30 min; most offices skip this)

1. Install [Homebrew](https://brew.sh) and Google Chrome if they're not already there.
2. Unzip AutoCut to your home folder, so you have `~/AutoCut`.
3. In Terminal run `bash ~/AutoCut/mac/install.sh --main`.
   - Answer **Y** to copying Motion Studio into the shared folder.
   - Answer **Y** to starting at login.
4. Turn on File Sharing: System Settings → General → Sharing → File Sharing.
5. Note the `smb://….local/AutoCut` address the installer printed.

## 2. Smoke test (≈5 min)

1. Click **✂** in the menu bar → **Open Dashboard**.
2. **This Mac:** check that everything is ✓. Motion Studio lines can be ! for now.
3. **Clients → Demo Roofing Co → Make caption sample.** It should play red pop captions.
   Then **Preview motion pack**. After a minute or two it plays every animated graphic in the demo brand.
4. **Short form edits:** pick Demo Roofing Co and drop a 60-second phone video of you talking,
   with a few deliberate "ums".
5. Watch it go from transcribing to done, then click **Preview**. The ums should be gone.
6. Media test: on Short form edits, drop a screenshot into **Media for these videos** and type a word
   you'll say ("inspection"). Drop a phone photo too, with no keyword. Then drop another short
   phone video below. In the preview, the screenshot floats in when you say the word, and the
   photo fills the screen somewhere else in the video.
7. Click **Edit transcript**, click one word to cut it and Option-click another to fix its spelling,
   then **Save & re-cut**. When it's done, check **Preview**.
8. Click **Show XML**. In Premiere, **File → Import** that XML and check the tracks
   (V1 cuts, V2 B-roll + full-screen media, V8 your floating media, V10 story cutaways, V11 captions; full list in README).

## 2b. Clip generator, Long form editor and Motion graphic generator (≈15 min)

1. **Clip generator:** drop a 10–20 minute podcast or stream recording (or a folder of them), then wait for "clips found".
   Click **Choose clips**, preview the top one, and **Make selected clips**. The clips appear in Short form edits.
2. **Long form editor:** drop the camera files and mic recordings from one short podcast together. When it says
   “edited”, click **Open**: check the preview, that each name has the right camera, then **Show XML**
   and import it into Premiere (one audio track per mic).
3. **Motion graphic generator:** type `lower third for 'Your Name' 'Your Title' square and vertical` and click **Generate**.
   Download the ProRes and drop it on a Premiere timeline. It should be transparent.

## 3. A Mac Mini (≈20 min)

1. Install Homebrew and Chrome.
2. In Finder: **Go → Connect to Server** → the `smb://` address. Tick **Remember password**.
3. In Terminal run `bash /Volumes/AutoCut/join.sh`.
4. Open its dashboard. You should see the same clients and jobs as the Mac Studio.
5. Drop two videos at once. One Mac takes each.

## 4. First real client (≈45 min)

1. **Clients → Add**, using the client's name.
2. **Open folder.** Put their fonts in `assets/fonts`, logo in `assets/logo/logo.png`,
   and B-roll in `assets/broll` (renamed descriptively).
3. Edit the brand kit in the dashboard: colours, font names, CTA, highlight words,
   vocabulary (their business name, towns, products). Then **Save**. Fix any ✗.
4. **Make caption sample** and show the team.
5. Drop a real video, then tune `max_pause`, caption size and B-roll frequency.
   **Re-run** is quick because the transcript is reused.

## Keep a list for round two

- **Cuts:** any too tight or too loose? Note the client and video.
- **B-roll:** picks that were wrong, and why.
- **Captions:** words the speech model misspells. Add them to that client's `vocabulary`.
- **Finishing work:** what editors always do by hand. These are the next things to automate.
  Open Claude Code in `~/AutoCut` and ask for them (see README → Changing the software).
