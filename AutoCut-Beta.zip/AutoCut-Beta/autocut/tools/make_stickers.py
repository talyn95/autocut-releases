"""Regenerates AutoCut's built-in sticker set (autocut/effects/stickers/*.png).
Run: .venv/bin/python tools/make_stickers.py  (needs Pillow)"""
import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

OUT = Path(__file__).resolve().parent.parent / "autocut" / "effects" / "stickers"
FONT = Path(__file__).resolve().parent.parent / "examples/demo-roofing-co/assets/fonts/Inter-ExtraBold.otf"
S = 512
W = (255, 255, 255, 255)


def badge(color):
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    shadow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(shadow).ellipse([46, 58, S - 34, S - 22], fill=(0, 0, 0, 110))
    img.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(14)))
    d = ImageDraw.Draw(img)
    d.ellipse([30, 30, S - 30, S - 30], fill=W)
    d.ellipse([52, 52, S - 52, S - 52], fill=color)
    return img, d


def glyph(d, text, size=290, dy=0):
    f = ImageFont.truetype(str(FONT), size)
    d.text((S / 2, S / 2 + dy), text, font=f, fill=W, anchor="mm")


def star_points(cx, cy, r1, r2, n=5):
    pts = []
    for i in range(n * 2):
        r = r1 if i % 2 == 0 else r2
        a = -math.pi / 2 + i * math.pi / n
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def make():
    OUT.mkdir(parents=True, exist_ok=True)
    green, red, gold, blue, pink, orange, purple = ((34, 177, 76, 255), (230, 57, 70, 255), (245, 176, 20, 255),
        (40, 120, 230, 255), (240, 80, 140, 255), (245, 120, 30, 255), (120, 80, 220, 255))
    img, d = badge(green); d.line([(150, 265), (225, 340), (365, 175)], fill=W, width=48, joint="curve"); img.save(OUT / "check.png")
    img, d = badge(red); d.line([(170, 170), (342, 342)], fill=W, width=48); d.line([(342, 170), (170, 342)], fill=W, width=48); img.save(OUT / "x.png")
    img, d = badge(gold); d.polygon(star_points(256, 266, 150, 62), fill=W); img.save(OUT / "star.png")
    img, d = badge(green); glyph(d, "$", 300, -8); img.save(OUT / "dollar.png")
    img, d = badge(blue); d.polygon([(256, 120), (380, 260), (300, 260), (300, 390), (212, 390), (212, 260), (132, 260)], fill=W); img.save(OUT / "arrow-up.png")
    img, d = badge(pink); d.ellipse([140, 160, 262, 282], fill=W); d.ellipse([250, 160, 372, 282], fill=W); d.polygon([(146, 240), (366, 240), (256, 380)], fill=W); img.save(OUT / "heart.png")
    img, d = badge(purple); d.ellipse([130, 130, 382, 382], outline=W, width=34); d.line([(256, 256), (256, 168)], fill=W, width=30); d.line([(256, 256), (320, 290)], fill=W, width=30); img.save(OUT / "clock.png")
    img, d = badge(orange); d.polygon([(256, 130), (390, 250), (360, 250), (360, 380), (152, 380), (152, 250), (122, 250)], fill=W); d.rectangle([226, 300, 286, 380], fill=orange); img.save(OUT / "house.png")
    img, d = badge(gold); d.ellipse([170, 120, 342, 292], fill=W); d.rectangle([212, 270, 300, 340], fill=W); d.rectangle([222, 350, 290, 380], fill=W); img.save(OUT / "lightbulb.png")
    img, d = badge(blue); glyph(d, "?", 320, -6); img.save(OUT / "question.png")
    img, d = badge(red); glyph(d, "!", 320, -6); img.save(OUT / "exclamation.png")
    img, d = badge(orange)
    d.ellipse([166, 222, 346, 402], fill=W)
    d.polygon([(170, 300), (230, 190), (256, 100), (300, 200), (342, 300)], fill=W)
    d.ellipse([214, 290, 298, 384], fill=orange)
    d.polygon([(218, 330), (256, 250), (294, 330)], fill=orange)
    img.save(OUT / "fire.png")


if __name__ == "__main__":
    make()
    print(f"Wrote {len(list(OUT.glob('*.png')))} stickers to {OUT}")
