#!/usr/bin/env python3
"""Keep a copy of AutoCut's update feed in a folder: on the office Synology, a second host, or a USB drive.

    python3 mirror_feed.py https://github.com/<you>/autocut-releases/releases/download/feed/feed.json /volume1/autocut/updates

Run it every hour (Synology: Control Panel → Task Scheduler → Create → Scheduled Task → User-defined script; DSM 7
has python3 built in). It downloads feed.json and its signature, refuses anything not signed with the agency's key,
downloads every file the feed lists (checking each SHA-256), then swaps the new feed in last, so the folder is always a
complete, signed copy. Files no longer listed are removed. Office computers add the folder (or its web address) as
"Office copy" on This Mac → Updates, and use it whenever the main address can't be reached.

Needs, in the same folder as this script: ed25519.py and release_key.pub (copy them from the AutoCut folder's
autocut/ folder). Standard library only; works on Python 3.8+.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import tempfile
import urllib.parse
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
for cand in (HERE, HERE.parent / "autocut"):
    if (cand / "ed25519.py").exists():
        sys.path.insert(0, str(cand))
        break
import ed25519  # noqa: E402


def keys() -> list:
    for cand in (HERE / "release_key.pub", HERE.parent / "autocut" / "release_key.pub"):
        if cand.exists():
            return [bytes.fromhex(k) for k in cand.read_text().split() if len(k) == 64]
    sys.exit("release_key.pub not found next to this script")


def get(url: str) -> bytes:
    if "://" not in url:
        return Path(url).read_bytes()
    req = urllib.request.Request(url, headers={"User-Agent": "AutoCut-mirror"})
    with urllib.request.urlopen(req, timeout=300) as r:
        return r.read()


def resolve(base: str, ref: str) -> str:
    if "://" in ref:
        return ref
    return urllib.parse.urljoin(base, ref) if "://" in base else str(Path(base).parent / ref)


def write(path: Path, data: bytes) -> None:
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=".part-")
    with os.fdopen(fd, "wb") as f:
        f.write(data)
    os.replace(tmp, path)


def main() -> int:
    if len(sys.argv) != 3:
        print(__doc__)
        return 2
    src, dest = sys.argv[1], Path(sys.argv[2])
    dest.mkdir(parents=True, exist_ok=True)
    body, sig = get(src), get(src + ".sig")
    if not any(ed25519.verify(k, body, bytes.fromhex(sig.decode().strip())) for k in keys()):
        print("The feed's signature doesn't match the release key: nothing copied.")
        return 1
    if (dest / "feed.json").exists() and (dest / "feed.json").read_bytes() == body:
        print("Already up to date.")
        return 0
    feed = json.loads(body)
    entries = list((feed.get("channels") or {}).values()) + list((feed.get("installers") or {}).values()) \
        + list(feed.get("packs") or [])
    if any("://" in e["url"] or "/" in e["url"] for e in entries):
        print("The feed points at other addresses; a mirror needs plain file names (tools/release.py makes them).")
        return 1
    wanted = set()
    for e in entries:
        name = Path(urllib.parse.urlparse(e["url"]).path).name
        wanted.add(name)
        target = dest / name
        if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest() == e["sha256"]:
            continue
        data = get(resolve(src, e["url"]))
        if hashlib.sha256(data).hexdigest() != e["sha256"]:
            print(f"{name} doesn't match the signed feed: stopping (the old copy stays as it was).")
            return 1
        write(target, data)
        print(f"  copied {name} ({len(data) / 2**20:.1f} MB)")
    write(dest / "feed.json.sig", sig)
    write(dest / "feed.json", body)
    for f in dest.iterdir():
        if f.is_file() and f.suffix == ".zip" and f.name not in wanted:
            f.unlink()
    chans = ", ".join("%s %s" % (k, v["version"]) for k, v in (feed.get("channels") or {}).items())
    print("Mirror updated: " + chans)
    return 0


if __name__ == "__main__":
    sys.exit(main())
