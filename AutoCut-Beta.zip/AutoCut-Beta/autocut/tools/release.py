"""Make a signed AutoCut release: the update zip, the installer zips, the content packs and the signed feed.

    python3 tools/release.py keygen                  once: make the agency's release key (keep the private half safe)
    python3 tools/release.py build [--channel beta]  zips + feed.json + feed.json.sig in dist/ (signs with the key)
    python3 tools/release.py verify dist             check a release folder the way AutoCut will
    python3 tools/release.py new-pack my-pack        start a content pack in packs/my-pack
    python3 tools/release.py publish-github --repo you/autocut-releases   upload dist/ as the "feed" release

Then upload everything in dist/ to the feed's address (docs/RELEASING.md). The private key is read from the
AUTOCUT_RELEASE_KEY environment variable (64 hex characters; a cloud session's environment secret is a good home)
or from --key FILE (default ~/.autocut/release.key). It is never stored in the repo.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO))

from autocut import __version__, ed25519, updates  # noqa: E402
from autocut.content import version_tuple  # noqa: E402

KEY_PUB = REPO / "autocut" / "release_key.pub"
DEFAULT_KEY = Path.home() / ".autocut" / "release.key"


def _seed(key_file: str | None) -> bytes:
    hexkey = os.environ.get("AUTOCUT_RELEASE_KEY", "").strip()
    if not hexkey:
        f = Path(key_file).expanduser() if key_file else DEFAULT_KEY
        if not f.exists():
            sys.exit(f"No release key: set AUTOCUT_RELEASE_KEY or pass --key (looked in {f}). "
                     "Make one with: python3 tools/release.py keygen")
        hexkey = f.read_text().strip()
    seed = bytes.fromhex(hexkey)
    pub = ed25519.public_key(seed).hex()
    shipped = KEY_PUB.read_text().split() if KEY_PUB.exists() else []
    if pub not in shipped:
        sys.exit("That key isn't one autocut/release_key.pub trusts, so AutoCut would reject the release.")
    return seed


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def cmd_keygen(args) -> None:
    out = Path(args.out).expanduser() if args.out else DEFAULT_KEY
    if out.exists() and not args.force:
        sys.exit(f"{out} already exists (use --force to replace it; releases signed with it would stop verifying "
                 "for anyone who hasn't updated)")
    seed, pub = ed25519.keygen()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(seed.hex() + "\n")
    os.chmod(out, 0o600)
    keys = KEY_PUB.read_text().split() if KEY_PUB.exists() else []
    KEY_PUB.write_text("\n".join([*keys, pub.hex()]) + "\n")
    print(f"Private key: {out}\n  Keep it safe and secret (a password manager, or a cloud environment secret named "
          f"AUTOCUT_RELEASE_KEY). Anyone with it can push code to every AutoCut.\nPublic key added to {KEY_PUB}: "
          f"{pub.hex()}\nCommit release_key.pub; computers trust it once they have a version that ships it.")


def _git_zip(out: Path) -> None:
    if subprocess.run(["git", "status", "--porcelain"], cwd=REPO, capture_output=True, text=True).stdout.strip():
        print("  ! the working tree has uncommitted changes; the release is made from the last commit (HEAD)")
    subprocess.run(["git", "archive", "--format=zip", "-o", str(out), "HEAD"], cwd=REPO, check=True)


def _installers(update_zip: Path, dist: Path, ver: str) -> dict:
    """AutoCut-Beta.zip (Mac) and AutoCut-Windows-Beta.zip: the code in AutoCut-Beta/autocut + the beta guides."""
    out = {}
    with tempfile.TemporaryDirectory() as tmp:
        top = Path(tmp) / "AutoCut-Beta"
        with zipfile.ZipFile(update_zip) as z:
            updates.extract(z, top / "autocut")  # keeps "Install AutoCut.command" executable
        for md in sorted((REPO / "beta").glob("*.md")):
            shutil.copy2(md, top / md.name)
        for name, drop in (("AutoCut-Beta.zip", "PASTE INTO CLAUDE (Windows).md"),
                           ("AutoCut-Windows-Beta.zip", "PASTE INTO CLAUDE.md")):
            target = dist / name
            with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as z:
                for f in sorted(top.rglob("*")):
                    rel = f.relative_to(Path(tmp))
                    if f.is_file() and f.name != drop:
                        z.write(f, str(rel).replace(os.sep, "/"))
            out["windows" if "Windows" in name else "mac"] = {"url": name, "sha256": _sha(target),
                                                               "size": target.stat().st_size}
        dmg = _dmg(top, dist / f"AutoCut-{ver}.dmg", ver)
        if dmg:
            out["mac_dmg"] = {"url": dmg.name, "sha256": _sha(dmg), "size": dmg.stat().st_size}
    return out


def _dmg(top: Path, out: Path, ver: str) -> Path | None:
    """The Mac download as a disk image: opens onto "Install AutoCut.command" (which copies AutoCut to ~/AutoCut) and
    the guides. hdiutil on a Mac; on Linux xorriso + the `dmg` tool from libdmg-hfsplus (Bitcoin Core's recipe;
    set AUTOCUT_DMG_TOOL to its path). Skipped with a note when neither is there."""
    with tempfile.TemporaryDirectory() as tmp:
        stage = Path(tmp) / "AutoCut"
        shutil.copytree(top / "autocut", stage, symlinks=True)
        for md in top.glob("*.md"):
            if "Windows" not in md.name:
                shutil.copy2(md, stage / md.name)
        out.unlink(missing_ok=True)
        if shutil.which("hdiutil"):
            subprocess.run(["hdiutil", "create", "-volname", f"AutoCut {ver}", "-srcfolder", str(stage), "-ov",
                            "-format", "UDZO", str(out)], check=True, capture_output=True)
            return out
        tool = os.environ.get("AUTOCUT_DMG_TOOL") or shutil.which("dmg")
        if shutil.which("xorriso") and tool:
            iso = Path(tmp) / "AutoCut.iso"
            subprocess.run(["xorriso", "-as", "mkisofs", "-D", "-l", "-V", f"AutoCut {ver}", "-no-pad", "-r",
                            "-dir-mode", "0755", "-o", str(iso), str(stage)], check=True, capture_output=True)
            subprocess.run([tool, str(iso), str(out)], check=True, capture_output=True)
            return out
    print("  (no .dmg: needs hdiutil on a Mac, or xorriso + AUTOCUT_DMG_TOOL on Linux; the Mac zip is still there)")
    return None


def _packs(src: Path, dist: Path) -> list[dict]:
    from autocut import content
    out = []
    for folder in sorted(src.glob("*/pack.json")):
        folder = folder.parent
        problems = content.check_pack(folder)
        if problems:
            sys.exit(f"Pack {folder.name} has problems:\n  " + "\n  ".join(problems))
        data = json.loads((folder / "pack.json").read_text(encoding="utf-8"))
        name = f"pack-{data['id']}-{data.get('version', '1.0')}.zip"
        with zipfile.ZipFile(dist / name, "w", zipfile.ZIP_DEFLATED) as z:
            for f in sorted(folder.rglob("*")):
                if f.is_file() and (f.name == "pack.json" or f.suffix == ".md"):
                    z.write(f, f"{data['id']}/{f.relative_to(folder).as_posix()}")
        out.append({"id": data["id"], "name": data.get("name", data["id"]), "version": str(data.get("version", "1.0")),
                    "description": data.get("description", ""), "min_app": data.get("min_app", ""),
                    "url": name, "sha256": _sha(dist / name), "size": (dist / name).stat().st_size})
    return out


def _notes(ver: str) -> list[str]:
    text = (REPO / "CHANGELOG.md").read_text(encoding="utf-8")
    m = re.search(rf"^## {re.escape(ver)}\s*\n(.*?)(?=^## |\Z)", text, re.S | re.M)
    if not m:
        sys.exit(f"CHANGELOG.md has no section for {ver}: write the release notes first")
    return [re.sub(r"\s+", " ", x).strip() for x in re.split(r"^- ", m.group(1), flags=re.M) if x.strip()]


def cmd_build(args) -> None:
    seed = _seed(args.key)
    dist = Path(args.out).resolve()
    dist.mkdir(parents=True, exist_ok=True)
    feed_file = dist / "feed.json"
    feed = json.loads(feed_file.read_text()) if feed_file.exists() else {}
    ver = subprocess.run(["git", "show", "HEAD:autocut/__init__.py"], cwd=REPO, capture_output=True, text=True).stdout
    ver = re.search(r'__version__\s*=\s*"([^"]+)"', ver).group(1)
    old = ((feed.get("channels") or {}).get(args.channel) or {}).get("version")
    if old and version_tuple(old) > version_tuple(ver):
        sys.exit(f"The {args.channel} channel already has {old}, newer than {ver}")
    upd = dist / f"AutoCut-update-{ver}.zip"
    print(f"Building AutoCut {ver} ({args.channel}) …")
    _git_zip(upd)
    print("  self-testing the release …")
    with tempfile.TemporaryDirectory() as tmp:
        with zipfile.ZipFile(upd) as z:
            z.extractall(tmp)
        env = dict(os.environ, PYTHONPATH=tmp, AUTOCUT_SELFTEST="1", PYTHONDONTWRITEBYTECODE="1")
        r = subprocess.run([sys.executable, "-X", "utf8", "-m", "autocut", "selftest"], cwd=tmp, env=env,
                           capture_output=True, text=True)
        if r.returncode:
            sys.exit("The release failed its self-test:\n" + r.stdout + r.stderr)
    channels = dict(feed.get("channels") or {})
    channels[args.channel] = {"version": ver, "url": upd.name, "sha256": _sha(upd), "size": upd.stat().st_size,
                              "date": dt.date.today().isoformat(), "notes": _notes(ver),
                              "min_version": args.min_version or ""}
    if args.channel == "stable" and version_tuple((channels.get("beta") or {}).get("version", "0")) < version_tuple(ver):
        channels["beta"] = channels["stable"]  # beta is never behind stable
    for k, v in list(channels.items()):
        if k != args.channel and v.get("url") == upd.name:
            channels[k] = channels[args.channel]  # the same version rebuilt: the other channel gets the new file's checksum
    feed = {"app": "autocut", "format": 1, "generated": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
            "channels": channels, "installers": _installers(upd, dist, ver) if not args.no_installers else
            feed.get("installers", {}),
            "packs": _packs(Path(args.packs), dist) if Path(args.packs).is_dir() else feed.get("packs", [])}
    body = json.dumps(feed, indent=1).encode()
    feed_file.write_bytes(body)
    (dist / "feed.json.sig").write_text(ed25519.sign(seed, body).hex() + "\n")
    print(f"  signed feed.json ({len(feed['packs'])} packs). Upload everything in {dist} to the feed address.")
    cmd_verify(argparse.Namespace(folder=str(dist), missing_ok=True))


def cmd_verify(args) -> None:
    d = Path(args.folder)
    body = (d / "feed.json").read_bytes()
    sig = bytes.fromhex((d / "feed.json.sig").read_text().strip())
    keys = [bytes.fromhex(k) for k in KEY_PUB.read_text().split()] if KEY_PUB.exists() else []
    if not any(ed25519.verify(k, body, sig) for k in keys):
        sys.exit("✗ feed.json's signature doesn't match release_key.pub")
    feed = json.loads(body)
    files = [c for c in feed["channels"].values()] + list(feed.get("installers", {}).values()) + feed.get("packs", [])
    kept = 0
    for f in files:
        p = d / f["url"]
        if not p.exists():
            if getattr(args, "missing_ok", False):  # made by an earlier release and already on the server
                kept += 1
                continue
            sys.exit(f"✗ {f['url']} is missing")
        if _sha(p) != f["sha256"]:
            sys.exit(f"✗ {f['url']} doesn't match its checksum")
    print(f"✓ signature good; {len(files) - kept} files match{f' ({kept} from earlier releases stay on the server)' if kept else ''}. Channels: "
          + ", ".join(f"{k} {v['version']}" for k, v in feed["channels"].items()))


def _gh_api(*args: str, ok_missing: bool = False):
    """GitHub's REST API through `gh api` (works in GitHub Actions, on a laptop and in cloud sessions, which have no
    GraphQL). Returns the parsed JSON, or None for a 404 when ok_missing."""
    gh = shutil.which("gh") or sys.exit("needs the GitHub CLI (gh), signed in")
    r = subprocess.run([gh, "api", *args], capture_output=True, text=True)
    if r.returncode:
        if ok_missing and "404" in (r.stdout + r.stderr):
            return None
        sys.exit(f"GitHub said no ({' '.join(args[:2])}): {(r.stdout + r.stderr).strip()[:400]}")
    return json.loads(r.stdout) if r.stdout.strip() else {}


def cmd_publish_github(args) -> None:
    """Upload dist/ to one release (tag "feed") of a public GitHub repo, so the feed address never changes:
    https://github.com/<repo>/releases/download/feed/feed.json. Files the feed no longer lists are removed.
    The repo needs at least one commit (a README) for the release's tag."""
    d = Path(args.dist)
    cmd_verify(argparse.Namespace(folder=str(d), missing_ok=True))
    repo = args.repo
    rel = _gh_api(f"repos/{repo}/releases/tags/feed", ok_missing=True)
    if rel is None:
        rel = _gh_api(f"repos/{repo}/releases", "-X", "POST", "-f", "tag_name=feed", "-f", "name=AutoCut updates",
                      "-f", "body=AutoCut's signed update feed and installers. AutoCut downloads from here by itself; "
                            "new computers: the .dmg (Mac) or AutoCut-Windows-Beta.zip (Windows).",
                      "-F", "make_latest=true")
    upload = rel["upload_url"].split("{")[0]
    feed = json.loads((d / "feed.json").read_bytes())
    files = [c["url"] for c in feed["channels"].values()] + [v["url"] for v in feed.get("installers", {}).values()] \
        + [p["url"] for p in feed.get("packs", [])]
    keep = set(files) | {"feed.json", "feed.json.sig"}

    def put(name: str) -> None:
        for a in _gh_api(f"repos/{repo}/releases/{rel['id']}/assets", "--paginate") or []:
            if a["name"] == name:
                _gh_api(f"repos/{repo}/releases/assets/{a['id']}", "-X", "DELETE")
        _gh_api(f"{upload}?name={name}", "-X", "POST", "-H", "Content-Type: application/octet-stream",
                "--input", str(d / name))
        print(f"  uploaded {name}")
    # the files first, the signed feed last, so nobody sees a feed whose files aren't there yet
    for f in sorted(set(files)):
        if (d / f).exists():
            put(f)
    put("feed.json")
    put("feed.json.sig")
    for a in _gh_api(f"repos/{repo}/releases/{rel['id']}/assets", "--paginate") or []:
        if a["name"] not in keep:
            _gh_api(f"repos/{repo}/releases/assets/{a['id']}", "-X", "DELETE")
            print(f"  removed {a['name']}")
    print(f"Published. Feed address: https://github.com/{repo}/releases/download/feed/feed.json")


def cmd_publish_git(args) -> None:
    """Publish dist/ by committing it into a clone of the public releases repo (served from
    https://raw.githubusercontent.com/<repo>/main/feed.json). For places that can push code but not create GitHub
    Releases (Claude Code cloud sessions). The signature, not the host, is what computers trust. Only the files the
    feed lists are kept; README.md gets fresh download links."""
    d, repo_dir = Path(args.dist), Path(args.repo_dir)
    cmd_verify(argparse.Namespace(folder=str(d), missing_ok=True))
    if not (repo_dir / ".git").exists():
        sys.exit(f"{repo_dir} isn't a clone of the releases repo")
    feed = json.loads((d / "feed.json").read_bytes())
    inst = feed.get("installers", {})
    files = [c["url"] for c in feed["channels"].values()] + [v["url"] for v in inst.values()] \
        + [p["url"] for p in feed.get("packs", [])]
    keep = set(files) | {"feed.json", "feed.json.sig", "README.md", ".gitattributes"}
    for f in repo_dir.iterdir():
        if f.is_file() and f.name not in keep:
            f.unlink()
    for f in sorted(set(files)) + ["feed.json", "feed.json.sig"]:  # the signed feed last
        shutil.copy2(d / f, repo_dir / f)
    stable = feed["channels"].get("stable") or next(iter(feed["channels"].values()))
    links = [f"- **Mac:** [{inst['mac_dmg']['url']}]({inst['mac_dmg']['url']}?raw=1) (open it, right-click "
             "**Install AutoCut** → Open)"] if "mac_dmg" in inst else []
    links += [f"- **Mac (zip):** [{inst['mac']['url']}]({inst['mac']['url']}?raw=1)"] if "mac" in inst else []
    links += [f"- **Windows:** [{inst['windows']['url']}]({inst['windows']['url']}?raw=1) (right-click → Extract All, "
              "then **Install AutoCut (Windows).cmd**)"] if "windows" in inst else []
    (repo_dir / "README.md").write_text(f"""# AutoCut releases

Signed AutoCut updates and installers. AutoCut checks this feed by itself and installs updates with one click
(This Mac → Updates); there's nothing to do here by hand.

**Current version: {stable['version']}** ({stable.get('date', '')})

New computer? Download the installer:

{chr(10).join(links)}

Every update is signed with Triumphant Media's release key and tested on each computer before it's installed.
""")
    git = ["git", "-C", str(repo_dir)]
    subprocess.run([*git, "add", "-A"], check=True)
    if not subprocess.run([*git, "status", "--porcelain"], capture_output=True, text=True).stdout.strip():
        print("Nothing changed: already published.")
        return
    msg = f"AutoCut {stable['version']}" + (f"\n\n{args.footer}" if args.footer else "")
    subprocess.run([*git, "commit", "-q", "-m", msg], check=True)
    if not args.no_push:
        subprocess.run([*git, "push", "-q", "origin", "HEAD"], check=True)
    print(f"Published {stable['version']}. Feed address: {args.feed_url or '(raw URL of feed.json in that repo)'}")


def cmd_new_pack(args) -> None:
    pid = args.id
    if not re.fullmatch(r"[a-z0-9][a-z0-9_-]{1,40}", pid):
        sys.exit("pack ids are lowercase letters, digits and dashes")
    d = REPO / "packs" / pid
    if d.exists():
        sys.exit(f"{d} already exists")
    (d / "knowledge").mkdir(parents=True)
    (d / "pack.json").write_text(json.dumps({
        "id": pid, "name": pid.replace("-", " ").title(), "version": "1.0.0", "author": "Triumphant Media",
        "description": "What this pack adds.", "min_app": __version__,
        "looks": {}, "storyboards": {}, "music_styles": {}, "style_fits": {}, "sfx_flavours": {}, "look_flavour": {}},
        indent=2) + "\n")
    print(f"Started {d}/pack.json. See docs/EXTENDING.md; check it with: python3 -m autocut pack check {d}")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    k = sub.add_parser("keygen")
    k.add_argument("--out")
    k.add_argument("--force", action="store_true")
    b = sub.add_parser("build")
    b.add_argument("--channel", choices=["stable", "beta"], default="stable")
    b.add_argument("--out", default=str(REPO / "dist"))
    b.add_argument("--key")
    b.add_argument("--packs", default=str(REPO / "packs"), help="folder of content packs to publish")
    b.add_argument("--min-version", help="oldest version that can update straight to this one")
    b.add_argument("--no-installers", action="store_true")
    v = sub.add_parser("verify")
    v.add_argument("folder")
    n = sub.add_parser("new-pack")
    n.add_argument("id")
    g = sub.add_parser("publish-github")
    g.add_argument("--repo", required=True, help="owner/name of the public releases repo")
    g.add_argument("--dist", default=str(REPO / "dist"))
    q = sub.add_parser("publish-git")
    q.add_argument("--repo-dir", required=True, help="a clone of the public releases repo")
    q.add_argument("--dist", default=str(REPO / "dist"))
    q.add_argument("--footer", default="", help="extra lines for the commit message")
    q.add_argument("--feed-url", default="")
    q.add_argument("--no-push", action="store_true")
    args = p.parse_args()
    {"keygen": cmd_keygen, "build": cmd_build, "verify": cmd_verify, "new-pack": cmd_new_pack,
     "publish-github": cmd_publish_github, "publish-git": cmd_publish_git}[args.cmd](args)


if __name__ == "__main__":
    main()
