#!/bin/bash
# Run AutoCut from anywhere: ./autocut.sh run video.mp4 --client acme-roofing
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHONPATH="$DIR" exec "$DIR/.venv/bin/python" -m autocut "$@"
